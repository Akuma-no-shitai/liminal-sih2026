// The page's side of the crowd host (pipe/host.js). It starts a Web Worker: from the bundled source the single file
// carries (opts.workerSrc, through a Blob), or as a module worker from pipe/worker.js on the dev page. If no worker
// starts within a few seconds, or one fails, the same host runs on the main thread in short timed slices (not tied to
// the frame rate), and whatever was asked of the worker is asked again.
import { createHost } from './pipe/host.js';

export function createCrowdClient({ workerSrc = null, workerUrl = null, onEvent = () => {} } = {}) {
  let worker = null, host = null, mode = 'starting', blobUrl = null, timer = 0, urgent = false;
  const queue = [];            // sent before the worker answered
  let lastInit = null, lastBg = null, lastSbx = null, bgDone = false;
  const deliver = (m) => {
    if (m.type === 'pong') { if (mode === 'starting') { mode = 'worker'; clearTimeout(timer); for (const q of queue.splice(0)) worker.postMessage(q); } return; }
    if (m.type === 'done') bgDone = true;
    if (m.type === 'sbxDone' || (m.type === 'error' && m.where === 'sandbox')) lastSbx = null;
    onEvent(m);
  };
  function fallback(why) {
    if (mode === 'main') return;
    if (worker) { try { worker.terminate(); } catch (e) { /* ignore */ } worker = null; }
    if (blobUrl) { URL.revokeObjectURL(blobUrl); blobUrl = null; }
    clearTimeout(timer); mode = 'main'; console.warn('[act2] crowd worker unavailable, computing on the page:', why);
    // a slice is about a third of the time since the last one ended (so a page drawing slowly still leaves the crowd a
    // fair share of the thread), more while the film waits for it or a sandbox run is going
    let lastEnd = performance.now();
    const budget = () => { const gap = performance.now() - lastEnd; return Math.max(12, Math.min(urgent ? 600 : 250, gap * (urgent ? 1.5 : .5))); };
    host = createHost((m) => deliver(m), { budget, tick: (f) => setTimeout(() => { f(); lastEnd = performance.now(); }, 4) });
    queue.length = 0;
    // ask again for whatever was in flight
    if (lastInit) host.onMessage(lastInit); if (lastBg && !bgDone) host.onMessage(lastBg); if (lastSbx) host.onMessage(lastSbx);
  }
  try {
    if (typeof Worker === 'undefined') throw new Error('no Worker');
    if (workerSrc) { blobUrl = URL.createObjectURL(new Blob([workerSrc], { type: 'text/javascript' })); worker = new Worker(blobUrl); }
    else if (workerUrl) worker = new Worker(workerUrl, { type: 'module' });
    else throw new Error('no worker source');
    worker.onmessage = (e) => deliver(e.data);
    worker.onerror = (e) => { e.preventDefault && e.preventDefault(); fallback(e.message || 'worker error'); };
    worker.onmessageerror = () => fallback('message error');
    worker.postMessage({ type: 'ping' });
    timer = setTimeout(() => { if (mode === 'starting') fallback('no answer from the worker'); }, 4000);
  } catch (e) { fallback(e.message); }
  const send = (m) => { if (mode === 'worker') worker.postMessage(m); else if (mode === 'main') host.onMessage(m); else queue.push(m); };
  return {
    get mode() { return mode; },
    init(m) { lastInit = { type: 'init', ...m }; lastBg = null; bgDone = false; send(lastInit); },
    background(token) { lastBg = { type: 'background', token }; bgDone = false; send(lastBg); },
    sandbox(m) { lastSbx = { type: 'sandbox', ...m }; send(lastSbx); },
    stopSandbox() { lastSbx = null; send({ type: 'stopSandbox' }); },
    // (the page computes: the film is waiting, or a sandbox run is going; a bigger share of the thread)
    setUrgent(u) { urgent = !!u; },
    dispose() { clearTimeout(timer); if (worker) worker.terminate(); if (blobUrl) URL.revokeObjectURL(blobUrl); worker = null; host = null; },
  };
}
