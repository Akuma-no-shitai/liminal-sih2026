// Act 2's concept cards (the right column, newest on top; Act 7's card machinery and styles): a small live chart or a
// few rows drawn from the case at the current moment of the film, a stat line, one plain sentence and the lab links.
import { getTheme, rgba } from '../../../act7/js/theme.js';
const FONTS = { mono: '"Geist Mono", ui-monospace, monospace', sans: 'Geist, ui-sans-serif, system-ui, sans-serif' };
let TH = getTheme('dusk'), C;
function chartPal(T) { const d = T.data, ch = T.chart; return { teal: d.swarm, safe: d.safe, heat: d.caution, danger: d.noentry, haze: d.unseen, apr: d.mid, lav: d.empty, rose: d.added, paper: ch.paper, faint: ch.faint, grid: ch.grid, well: ch.well, bar: ch.bar, band: ch.band, dash: ch.dash, ...FONTS }; }
C = chartPal(TH);
const FLOOR = ['Ground', 'First', 'Second', 'Third'];
const pct = (v) => `${Math.round(v * 100)}\u00a0%`;
const mm = (s) => `${String(Math.floor(s / 60)).padStart(2, '0')}:${String(Math.floor(s % 60)).padStart(2, '0')}`;
const sec = (v) => (v == null || !Number.isFinite(v) ? '—' : `${Math.round(v)} s`);
export const CARD = {
  survey: { name: 'The survey', tag: 'frontier exploration', line: 'Each drone flies to the nearest unexplored edge of the shared map. β₀ counts the separate unexplored regions left; at zero the baseline is complete.', labs: [['lab-topology', 'β₀ in the lab'], ['lab-crdt', 'One shared map in the lab']] },
  base: { name: 'The baseline', tag: 'what Act 7 compares against', line: 'Measured, not drawn: widths come off the point cloud, the voxel map is the free and occupied space.', html: true },
  graph: { name: 'Access graph', tag: 'β₁ loops, weak links', line: 'β₁ is the number of independent loops, each an alternative route. Where β₁ is 0, one blockage cuts a part off: those links are bridges.', html: true, labs: [['lab-topology', 'Loops in the lab']] },
  crowd: { name: 'Crowd model', tag: 'Helbing, Farkas & Vicsek 2000', line: 'Published social-force parameters with simulated occupancy: a model, not a prediction for a real building.', labs: [['assumptions', 'Assumptions'], ['lab-vicsek', 'Vicsek in the lab']] },
  fis: { name: 'Faster is slower', tag: '80 people, desired speed raised', line: 'The same people and building; only the desired speed changes. Each dot is the mean of runs that differ only in small random pushes, the whisker their range.' },
  perc: { name: 'Percolation margin', tag: 'random blockages', line: 'How many random blockages it takes before someone has no route to an exit, over many trials.' },
  fix: { name: 'Change one thing', tag: 'computed again', line: 'Each fix re-runs the crowd (the same people, three runs) and the access graph. Muted: inside the spread between runs.', html: true },
};
export function createCards(el, { onLab = () => {}, phone = false, theme = null } = {}) {
  TH = theme || getTheme('dusk'); C = chartPal(TH);
  const live = new Map(), order = []; let Cs = null;
  const cap = () => (phone ? 4 : (el.clientHeight || innerHeight) < 600 || innerHeight < 800 ? 2 : 3);
  function add(id) {
    const def = CARD[id]; if (!def || live.has(id)) return;
    const node = document.createElement('article'); node.className = 'a7card enter'; node.dataset.card = id; node.setAttribute('aria-label', def.name);
    const labs = def.labs || [];
    node.innerHTML = `<header><i></i><h4>${def.name}</h4><span class="tag">${def.tag}</span></header>${def.html ? '<div class="q4"></div>' : '<canvas></canvas>'}<div class="st"><span class="a"></span><span class="b"></span></div><p>${def.line}</p>${labs.length ? `<div class="labs">${labs.map(([l, t]) => `<button class="lab${l === 'assumptions' ? ' as' : ''}" type="button" data-lab="${l}">${t}</button>`).join('')}</div>` : ''}`;
    node.querySelectorAll('[data-lab]').forEach((b) => b.addEventListener('click', () => onLab(b.dataset.lab)));
    el.insertBefore(node, el.firstChild);
    const cv = node.querySelector('canvas'); live.set(id, { node, cv, ctx: cv && cv.getContext('2d'), q4: node.querySelector('.q4'), sa: node.querySelector('.st .a'), sb: node.querySelector('.st .b'), w: 0, h: 0 }); order.unshift(id);
    requestAnimationFrame(() => node.classList.remove('enter'));
    if (phone) requestAnimationFrame(() => { if (el.scrollLeft > 0) el.scrollLeft = 0; });
    while (order.length > cap()) remove(order[order.length - 1]);
  }
  function remove(id, now = false) { const o = live.get(id); if (!o) return; live.delete(id); const i = order.indexOf(id); if (i >= 0) order.splice(i, 1); if (now) { o.node.remove(); return; } o.node.classList.add('leave'); setTimeout(() => o.node.remove(), 460); }
  function show(ids) { const want = ids.slice(-cap()); for (const c of [...live.keys()]) if (!want.includes(c)) remove(c); for (const c of want) if (!live.has(c)) add(c); }
  let last = 0;
  function update(st, force = false) {
    if (!Cs) return; const now = performance.now(); if (!force && now - last < 80) return; last = now;
    for (const [id, o] of live) {
      try {
        if (o.q4) { const s = DRAW[id](null, 0, 0, Cs, st) || ['', '', '']; if (o.q4.innerHTML !== s[2]) o.q4.innerHTML = s[2]; if (o.sa.innerHTML !== s[0]) o.sa.innerHTML = s[0]; if (o.sb.innerHTML !== s[1]) o.sb.innerHTML = s[1]; continue; }
        const r = o.cv.getBoundingClientRect(); const dpr = Math.min(2, window.devicePixelRatio || 1); if (r.width < 4) continue;
        if (Math.abs(r.width - o.w) > .5 || Math.abs(r.height - o.h) > .5) { o.w = r.width; o.h = r.height; o.cv.width = Math.round(r.width * dpr); o.cv.height = Math.round(r.height * dpr); }
        const x = o.ctx; x.setTransform(dpr, 0, 0, dpr, 0, 0); x.clearRect(0, 0, o.w, o.h);
        const s = DRAW[id](x, o.w, o.h, Cs, st) || ['', '']; if (o.sa.innerHTML !== s[0]) o.sa.innerHTML = s[0]; if (o.sb.innerHTML !== s[1]) o.sb.innerHTML = s[1];
      } catch (e) { console.warn('[act2] card', id, e); }
    }
  }
  return { show, update, setCase(c) { Cs = c; for (const k of [...live.keys()]) remove(k, true); }, refresh() { last = 0; }, clear() { for (const k of [...live.keys()]) remove(k, true); }, get active() { return [...order]; } };
}
const label = (x, s, X, Y, col = C.faint, align = 'left', size = 10.5, font = C.sans) => { x.font = `${size}px ${font}`; x.fillStyle = col; x.textAlign = align; x.textBaseline = 'alphabetic'; x.fillText(s, X, Y); };
const rows = (list) => list.map(([n, v, l, cls]) => `<div class="r${cls ? ' ' + cls : ''}"><span class="n">${n}</span><b>${v}</b>${l ? `<small>${l}</small>` : ''}</div>`).join('');
// an evacuation curve: people out against time (one or two runs), with a playhead
function curve(x, w, h, runs, tNow, tMax) {
  const X0 = 26, Y0 = 8, W = w - 34, H = h - 24, n = Math.max(...runs.map((r) => r.n));
  x.strokeStyle = C.grid; x.lineWidth = 1; x.beginPath(); x.moveTo(X0, Y0 + H); x.lineTo(X0 + W, Y0 + H); x.moveTo(X0, Y0); x.lineTo(X0, Y0 + H); x.stroke();
  const px = (t) => X0 + Math.min(1, t / tMax) * W, py = (k) => Y0 + H - k / n * H;
  for (const r of runs) { x.beginPath(); x.moveTo(px(0), py(0)); let k = 0; for (const t of r.times) { if (t > (r.upto ?? 1e9)) break; x.lineTo(px(t), py(k)); k++; x.lineTo(px(t), py(k)); } if ((r.upto ?? 1e9) < 1e8) x.lineTo(px(Math.min(r.upto, tMax)), py(k)); x.strokeStyle = r.col; x.lineWidth = r.lw || 1.6; x.setLineDash(r.dash ? [3, 3] : []); x.stroke(); x.setLineDash([]); }
  if (tNow != null) { x.strokeStyle = C.dash; x.beginPath(); x.moveTo(px(tNow), Y0); x.lineTo(px(tNow), Y0 + H); x.stroke(); }
  label(x, String(n), X0 - 4, Y0 + 8, C.faint, 'right', 10, C.mono); label(x, '0', X0 - 4, Y0 + H, C.faint, 'right', 10, C.mono); label(x, `${Math.round(tMax)} s`, X0 + W, h - 3, C.faint, 'right', 10, C.mono); label(x, 'people out', X0 + 4, Y0 + 9, C.faint, 'left', 10);
}
const DRAW = {
  survey(x, w, h, Cs, st) {
    const tl = Cs.survey.timeline, T = Cs.survey.stats.flightS, t = Math.min(T, st.surveyT ?? T), X0 = 8, W = w - 16, Y0 = 8, H = h - 22, b0m = Math.max(4, ...tl.map((q) => q.b0));
    const px = (v) => X0 + v / T * W;
    x.fillStyle = C.band; x.fillRect(X0, Y0, W, H);
    x.beginPath(); x.moveTo(px(0), Y0 + H); for (const q of tl) { if (q.t > t) break; x.lineTo(px(q.t), Y0 + H - q.cov * H); } x.lineTo(px(t), Y0 + H); x.closePath(); x.fillStyle = rgba(C.teal, .22); x.fill();
    x.beginPath(); let first = true; for (const q of tl) { if (q.t > t) break; const yy = Y0 + H - q.b0 / b0m * H * .9; first ? x.moveTo(px(q.t), yy) : x.lineTo(px(q.t), yy); first = false; } x.strokeStyle = C.lav; x.lineWidth = 1.6; x.stroke();
    label(x, 'coverage', X0 + 3, Y0 + 10, C.teal, 'left', 10); label(x, 'β₀', X0 + 58, Y0 + 10, C.lav, 'left', 10.5); label(x, `${Math.round(T / 60)} min`, X0 + W, h - 3, C.faint, 'right', 10, C.mono);
    let q = tl[0]; for (const r of tl) { if (r.t <= t) q = r; else break; }
    const done = t >= T - 1;
    const mb = q.pts * 16 / 1e6;
    return [`<b>${pct(done ? Cs.survey.stats.coverage : q.cov)}</b> seen, β₀ <b>${done ? 0 : q.b0}</b>`, `<b>${mm(t)}</b> flown, <b>${mb.toFixed(1)} MB</b>`];
  },
  base(x, w, h, Cs) {
    const B = Cs.base, em = B.doors.filter((d) => d.measured != null).map((d) => Math.abs(d.err)).sort((a, b) => a - b), med = em.length ? em[em.length >> 1] : 0, rear = B.doors.find((d) => d.kind === 'rear');
    const html = rows([
      ['Rooms mapped', `${B.roomsMapped} of ${Cs.model.rooms.length}`, 'open space at hand height in the voxel map'],
      ['Doors measured', `${B.measured}`, `width off the cloud, typically within ${Math.max(1, Math.round(med * 100))} cm of the plan`],
      ...(B.gap != null ? [['Lobby, clear width', `${B.gap.toFixed(2)} m`, `between ${Cs.clutter.length} parked scooters`]] : []),
      ['Stair', '3 flights', 'one stair, 1.3 m lanes, half-landings'],
      ['Exits', rear && rear.closed ? 'street door; rear shut' : 'street door, rear door', 'the rear door opens under the stair landing'],
    ]);
    const S = Cs.survey.stats; return [`<b>${(S.points / 1e3).toFixed(0)}k</b> points, <b>${S.mb.toFixed(1)} MB</b>`, `<b>${pct(S.surfaces)}</b> of surfaces`, html];
  },
  graph(x, w, h, Cs, st) {
    const g = st.graph || { betti: Cs.betti, perc: Cs.percSummary, dead: Cs.deadEnds.length }, b = g.betti;
    const html = rows([
      ['β₁ per floor', b.floors.map((v, i) => `${v}`).join('  '), 'ground, first, second, third floor: independent loops'],
      ['Bridges', `${g.perc.bridges} of ${g.perc.links}`, 'links whose loss splits the graph'],
      ['Weak links', `${g.perc.weakN}`, 'bridges with someone behind them at night'],
      ['Dead ends', `${Cs.deadEnds.length} hall ends`, 'past the last door of each flat’s hall'],
    ]);
    return [`β₁ <b>${b.b1}</b> in all`, `${g.perc.links} links`, html];
  },
  crowd(x, w, h, Cs, st) {
    const run = st.run || 'night', an = run === 'night' ? Cs.night.calm : run === 'fullLast' && Cs.full ? Cs.full.sweep.find((s) => s.v0 === Cs.full.fis.last).an : run === 'sandbox' ? st.sbAn : Cs.night.calm;
    if (!an) { label(x, 'computing…', w / 2, h / 2, C.faint, 'center'); return ['', '']; }
    const tMax = Math.max(30, (an.tEnd || 60) + 2), runs = [{ times: an.times, n: an.n, col: run === 'night' ? C.teal : C.heat, upto: st.crowdT }];
    if (run === 'fullLast' && Cs.full) { const b = Cs.full.sweep.find((s) => s.v0 === Cs.full.fis.best).an; runs.unshift({ times: b.times, n: b.n, col: C.teal, dash: true, upto: st.crowdT }); }
    curve(x, w, h, runs, st.crowdT, tMax);
    const out = an.times.filter((t) => t <= (st.crowdT ?? 1e9)).length;
    return [`out <b>${out} of ${an.n}</b>${an.total != null && (st.crowdT ?? 1e9) >= an.total ? ` in <b>${sec(an.total)}</b>` : ''}`, `peak <b>${an.peak.toFixed(1)}</b>/m²`];
  },
  fis(x, w, h, Cs) {
    if (!Cs.full) { label(x, 'computing the full-house runs…', w / 2, h / 2, C.faint, 'center'); return ['', '']; }
    // each speed: the mean of its runs (they differ only in the random pushes) and their range as a whisker; a speed
    // where a run clogged is drawn at the moment the run was stopped, marked '>'
    const sw = Cs.full.sweep, f = Cs.full.fis, X0 = 30, Y0 = 18, W = w - 44, H = h - 34, v0m = 5.2;
    const fin = (s) => s.rep.T.filter(Number.isFinite), tOf = (s) => (Number.isFinite(s.rep.mean) ? s.rep.mean : Math.max(s.rep.stop || s.an.tEnd || 0, ...fin(s)));
    const Tm = Math.max(...sw.map((s) => Math.max(tOf(s), ...fin(s)))) * 1.08;
    const px = (v) => X0 + (v - 1) / (v0m - 1) * W, py = (t) => Y0 + H - t / Tm * H;
    x.strokeStyle = C.grid; x.beginPath(); x.moveTo(X0, Y0 + H); x.lineTo(X0 + W, Y0 + H); x.moveTo(X0, Y0); x.lineTo(X0, Y0 + H); x.stroke();
    x.beginPath(); sw.forEach((s, i) => { const t = tOf(s); i ? x.lineTo(px(s.v0), py(t)) : x.moveTo(px(s.v0), py(t)); }); x.strokeStyle = rgba(C.paper, .5); x.lineWidth = 1.2; x.stroke();
    for (const s of sw) { const t = tOf(s), clog = !Number.isFinite(s.rep.mean), c = s.v0 === f.best ? C.teal : s.v0 === f.last && f.emerges ? C.heat : C.paper;
      const ft = fin(s); if (ft.length > 1) { x.strokeStyle = rgba(c, .55); x.lineWidth = 1; x.beginPath(); x.moveTo(px(s.v0), py(Math.min(...ft))); x.lineTo(px(s.v0), py(Math.max(...ft))); x.stroke(); }
      x.fillStyle = c; x.beginPath(); x.arc(px(s.v0), py(t), s.v0 === f.best || s.v0 === f.last ? 3.6 : 2.6, 0, 7); x.fill(); if (clog) label(x, '>', px(s.v0) + 5, py(t) + 3, c, 'left', 10, C.mono); label(x, `${s.v0}`, px(s.v0), h - 3, C.faint, 'center', 10, C.mono); }
    label(x, 'm/s', X0 + W + 10, h - 3, C.faint, 'right', 9.5); label(x, 'time to get everyone out, against desired speed', X0, 11, C.faint, 'left', 10);
    const lastTxt = Number.isFinite(f.lastT) ? sec(f.lastT) : 'clogged';
    return [`best <b>${f.best} m/s</b>, ${sec(f.bestT)}`, f.emerges ? `${f.last} m/s: <b style="color:var(--heat-txt)">${lastTxt}</b>` : `${f.last} m/s: <b>${lastTxt}</b>`];
  },
  perc(x, w, h, Cs, st) {
    const P = st.perc || Cs.percSummary, hist = P.hist, X0 = 8, W = w - 16, Y0 = 8, H = h - 22, mx = Math.max(...hist, 1), n = hist.length - 1;
    for (let k = 1; k <= n; k++) { const bw = W / n, bh = hist[k] / mx * H; x.fillStyle = k === P.median ? C.heat : rgba(C.paper, .35); x.fillRect(X0 + (k - 1) * bw + 1, Y0 + H - bh, bw - 2, bh); if (k <= 6 || k === n) label(x, k === n ? `${n}+` : String(k), X0 + (k - .5) * bw, h - 3, C.faint, 'center', 10, C.mono); }
    label(x, 'blockages until someone is cut off', X0 + W, Y0 + 9, C.faint, 'right', 10);
    return [`median <b>${P.median}</b>; one cuts in <b>${pct(P.p1)}</b>`, P.worst ? `worst link: <b>${P.worst.people}</b>\u00a0people` : "no single link"];
  },
  fix(x, w, h, Cs, st) {
    if (!Cs.fixes) return ['', '', rows([['Computing the fixes…', '', '']])];
    // full-house times are means of several runs; a change that stays inside the spread between runs is shown muted
    const F = Cs.fixes, base = Cs.full.calmRep.mean, cur = st.fix;
    const tt = (v) => (v === Infinity ? 'clog' : sec(v)), ch = (a, b) => (a == null || b == null ? '—' : `${tt(a)} → ${tt(b)}`);
    const note = (f) => (f.cmp.real ? '' : 'within the spread between runs; ');
    const list = [
      ['clear', 'Move the scooters', ch(base, F.clear.rep.mean), F.clear, Cs.clutter && Cs.clutter.length ? `${note(F.clear)}peak at ${(Cs.full.calm.bottlenecks[0] || {}).kind === 'lobby' ? 'the gap' : 'the busiest spot'} ${Cs.rhoHot != null ? Cs.rhoHot.toFixed(1) : '—'} → ${F.clear.rhoHot != null ? F.clear.rhoHot.toFixed(1) : '—'} people/m²; at night ${ch(Cs.night.calm.total, F.clear.night.total)}` : 'nothing parked here'],
      ['rear', 'Rear door unlocked', ch(base, F.rear.rep.mean), F.rear, `${note(F.rear)}β₁ ${Cs.betti.b1} → ${F.rear.graph.betti.b1}; worst link ${Cs.percSummary.worst ? Cs.percSummary.worst.people : 0} → ${F.rear.graph.perc.worst ? F.rear.graph.perc.worst.people : 0} people`],
      ['widen', `Door to ${Cs.widen.to.toFixed(1)} m`, ch(base, F.widen.rep.mean), F.widen, `${note(F.widen)}${Cs.widen.label}`],
    ];
    return [`as surveyed <b>${tt(base)}</b>`, `80 people, mean of ${Cs.full.calmRep.n} runs`, list.map(([id, n, v, f, l]) => `<div class="r${id === cur ? ' on' : ''}${f.cmp.real ? '' : ' nr'}"><span class="n">${n}</span><b>${v}</b><small>${l}</small></div>`).join('')];
  },
};
