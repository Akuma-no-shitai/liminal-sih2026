// The sandbox: block doors, corridor segments and stair flights (tap their markers in the view), change the crowd
// (people per flat, desired speed, the bottleneck door's width), toggle the rear door and the scooters, and run the
// evacuation live. β₁ and the percolation margin update at once. The crowd is computed by the crowd host (a Web Worker,
// or timed slices on the page if no worker can start), which streams the run back frame by frame; the view plays it at
// four times real time by the clock (not by the frame rate), and its people-out curve is drawn against the last run.
import * as THREE from 'three';
import { getTheme, rgba } from '../../../act7/js/theme.js';
import { accessGraph, occupancy, offOf, reachOut } from '../pipe/plan.js';
import { percolation, peopleAt } from '../pipe/percolation.js';
import { planOpts } from '../pipe/mitigate.js';

const SPEEDS = [[1.3, 'calm'], [2, 'brisk'], [3, 'hurried'], [4, 'running'], [5, 'pushing']];
const word = (v) => { let w = SPEEDS[0][1]; for (const [s, n] of SPEEDS) if (v >= s - 0.05) w = n; return w; };
const sec = (v) => (v == null || !Number.isFinite(v) ? '—' : `${Math.round(v)} s`);
const FLOOR = ['ground', 'first', 'second', 'third'];

export function createSandbox(el, { phone = false, theme = null, onClose = () => {}, toast = () => {}, onChange = () => {}, crowd = null } = {}) {
  const TH = theme || getTheme('dusk'), CH = TH.chart, D = TH.data;
  el.className = 'a2sb'; el.hidden = true;
  let C = null, opts = { perFlat: 3, v0: 1.3, width: null, rear: false, clear: false, graph: true }, blocked = new Set();
  let G = null, graphKey = '', perc = null, people = null, an = null, an0 = null, lastAn = null, running = false, prepping = false, graphChanged = false, cutNow = 0;
  // the live run, streamed from the crowd host: { id, n, r, trapped, frames, tFrames, outAt, t0 (clock), computing, an, ts }
  let live = null, runId = 0; const SPEED = 4;
  const heads = new Float32Array(160);
  el.innerHTML = `<header><h4>Sandbox</h4><span class="tag">your own runs</span><button class="x" type="button" aria-label="Close the sandbox">×</button></header>
    <p class="hint">Tap a marker in the view to block or unblock a door, a corridor or a stair flight. Change the crowd, then run.</p>
    <div class="ctl">
      <label><span>People per flat</span><output data-o="perFlat"></output><input type="range" min="1" max="10" step="1" data-i="perFlat"></label>
      <label><span>Desired speed</span><output data-o="v0"></output><input type="range" min="1.3" max="5" step="0.1" data-i="v0"></label>
      <label><span data-o="wname">Bottleneck door</span><output data-o="width"></output><input type="range" min="0.7" max="1.8" step="0.05" data-i="width"></label>
      <div class="tg"><button type="button" data-x="rear" aria-pressed="false">Rear door unlocked</button><button type="button" data-x="clear" aria-pressed="false">Scooters moved out</button><button type="button" data-x="graph" aria-pressed="true">Access graph</button></div>
      <div class="blk"><span class="k">Blocked</span><span class="chips"></span></div>
    </div>
    <div class="read">
      <div><b data-r="t">0 s</b><small>time</small></div><div><b data-r="out">—</b><small>people out</small></div><div><b data-r="rho">—</b><small>peak people/m²</small></div>
      <div><b data-r="b1">—</b><small>β₁ by floor</small></div><div><b data-r="margin">—</b><small>blockages to cut someone off</small></div><div><b data-r="cut">—</b><small>people with no route now</small></div>
    </div>
    <p class="nt" hidden></p>
    <canvas class="cv"></canvas>
    <div class="row"><button class="a7pri" type="button" data-a="run">Run evacuation</button><button class="a7sec" type="button" data-a="plan" hidden>Plan view</button><button class="a7sec" type="button" data-a="reset">Reset</button></div>`;
  const $ = (s) => el.querySelector(s), out = (k) => el.querySelector(`[data-o="${k}"]`), rd = (k) => el.querySelector(`[data-r="${k}"]`);
  const cv = $('.cv'), ctx = cv.getContext('2d');
  // the markers over the view: one per link on the floor in view
  let marks = null; const markEls = new Map();
  function paint() {
    out('perFlat').textContent = String(opts.perFlat); out('v0').textContent = `${opts.v0.toFixed(1)} m/s, ${word(opts.v0)}`;
    out('width').textContent = `${(opts.width ?? 0).toFixed(2)} m`;
    el.querySelector('[data-i="perFlat"]').value = opts.perFlat; el.querySelector('[data-i="v0"]').value = opts.v0; el.querySelector('[data-i="width"]').value = opts.width ?? 0.9;
    for (const k of ['rear', 'clear', 'graph']) { const b = el.querySelector(`[data-x="${k}"]`); b.classList.toggle('on', !!opts[k]); b.setAttribute('aria-pressed', String(!!opts[k])); }
    const chips = $('.chips'); chips.innerHTML = blocked.size ? [...blocked].map((id) => `<button type="button" data-u="${id}" title="Unblock">${G ? G.links[id].label : id} ×</button>`).join('') + '<button type="button" data-u="all" class="all">Clear all</button>' : '<span class="none">nothing blocked</span>';
    $('[data-a="run"]').textContent = running ? 'Running…' : prepping ? 'Preparing…' : 'Run evacuation';
  }
  el.addEventListener('input', (e) => { const i = e.target.closest('[data-i]'); if (!i) return; const k = i.dataset.i; opts[k] = +i.value; if (k === 'perFlat') { people = null; stopSim(); } changed(); });
  el.addEventListener('click', (e) => {
    const x = e.target.closest('[data-x]'); if (x) { const k = x.dataset.x; opts[k] = !opts[k]; changed(); return; }
    const u = e.target.closest('[data-u]'); if (u) { if (u.dataset.u === 'all') blocked.clear(); else blocked.delete(+u.dataset.u); changed(); return; }
    const a = e.target.closest('[data-a]'); if (!a) return; if (a.dataset.a === 'run') run(); else if (a.dataset.a === 'reset') reset(); else if (a.dataset.a === 'plan') { planView = true; paintPlan(); onChange(); }
  });
  $('.x').addEventListener('click', () => onClose());
  function fixes() { const f = []; if (opts.rear) f.push('rear'); if (opts.clear) f.push('clear'); return f; }
  const doorId = () => (C.widen ? C.widen.door : C.model.openings.find((q) => q.kind === 'street').id);
  const optsNow = () => { const o = planOpts(C, fixes(), { blocked }); if (opts.width != null) o.widen[doorId()] = opts.width; return o; };
  function changed() { stopSim(); recompute(); paint(); onChange(); }
  function stopSim() { if (live && (live.computing || prepping) && crowd) crowd.stopSandbox(); running = false; prepping = false; live = null; an = null; note(''); paintPlan(); }
  function note(t) { const n = $('.nt'); n.textContent = t; n.hidden = !t; }
  // a run is watched in the section view; "Plan view" returns to the markers (the result stays in the panel)
  let planView = false;
  function paintPlan() { const b = el.querySelector('[data-a="plan"]'); if (b) b.hidden = !live || planView; }
  // the graph side: instant on every change
  function recompute() {
    if (!C) return; const o = optsNow();
    const key = JSON.stringify([fixes(), [...blocked].sort(), opts.width]);
    if (key !== graphKey) { graphKey = key; G = accessGraph(C.model, o); perc = percolation(G, peopleNow(), { seed: C.seed, trials: 400, blocked }); graphChanged = true;
      const at = peopleAt(G, peopleNow()), ok = reachOut(G, offOf(G, blocked)); cutNow = 0; for (let i = 0; i < at.length; i++) if (at[i] && !ok[i]) cutNow += at[i]; }
    rd('b1').textContent = perc.betti.floors.join(' '); rd('margin').textContent = perc.base > 0 ? '0' : perc.weak.length ? String(perc.median) : 'none';
    rd('cut').textContent = String(cutNow); rd('cut').classList.toggle('bad', cutNow > 0); rd('margin').classList.toggle('bad', perc.base > 0);
  }
  function peopleNow() { if (!people) people = occupancy(C.model, C.W, C.seed, { perFlat: opts.perFlat }); return people; }
  function run() {
    if (!C || prepping || !crowd) return; stopSim(); prepping = true; paint();
    const o = optsNow(); runId++;
    crowd.sandbox({ id: runId, o: { clutter: o.clutter, rearOpen: o.rearOpen, widen: o.widen, blocked: [...blocked] }, perFlat: opts.perFlat, v0: opts.v0 });
  }
  // what the crowd host says about the run
  function onHost(m) {
    if (m.id !== runId) return;
    if (m.type === 'sbxStart') { live = { id: m.id, n: m.n, r: m.r, trapped: m.trapped.reduce((q, v) => q + v, 0), frames: [], tFrames: [], outAt: new Float32Array(m.n).fill(-1), t0: performance.now(), computing: true, an: null, ts: 0 }; prepping = false; running = true; planView = false; paintPlan(); paint(); onChange(); }
    else if (m.type === 'sbxChunk' && live) { for (let k = 0; k < m.frames.length; k++) { const f = m.frames[k], t = m.tFrames[k]; for (let i = 0; i < live.n; i++) if (f[i * 3 + 2] < 0 && live.outAt[i] < 0) live.outAt[i] = t; live.frames.push(f); live.tFrames.push(t); } }
    else if (m.type === 'sbxDone' && live) { live.computing = false; live.an = m.an; }
    else if (m.type === 'error') { prepping = false; running = false; live = null; paint(); toast('That run could not be computed.'); }
  }
  // positions at the moment shown (interpolated between frames; heading from the motion)
  function liveAt(cb) {
    const L = live, T = L.tFrames, F = L.frames; if (!F.length) return; let k = 0; while (k < T.length - 2 && T[k + 1] <= L.ts) k++;
    const a = F[k], b = F[Math.min(F.length - 1, k + 1)], u = T.length > 1 ? Math.max(0, Math.min(1, (L.ts - T[k]) / Math.max(1e-6, T[Math.min(T.length - 1, k + 1)] - T[k]))) : 0;
    for (let i = 0; i < L.n; i++) {
      const da = a[i * 3 + 2], db = b[i * 3 + 2]; if (da < 0) { cb(i, 0, 0, -1, 0, true); continue; }
      const x = a[i * 3] + (db < 0 ? 0 : (b[i * 3] - a[i * 3]) * u), z = a[i * 3 + 1] + (db < 0 ? 0 : (b[i * 3 + 1] - a[i * 3 + 1]) * u);
      const vx = b[i * 3] - a[i * 3], vz = b[i * 3 + 1] - a[i * 3 + 1]; if (db >= 0 && Math.hypot(vx, vz) > .004) { const want = Math.atan2(vx, vz); let d = want - heads[i]; d = Math.atan2(Math.sin(d), Math.cos(d)); heads[i] += d * .4; }
      cb(i, x, z, da, heads[i], false);
    }
  }
  const outBy = (t) => { let k = 0; for (let i = 0; i < live.n; i++) if (live.outAt[i] >= 0 && live.outAt[i] <= t) k++; return k; };
  function finish() {
    const r = live.an; lastAn = an0; an = r; an0 = r; running = false; paint(); drawCurve();
    if (r.trapped >= r.n) note(`Nobody can get out: every way out is blocked for all ${r.n} people. Unblock a link or unlock the rear door, then run again.`);
    else if (r.trapped > 0) note(`${r.trapped} ${r.trapped === 1 ? 'person has' : 'people have'} no route out and stayed where they were.`);
    else if (r.clogged) note(`The run was stopped after ${Math.round(r.tEnd)} s: nobody had got out for 40 s (a clog).`);
    else note('');
  }
  function reset() { blocked.clear(); opts = { perFlat: 3, v0: 1.3, width: C ? C.model.openings[doorId()].w : 0.9, rear: false, clear: false, graph: true }; people = null; stopSim(); an0 = null; lastAn = null; recompute(); paint(); drawCurve(); onChange(); }
  function drawCurve() {
    const r = cv.getBoundingClientRect(); const dpr = Math.min(2, devicePixelRatio || 1); if (r.width < 4) return; const w = r.width, h = r.height;
    if (cv.width !== Math.round(w * dpr)) { cv.width = Math.round(w * dpr); cv.height = Math.round(h * dpr); }
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0); ctx.clearRect(0, 0, w, h);
    const runs = [], ghost = running || !an ? an0 : lastAn; if (ghost) runs.push({ times: ghost.times, n: ghost.n, col: rgba(CH.paper, .45), dash: true });
    const cur = live && running ? { times: Array.from(live.outAt).filter((t) => t >= 0 && t <= live.ts).sort((a, b) => a - b), n: live.n, col: D.swarm, upto: live.ts } : an ? { times: an.times, n: an.n, col: D.swarm } : null; if (cur) runs.push(cur);
    const X0 = 26, Y0 = 8, Wd = w - 34, Hh = h - 22; ctx.strokeStyle = CH.grid; ctx.beginPath(); ctx.moveTo(X0, Y0 + Hh); ctx.lineTo(X0 + Wd, Y0 + Hh); ctx.moveTo(X0, Y0); ctx.lineTo(X0, Y0 + Hh); ctx.stroke();
    ctx.font = '10px "Geist Mono", ui-monospace, monospace'; ctx.fillStyle = CH.faint; ctx.textAlign = 'right';
    if (!runs.length) { ctx.textAlign = 'center'; ctx.font = '11px Geist, ui-sans-serif, system-ui, sans-serif'; ctx.fillText('people out against time, after a run', w / 2, h / 2); return; }
    const n = Math.max(...runs.map((q) => q.n)), tMax = Math.max(30, ...runs.map((q) => (q.times.length ? q.times[q.times.length - 1] : 0)), live ? live.ts : 0) * 1.05;
    ctx.fillText(String(n), X0 - 4, Y0 + 8); ctx.fillText(`${Math.round(tMax)} s`, X0 + Wd, h - 3);
    for (const q of runs) { ctx.beginPath(); ctx.moveTo(X0, Y0 + Hh); let k = 0; for (const t of q.times) { const x = X0 + t / tMax * Wd; ctx.lineTo(x, Y0 + Hh - k / n * Hh); k++; ctx.lineTo(x, Y0 + Hh - k / n * Hh); } if (q.upto != null) ctx.lineTo(X0 + q.upto / tMax * Wd, Y0 + Hh - k / n * Hh); ctx.strokeStyle = q.col; ctx.lineWidth = q.dash ? 1.2 : 1.8; ctx.setLineDash(q.dash ? [3, 3] : []); ctx.stroke(); ctx.setLineDash([]); }
  }
  // gathering spots on the pavement for people who are out
  const spots = []; const spotOf = (i) => { if (!spots[i] && C) { const row = Math.floor(i / 12), col = i % 12; spots[i] = [(col - 5.5) * 0.85 + (row % 2) * 0.4, 0.02, C.model.dims.D / 2 + 3.2 + 2.3 + row * 0.8]; } return spots[i] || [0, 0, 0]; };
  let curveT = 0;
  return {
    get showGraph() { return opts.graph; },
    setCase(c) { C = c; spots.length = 0; graphKey = ''; people = null; live = null; an = null; lastAn = null; reset(); out('wname').textContent = 'Bottleneck door'; },
    onHost,
    open() { if (!C) return; if (C.widen) { out('wname').textContent = `${C.widen.label.replace(/^the /, '').replace(/^./, (m) => m.toUpperCase())}`; if (opts.width == null || !this._opened) opts.width = C.model.openings[C.widen.door].w; } else { const sd = C.model.openings.find((q) => q.kind === 'street'); out('wname').textContent = 'Street door'; opts.width = opts.width ?? sd.w; }
      this._opened = true; el.hidden = false; recompute(); paint(); requestAnimationFrame(drawCurve); },
    close() { el.hidden = true; stopSim(); if (marks) for (const m of markEls.values()) m.style.display = 'none'; },
    // every frame: advance the live run (at most 8 ms of work), and hand the scene what to show
    frame(dt, Cc, { cutLevel }) {
      if (live) { const T = live.tFrames, tl = T.length ? T[T.length - 1] : 0; live.ts = Math.min(tl, (performance.now() - live.t0) / 1000 * SPEED); if (running && !live.computing && live.ts >= tl - 1e-6) finish(); }
      if (running && live) { rd('t').textContent = `${Math.round(live.ts)} s`; rd('out').textContent = `${outBy(live.ts)} of ${live.n}`; }
      else if (prepping) { rd('t').textContent = '0 s'; rd('out').textContent = `— of ${peopleNow().length}`; }
      else if (an) { rd('t').textContent = an.trapped >= an.n ? '—' : an.total != null && !an.clogged ? sec(an.total) : `${sec(an.tEnd)}+`; rd('out').textContent = `${an.out} of ${an.n}`; rd('rho').textContent = an.out ? an.peak.toFixed(1) : '—'; }
      else { rd('t').textContent = '0 s'; rd('out').textContent = `— of ${peopleNow().length}`; rd('rho').textContent = '—'; }
      if (running) { curveT += dt; if (curveT > .25) { curveT = 0; drawCurve(); } }
      const ch = graphChanged; graphChanged = false;
      return { live: live && live.frames.length ? { n: live.n, r: live.r, at: liveAt } : null, runView: !!live && !planView, G: G || Cc.G, people: live ? null : peopleNow(), blocked: [...blocked], rear: opts.rear, clear: opts.clear, weak: perc ? perc.weak.map((q) => [q.link, q.people]) : [], bridges: perc ? perc.bridgeIds : [], graphChanged: ch, an };
    },
    // markers: every link on the floor in view, as a small button (blocked ones crossed out)
    labels(labels, camera, rect, cutLevel) {
      if (!marks) { marks = el.parentNode.querySelector('.a2marks'); }
      if (!marks || !G) return; const lv = cutLevel == null ? 0 : Math.min(3, cutLevel), v = new THREE.Vector3(), seen = new Set();
      for (const l of G.links) {
        if (l.locked) continue; const s = l.kind === 'flight' ? (l.upper ? l.storey + 1 : l.storey) : l.storey; if (s !== lv) continue;
        v.set(l.p[0], l.kind === 'flight' ? (l.upper ? l.p[1] + .4 : l.p[1] + .2) : l.p[1] + 0.25, l.p[2]).project(camera); if (v.z > 1) continue;
        const x = (v.x * .5 + .5) * rect.width, y = (-v.y * .5 + .5) * rect.height; if (x < 4 || y < 4 || x > rect.width - 4 || y > rect.height - 4) continue;
        let m = markEls.get(l.id); if (!m) { m = document.createElement('button'); m.type = 'button'; m.className = 'a2mk'; m.dataset.l = l.id; m.title = l.label; m.setAttribute('aria-label', `Block or unblock: ${l.label}`); m.addEventListener('click', (e) => { e.stopPropagation(); const id = +m.dataset.l; if (blocked.has(id)) blocked.delete(id); else blocked.add(id); changed(); }); marks.appendChild(m); markEls.set(l.id, m); }
        m.style.display = ''; m.style.transform = `translate(${x.toFixed(1)}px, ${y.toFixed(1)}px) translate(-50%, -50%)`; m.classList.toggle('on', blocked.has(l.id)); m.classList.toggle('k' + l.kind[0], true); seen.add(l.id);
      }
      for (const [id, m] of markEls) if (!seen.has(id) && m.style.display !== 'none') m.style.display = 'none';
    },
    hideMarks() { if (marks) for (const m of markEls.values()) if (m.style.display !== 'none') m.style.display = 'none'; },
    run, spotOf, headOf: (i) => heads[i] || 0, setHead: (i, v) => { heads[i] = v; },
    api: {
      block(id) { blocked.add(id); changed(); }, unblock(id) { blocked.delete(id); changed(); }, set(o) { Object.assign(opts, o); if (o.perFlat) people = null; changed(); }, run() { run(); },
      get state() { return { running, prepping, computing: !!(live && live.computing), mode: crowd ? crowd.mode : 'none', trapped: an ? an.trapped : null, note: $('.nt').hidden ? '' : $('.nt').textContent, blocked: [...blocked], opts: { ...opts }, t: live ? live.ts : null, out: running && live ? outBy(live.ts) : an ? an.out : null, shownFrames: live ? live.frames.length : 0, n: live ? live.n : peopleNow().length, total: an ? an.total : null, peak: an ? an.peak : null, b1: perc ? perc.betti.floors : null, margin: perc ? perc.median : null, cut: cutNow, last: lastAn ? lastAn.total : null }; },
      links: () => (G ? G.links.map((l) => ({ id: l.id, kind: l.kind, storey: l.storey, label: l.label })) : []),
    },
    dispose() { if (marks) for (const m of markEls.values()) m.remove(); markEls.clear(); },
  };
}
