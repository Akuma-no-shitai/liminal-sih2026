// The computing overlay (real progress, a readable message and Try again if anything fails), the handover end card,
// and the assumptions panel.
const esc = (s) => String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;');
export function createSimOverlay(el) {
  el.className = 'a7over a7sim hide';
  el.innerHTML = '<div class="box"><p class="k">Before it falls</p><h2>Surveying the building</h2><p class="pl">Eight drones map an apartment block in peacetime; then the map is turned into a risk picture.</p><div class="bar"><s></s></div><p class="pc">0 %</p><p class="why">The survey flight, the map, the access graph and the night-time crowd run are computed first, from a seed. Then they play back as a film you can scrub.</p></div>';
  const h2 = el.querySelector('h2'), bar = el.querySelector('.bar s'), pc = el.querySelector('.pc'), k = el.querySelector('.k');
  return {
    show(title = 'Surveying the building') { el.classList.remove('failed'); k.textContent = 'Before it falls'; h2.textContent = title; bar.style.width = '0%'; pc.textContent = '0 %'; el.classList.remove('hide'); },
    progress(p, label) { el.classList.remove('failed'); bar.style.width = (Math.max(0, Math.min(1, p)) * 100).toFixed(1) + '%'; pc.textContent = `${label || 'Working'} ${Math.round(p * 100)} %`; },
    hide() { el.classList.add('hide'); el.classList.remove('failed'); },
    fail(text, onRetry, onBack) {
      el.classList.remove('hide'); el.classList.add('failed'); k.textContent = 'Something went wrong'; pc.textContent = text;
      let row = el.querySelector('.row'); if (!row) { row = document.createElement('div'); row.className = 'row'; el.querySelector('.box').appendChild(row); }
      row.innerHTML = '<button class="a7pri" type="button" data-a="retry">Try again</button><button class="a7sec" type="button" data-a="back">Back to the story</button>';
      row.querySelector('[data-a="retry"]').addEventListener('click', () => onRetry && onRetry());
      row.querySelector('[data-a="back"]').addEventListener('click', () => onBack && onBack());
    },
  };
}

const sec = (v) => (v == null || !Number.isFinite(v) ? '—' : `${Math.round(v)} s`);
// the end card: what the Before phase hands on
export function createReport(el, { onSandbox, onReplay, onNext, onBack, hasNext = false } = {}) {
  el.className = 'a7over a7rep hide'; let shown = false;
  function show(C) {
    const S = C.survey.stats, B = C.base, PS = C.percSummary, nc = C.night.calm, F = C.full, fx = C.fixes;
    const hot = nc.bottlenecks[0], weak = PS.top.slice(0, 3).map((q) => `${esc(q.label)} (${q.people})`).join(', ');
    const best = F ? F.fis : null;
    const B0 = F && F.calmRep ? F.calmRep.mean : null, tt = (v) => (v === Infinity ? 'a clog' : sec(v)), ch = (f) => `${tt(B0)} → ${tt(f.rep.mean)}`, nr = (f) => (f.cmp.real ? '' : ', within the spread between runs');
    const fixRows = fx ? [
      ['Move the scooters out of the lobby', ch(fx.clear), C.clutter && C.clutter.length ? `full house${nr(fx.clear)}; at night ${sec(nc.total)} → ${sec(fx.clear.night.total)}` : 'nothing parked'],
      ['Keep the rear door unlocked at night', `β₁ ${C.betti.b1} → ${fx.rear.graph.betti.b1}`, `worst single link ${PS.worst ? PS.worst.people : 0} → ${fx.rear.graph.perc.worst ? fx.rear.graph.perc.worst.people : 0} people; full house ${ch(fx.rear)}${nr(fx.rear)}`],
      [`Widen one door (${esc(C.widen.label)}) to ${C.widen.to.toFixed(1)} m`, ch(fx.widen), `full house, walking pace${nr(fx.widen)}`],
    ] : [];
    el.innerHTML = `<div class="card" role="dialog" aria-label="End of Act 2"><p class="k">Handed on</p><h2>What the Before phase hands over</h2>
      <p class="pl">Building no. ${C.seed}. The crowd is a published model (Helbing, Farkas &amp; Vicsek 2000) with simulated occupancy: a planning tool, not a prediction for a real building.</p>
      <div class="cmd">
        <section><h5>The baseline map, to Act 7</h5><p><b>${(S.points / 1e3).toFixed(0)}k</b> points and a 12 cm voxel map, <b>${S.mb.toFixed(1)} MB</b>, from <b>${Math.round(S.minutes)}</b> minutes of flight. All <b>${B.roomsMapped}</b> rooms, <b>${B.measured}</b> door widths, the stair and both exits. After a disaster, Act 7 measures change against exactly this.</p></section>
        <section><h5>The risk map</h5><p>β₁ = <b>${C.betti.b1}</b>: ${C.betti.b1 === 0 ? 'no alternative routes; every flat and floor hangs on one chain of doors and one stair' : `${C.betti.b1} alternative route${C.betti.b1 === 1 ? '' : 's'}`}. Weak links with the most people behind them: ${weak || 'none'}.</p><p>Percolation margin: <b>${PS.median}</b> random blockage${PS.median === 1 ? '' : 's'} (median) before someone is cut off. Bottleneck at night: <b>${hot ? esc(hot.label) : 'none'}</b>${hot ? `, ${hot.rho.toFixed(1)} people/m² at its peak` : ''}. Dead ends: ${C.deadEnds.length} hall ends.</p></section>
        <section><h5>The route plan</h5><p>Night-time evacuation of ${nc.n} people: <b>${sec(nc.total)}</b>, out through ${Object.keys(nc.exits).length > 1 ? 'both exits' : 'the street door'}.${best ? ` A full house of 80 (means of repeated runs): best at ${best.best} m/s (${sec(best.bestT)}); ${best.emerges ? `pushing harder makes it slower in every run (${Number.isFinite(best.lastT) ? sec(best.lastT) : 'a clog that did not clear'} at ${best.last} m/s)` : best.close ? `at ${best.last} m/s slower on average (${sec(best.lastT)}), but the runs overlap` : 'pushing harder did not slow it here'}.` : ''}</p></section>
        ${fixRows.length ? `<section><h5>Fixes tested, and their effect</h5>${fixRows.map(([n, v, l]) => `<p>${n}: <b>${v}</b> <span class="draft">${l}</span></p>`).join('')}</section>` : ''}
        <section><h5>The loop closes</h5><p>After each event, Act 7’s measurements refine the next Before plan: what failed, where, and how fast.</p></section>
      </div>
      <div class="row"><button class="a7pri" type="button" data-a="sandbox">Open the sandbox</button><button class="a7sec" type="button" data-a="replay">Watch again</button>${hasNext ? '<button class="a7sec" type="button" data-a="next">Next: Act 3</button>' : ''}<button class="a7sec" type="button" data-a="back">Back to the story</button></div></div>`;
    const b = (a, f) => { const x = el.querySelector(`[data-a="${a}"]`); if (x) x.addEventListener('click', () => f && f()); };
    b('sandbox', onSandbox); b('replay', onReplay); b('next', onNext); b('back', onBack);
    el.classList.remove('hide'); shown = true;
  }
  return { show, hide() { el.classList.add('hide'); shown = false; }, get shown() { return shown; } };
}

const SUP = { 0: '⁰', 1: '¹', 2: '²', 3: '³', 4: '⁴', 5: '⁵', 6: '⁶', 7: '⁷', 8: '⁸', 9: '⁹' };
const sci = (v) => { const e = Math.floor(Math.log10(v)), m = v / 10 ** e; return `${+m.toFixed(1)} × 10${String(e).split('').map((d) => SUP[d]).join('')}`; };
// the model's assumptions, reachable from the crowd card
export function createAssumptions(el, { onClose }) {
  el.className = 'a2asm'; el.hidden = true;
  function show(C) {
    const H = C.consts.HELBING, S = C.stair;
    el.innerHTML = `<div class="box" role="dialog" aria-label="Crowd model assumptions"><button class="x" type="button" aria-label="Close">×</button><p class="k">Crowd model</p><h3>Assumptions</h3>
      <dl>
        <dt>Model</dt><dd>Social force, Helbing, Farkas &amp; Vicsek, Nature 407 (2000), with their parameters: A ${H.A} N, B ${H.B} m, k ${sci(H.k)} kg/s², κ ${sci(H.kappa)} kg/(m·s), τ ${H.tau} s, mass ${H.m} kg, body radius ${H.rMin} to ${H.rMax} m.</dd>
        <dt>Occupancy</dt><dd>Simulated. Night: 2 to 4 people per flat, seeded, asleep in the bedroom first, then the living room. Full house: 10 per flat (80 people). Everyone sets off at once; the minutes real people take to wake and dress are not modelled.</dd>
        <dt>Speeds</dt><dd>Desired walking speed 1.3 m/s on the level. On a flight ${(S.f * 100).toFixed(0)}\u00a0% of that in plan (SFPE speed constants, k ≈ 1.2 on these stairs against 1.4 on the level, times cos ${(S.theta * 180 / Math.PI).toFixed(0)}°). Stooping under the stair landing: half speed (our assumption). Faster is slower: 1.3 to 5 m/s.</dd>
        <dt>Steering</dt><dd>Each person heads down a floor field (the quickest walkable way to an exit). The social force from a wall acts across its face; at door edges only body contact and friction act. Two rules of ours: a small random push (10\u00a0% of the walking force, redrawn every 0.5 s), and someone who has made no headway for 3 s eases off for 1.2 s. Without them a perfectly balanced standoff in the model lasts forever.</dd>
        <dt>Numerics</dt><dd>Steps of 4 ms on a 5 cm grid. In one step, sliding friction can stop a slide but never reverse it.</dd>
        <dt>Runs</dt><dd>The crowd is chaotic: runs that differ only in the random pushes leave seconds apart, more where a clog forms. Every full-house time is the mean of ${C.consts.REPEAT ? `${C.consts.REPEAT.sweep} or ${C.consts.REPEAT.calm}` : 'several'} such runs, and a fix counts as a change only when its runs and the base runs do not overlap.</dd>
        <dt>Geometry</dt><dd>The surveyed plan on a 5 cm grid: rooms, door openings, columns, the stair as two flights and a half-landing per floor, parked scooters. Door widths as built (the survey measured them within a few centimetres).</dd>
        <dt>What it is not</dt><dd>A prediction for a real building. Smoke, fire, darkness, disability, families moving together and people going back are not in it.</dd>
      </dl></div>`;
    el.querySelector('.x').addEventListener('click', () => onClose && onClose());
    el.hidden = false;
  }
  return { show, hide() { el.hidden = true; }, get shown() { return !el.hidden; } };
}
