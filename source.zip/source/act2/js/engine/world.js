// The clay diorama for Act 2 (adapted from Act 7's world): the intact building (act7's model for this seed, the same
// block Act 7 collapses), its site and neighbours, what is parked in the lobby, the closed rear door, the survey team's
// van, the anchor robot with its mast, the ground-station table and the landing pad with eight drones. A floor cutaway
// hides every storey above a level; barriers mark the links the viewer (or the director) has blocked.
import * as THREE from 'three';
import { propGeometry, droneGeometry, makeUgv, clay } from '../../../act7/js/engine/models.js';
import { getTheme } from '../../../act7/js/theme.js';

let DIMC = new THREE.Color('#8A85AC');
export function dimPatch(mat, U) {
  mat.onBeforeCompile = (sh) => {
    sh.uniforms.a7Dim = U.dim;
    sh.fragmentShader = sh.fragmentShader.replace('#include <common>', '#include <common>\nuniform float a7Dim;')
      .replace('#include <dithering_fragment>', `#include <dithering_fragment>
        { float l = dot(gl_FragColor.rgb, vec3(.3, .55, .15)); gl_FragColor.rgb = mix(gl_FragColor.rgb, mix(vec3(l) * .8, vec3(${DIMC.r.toFixed(3)}, ${DIMC.g.toFixed(3)}, ${DIMC.b.toFixed(3)}), .6), a7Dim * .9); }`);
  };
  const key = 'a2dim' + DIMC.getHexString(); mat.customProgramCacheKey = () => key;
  return mat;
}

export function buildWorld(C, props, { phone = false, theme = null } = {}) {
  const T = theme || getTheme('dusk'), K = T.clay, COL = K.col; DIMC = new THREE.Color(K.dim);
  const group = new THREE.Group(); group.name = 'world';
  const U = { dim: { value: 0 } }, mats = [], geos = [];
  const mkMat = (c, o = {}) => { const m = dimPatch(new THREE.MeshStandardMaterial({ color: new THREE.Color(c), roughness: o.r ?? .92, metalness: 0, ...o.extra }), U); mats.push(m); return m; };
  const PT = K.prop ? new THREE.Color(K.prop.color) : null, pm = K.prop ? K.prop.mix : 0;
  const tintProp = (obj, skip) => { if (!PT) return obj; obj.traverse((o) => { if (!o.isMesh || o === skip || !o.material || o.material.isShaderMaterial) return; const m = o.material.clone(); if (m.color) m.color.lerp(PT, pm); o.material = m; mats.push(m); }); return obj; };
  const tintGeo = (geo) => { if (!PT || !geo || !geo.attributes.color) return; const a = geo.attributes.color; for (let i = 0; i < a.count; i++) a.setXYZ(i, a.getX(i) + (PT.r - a.getX(i)) * pm, a.getY(i) + (PT.g - a.getY(i)) * pm, a.getZ(i) + (PT.b - a.getZ(i)) * pm); a.needsUpdate = true; };
  const box = new THREE.BoxGeometry(1, 1, 1); geos.push(box);
  const M4 = new THREE.Matrix4(), Q = new THREE.Quaternion(), P = new THREE.Vector3(), S = new THREE.Vector3(), col = new THREE.Color();
  let h = 1; const jit = () => { h = (h * 16807) % 2147483647; return h / 2147483647; };
  const model = C.model, inst = [];
  // the section (dollhouse) view of the crowd: the block cut open along its length. Every wall that faces the street
  // (the facade, the hall walls, the back rooms' front walls) goes, with the balconies, the street-side roof parapet and
  // the beams along the length; the floors, the side walls and partitions (seen edge-on), the columns, the stair and the
  // back wall stay. Seen from the street a little above, all four floors, the stair and everyone on them are in view.
  const sectionCut = (p) => {
    const D2 = model.dims.D / 2;
    if (p.kind === 'wall') { const u = model.walls[p.unit]; return !!u && u.axis === 'z' && u.off > -D2 + 0.3; }
    if (p.kind === 'balcony') return true;
    if (p.kind === 'parapet') return !!p.balcony || (p.box.h[0] > p.box.h[2] && p.box.c[2] > 0);
    if (p.kind === 'beam') return p.box.h[0] > p.box.h[2] && p.box.c[2] > -D2 + 0.5;
    return false;
  };
  // ------------------------------------------------------------------ the building
  const byMat = new Map(); for (const p of model.parts) { if (p.kind === 'site') continue; if (!byMat.has(p.mat)) byMat.set(p.mat, []); byMat.get(p.mat).push(p); }
  for (const [m, list] of byMat) {
    const mesh = new THREE.InstancedMesh(box, mkMat(K.squared === false ? '#FFFFFF' : (COL[m] || '#DDD')), list.length); mesh.castShadow = true; mesh.receiveShadow = true; mesh.frustumCulled = false;
    const storeys = new Int8Array(list.length), mats4 = [], sec = new Uint8Array(list.length);
    list.forEach((p, i) => { P.set(...p.box.c); Q.set(...p.box.q); S.set(p.box.h[0] * 2, p.box.h[1] * 2, p.box.h[2] * 2); M4.compose(P, Q, S); mesh.setMatrixAt(i, M4); mats4.push(M4.clone()); col.set(COL[m] || '#DDD').offsetHSL(0, 0, (jit() - .5) * .04); mesh.setColorAt(i, col); storeys[i] = p.storey; sec[i] = sectionCut(p) ? 1 : 0; });
    mesh.instanceMatrix.needsUpdate = true; if (mesh.instanceColor) mesh.instanceColor.needsUpdate = true; group.add(mesh); inst.push({ mesh, storeys, mats4, sec });
  }
  // window frames
  { const bf = []; for (const o of model.openings) { if (o.kind !== 'window' && o.kind !== 'balcony') continue; const t = 0.06, d = 0.07;
      const bars = o.axis === 'x' ? [[o.off, o.y0 + t / 2, (o.o0 + o.o1) / 2, d, t, o.o1 - o.o0], [o.off, o.y1 - t / 2, (o.o0 + o.o1) / 2, d, t, o.o1 - o.o0], [o.off, (o.y0 + o.y1) / 2, o.o0 + t / 2, d, o.y1 - o.y0, t], [o.off, (o.y0 + o.y1) / 2, o.o1 - t / 2, d, o.y1 - o.y0, t], [o.off, (o.y0 + o.y1) / 2, (o.o0 + o.o1) / 2, d * .8, o.y1 - o.y0, t * .7]]
        : [[(o.o0 + o.o1) / 2, o.y0 + t / 2, o.off, o.o1 - o.o0, t, d], [(o.o0 + o.o1) / 2, o.y1 - t / 2, o.off, o.o1 - o.o0, t, d], [o.o0 + t / 2, (o.y0 + o.y1) / 2, o.off, t, o.y1 - o.y0, d], [o.o1 - t / 2, (o.y0 + o.y1) / 2, o.off, t, o.y1 - o.y0, d], [(o.o0 + o.o1) / 2, (o.y0 + o.y1) / 2, o.off, t * .7, o.y1 - o.y0, d * .8]];
      for (const b of bars) bf.push({ b, storey: o.storey, sec: o.axis === 'z' && o.off > -model.dims.D / 2 + 0.3 }); }
    const mesh = new THREE.InstancedMesh(box, mkMat(K.frame), bf.length); mesh.frustumCulled = false; const storeys = new Int8Array(bf.length), mats4 = [], sec = new Uint8Array(bf.length);
    bf.forEach((f, i) => { M4.compose(P.set(f.b[0], f.b[1], f.b[2]), Q.set(0, 0, 0, 1), S.set(f.b[3], f.b[4], f.b[5])); mesh.setMatrixAt(i, M4); mats4.push(M4.clone()); storeys[i] = f.storey; sec[i] = f.sec ? 1 : 0; });
    mesh.instanceMatrix.needsUpdate = true; group.add(mesh); inst.push({ mesh, storeys, mats4, sec }); }
  // the rear door, closed and locked at night (the "rear door" fix opens it)
  const rear = model.openings.find((o) => o.kind === 'rear');
  const leaf = new THREE.Mesh(box, mkMat(COL.door || '#B9907E')); leaf.scale.set(rear.o1 - rear.o0 - 0.02, rear.y1 - rear.y0, 0.05); leaf.position.set((rear.o0 + rear.o1) / 2, (rear.y0 + rear.y1) / 2, rear.off); leaf.castShadow = true; group.add(leaf);
  // scooters parked in the lobby: a body, a seat, two wheels and the handlebar, in muted clay
  const scooters = new THREE.Group(); group.add(scooters);
  { const bodyM = mkMat(K.van || '#E8DFE6', { r: .7 }), darkM = mkMat(K.laptop || '#5E5878'), seatM = mkMat(K.legs || '#8C86A8'); const tones = ['#C9A9B6', '#A9B8CC', '#C4C9B4'];
    (C.clutter || []).forEach((b, i) => { const g = new THREE.Group(), w = b.x1 - b.x0, len = b.z1 - b.z0, bm = mkMat(PT ? new THREE.Color(tones[i % 3]).lerp(PT, pm).getStyle() : tones[i % 3], { r: .7 });
      const deck = new THREE.Mesh(box, bm); deck.scale.set(w * .55, 0.42, len * .62); deck.position.set(0, 0.45, -len * .05); g.add(deck);
      const seat = new THREE.Mesh(box, seatM); seat.scale.set(w * .45, 0.1, len * .35); seat.position.set(0, 0.72, -len * .12); g.add(seat);
      const front = new THREE.Mesh(box, bm); front.scale.set(w * .5, 0.6, 0.18); front.position.set(0, 0.62, len * .33); g.add(front);
      const bar = new THREE.Mesh(box, darkM); bar.scale.set(w * .95, 0.05, 0.05); bar.position.set(0, 1.02, len * .36); g.add(bar);
      for (const zz of [-len * .36, len * .38]) { const wh = new THREE.Mesh(new THREE.CylinderGeometry(0.2, 0.2, 0.1, 18), darkM); geos.push(wh.geometry); wh.rotation.z = Math.PI / 2; wh.position.set(0, 0.2, zz); g.add(wh); }
      g.position.set((b.x0 + b.x1) / 2, floorY0(), (b.z0 + b.z1) / 2); g.traverse((o) => { if (o.isMesh) { o.castShadow = true; o.receiveShadow = true; } }); scooters.add(g); void bodyM; }); }
  function floorY0() { return 0.15; }
  // ------------------------------------------------------------------ the site
  const { L, D } = model.dims, site = model.site;
  const plane = (w, d, mat, x, y, z) => { const m = new THREE.Mesh(new THREE.PlaneGeometry(w, d).rotateX(-Math.PI / 2), mkMat(mat)); m.position.set(x, y, z); m.receiveShadow = true; group.add(m); geos.push(m.geometry); return m; };
  plane(260, 260, K.ground, 0, -0.002, 0); plane(L + 5.6, D + 6.4, K.yard, 0, 0.003, 0);
  plane(260, site.street.z1 - site.street.z0, K.street, 0, 0.004, (site.street.z0 + site.street.z1) / 2); plane(260, 2.0, K.pave, 0, 0.006, D / 2 + 3.2 + 1.1);
  { const marks = []; for (let x = -60; x < 60; x += 4) marks.push(x); const mk = new THREE.InstancedMesh(box, mkMat(K.marks), marks.length); marks.forEach((x, i) => { M4.compose(P.set(x, 0.01, (site.street.z0 + site.street.z1) / 2), Q.set(0, 0, 0, 1), S.set(2, 0.01, 0.12)); mk.setMatrixAt(i, M4); }); mk.receiveShadow = true; group.add(mk); }
  const fades = [];
  const winTex = (() => { if (typeof document === 'undefined') return null; const cv = document.createElement('canvas'); cv.width = 64; cv.height = 64; const x = cv.getContext('2d'); x.fillStyle = K.winBase; x.fillRect(0, 0, 64, 64); x.fillStyle = K.winGlass; for (let r = 0; r < 2; r++) for (let c = 0; c < 2; c++) x.fillRect(8 + c * 32, 10 + r * 32, 18, 14); const t = new THREE.CanvasTexture(cv); t.wrapS = t.wrapT = THREE.RepeatWrapping; t.colorSpace = THREE.SRGBColorSpace; return t; })();
  for (const p of model.parts.filter((q) => q.kind === 'site')) {
    const isN = p.mat === 'neighbour', g = new THREE.BoxGeometry(p.box.h[0] * 2, p.box.h[1] * 2, p.box.h[2] * 2); geos.push(g);
    let mat; if (isN && winTex) { const t = winTex.clone(); t.needsUpdate = true; t.repeat.set(Math.max(1, Math.round(p.box.h[0] * 2 / 3.2)), Math.max(1, Math.round(p.box.h[1] * 2 / 3))); mat = mkMat('#FFFFFF', { extra: { map: t } }); } else mat = mkMat(COL[p.mat] || COL.site);
    const m = new THREE.Mesh(g, mat); m.position.set(...p.box.c); m.castShadow = true; m.receiveShadow = true; group.add(m);
    if (isN) fades.push({ m, mat, bb: p.aabb, k: 1 });
  }
  const pickProp = (name) => (props && props.getObjectByName ? props.getObjectByName(name) : null);
  const tree = pickProp('tree_broad'), trees = [];
  for (const [x, z] of [[-16, site.street.z1 + 1.5], [-6, site.street.z1 + 2.2], [7, site.street.z1 + 1.6], [17, site.street.z1 + 2.4]]) {
    let t; if (tree) { t = tintProp(tree.clone()); t.scale.setScalar(1.1); } else { t = new THREE.Group(); const tr = new THREE.Mesh(new THREE.CylinderGeometry(.12, .16, 2.2, 8), mkMat(K.trunk)); tr.position.y = 1.1; const cr = new THREE.Mesh(new THREE.SphereGeometry(1.4, 14, 10), mkMat(K.crown)); cr.position.y = 3.0; t.add(tr, cr); }
    t.position.set(x, 0, z); t.traverse((o) => { if (o.isMesh) { o.castShadow = true; o.receiveShadow = true; } }); group.add(t); trees.push(t);
  }
  // ------------------------------------------------------------------ the survey team
  const van = (() => { const p = pickProp('van'); if (p) return tintProp(p.clone()); const g = new THREE.Group(); const b = new THREE.Mesh(new THREE.BoxGeometry(5, 2, 2), mkMat(K.van)); b.position.y = 1.3; g.add(b); return g; })();
  van.position.set(site.van.x, 0, site.van.z); van.traverse((o) => { if (o.isMesh) { o.castShadow = true; o.receiveShadow = true; } }); group.add(van);
  const ugv = makeUgv(props, K.beacon); tintProp(ugv, ugv.userData.beacon); ugv.position.set(site.anchor.x, 0, site.anchor.z); ugv.rotation.y = -Math.PI / 2; group.add(ugv);
  const mast = new THREE.Mesh(new THREE.CylinderGeometry(.04, .05, 2.2, 8), mkMat(K.mast)); mast.position.set(site.anchor.x + 0.42, 1.85, site.anchor.z); mast.castShadow = true; group.add(mast);
  const mastHead = new THREE.Mesh(new THREE.SphereGeometry(.13, 12, 8), new THREE.MeshBasicMaterial({ color: new THREE.Color(K.mastHead).multiplyScalar(T.dark ? 1.6 : 1.0) })); mastHead.position.set(site.anchor.x + 0.42, 3.0, site.anchor.z); group.add(mastHead); mats.push(mastHead.material); geos.push(mastHead.geometry);
  const table = new THREE.Group(); table.position.set(site.table.x, 0, site.table.z);
  { const top = new THREE.Mesh(new THREE.BoxGeometry(1.8, .04, .8), mkMat(K.table)); top.position.y = .74; table.add(top);
    for (const [lx, lz] of [[-.8, -.32], [.8, -.32], [-.8, .32], [.8, .32]]) { const leg = new THREE.Mesh(new THREE.CylinderGeometry(.02, .02, .72, 6), mkMat(K.legs)); leg.position.set(lx, .36, lz); table.add(leg); }
    const lapBase = new THREE.Mesh(new THREE.BoxGeometry(.42, .02, .3), mkMat(K.laptop)); lapBase.position.set(-.2, .77, .05); table.add(lapBase);
    const lid = new THREE.Mesh(new THREE.BoxGeometry(.42, .28, .015), mkMat(K.laptop)); lid.position.set(-.2, .92, -.1); lid.rotation.x = -.22; table.add(lid);
    const scr = new THREE.Mesh(new THREE.PlaneGeometry(.38, .24), new THREE.MeshBasicMaterial({ color: new THREE.Color(K.screen) })); scr.position.set(-.2, .92, -.091); scr.rotation.x = -.22; table.add(scr); mats.push(scr.material); geos.push(scr.geometry);
    const crate = new THREE.Mesh(new THREE.BoxGeometry(.6, .4, .4), mkMat(K.crate)); crate.position.set(.45, .2, .55); table.add(crate); }
  table.traverse((o) => { if (o.isMesh) { o.castShadow = true; o.receiveShadow = true; } }); group.add(table);
  const resc = pickProp('rescuer');
  for (const [x, z, ry] of [[site.table.x + 0.9, site.table.z + 0.9, 2.6], [site.table.x - 1.1, site.table.z + 0.8, 3.6]]) { let r; if (resc) r = tintProp(resc.clone()); else { r = new THREE.Group(); const b = new THREE.Mesh(new THREE.CapsuleGeometry(.22, 1.0, 4, 8), mkMat(K.rescuer)); b.position.y = .85; r.add(b); } r.position.set(x, 0, z); r.rotation.y = ry; r.traverse((o) => { if (o.isMesh) o.castShadow = true; }); group.add(r); }
  const pad = new THREE.Mesh(new THREE.CylinderGeometry(1.25, 1.25, .04, 40), mkMat(K.pad)); pad.position.set(site.pad.x, .02, site.pad.z); pad.receiveShadow = true; group.add(pad);
  const ring = new THREE.Mesh(new THREE.RingGeometry(1.0, 1.08, 48).rotateX(-Math.PI / 2), new THREE.MeshBasicMaterial({ color: new THREE.Color(K.ring) })); ring.position.set(site.pad.x, .05, site.pad.z); group.add(ring); mats.push(ring.material); geos.push(ring.geometry);
  let dGeo = null; const dp = pickProp('swarm_drone'); if (dp) dGeo = propGeometry(dp); if (!dGeo) dGeo = droneGeometry(); tintGeo(dGeo); geos.push(dGeo);
  const dMat = clay('#ffffff', { vc: true, r: .6 }); dimPatch(dMat, U); mats.push(dMat);
  const drones = new THREE.InstancedMesh(dGeo, dMat, 8); drones.castShadow = true; drones.frustumCulled = false; group.add(drones);
  const dScale = dp ? 1.7 : 2.6;
  const setDrone = (i, x, y, z, yaw = 0, show = true) => { M4.compose(P.set(x, y, z), Q.setFromAxisAngle(new THREE.Vector3(0, 1, 0), yaw), S.setScalar(show ? dScale : 0)); drones.setMatrixAt(i, M4); };
  for (let i = 0; i < 8; i++) setDrone(i, 0, -10, 0, 0, false); drones.instanceMatrix.needsUpdate = true;
  // ------------------------------------------------------------------ barriers (blocked links): two posts and a striped board
  const barM = new THREE.MeshStandardMaterial({ color: new THREE.Color(T.data.noentry), roughness: .55, emissive: new THREE.Color(T.data.noentry), emissiveIntensity: .25 }), postM = mkMat(K.legs || '#8C86A8'); mats.push(barM);
  const barBoard = new THREE.InstancedMesh(box, barM, 128), barPost = new THREE.InstancedMesh(box, postM, 128); for (const m of [barBoard, barPost]) { m.count = 0; m.castShadow = true; m.frustumCulled = false; group.add(m); }
  function setBarriers(list) {
    // list: [{ p: [x, y, z], along: 'x'|'z', w, storey }]
    let nb = 0, np = 0;
    for (const b of list) { if (level != null && b.storey > level) continue; const ax = b.along === 'x', w = Math.max(0.5, b.w);
      M4.compose(P.set(b.p[0], b.p[1] + 0.9, b.p[2]), Q.set(0, 0, 0, 1), S.set(ax ? w : 0.08, 0.34, ax ? 0.08 : w)); barBoard.setMatrixAt(nb++, M4); M4.compose(P.set(b.p[0], b.p[1] + 0.45, b.p[2]), Q.set(0, 0, 0, 1), S.set(ax ? w : 0.08, 0.16, ax ? 0.08 : w)); barBoard.setMatrixAt(nb++, M4);
      for (const sg of [-1, 1]) { M4.compose(P.set(b.p[0] + (ax ? sg * w / 2 : 0), b.p[1] + 0.5, b.p[2] + (ax ? 0 : sg * w / 2)), Q.set(0, 0, 0, 1), S.set(0.07, 1.0, 0.07)); barPost.setMatrixAt(np++, M4); } }
    barBoard.count = nb; barPost.count = np; barBoard.instanceMatrix.needsUpdate = true; barPost.instanceMatrix.needsUpdate = true;
  }
  // ------------------------------------------------------------------ beds (the night: everyone starts asleep)
  // a low frame, a sheet, a pillow at the head and a blanket over the legs; list: [{ x, y (floor), z, yaw }], the head
  // toward -(sin yaw, cos yaw), as people.set(..., lie) lays a person
  const bedM = mkMat(K.legs || '#8C86A8', { r: .8 }), sheetM = mkMat(K.prop ? new THREE.Color('#EDE6EA').lerp(new THREE.Color(K.prop.color), K.prop.mix).getStyle() : '#EDE6EA', { r: .9 }), blanketM = mkMat(K.van || '#B9B2CC', { r: .9 });
  const bedParts = [[bedM, 0.92, 0.3, 2.02, 0, 0.15, 0], [sheetM, 0.86, 0.14, 1.96, 0, 0.37, 0], [sheetM, 0.6, 0.1, 0.34, 0, 0.49, -0.78], [blanketM, 0.94, 0.12, 1.1, 0, 0.62, 0.42]];
  const beds = bedParts.map(([m]) => { const im = new THREE.InstancedMesh(box, m, 128); im.count = 0; im.castShadow = true; im.receiveShadow = true; im.frustumCulled = false; group.add(im); return im; });
  const BED_TOP = 0.44, V3 = new THREE.Vector3(), QY = new THREE.Quaternion(), YAX = new THREE.Vector3(0, 1, 0);
  function setBeds(list, blanket = 1) {
    let n = 0;
    for (const b of list) { if (n >= 128) break; if (level != null && b.storey > level) continue; QY.setFromAxisAngle(YAX, b.yaw);
      bedParts.forEach(([, w, h, l, ox, oy, oz], k) => { V3.set(ox, 0, oz).applyQuaternion(QY); M4.compose(P.set(b.x + V3.x, b.y + oy, b.z + V3.z), QY, S.set(w, k === 3 ? h * blanket : h, l)); beds[k].setMatrixAt(n, M4); }); n++; }
    for (const im of beds) { im.count = n; im.instanceMatrix.needsUpdate = true; }
  }
  // ------------------------------------------------------------------ cutaway and dim
  let level = null; const Z = new THREE.Matrix4().makeScale(0, 0, 0);
  let section = false;
  function vis() { for (const it of inst) { for (let i = 0; i < it.storeys.length; i++) { const s = it.storeys[i]; it.mesh.setMatrixAt(i, (level == null || s <= level) && !(section && it.sec[i]) ? it.mats4[i] : Z); } it.mesh.instanceMatrix.needsUpdate = true; } for (const t of trees) t.visible = !section; }
  function cutaway(lv) { if (lv === level) return; level = lv; vis(); }
  function setSection(on) { on = !!on; if (on === section) return; section = on; vis(); }
  const bounds = new THREE.Box3(new THREE.Vector3(-L / 2 - 5, 0, -D / 2 - 5), new THREE.Vector3(L / 2 + 5, 14, site.street.z1));
  const ts = T.sky, sky = { ...ts, sun: { ...ts.sun, dir: new THREE.Vector3(...ts.sun.dir) }, hemi: { ...ts.hemi } };
  const padSlots = []; for (let i = 0; i < 8; i++) { const a = i / 8 * Math.PI * 2; padSlots.push([site.pad.x + Math.cos(a) * .7, .06, site.pad.z + Math.sin(a) * .7]); }
  return {
    group, U, drones, setDrone, padSlots, bounds, sky, leaf, scooters, setBarriers, setBeds, BED_TOP, cutaway, setSection, get section() { return section; }, get level() { return level; },
    anchors: { pad: [site.pad.x, 0, site.pad.z], table: [site.table.x, 0.95, site.table.z], anchor: [site.anchor.x, 0, site.anchor.z], mast: [site.anchor.x + 0.42, 3.0, site.anchor.z], van: [site.van.x, 0, site.van.z] },
    setRear(open) { leaf.visible = !open; },
    setClutter(on) { scooters.visible = on; },
    fadeNeighbours(cam, tgt, dt) {
      for (const f of fades) {
        const b = f.bb, o = [cam.x, cam.y, cam.z];
        const seg = (ty) => { let t0 = 0, t1 = 1; const d = [tgt.x - cam.x, ty - cam.y, tgt.z - cam.z]; for (let i = 0; i < 3; i++) { const lo = b[i] - .6, hi = b[i + 3] + .6; if (Math.abs(d[i]) < 1e-9) { if (o[i] < lo || o[i] > hi) return false; continue; } let a1 = (lo - o[i]) / d[i], a2 = (hi - o[i]) / d[i]; if (a1 > a2) { const t = a1; a1 = a2; a2 = t; } t0 = Math.max(t0, a1); t1 = Math.min(t1, a2); if (t0 > t1) return false; } return true; };
        const hit = seg(tgt.y) || seg(Math.max(.5, tgt.y - 4)); const goal = hit ? .16 : 1; f.k += (goal - f.k) * (1 - Math.exp(-(dt || .1) * 4)); if (Math.abs(f.k - goal) < .01) f.k = goal;
        const tr = f.k < .99; f.mat.transparent = tr; f.mat.opacity = f.k; f.mat.depthWrite = !tr; f.m.castShadow = !tr; f.m.renderOrder = tr ? 3 : 0;
      }
    },
    setDim(d) { U.dim.value = d; },
    dispose() { for (const g of geos) g.dispose(); for (const m of mats) { if (m.map) m.map.dispose(); m.dispose(); } for (const it of inst) it.mesh.dispose(); for (const im of beds) im.dispose(); drones.dispose(); barBoard.dispose(); barPost.dispose(); if (winTex) winTex.dispose(); },
  };
}
