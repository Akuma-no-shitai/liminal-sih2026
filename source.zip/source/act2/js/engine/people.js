// People as soft clay figures: one instanced body (legs, torso, arms) and one instanced head, so a hundred people cost
// two draw calls. Clothes in a few muted tones of the theme's clay; no faces, real proportions (about 1.7 m), widths
// from each person's radius in the crowd model. They stand where the crowd model puts them, turned the way they walk,
// and once out they walk on to a gathering spot on the pavement.
import * as THREE from 'three';
import { mergeGeometries } from 'three/addons/utils/BufferGeometryUtils.js';
import { dimPatch } from './world.js';

const CLOTHES = {
  dusk: ['#C7A9B2', '#A9B1CC', '#B7C2B0', '#D8C2A8', '#9E9AB8', '#C9B7C9', '#AFC3C6', '#D1B19F'],
  overcast: ['#9AA3AA', '#B49A84', '#8E9C8C', '#C2B49B', '#7F8796', '#A88F86', '#9BA9A8', '#B8AA94'],
  graphite: ['#7C7468', '#6D7680', '#7A8274', '#8E8170', '#6A6E78', '#857671', '#717E80', '#8A7C68'],
  bluedawn: ['#8EA0B0', '#A89184', '#8FA394', '#BFAE98', '#7E8A9C', '#A28E97', '#93A8A9', '#B49F8A'],
};
const SKIN = ['#C99B7E', '#B68468', '#D9AE8E', '#9E7058', '#E0BBA0', '#A87A60'];

function bodyGeometry() {
  const parts = [];
  const add = (g, x, y, z, sx = 1, sy = 1, sz = 1) => { g.scale(sx, sy, sz); g.translate(x, y, z); parts.push(g.index ? g.toNonIndexed() : g); };
  add(new THREE.CylinderGeometry(0.075, 0.06, 0.84, 10), -0.085, 0.42, 0);            // legs
  add(new THREE.CylinderGeometry(0.075, 0.06, 0.84, 10), 0.085, 0.42, 0);
  add(new THREE.CylinderGeometry(0.17, 0.15, 0.62, 14), 0, 1.13, 0, 1, 1, 0.68);      // torso (flattened front to back)
  add(new THREE.SphereGeometry(0.17, 14, 8, 0, Math.PI * 2, 0, Math.PI / 2), 0, 1.43, 0, 1.05, 0.5, 0.7);   // shoulders
  add(new THREE.CylinderGeometry(0.045, 0.038, 0.62, 8), -0.215, 1.12, 0);            // arms
  add(new THREE.CylinderGeometry(0.045, 0.038, 0.62, 8), 0.215, 1.12, 0);
  add(new THREE.CylinderGeometry(0.05, 0.055, 0.08, 8), 0, 1.52, 0);                  // neck
  const g = mergeGeometries(parts); g.computeVertexNormals(); return g;
}
function headGeometry() { const g = new THREE.SphereGeometry(0.105, 16, 12); g.scale(0.92, 1.08, 1); g.translate(0, 1.645, 0.0); return g; }

export function createPeople(scene, { max = 128, theme, seed = 1 } = {}) {
  const U = { dim: { value: 0 } };
  const mBody = dimPatch(new THREE.MeshStandardMaterial({ color: 0xffffff, roughness: 0.88, metalness: 0 }), U);
  const mHead = dimPatch(new THREE.MeshStandardMaterial({ color: 0xffffff, roughness: 0.8, metalness: 0 }), U);
  const gB = bodyGeometry(), gH = headGeometry();
  const body = new THREE.InstancedMesh(gB, mBody, max), head = new THREE.InstancedMesh(gH, mHead, max);
  for (const m of [body, head]) { m.castShadow = true; m.receiveShadow = false; m.frustumCulled = false; m.count = 0; scene.add(m); }

  const pal = CLOTHES[theme && theme.id] || CLOTHES.dusk, col = new THREE.Color();
  let h = (seed * 2654435761) >>> 0; const rnd = () => { h = (h * 16807) % 2147483647; return h / 2147483647; };
  const scale = new Float32Array(max), yaw = new Float32Array(max), tall = new Float32Array(max);
  for (let i = 0; i < max; i++) { col.set(pal[i % pal.length]).offsetHSL(0, (rnd() - .5) * 0.04, (rnd() - .5) * 0.06); body.setColorAt(i, col); col.set(SKIN[Math.floor(rnd() * SKIN.length)]); head.setColorAt(i, col); tall[i] = 0.94 + rnd() * 0.12; }
  body.instanceColor.needsUpdate = true; head.instanceColor.needsUpdate = true;
  // see-through silhouettes: the same figures drawn again, flat and faint in their own colours, only where something
  // stands in front of them (depth test reversed), so in the cut-open building nobody vanishes behind a slab edge or a bed
  const mGhost = new THREE.MeshBasicMaterial({ color: 0xffffff, transparent: true, opacity: 0.38, depthWrite: false, depthFunc: THREE.GreaterDepth, fog: false });
  const ghosts = [gB, gH].map((g, k) => { const src = k ? head : body, m = new THREE.InstancedMesh(g, mGhost, max); m.instanceMatrix = src.instanceMatrix; m.instanceColor = src.instanceColor; m.frustumCulled = false; m.count = 0; m.renderOrder = 12; m.visible = false; scene.add(m); return m; });
  const M = new THREE.Matrix4(), P = new THREE.Vector3(), Q = new THREE.Quaternion(), Q2 = new THREE.Quaternion(), S = new THREE.Vector3(), Y = new THREE.Vector3(0, 1, 0), X = new THREE.Vector3(1, 0, 0);
  return {
    body, head, U,
    // place person i (r: crowd radius, scaled by it; yaw: heading in radians; show false hides it). lie (0-1): lying
    // on their back, head toward -z of their heading frame, centred on (x, z), body on top of a bed whose top is at y
    set(i, x, y, z, r, heading, show = true, bob = 0, lie = 0) {
      if (i >= max) return; const w = show ? Math.max(0.8, r / 0.3) : 0, t = show ? tall[i] : 0;
      if (lie > 0.001) {
        Q.setFromAxisAngle(Y, heading); Q2.setFromAxisAngle(X, -Math.PI / 2 * lie); Q.multiply(Q2);
        const off = 0.85 * t * lie; P.set(x + Math.sin(heading) * off, y + 0.1 * lie + bob, z + Math.cos(heading) * off);
        M.compose(P, Q, S.set(w, t, w));
      } else M.compose(P.set(x, y + bob, z), Q.setFromAxisAngle(Y, heading), S.set(w, t, w));
      body.setMatrixAt(i, M); head.setMatrixAt(i, M);
    },
    count(n) { body.count = Math.min(max, n); head.count = Math.min(max, n); for (const g of ghosts) g.count = body.count; },
    done() { body.instanceMatrix.needsUpdate = true; head.instanceMatrix.needsUpdate = true; },
    visible(on) { body.visible = on; head.visible = on; if (!on) for (const g of ghosts) g.visible = false; },
    // the silhouettes (on in the cut-open view)
    seeThrough(on) { for (const g of ghosts) g.visible = !!on && body.visible; },
    setDim(d) { U.dim.value = d; },
    dispose() { scene.remove(body); scene.remove(head); for (const g of ghosts) scene.remove(g); gB.dispose(); gH.dispose(); mBody.dispose(); mHead.dispose(); mGhost.dispose(); body.dispose(); head.dispose(); },
  };
}

// playback of a recorded run: positions at sim time t (interpolated between frames), headings from the motion, and a
// gathering spot on the pavement for everyone who is out
export function playRun(rec, W, model) {
  const n = rec.r.length, F = rec.frames, T = rec.tFrames, { D, L } = model.dims;
  const head = new Float32Array(n), spot = [];
  for (let i = 0; i < n; i++) { const row = Math.floor(i / 12), col = i % 12; spot.push([(col - 5.5) * 0.85 + (row % 2) * 0.4, 0.02, D / 2 + 3.2 + 2.3 + row * 0.8]); }
  const exitAt = new Float32Array(n * 2);
  // where each person stepped out (their last position on the floor)
  for (let i = 0; i < n; i++) { let k = F.length - 1; while (k > 0 && F[k][i * 3 + 2] < 0) k--; exitAt[i * 2] = F[k][i * 3]; exitAt[i * 2 + 1] = F[k][i * 3 + 1]; }
  return {
    n, tEnd: T[T.length - 1],
    // out: callback(i, x, y, z, heading, moving 0-1, hidden). away: (the section view) once out, people walk off along
    // the pavement, half each way, instead of gathering in front of the block where they would hide the ground floor
    at(t, out, away = false) {
      let k = Math.max(0, Math.min(T.length - 2, Math.floor(t / (T[1] - T[0] || 0.1)))); while (k > 0 && T[k] > t) k--; while (k < T.length - 2 && T[k + 1] < t) k++;
      const a = F[k], b = F[k + 1], u = Math.max(0, Math.min(1, (t - T[k]) / Math.max(1e-6, T[k + 1] - T[k])));
      for (let i = 0; i < n; i++) {
        const da = a[i * 3 + 2], db = b[i * 3 + 2];
        if (da < 0 || (db < 0 && u > 0.5) || (rec.outT[i] >= 0 && t >= rec.outT[i])) {
          // out: walk from the door to the gathering spot in about 4 s
          const te = rec.outT[i] >= 0 ? rec.outT[i] : T[k];
          if (away) { const ex = exitAt[i * 2], ez = exitAt[i * 2 + 1]; if (ez < 0) { out(i, ex, 0.02, ez, Math.PI, 1, true); continue; }
            const zp = D / 2 + 3.7 + (i % 3) * 0.45, sg = i % 2 ? 1 : -1, d = Math.max(0, t - te) * 1.4, l1 = Math.max(0, zp - ez), far = L / 2 + 16;
            if (d < l1) out(i, ex, 0.02, ez + d, 0, 1); else { const xx = ex + sg * (d - l1); if (Math.abs(xx) > far) out(i, xx, 0.02, zp, 0, 0, true); else out(i, xx, 0.02, zp, sg * Math.PI / 2, 1); }
            continue; }
          const w = Math.max(0, Math.min(1, (t - te) / 4)), s = spot[i];
          const ex = exitAt[i * 2], ez = exitAt[i * 2 + 1] > 0 ? Math.max(exitAt[i * 2 + 1], D / 2 + 1.2) : exitAt[i * 2 + 1];
          const tx = ez < 0 ? ex + (s[0] - ex) * w : ex + (s[0] - ex) * w, tz = ez < 0 ? ez - w * 1.5 : ez + (s[2] - ez) * w;
          out(i, tx, 0.02, tz, Math.atan2(s[0] - ex, (ez < 0 ? -1 : s[2] - ez)), w < 1 ? 1 : 0); continue;
        }
        const x = a[i * 3] + (b[i * 3] - a[i * 3]) * (db < 0 ? 0 : u), z = a[i * 3 + 1] + (b[i * 3 + 1] - a[i * 3 + 1]) * (db < 0 ? 0 : u), dom = da;
        const vx = b[i * 3] - a[i * 3], vz = b[i * 3 + 1] - a[i * 3 + 1], sp = Math.hypot(vx, vz);
        if (sp > 0.01) { const want = Math.atan2(vx, vz); let d = want - head[i]; d = Math.atan2(Math.sin(d), Math.cos(d)); head[i] += d * 0.5; }
        out(i, x, W.heightAt(dom, x, z), z, head[i], Math.min(1, sp / 0.12));
      }
    },
  };
}
