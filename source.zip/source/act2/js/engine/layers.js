// Act 2's overlay layers, built from the case, each with a weight the lenses ease (built lazily, the first time they
// are needed). One horizontal clipping plane (the floor cutaway) is shared by every overlay.
//   cloud    the baseline point cloud, revealed in the order the survey took it
//   vox      the baseline voxel map (occupied 12 cm voxels, greedy-meshed)
//   tracks   the drones' flight paths, drawn up to the moment of the film; scan stops as small glows
//   skeleton the free space thinned to a path network (act7's routes on the survey map), per floor
//   graph    the access graph: doors, corridor segments, stair flights; weak links (bridges) warm, loops teal,
//            dead-end hall stubs dashed
//   risk     every link coloured by how many people its loss alone would cut off
//   heat     people per square metre, as soft splats on the floor (rebuilt every frame from the crowd)
//   flows    people per second through each door (rebuilt every frame)
//   doors    the doors the survey measured, as small marks
import * as THREE from 'three';
import { greedyMesh } from '../../../act7/js/engine/voxmesh.js';
import { createLines as createLines0, createGlows as createGlows0 } from '../../../act7/js/engine/lines.js';
import { getTheme } from '../../../act7/js/theme.js';
import { O_OCC } from '../../../act7/js/pipe/occupancy.js';
import { floorTop } from '../../../act7/js/building/building.js';

const C3 = (h) => new THREE.Color(h);
let TH = getTheme('dusk'), PAL;
function setPal(T) { TH = T; const d = T.data; PAL = { teal: C3(d.swarm), rose: C3(d.added), apr: C3(d.mid), heat: C3(d.caution), danger: C3(d.noentry), lav: C3(d.empty), haze: C3(d.unseen), paper: C3(d.paper), safe: C3(d.safe), base: C3(d.base) }; }
setPal(TH);
const createGlows = (cap, o = {}) => createGlows0(cap, TH.data.additive || o.additive === false ? o : { ...o, additive: false, premul: true });
const createLines = (cap, o = {}) => createLines0(cap, { ...(TH.data.additive || !o.additive ? o : { ...o, additive: false, premul: true }), packetColor: TH.data.linePacket });
const lin = (c) => [c.r, c.g, c.b];
// a faint copy of a line mesh drawn through walls (same buffers, no depth test): from above, the walls of a cut-away
// floor hide much of a plan drawn at floor level; the copy keeps the whole network readable, the solid one stays on top
// where nothing is in the way. Only the floor at the cut shows its copy (the floors below stay under their slabs).
function xray(mesh, k = .38) { const m = mesh.material.clone(); m.depthTest = false; m.uniforms.op.value = k; m.userData.xk = k; const x = new THREE.Mesh(mesh.geometry, m); x.frustumCulled = false; x.renderOrder = mesh.renderOrder - 1; x.userData.xray = true; return x; }
export const densityColor = (rho) => { const c = PAL.teal.clone(); if (rho < 1) return c.lerp(PAL.apr, Math.max(0, rho - 0.3) / 0.7 * 0.5); if (rho < 3) return PAL.apr.clone().lerp(PAL.heat, (rho - 1) / 2); return PAL.heat.clone().lerp(PAL.danger, Math.min(1, (rho - 3) / 2)); };

function cloudMaterial(color, size, clip) {
  return new THREE.ShaderMaterial({
    transparent: true, depthWrite: false, clipping: true, clippingPlanes: [clip], fog: false,
    uniforms: { col: { value: color.clone() }, alpha: { value: 0 }, size: { value: size }, px: { value: 1 }, hh: { value: 800 }, tReveal: { value: 1e9 } },
    vertexShader: `attribute float at; uniform float size, px, hh, tReveal; varying float vA;
      #include <clipping_planes_pars_vertex>
      void main(){ vec4 mvPosition = modelViewMatrix * vec4(position, 1.); gl_Position = projectionMatrix * mvPosition;
        #include <clipping_planes_vertex>
        vA = at <= tReveal ? 1. : 0.; float fresh = at <= tReveal ? smoothstep(4., 0., tReveal - at) : 0.;
        float s = size * (1. + fresh * .35) * projectionMatrix[1][1] * hh * .5 / max(.1, -mvPosition.z); gl_PointSize = vA > 0. ? clamp(s, 1.3 * px, 6. * px) : 0.; }`,
    fragmentShader: `uniform vec3 col; uniform float alpha; varying float vA;
      #include <clipping_planes_pars_fragment>
      void main(){
        #include <clipping_planes_fragment>
        if (vA < .5) discard; vec2 q = gl_PointCoord - .5; float d = length(q) * 2.; if (d > 1.) discard;
        float a = alpha * (1. - smoothstep(.65, 1., d)); gl_FragColor = vec4(col, a); }`,
  });
}

export function createLayers(scene, C, world, opts = {}) {
  setPal(opts.theme || getTheme('dusk'));
  const root = new THREE.Group(); root.name = 'layers'; scene.add(root);
  const clip = new THREE.Plane(new THREE.Vector3(0, -1, 0), 1000);
  const L = {}, disposers = [], SV = C.survey;
  // the graph the 'graph' and 'risk' layers draw (the survey's, or a fix's, or the sandbox's)
  let cur = { G: C.G, weak: C.percSummary.weak, bridges: C.perc.bridgeIds, dead: C.deadEnds };
  const pend = (o, f) => { disposers.push(f); return o; };
  const get = {
    cloud() {
      const n = SV.cloud.n, MAXP = 340000, st = n > MAXP ? Math.ceil(n / MAXP) : 1, m = Math.floor(n / st), pos = new Float32Array(m * 3), at = new Float32Array(m);
      for (let i = 0; i < m; i++) { const j = i * st; pos[i * 3] = SV.cloud.pts[j * 3]; pos[i * 3 + 1] = SV.cloud.pts[j * 3 + 1]; pos[i * 3 + 2] = SV.cloud.pts[j * 3 + 2]; at[i] = SV.cloud.t[j]; }
      const g = new THREE.BufferGeometry(); g.setAttribute('position', new THREE.BufferAttribute(pos, 3)); g.setAttribute('at', new THREE.BufferAttribute(at, 1));
      const mat = cloudMaterial(PAL.base, 0.032, clip), p = new THREE.Points(g, mat); p.frustumCulled = false; p.renderOrder = 4; root.add(p);
      return pend(p, () => { g.dispose(); mat.dispose(); });
    },
    vox() {
      // walls, columns, stairs and what stands on the floors: the slab surfaces (one flat sheet each, mottled by range
      // noise) are left out so the plan reads
      const g = SV.g, lab = new Uint8Array(g.N), SY = g.nx * g.nz;
      for (let j = 0; j < g.ny; j++) { const y = g.y0 + (j + .5) * g.vox, u = (((y - 0.15) % 3) + 3) % 3; if (y < 0.3 || u < 0.22 || u > 2.62) continue; const o = j * SY; for (let c = 0; c < SY; c++) if (SV.S[o + c] === O_OCC) lab[o + c] = 1; }
      const geos = greedyMesh(g, lab, [1]); const geo = geos.get(1); const grp = new THREE.Group(); if (!geo) { root.add(grp); return grp; }
      const m = new THREE.MeshStandardMaterial({ color: PAL.teal.clone().lerp(PAL.paper, .55), roughness: .75, metalness: 0, transparent: true, opacity: 0, clippingPlanes: [clip], emissive: PAL.teal, emissiveIntensity: .1 });
      const mesh = new THREE.Mesh(geo, m); mesh.renderOrder = 3; grp.add(mesh); root.add(grp);
      grp.userData.setW = (w) => { m.opacity = w * 0.92; m.transparent = w < .99; m.depthWrite = w > .5; grp.visible = w > .01; };
      return pend(grp, () => { geo.dispose(); m.dispose(); });
    },
    tracks() {
      const segs = []; for (const tr of SV.tracks) for (let i = 1; i < tr.length; i++) segs.push([tr[i - 1], tr[i]]);
      const lines = createLines(segs.length + 8, { width: 1.6, additive: true }), glow = createGlows(SV.stops.length + 8, { minPx: 4 });
      const grp = new THREE.Group(); grp.add(lines.mesh, glow.mesh); root.add(grp);
      const tl = lin(PAL.teal);
      grp.userData.upto = (t) => {
        lines.begin(); for (const [a, b] of segs) { if (a.t > t) continue; const u = b.t <= t ? 1 : (t - a.t) / Math.max(1e-3, b.t - a.t); const age = Math.max(0, t - b.t); const al = .18 + .5 * Math.exp(-age / 40);
          lines.seg(a.p[0], a.p[1], a.p[2], a.p[0] + (b.p[0] - a.p[0]) * u, a.p[1] + (b.p[1] - a.p[1]) * u, a.p[2] + (b.p[2] - a.p[2]) * u, ...tl, al); } lines.end();
        glow.begin(); for (const s of SV.stops) { if (s.t > t) break; const age = t - s.t; glow.add(s.p[0], s.p[1], s.p[2], ...tl, .25 + .6 * Math.exp(-age / 6), .12 + .2 * Math.exp(-age / 6)); } glow.end();
      };
      grp.userData.upto(1e9);
      return pend(grp, () => { lines.dispose(); glow.dispose(); });
    },
    skeleton() {
      const grp = new THREE.Group(), all = [];
      for (const f of C.routes) { const lines = createLines(f.edges.reduce((s, e) => s + e.pts.length, 0) + 8, { width: 2.4, additive: false }); lines.begin(); const hz = lin(PAL.paper.clone().lerp(PAL.teal, .35));
        for (const e of f.edges) for (let i = 1; i < e.pts.length; i++) lines.seg(e.pts[i - 1][0], e.pts[i - 1][1] + .04, e.pts[i - 1][2], e.pts[i][0], e.pts[i][1] + .04, e.pts[i][2], ...hz, .9);
        lines.end(); const sg = new THREE.Group(); sg.userData.storey = f.storey; const xr = xray(lines.mesh, .3); sg.add(xr, lines.mesh); grp.add(sg); all.push(lines, { dispose: () => xr.material.dispose() }); }
      root.add(grp); return pend(grp, () => { for (const x of all) x.dispose(); });
    },
    graph() { return graphLayer(false); },
    // the loop the rear door makes: in through the street door, out through the rear door, round the side of the block
    loop() {
      const { L, D } = C.model.dims, y = 0.3, rear = C.model.openings.find((o) => o.kind === 'rear'), rx = (rear.o0 + rear.o1) / 2, zc = (C.model.dims.zb + C.model.dims.zf) / 2;
      const pts = [[0, y, zc], [0, y, D / 2 - .6], [0, y, D / 2 + 1.3], [L / 2 + 1.6, y, D / 2 + 1.3], [L / 2 + 1.6, y, -D / 2 - 1.3], [rx, y, -D / 2 - 1.3], [rx, y, -D / 2 + .4], [rx, y, C.stair.zTop + .5], [0.6, y, C.model.dims.zb], [0, y, zc]];
      const lines = createLines(64, { width: 3.4, additive: true, packets: true }); lines.begin(); let u = 0; const tl = lin(PAL.teal);
      for (let i = 1; i < pts.length; i++) { const a = pts[i - 1], b = pts[i], l2 = Math.hypot(b[0] - a[0], b[2] - a[2]); lines.seg(...a, ...b, ...tl, .85, .85, u, u + l2, 1); u += l2; }
      lines.end(); lines.mesh.renderOrder = 9; const grp = new THREE.Group(), xr = xray(lines.mesh, .45); grp.add(xr, lines.mesh); root.add(grp); return pend(grp, () => { lines.dispose(); xr.material.dispose(); });
    },
    risk() { return graphLayer(true); },
    doors() {
      const glow = createGlows(C.base.doors.length + 4, { minPx: 6 }); glow.begin();
      for (const d of C.base.doors) { const o = C.model.openings[d.id]; const p = o.axis === 'x' ? [o.off, o.y0 + 0.05, (o.o0 + o.o1) / 2] : [(o.o0 + o.o1) / 2, o.y0 + 0.05, o.off]; glow.add(...p, ...lin(d.closed ? PAL.danger : PAL.teal), .9, .3); }
      glow.end(); root.add(glow.mesh); return pend(glow.mesh, () => glow.dispose());
    },
    heat() {
      const glow = createGlows(160, { minPx: 3 }); root.add(glow.mesh); glow.mesh.renderOrder = 7;
      // (k: a smaller, fainter splat for the side-on cut-open view, where a splat stands up in front of the person)
      glow.mesh.userData.set = (pts, k = 1) => { glow.begin(); for (const q of pts) { const c = densityColor(q.rho); glow.add(q.x, q.y + 0.06, q.z, c.r, c.g, c.b, Math.min(.95, .45 + q.rho * .14) * (k < 1 ? .8 : 1), (1.1 + Math.min(0.9, q.rho * .22)) * k); } glow.end(); };
      return pend(glow.mesh, () => glow.dispose());
    },
    // room lights at night and the alarm: soft glows; set([{ x, y, z, c: [r, g, b], a, s }])
    lights() {
      const glow = createGlows(96, { minPx: 4 }); root.add(glow.mesh); glow.mesh.renderOrder = 6;
      glow.mesh.userData.set = (pts) => { glow.begin(); for (const q of pts) glow.add(q.x, q.y, q.z, q.c[0], q.c[1], q.c[2], q.a, q.s); glow.end(); };
      return pend(glow.mesh, () => glow.dispose());
    },
    flows() {
      const glow = createGlows(80, { minPx: 5 }); root.add(glow.mesh); glow.mesh.renderOrder = 8;
      glow.mesh.userData.set = (list) => { glow.begin(); for (const q of list) { const c = q.rate > 1.2 ? PAL.heat : PAL.teal; glow.add(q.p[0], q.p[1] + 0.25, q.p[2], c.r, c.g, c.b, Math.min(1, .45 + q.rate * .4), .35 + Math.min(.6, q.rate * .25)); } glow.end(); };
      return pend(glow.mesh, () => glow.dispose());
    },
  };
  // the access graph: per floor, each link a line between its two nodes (doors short and bold), coloured by its role
  function graphLayer(risk) {
    const grp = new THREE.Group(), all = [], per = new Map(), G = cur.G;
    const lineOf = (s) => { if (!per.has(s)) { const lines = createLines(900, { width: 3.2, additive: false }), dash = createLines(200, { width: 2.4, additive: false, dash: .35 }), glow = createGlows(260, { minPx: 7 }); lines.begin(); dash.begin(); glow.begin(); const sg = new THREE.Group(); sg.userData.storey = s; const xl = xray(lines.mesh), xd = xray(dash.mesh); sg.add(xl, xd, lines.mesh, dash.mesh, glow.mesh); grp.add(sg); per.set(s, { lines, dash, glow }); all.push(lines, dash, glow, { dispose: () => { xl.material.dispose(); xd.material.dispose(); } }); } return per.get(s); };
    const weak = new Map((cur.weak || []).map(([id, n]) => [id, n])), bridges = new Set(cur.bridges), maxP = Math.max(1, ...weak.values());
    for (const l of G.links) {
      const A = G.nodes[l.a].p, s = l.kind === 'flight' ? l.storey + (l.upper ? 1 : 0) : l.storey, o = lineOf(Math.max(0, Math.min(3, s)));
      // an exit is drawn to just outside its door (the outside is one node in the graph, but not one place)
      const B = l.exit ? (l.exit === 'street' ? [0, l.p[1], C.model.dims.D / 2 + 1.3] : [l.p[0], l.p[1], -C.model.dims.D / 2 - 1.3]) : G.nodes[l.b].p;
      if (l.locked) { o.dash.seg(A[0], A[1] + .12, A[2], B[0], B[1] + .12, B[2], ...lin(PAL.haze), .8, .8, 0, Math.hypot(B[0] - A[0], B[2] - A[2])); continue; }
      let c, a = .95;
      if (risk) { const k = (weak.get(l.id) || 0) / maxP; c = k > 0 ? PAL.heat.clone().lerp(PAL.danger, Math.min(1, k * 1.2)) : PAL.teal.clone().lerp(PAL.paper, .3); a = k > 0 ? .95 : .45; }
      else c = bridges.has(l.id) ? PAL.heat : PAL.teal;
      // a door link runs through its door (so it never seems to cross a wall)
      if (l.kind === 'door' && !l.exit) { const D2 = l.p; o.lines.seg(A[0], A[1] + .12, A[2], D2[0], A[1] + .12, D2[2], ...lin(c), a); o.lines.seg(D2[0], A[1] + .12, D2[2], B[0], B[1] + .12, B[2], ...lin(c), a); }
      else if (l.kind === 'flight') { const M = l.p; o.lines.seg(A[0], A[1] + .12, A[2], M[0], M[1] + .12, M[2], ...lin(c), a); o.lines.seg(M[0], M[1] + .12, M[2], B[0], B[1] + .12, B[2], ...lin(c), a); }
      else o.lines.seg(A[0], A[1] + .12, A[2], B[0], B[1] + .12, B[2], ...lin(c), a);
      if (l.kind === 'door' || l.kind === 'flight') o.glow.add(l.p[0], l.p[1] + .14, l.p[2], ...lin(c), .9, risk ? .14 + .4 * ((weak.get(l.id) || 0) / maxP) : .16);
    }
    if (!risk) for (const d of cur.dead) { const o = lineOf(G.nodes[d.node].storey), A = G.nodes[d.node].p, e = d.p; const ex = A[0] + (e[0] - A[0]) * 2; o.dash.seg(A[0], A[1] + .12, A[2], ex, A[1] + .12, A[2], ...lin(PAL.lav), .9, .9, 0, Math.abs(ex - A[0])); }
    for (const n of G.nodes) { if (n.kind === 'out') continue; const o = lineOf(Math.max(0, Math.min(3, n.storey))); o.glow.add(n.p[0], n.p[1] + .14, n.p[2], ...lin(PAL.paper), n.kind === 'room' ? .8 : .6, n.kind === 'room' ? .16 : .1); }
    for (const v of per.values()) { v.lines.end(); v.dash.end(); v.glow.end(); }
    root.add(grp); return pend(grp, () => { for (const x of all) x.dispose(); });
  }
  const ensure = (name) => { if (!(name in L)) { try { L[name] = get[name](); } catch (e) { console.warn('[act2] layer', name, e); L[name] = null; } } return L[name]; };
  const setW = (name, w) => {
    if (w <= .005 && !L[name]) return; const o = ensure(name); if (!o) return;
    if (o.userData && o.userData.setW) { o.userData.setW(w); return; }
    if (o.isPoints) { o.visible = w > .005; o.material.uniforms.alpha ? (o.material.uniforms.alpha.value = w) : (o.material.uniforms.op && (o.material.uniforms.op.value = w)); if (o.material.uniforms.op) o.material.uniforms.op.value = w; return; }
    o.visible = w > .005; o.traverse((x) => { if (x.material && x.material.uniforms) { if (x.material.uniforms.op) x.material.uniforms.op.value = w * (x.material.userData.xk ?? 1); if (x.material.uniforms.alpha) x.material.uniforms.alpha.value = w; } });
  };
  // per-floor overlays: the floors up to the cut, and the see-through copy only on the floor at the cut
  const floorsTo = (level) => { for (const n of ['skeleton', 'graph', 'risk']) { const g = L[n]; if (!g) continue; for (const s2 of g.children) { const on = level == null || s2.userData.storey <= level; if (s2.visible !== on) s2.visible = on; for (const x of s2.children) if (x.userData.xray) { const xo = level != null && s2.userData.storey === level; if (x.visible !== xo) x.visible = xo; } } } };
  return {
    root, L, clip, ensure, setW, floorsTo, get: (n) => L[n], warm: lin(PAL.apr), alarm: lin(PAL.danger),
    rebuild(name) { const o = L[name]; if (o) { root.remove(o); } delete L[name]; },
    setGraph(g) { cur = g; for (const n of ['graph', 'risk']) if (L[n]) { root.remove(L[n]); delete L[n]; } },
    setCut(level) { if (level == null) { clip.set(new THREE.Vector3(0, -1, 0), 1000); return; } clip.set(new THREE.Vector3(0, -1, 0), (level + 1) * 3 + 0.02); },
    dispose() { for (const d of disposers) { try { d(); } catch (e) { /* ignore */ } } scene.remove(root); },
  };
}
export { floorTop };
