// Lenses: which layers are shown over the clay world. In the World lens the film decides; any other lens pins its
// layers until the viewer goes back to World. Every layer has a weight that eases toward its goal.
export const LENSES = [
  { id: 'world', name: 'World', key: '1', tip: 'The building, with whatever the film is showing now' },
  { id: 'survey', name: 'Survey', key: '2', tip: 'The drones’ flight paths and every scan stop', layers: { tracks: 1, cloud: .55 }, dim: .55, people: 0 },
  { id: 'baseline', name: 'Baseline', key: '3', tip: 'The baseline map: point cloud or voxels, and the doors it measured', layers: { cloud: 1, doors: 1 }, dim: .65, people: 0 },
  { id: 'routes', name: 'Routes', key: '4', tip: 'The path network and the access graph: loops, weak links (warm), dead ends (dashed)', layers: { skeleton: 1, graph: 1 }, dim: .55, people: 0 },
  { id: 'crowd', name: 'Crowd', key: '5', tip: 'The crowd model: people, density (people per m²) and door flows', layers: { heat: 1, flows: 1 }, dim: .35, people: 1 },
  { id: 'risk', name: 'Risk', key: '6', tip: 'How many people each link’s loss alone would cut off', layers: { risk: 1 }, dim: .55, people: 0 },
];
export const LAYERS = ['cloud', 'vox', 'tracks', 'skeleton', 'graph', 'risk', 'doors', 'heat', 'flows', 'loop'];
export function createLenses() {
  let cur = 'world';
  const W = {}; for (const l of LAYERS) W[l] = 0;
  const S = { dim: 0, people: 1 };
  return {
    W, S,
    get current() { return cur; },
    set(id) { if (LENSES.some((l) => l.id === id)) cur = id; },
    update(dt, film = {}) {
      const L = LENSES.find((l) => l.id === cur); const k = 1 - Math.exp(-dt * 5);
      for (const name of LAYERS) { const goal = cur === 'world' ? (film[name] || 0) : (L.layers[name] || 0); W[name] += (goal - W[name]) * k; if (Math.abs(W[name] - goal) < .003) W[name] = goal; }
      const dg = cur === 'world' ? (film.dim || 0) : L.dim; S.dim += (dg - S.dim) * k; if (Math.abs(S.dim - dg) < .003) S.dim = dg;
      const pg = cur === 'world' ? (film.people ?? 1) : L.people; S.people = pg;
    },
  };
}
