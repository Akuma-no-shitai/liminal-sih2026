// The peacetime survey: eight identical drones map the intact building with no set route. They follow the same rule
// as during a disaster: each flies to the nearest unexplored edge (frontier) of the map they share (merged in any order,
// a CRDT), scans there with its tilting LiDAR, and moves on, until no reachable frontier is left. That map is the
// baseline Act 7 compares against.
//   The world is act7's building (and whatever is parked in the lobby on survey day); the scanner is act7's simulated
//   LiDAR (RPLidar A1M8 class, 12 m, σ 1.5 cm) and the map is act7's ray carving. Glass stops drones but not light, so
//   rooms are partly seen through their windows before a drone flies in through the street door and up the stair.
//   Planning works on a 0.36 m grid (known / unknown; where a drone fits is decided by the simulated building), with
//   a vertical step costing three horizontal ones, so the swarm tends to finish a floor before it climbs.
// β₀ of the unexplored space: the number of separate unexplored regions the shared map still opens onto (clusters of
// frontier cells). Zero means nothing reachable is left unknown: the baseline is complete.
import { makeGrid, rasterBox } from '../../../act7/js/building/voxel.js';
import { rasteriseWorld, reachable, L_FREE } from '../../../act7/js/building/truth.js';
import { aabox, rngFor } from '../../../act7/js/building/geom.js';
import { buildScene } from '../../../act7/js/pipe/raycast.js';
import { scan, LIDAR } from '../../../act7/js/pipe/scan.js';
import { makeObs, carve, classify } from '../../../act7/js/pipe/occupancy.js';
import { NS, SH, T_EXT } from '../../../act7/js/building/building.js';

export const DRONES = 8, RAYS = 1000, DWELL = 4, V_IN = 0.7, V_OUT = 1.5, CF = 3;
const PERF = () => (typeof performance !== 'undefined' ? performance.now() : Date.now());
const ID = { R: [1, 0, 0, 0, 1, 0, 0, 0, 1], t: [0, 0, 0] };

// what stands in the world on survey day: the building, its site, the clutter, and the closed rear door
export function surveyWorld(model, clutter) {
  const extra = [];
  for (const b of clutter || []) extra.push({ box: aabox(b.x0, 0, b.z0, b.x1, 1.1, b.z1), kind: 'clutter' });
  const rear = model.openings.find((o) => o.kind === 'rear');
  extra.push({ box: aabox(rear.o0, rear.y0, rear.off - 0.025, rear.o1, rear.y1, rear.off + 0.025), kind: 'leaf' });
  // glass in the windows and balcony doors: no drone passes, light does
  const glass = model.openings.filter((o) => o.kind === 'window' || o.kind === 'balcony').map((o) => (o.axis === 'x' ? aabox(o.off - 0.03, o.y0, o.o0, o.off + 0.03, o.y1, o.o1) : aabox(o.o0, o.y0, o.off - 0.03, o.o1, o.y1, o.off + 0.03)));
  return { extra, glass };
}

export function* survey(model, clutter, seed) {
  const t0 = PERF(), tm = {};
  const g = makeGrid(model.grid), W = surveyWorld(model, clutter);
  const B = rasteriseWorld(model, model.parts, g); for (const e of W.extra) rasterBox(g, e.box, B, 1, { ymin: 0 });
  const noFly = new Uint8Array(g.N); for (const b of W.glass) rasterBox(g, b, noFly, 1);
  const free = new Uint8Array(g.N); for (let c = 0; c < g.N; c++) free[c] = B[c] === L_FREE && !noFly[c] ? 1 : 0;
  const RCH = reachable(g, free, 1), reach = RCH.centre, body = RCH.body;
  tm.world = Math.round(PERF() - t0); yield { p: 0.05 };
  const scene = buildScene([...model.parts.map((p) => p.box), ...W.extra.map((e) => e.box)], { cell: 0.5 });
  // ---- the planning grid
  const { L, D } = model.dims, cs = g.vox * CF, cx = Math.ceil(g.nx / CF), cy = Math.ceil(g.ny / CF), cz = Math.ceil(g.nz / CF), CN = cx * cy * cz, CSY = cx * cz;
  const cidx = (i, j, k) => i + cx * (k + cz * j), ccen = (c, o = [0, 0, 0]) => { const i = c % cx, r = (c - i) / cx, k = r % cz, j = (r - k) / cz; o[0] = g.x0 + (i + .5) * cs; o[1] = g.y0 + (j + .5) * cs; o[2] = g.z0 + (k + .5) * cs; return o; };
  const ccell = (x, y, z) => { const i = Math.floor((x - g.x0) / cs), j = Math.floor((y - g.y0) / cs), k = Math.floor((z - g.z0) / cs); return i < 0 || j < 0 || k < 0 || i >= cx || j >= cy || k >= cz ? -1 : cidx(i, j, k); };
  // what has to be mapped: the building and a 1.2 m shell around it (facades, balconies, roof); the yard and the open
  // air are seen on the way but are not targets
  const vol = { x0: -L / 2 - 1.2, x1: L / 2 + 1.2, z0: -D / 2 - 1.2, z1: D / 2 + 1.6, y0: 0.4, y1: NS * SH + 1.6 };
  const pass = new Uint8Array(CN), inVol = new Uint8Array(CN), kn = new Uint8Array(CN), hitc = new Uint8Array(CN), unobs = new Uint8Array(CN), fr = new Uint8Array(CN), ab = new Uint8Array(CN);
  { const q = [0, 0, 0]; for (let c = 0; c < CN; c++) { ccen(c, q); inVol[c] = q[0] > vol.x0 && q[0] < vol.x1 && q[1] > vol.y0 && q[1] < vol.y1 && q[2] > vol.z0 && q[2] < vol.z1 ? 1 : 0; } }
  // a drone flies a planning cell when its centre fits in a good part of it (a third of the fine voxels), at least 0.5 m up
  { const cnt = new Uint8Array(CN); for (let j = 0; j < g.ny; j++) for (let k = 0; k < g.nz; k++) for (let i = 0; i < g.nx; i++) if (reach[i + g.nx * (k + g.nz * j)]) cnt[cidx((i / CF) | 0, (j / CF) | 0, (k / CF) | 0)]++;
    const q = [0, 0, 0]; for (let c = 0; c < CN; c++) { ccen(c, q); pass[c] = cnt[c] >= 9 && q[1] > 0.5 ? 1 : 0; } }
  let reachTot = 0; for (let c = 0; c < CN; c++) if (pass[c] && inVol[c]) reachTot++;
  for (let c = 0; c < CN; c++) if (!inVol[c]) kn[c] = 1;      // outside the survey volume: nothing to learn
  const trav = (c) => pass[c] && kn[c];
  const NB6 = [1, -1, cx, -cx, CSY, -CSY];
  // a frontier: known, free of returns (light passed through it and stopped nowhere in it), where a drone fits, next to
  // unknown space (an unknown cell behind a surface is not one: it is most likely inside the wall)
  const isFront = (c) => { if (!trav(c) || !inVol[c] || ab[c] || hitc[c]) return false; const i = c % cx, r = (c - i) / cx, k = r % cz, j = (r - k) / cz;
    if (i > 0 && !kn[c - 1] && !unobs[c - 1]) return true; if (i < cx - 1 && !kn[c + 1] && !unobs[c + 1]) return true; if (k > 0 && !kn[c - cx] && !unobs[c - cx]) return true; if (k < cz - 1 && !kn[c + cx] && !unobs[c + cx]) return true;
    if (j > 0 && !kn[c - CSY] && !unobs[c - CSY]) return true; if (j < cy - 1 && !kn[c + CSY] && !unobs[c + CSY]) return true; return false; };
  let covered = 0; const touched = [];
  // coarse ray carving: every cell a ray passes through or ends in becomes known
  const markRay = (ox, oy, oz, ex, ey, ez, isHit) => {
    const dx = ex - ox, dy = ey - oy, dz = ez - oz, Lr = Math.hypot(dx, dy, dz); if (Lr < 1e-6) return;
    const ux = dx / Lr, uy = dy / Lr, uz = dz / Lr; let i = Math.floor((ox - g.x0) / cs), j = Math.floor((oy - g.y0) / cs), k = Math.floor((oz - g.z0) / cs);
    const sI = ux > 0 ? 1 : -1, sJ = uy > 0 ? 1 : -1, sK = uz > 0 ? 1 : -1, dI = Math.abs(ux) > 1e-12 ? cs / Math.abs(ux) : Infinity, dJ = Math.abs(uy) > 1e-12 ? cs / Math.abs(uy) : Infinity, dK = Math.abs(uz) > 1e-12 ? cs / Math.abs(uz) : Infinity;
    let mI = Math.abs(ux) > 1e-12 ? (g.x0 + (i + (ux > 0 ? 1 : 0)) * cs - ox) / ux : Infinity, mJ = Math.abs(uy) > 1e-12 ? (g.y0 + (j + (uy > 0 ? 1 : 0)) * cs - oy) / uy : Infinity, mK = Math.abs(uz) > 1e-12 ? (g.z0 + (k + (uz > 0 ? 1 : 0)) * cs - oz) / uz : Infinity;
    for (let guard = 0; guard < 400; guard++) {
      if (i < 0 || j < 0 || k < 0 || i >= cx || j >= cy || k >= cz) break;
      const c = cidx(i, j, k); if (!kn[c]) { kn[c] = 1; touched.push(c); if (pass[c] && inVol[c]) covered++; }
      const tn = Math.min(mI, mJ, mK); if (tn > Lr) { if (isHit && !hitc[c]) { hitc[c] = 1; touched.push(c); } break; }
      if (mI === tn) { i += sI; mI += dI; } else if (mJ === tn) { j += sJ; mJ += dJ; } else { k += sK; mK += dK; }
    }
  };
  const refresh = () => { for (const c of touched) { for (let dj = -1; dj <= 1; dj++) for (let dk = -1; dk <= 1; dk++) for (let di = -1; di <= 1; di++) { if (Math.abs(di) + Math.abs(dj) + Math.abs(dk) > 1) continue; const q = c + di + dk * cx + dj * CSY; if (q >= 0 && q < CN) fr[q] = isFront(q) ? 1 : 0; } } touched.length = 0; };
  // ---- the flight
  const site = model.site, pad = [site.pad.x, 0, site.pad.z], R = rngFor(seed, 'survey');
  // they take off from the pad in the street one after another and gather over the front gate (inside the map's domain)
  const zg = Math.min(D / 2 + 4.3, g.z0 + g.nz * g.vox - 0.4);
  const drones = []; for (let d = 0; d < DRONES; d++) { const a = d / DRONES * Math.PI * 2, home = [pad[0] + Math.cos(a) * 0.7, 0.06, pad[2] + Math.sin(a) * 0.7], up = [home[0], 2.2, home[2]], gate = [(d - 3.5) * 0.55, 2.2 + (d % 2) * 0.5, zg];
    const tUp = 2 * d + 1.5, tGate = tUp + Math.hypot(gate[0] - up[0], gate[1] - up[1], gate[2] - up[2]) / V_OUT;
    drones.push({ id: d, p: gate, t: tGate, target: -1, track: [{ t: 2 * d, p: home }, { t: tUp, p: up }, { t: tGate, p: gate.slice() }], idle: false, stops: 0, dist: 0 }); }
  const all = { pts: [], hit: [], org: [] }, cloud = [], ptT = [], stops = [], timeline = [];
  let nPts = 0, nRays = 0;
  const doScan = (p, t, who) => {
    const out = scan(scene, [{ p, kind: 'room' }], { rays: () => RAYS, seed, salt: `stop${stops.length}` }).next();
    let res = out.value; if (!out.done) { const it = scan(scene, [{ p, kind: 'room' }], { rays: () => RAYS, seed, salt: `stop${stops.length}` }); for (;;) { const r2 = it.next(); if (r2.done) { res = r2.value; break; } } }
    const first = nPts;
    for (let i = 0; i < res.n; i++) { const ex = res.pts[i * 3], ey = res.pts[i * 3 + 1], ez = res.pts[i * 3 + 2]; markRay(p[0], p[1], p[2], ex, ey, ez, res.hit[i]); all.pts.push(ex, ey, ez); all.hit.push(res.hit[i]); all.org.push(stops.length); nRays++;
      if (res.hit[i]) { cloud.push(ex, ey, ez); ptT.push(t); nPts++; } }
    stops.push({ t, drone: who, p: p.slice(), first, n: nPts - first });
    refresh();
  };
  // bootstrap: the first drone scans from above the pad
  doScan(drones[0].p, drones[0].t, 0);
  const claimed = (c, me) => { const q = ccen(c); for (const d of drones) { if (d === me || d.target < 0) continue; const o = ccen(d.target); if (Math.abs(o[0] - q[0]) + Math.abs(o[2] - q[2]) < 2.2 && Math.abs(o[1] - q[1]) < 1.5) return true; } return false; };
  // nearest frontier by path (Dial's buckets: 1 per horizontal step, 3 per vertical)
  const dist = new Int32Array(CN), prev = new Int32Array(CN); let stamp = 0; const seen = new Int32Array(CN);
  const buckets = []; for (let q = 0; q < 4; q++) buckets.push([]);
  function nearest(d) {
    stamp++; const s0 = ccell(d.p[0], d.p[1], d.p[2]); if (s0 < 0) return null;
    for (const b of buckets) b.length = 0; seen[s0] = stamp; dist[s0] = 0; prev[s0] = -1; buckets[0].push(s0); let cur = 0, left = 1;
    while (left > 0) {
      const bk = buckets[cur & 3]; if (!bk.length) { cur++; continue; }
      const c = bk.pop(); left--; if (dist[c] !== cur) continue;
      if (c !== s0 && fr[c] && !claimed(c, d)) { const path = []; for (let q = c; q >= 0; q = prev[q]) path.push(q); return path.reverse(); }
      for (let a = 0; a < 6; a++) { const q = c + NB6[a]; if (q < 0 || q >= CN) continue; if ((a < 2 && Math.abs((q % cx) - (c % cx)) !== 1)) continue; if (!trav(q)) continue; const w = a >= 4 ? 3 : 1, nd = cur + w;
        if (seen[q] !== stamp || nd < dist[q]) { seen[q] = stamp; dist[q] = nd; prev[q] = c; buckets[nd & 3].push(q); left++; } }
    }
    return null;
  }
  // line of sight on the planning grid (for smoothing a path)
  const los = (a, b) => { const n = Math.ceil(Math.hypot(b[0] - a[0], b[1] - a[1], b[2] - a[2]) / (cs * 0.5)); for (let s = 1; s < n; s++) { const u = s / n, c = ccell(a[0] + (b[0] - a[0]) * u, a[1] + (b[1] - a[1]) * u, a[2] + (b[2] - a[2]) * u); if (c < 0 || !trav(c)) return false; } return true; };
  const inside = (p) => Math.abs(p[0]) < L / 2 && Math.abs(p[2]) < D / 2 && p[1] < NS * SH + 0.2;
  let lastY = PERF(), events = 0;
  const T_LIMIT = 3600, STOP_LIMIT = 520;
  for (;;) {
    let d = null; for (const q of drones) if (!q.idle && (!d || q.t < d.t)) d = q;
    if (!d || stops.length >= STOP_LIMIT || d.t > T_LIMIT) break;
    const path = nearest(d);
    if (!path) { d.idle = true; d.target = -1; continue; }
    d.target = path[path.length - 1];
    // smooth the path (string pulling), then fly it
    const pts = path.map((c) => ccen(c)); pts[0] = d.p.slice(); const sm = [pts[0]]; let a = 0;
    while (a < pts.length - 1) { let b = pts.length - 1; while (b > a + 1 && !los(pts[a], pts[b])) b--; sm.push(pts[b]); a = b; }
    let t = d.t;
    for (let q = 1; q < sm.length; q++) { const A = sm[q - 1], Bp = sm[q], len = Math.hypot(Bp[0] - A[0], Bp[1] - A[1], Bp[2] - A[2]); t += len / (inside(A) || inside(Bp) ? V_IN : V_OUT); d.track.push({ t, p: Bp.slice() }); d.dist += len; }
    t += 0.6; d.p = sm[sm.length - 1].slice();
    const target = d.target; doScan(d.p, t, d.id); d.stops++;
    // a frontier that is still a frontier after a scan from right there cannot be resolved (behind glass, inside the
    // tank, under a flight): drop it
    if (fr[target]) { ab[target] = 1; for (const o of NB6) { const q = target + o; if (q >= 0 && q < CN && !kn[q]) unobs[q] = 1; } fr[target] = 0; touched.push(target); refresh(); }
    d.t = t + DWELL; d.track.push({ t: d.t, p: d.p.slice() }); d.target = -1;
    for (const q of drones) if (q.idle) q.idle = false;    // new map: idle drones look again
    events++;
    if (events % 4 === 0) timeline.push({ t, b0: beta0(), cov: covered / Math.max(1, reachTot), pts: nPts });
    if (PERF() - lastY > 40) { lastY = PERF(); yield { p: 0.05 + 0.75 * Math.min(1, stops.length / 220) }; }
  }
  // every drone flies home to the pad (their tracks end where they landed)
  let tEnd = 0;
  for (const d of drones) { const home = d.track[0].p; const A = d.p, len = Math.hypot(home[0] - A[0], 1.6 - A[1], home[2] - A[2]); const up = [A[0], Math.max(A[1], 1.6), A[2]]; let t = d.t + len / V_OUT; d.track.push({ t, p: [home[0], 1.6, home[2]] }); d.track.push({ t: t + 1.5, p: home.slice() }); tEnd = Math.max(tEnd, t + 1.5); }
  function beta0() {
    // clusters (26-connected) of frontier cells, at least two cells each
    const lab = new Int32Array(0); let n = 0; const vis = new Uint8Array(CN), st = [];
    for (let c = 0; c < CN; c++) { if (!fr[c] || vis[c]) continue; let size = 0; vis[c] = 1; st.push(c);
      while (st.length) { const q = st.pop(); size++; const i = q % cx, r = (q - i) / cx, k = r % cz, j = (r - k) / cz;
        for (let dj = -1; dj <= 1; dj++) for (let dk = -1; dk <= 1; dk++) for (let di = -1; di <= 1; di++) { const ii = i + di, jj = j + dj, kk = k + dk; if (ii < 0 || jj < 0 || kk < 0 || ii >= cx || jj >= cy || kk >= cz) continue; const o = cidx(ii, jj, kk); if (fr[o] && !vis[o]) { vis[o] = 1; st.push(o); } } }
      if (size >= 2) n++; }
    return n;
  }
  timeline.push({ t: tEnd, b0: beta0(), cov: covered / Math.max(1, reachTot), pts: nPts });
  tm.flight = Math.round(PERF() - t0 - tm.world); yield { p: 0.82 };
  // ---- the fine map: every ray carved into the 12 cm voxel grid, then classified (free / occupied / unknown)
  const nr = all.hit.length, poses = stops.map((s) => ({ p: s.p })), O = makeObs(g);
  const scanOut = { pts: Float32Array.from(all.pts), hit: Uint8Array.from(all.hit), pose: Uint16Array.from(all.org), n: nr, poses };
  const t1 = PERF(); for (const pr of carve(g, O, scanOut, ID)) { if (PERF() - lastY > 40) { lastY = PERF(); yield { p: 0.82 + 0.12 * pr.p }; } }
  const S = classify(g, O); tm.map = Math.round(PERF() - t1);
  // coverage of surfaces, on the planning grid: cells holding a true surface next to space a drone could reach, that
  // returned light (per 12 cm voxel the count would mostly measure how densely 1000 rays sample a wall)
  let surf = 0, seenS = 0; { const SY = g.nx * g.nz, sc = new Uint8Array(CN); for (let c = SY; c < g.N - SY; c++) { if (B[c] === L_FREE) continue; if (!(body[c - 1] || body[c + 1] || body[c - g.nx] || body[c + g.nx] || body[c - SY] || body[c + SY])) continue; const i = c % g.nx; if (i < 2 || i > g.nx - 3) continue; const r2 = (c - i) / g.nx, k = r2 % g.nz, j = (r2 - k) / g.nz; sc[cidx((i / CF) | 0, (j / CF) | 0, (k / CF) | 0)] = 1; }
    for (let c = 0; c < CN; c++) if (sc[c] && inVol[c]) { surf++; if (hitc[c]) seenS++; } }
  const tracks = drones.map((d) => d.track);
  return {
    g: { x0: g.x0, y0: g.y0, z0: g.z0, nx: g.nx, ny: g.ny, nz: g.nz, vox: g.vox, N: g.N, V3: g.V3 }, S, B,
    cloud: { pts: Float32Array.from(cloud), t: Float32Array.from(ptT), n: nPts },
    stops, tracks, timeline, rays: nr,
    stats: { flightS: tEnd, minutes: tEnd / 60, stops: stops.length, points: nPts, rays: nr, mb: nPts * 16 / 1e6, coverage: covered / Math.max(1, reachTot), surfaces: surf ? seenS / surf : 0, droneKm: drones.reduce((s, d) => s + d.dist, 0) / 1000, abandoned: ab.reduce((s, v) => s + v, 0) },
    timings: tm, _dbg: { ab: [...ab.keys()].filter((c) => ab[c]).map((c) => ccen(c)), fr: [...fr.keys()].filter((c) => fr[c]).map((c) => ccen(c)) },
  };
}
