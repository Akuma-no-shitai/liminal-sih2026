// The baseline, read off the survey: door widths measured from the point cloud (the gap between the two door jambs),
// the clear width left in the lobby, and which rooms the map has as open space. The crowd model and the access graph
// need clear widths, and Act 7 needs the map.
import { T_EXT } from '../../../act7/js/building/building.js';
import { O_FREE } from '../../../act7/js/pipe/occupancy.js';

function hashPts(P, n, cell = 0.5) {
  const m = new Map(); for (let i = 0; i < n; i++) { const k = `${Math.floor(P[i * 3] / cell)},${Math.floor(P[i * 3 + 2] / cell)}`; let a = m.get(k); if (!a) m.set(k, a = []); a.push(i); }
  return { near(x0, z0, x1, z1) { const out = []; for (let a = Math.floor(x0 / cell); a <= Math.floor(x1 / cell); a++) for (let b = Math.floor(z0 / cell); b <= Math.floor(z1 / cell); b++) { const q = m.get(`${a},${b}`); if (q) for (const i of q) out.push(i); } return out; } };
}
const pctl = (a, q) => { if (!a.length) return NaN; const s = a.slice().sort((p, r) => p - r); return s[Math.min(s.length - 1, Math.floor(q * s.length))]; };

export function readBaseline(model, survey, clutter, { minCluster = 2, minPts = 0 } = {}) {
  const P = survey.cloud.pts, n = survey.cloud.n, H = hashPts(P, n);
  // doors: the jamb faces are the only surfaces inside the wall's thickness at hand height
  const doors = [];
  for (const o of model.openings) {
    if (!['door', 'entry', 'street', 'rear'].includes(o.kind)) continue;
    const t = model.walls[o.unit].t, mid = (o.o0 + o.o1) / 2, L = [], R = [], beyond = [];
    const ids = o.axis === 'x' ? H.near(o.off - 0.3, o.o0 - 0.5, o.off + 0.3, o.o1 + 0.5) : H.near(o.o0 - 0.5, o.off - 0.3, o.o1 + 0.5, o.off + 0.3);
    let leaf = 0;
    for (const i of ids) {
      const x = P[i * 3], y = P[i * 3 + 1], z = P[i * 3 + 2], perp = o.axis === 'x' ? x : z, along = o.axis === 'x' ? z : x, dp = Math.abs(perp - o.off);
      if (y < o.y0 + 0.3 || y > o.y0 + 1.9 || along < o.o0 - 0.35 || along > o.o1 + 0.35) continue;
      if (dp < 0.04 && along > o.o0 + 0.05 && along < o.o1 - 0.05) leaf++;      // a closed leaf in the opening
      if (dp > t / 2 + 0.03 && dp < 0.165) beyond.push(along);                   // a surface sticking out past the wall faces
      if (dp > t / 2 - 0.015) continue;                                           // inside the thickness (a stray return from a wall face is caught below)
      (along < mid ? L : R).push(along);
    }
    // each jamb is the innermost tight cluster on its side; a cluster whose surface carries on past the wall faces is the
    // face of a column standing next to the door, not the jamb
    const inner = (A, sign) => { const s = A.slice().sort((p, q) => sign * (q - p)); for (let i = 0; i < s.length; i++) { const c = s.filter((v) => Math.abs(v - s[i]) <= 0.035); if (c.length < minCluster) continue; const m = pctl(c, 0.5); if (beyond.filter((b) => Math.abs(b - m) < 0.03).length >= 2) continue; return m; } return NaN; };
    const closed = leaf > 6, few = L.length + R.length < minPts, wl = closed || few ? NaN : inner(L, 1), wr = closed || few ? NaN : inner(R, -1), ok = Number.isFinite(wl) && Number.isFinite(wr), w = ok ? wr - wl : NaN;
    doors.push({ id: o.id, kind: o.kind, storey: o.storey, plan: o.w, measured: ok ? w : null, err: ok ? w - o.w : null, closed, pts: L.length + R.length });
  }
  // the lobby: across the core, the widest free stretch in each 15 cm slice; the narrowest of those is the clear width
  const { zf, D, c } = model.dims, inX = c - T_EXT / 2; let gap = 2 * inX, gapZ = null;
  for (let z = zf + 0.2; z < D / 2 - T_EXT - 0.3; z += 0.15) {
    const xs = []; for (const i of H.near(-inX, z, inX, z + 0.15)) { const x = P[i * 3], y = P[i * 3 + 1], zz = P[i * 3 + 2]; if (zz < z || zz >= z + 0.15 || y < 0.35 || y > 1.0 || Math.abs(x) > inX - 0.03) continue; xs.push(x); }
    if (!xs.length) continue; xs.sort((p, q) => p - q);
    let best = xs[0] + inX, prev = xs[0]; for (const x of xs) { best = Math.max(best, x - prev); prev = x; } best = Math.max(best, inX - prev);
    if (best < gap) { gap = best; gapZ = z + 0.075; }
  }
  // rooms the map has as open space (at least nine in ten samples free)
  const S = survey.S, g = survey.g, cell = (x, y, z) => { const i = Math.floor((x - g.x0) / g.vox), j = Math.floor((y - g.y0) / g.vox), k = Math.floor((z - g.z0) / g.vox); return i < 0 || j < 0 || k < 0 || i >= g.nx || j >= g.ny || k >= g.nz ? -1 : i + g.nx * (k + g.nz * j); };
  // (at 1.6 m, above anything parked; the stair core only in front of its flights)
  const rooms = model.rooms.map((rm) => { let a = 0, f = 0; const z0 = rm.kind === 'core' ? model.dims.zb + 0.2 : rm.z0 + 0.25; for (let x = rm.x0 + 0.25; x < rm.x1 - 0.2; x += 0.36) for (let z = z0; z < rm.z1 - 0.2; z += 0.36) { const q = cell(x, rm.y0 + 1.6, z); if (q < 0) continue; a++; if (S[q] === O_FREE) f++; } return { id: rm.id, free: a ? f / a : 0 }; });
  const meas = doors.filter((d) => d.measured != null);
  return { doors, doorErr: meas.length ? meas.reduce((s, d) => s + Math.abs(d.err), 0) / meas.length : null, doorErrMax: meas.length ? Math.max(...meas.map((d) => Math.abs(d.err))) : null, measured: meas.length,
    gap: clutter && clutter.length ? gap : null, gapZ, rooms, roomsMapped: rooms.filter((r) => r.free >= 0.9).length };
}
