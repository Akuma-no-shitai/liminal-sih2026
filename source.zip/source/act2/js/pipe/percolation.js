// How close to cut off: percolation on the access graph (Stauffer & Aharony). Links (doors, corridor segments, stair
// flights) are blocked one at a time in a random order, many times over; each trial counts how many blockages it takes
// before at least one occupied room has no route left to an exit. Also: the share of people who still have a route
// after m random blockages, and for every single link, how many people its loss alone would cut off (the weak links).
import { rngFor } from '../../../act7/js/building/geom.js';
import { reachOut, offOf, betti, bridges } from './plan.js';

// people per graph node (the room each person starts in)
export function peopleAt(G, people) {
  const byRoom = new Map(); for (const p of people) byRoom.set(p.room, (byRoom.get(p.room) || 0) + 1);
  const at = new Float64Array(G.nodes.length);
  G.nodes.forEach((n, i) => { if (n.kind === 'room' && byRoom.has(n.room)) at[i] = byRoom.get(n.room); });
  // people starting in a hall count at the hall's first junction
  for (const p of people) { if (G.nodes.some((n) => n.room === p.room)) continue; let best = -1, bd = 1e9; G.nodes.forEach((n, i) => { if (n.kind !== 'junction' || n.storey !== p.storey) return; const d = (n.p[0] - p.x) ** 2 + (n.p[2] - p.z) ** 2; if (d < bd) { bd = d; best = i; } }); if (best >= 0) at[best]++; }
  return at;
}
const cutOff = (G, off, at) => { const ok = reachOut(G, off); let n = 0; for (let i = 0; i < at.length; i++) if (at[i] && !ok[i]) n += at[i]; return n; };

export function percolation(G, people, { seed = 1, trials = 1500, mMax = 12, blocked = null } = {}) {
  const at = peopleAt(G, people), total = at.reduce((s, v) => s + v, 0);
  const off0 = offOf(G, blocked);
  // links that can be blocked: everything open (a locked door is closed already)
  const cand = G.links.filter((l) => !off0[l.id]).map((l) => l.id);
  // a single blockage at a time: who it cuts off
  const base = cutOff(G, off0, at);      // already without a route (the sandbox's blocks)
  const single = cand.map((id) => { const off = off0.slice(); off[id] = 1; return { link: id, people: cutOff(G, off, at) - base }; }).sort((a, b) => b.people - a.people);
  const weak = single.filter((s) => s.people > 0);
  // random trials
  const r = rngFor(seed, 'percolation'), first = new Int16Array(trials), still = new Float64Array(mMax + 1);
  const order = cand.slice();
  for (let tr = 0; tr < trials; tr++) {
    r.shuffle(order); const off = off0.slice(); let k = 0;
    for (let m = 1; m <= Math.max(mMax, order.length); m++) {
      if (m > order.length) break; off[order[m - 1]] = 1;
      const c = cutOff(G, off, at);
      if (m <= mMax) still[m] += total ? (total - c) / total : 1;
      if (!k && c > base) k = m;
      if (k && m >= mMax) break;
    }
    first[tr] = k || order.length + 1;
  }
  still[0] = total ? (total - base) / total : 1; for (let m = 1; m <= mMax; m++) still[m] /= trials;
  // (someone already without a route: the margin is zero)
  const sorted = Array.from(first).sort((a, b) => a - b), median = base > 0 ? 0 : sorted[Math.floor(trials / 2)], mean = base > 0 ? 0 : sorted.reduce((s, v) => s + v, 0) / trials;
  const hist = new Array(mMax + 1).fill(0); for (const k of first) hist[Math.min(mMax, k)]++;
  const b = betti(G, off0), br = bridges(G, off0);
  return { trials, total, base, links: cand.length, first, median, mean, p1: weak.length / cand.length, hist, still: Array.from(still), single, weak, worst: single[0], betti: b, bridges: br.length, bridgeIds: br };
}

// dead ends: hall stubs past the last door, and corridors whose only way on is back the way they came
export function deadEnds(G) {
  const out = [];
  for (const n of G.nodes) if (n.stub) out.push({ kind: 'hall', node: n.id, len: n.stub.len, p: n.stub.p, label: `flat ${n.flat} hall end, ${['ground', 'first', 'second', 'third'][n.storey]} floor` });
  return out;
}
