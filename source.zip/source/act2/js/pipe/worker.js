// The crowd worker: the crowd host (host.js) on its own thread. Bundled by build_preview.py as a separate script and
// started from a Blob in the single file; on the dev page it is started as a module worker from this file.
import { createHost } from './host.js';
const host = createHost((m, transfer) => self.postMessage(m, transfer || []), { budget: 40, tick: (f) => setTimeout(f, 0) });
self.onmessage = (e) => host.onMessage(e.data);
