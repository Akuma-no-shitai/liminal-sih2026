// The whole Before-phase pipeline for one seed, as generators that run in slices and yield progress ({ p, label }).
//   runCore: the building (act7's, the same block for the same seed) -> the frontier survey -> the baseline map, door
//            widths, the path network (act7's routes on the survey map) -> the access graph, β₁, bridges, dead ends
//            -> the night-time crowd run -> percolation trials -> each fix's graph. (Before the film starts.)
//   runCrowd: the full-house runs (desired speed 1.3 to 5 m/s: does "faster is slower" emerge?) and each fix's crowd
//            runs. (In the background while the first chapters play; the film needs them from chapter 5.)
// Pure JS: no DOM, no three.js; deterministic from the seed; runs in node for the sweep.
import { buildBuilding } from '../../../act7/js/building/building.js';
import { makeGrid } from '../../../act7/js/building/voxel.js';
import { routes } from '../../../act7/js/pipe/routes.js';
import { survey } from './survey.js';
import { readBaseline } from './baseline.js';
import { accessGraph, crowdWorld, occupancy, lobbyClutter, lobbyGap, stairGeom, offOf, betti } from './plan.js';
import { createSim, HELBING, DT } from './crowd.js';
import { analyse, rhoNear } from './analyse.js';
import { percolation, deadEnds } from './percolation.js';
import { FIXES, planOpts, pickWiden, graphFor, worldFor } from './mitigate.js';

const PERF = () => (typeof performance !== 'undefined' ? performance.now() : Date.now());
export const CALM = 1.3, SWEEP = [1.3, 2, 3, 4, 5], FULL = 10;
export const NIGHT = { min: 2, max: 4 };
const ID5 = () => Array.from({ length: 5 }, () => ({ T: { R: [1, 0, 0, 0, 1, 0, 0, 0, 1], t: [0, 0, 0] }, tilt: 0, ident: true }));

// a crowd run in slices
function* crowdRun(W, G, people, { v0, seed, clutter, keep = false, label, p0 = 0, p1 = 1 }) {
  const sim = createSim(W, people, { v0, seed, clogAfter: 40, tMax: 400 });
  // (half a simulated second per slice: a few milliseconds, so the background job never stalls a frame)
  while (!sim.run(0.5)) yield { p: p0 + (p1 - p0) * Math.min(.95, sim.nOut / Math.max(1, people.length)), label };
  const res = sim.result(), an = analyse(res, W, G, { clutter, v0 });
  return { an, res: keep ? { frames: res.frames, tFrames: res.tFrames, outT: res.outT, r: people.map((p) => p.r) } : null, raw: res };
}

export function* runCore(seed, opts = {}) {
  const tm = {}, C = { seed, version: 1 }; let t0 = PERF();
  const lap = (k) => { tm[k] = Math.round(PERF() - t0); t0 = PERF(); };
  const model = buildBuilding({ seed }), clutter = lobbyClutter(model, seed);
  C.model = model; C.clutter = clutter; C.gapPlan = lobbyGap(model, clutter);
  yield { p: 0.01, label: 'Placing the drones' };
  // ---- the survey
  const sg = survey(model, clutter, seed); let SV;
  for (;;) { const r = sg.next(); if (r.done) { SV = r.value; break; } yield { p: 0.02 + 0.55 * r.value.p, label: 'Surveying the building' }; }
  lap('survey'); Object.assign(tm, { survey_world: SV.timings.world, survey_flight: SV.timings.flight, survey_map: SV.timings.map });
  C.survey = SV; C.base = readBaseline(model, SV, clutter); lap('baseline');
  // ---- the path network from the survey map (act7's routes, unchanged: free space thinned to a skeleton)
  yield { p: 0.6, label: 'Tracing the path network' };
  const g = makeGrid(SV.g); const rg = routes({ model, fits: ID5(), g, S: SV.S, B: SV.B }); let RT;
  for (;;) { const r = rg.next(); if (r.done) { RT = r.value; break; } yield { p: 0.6 + 0.08 * r.value.p, label: 'Tracing the path network' }; }
  // (two skeletons: from the survey's own occupancy map, and from the as-surveyed plan at the same 12 cm, which is what
  // the film draws: at this resolution the sparse returns leave door openings ragged and the map's skeleton broken)
  C.routes = RT.map((f) => ({ storey: f.storey, edges: f.base.edges, beta1: f.base.beta1, mapEdges: f.post.edges.length, mapBeta1: f.post.beta1, entry: f.entry, reach: f.routes.filter((q) => q.reachable).length, rooms: f.routes.length }));
  delete SV.B; lap('routes');
  // ---- the access graph
  const G = accessGraph(model, { clutter }), off = offOf(G); C.G = G; C.betti = betti(G, off); C.deadEnds = deadEnds(G);
  C.stair = stairGeom(model);
  // ---- night-time occupancy and the crowd
  yield { p: 0.7, label: 'Building the crowd model' };
  const W = crowdWorld(model, G, { clutter }); C.W = W; lap('world');
  const people = occupancy(model, W, seed, NIGHT); C.night = { people };
  const nr = yield* crowdRun(W, G, people, { v0: CALM, seed, clutter, keep: true, label: 'Running the night-time evacuation', p0: 0.72, p1: 0.86 });
  C.night.calm = nr.an; C.night.frames = nr.res; lap('night');
  // ---- percolation
  yield { p: 0.87, label: 'Blocking routes at random' };
  C.perc = percolation(G, people, { seed, trials: 1500 }); lap('percolation');
  // ---- each fix, on the graph
  C.fixGraph = {}; for (const f of FIXES) { const r = graphFor(C, f.id === 'widen' ? [] : [f.id]); C.fixGraph[f.id] = { betti: r.perc.betti, perc: summarize(r.perc, r.G) }; }
  C.percSummary = summarize(C.perc, G); lap('fixgraph');
  C.timings = tm; tm.core = Object.entries(tm).reduce((s, [k, v]) => s + (k.startsWith('survey_') ? 0 : v), 0);   // (the survey's parts are inside 'survey')
  C.consts = { HELBING, DT, CALM, SWEEP, FULL, NIGHT, REPEAT };
  yield { p: 0.99, label: 'Done' };
  return C;
}
function summarize(pc, G) {
  const w = pc.worst, wl = w && w.people ? G.links[w.link] : null;
  return { median: pc.median, mean: pc.mean, p1: pc.p1, hist: pc.hist, still: pc.still, total: pc.total, links: pc.links, weakN: pc.weak.length, bridges: pc.bridges, worst: wl ? { link: wl.id, label: wl.label, people: w.people } : null,
    top: pc.weak.slice(0, 6).map((q) => ({ link: q.link, label: G.links[q.link].label, people: q.people })), weak: pc.weak.map((q) => [q.link, q.people]) };
}

// The crowd is chaotic: the same people in the same building, with only the small random pushes reseeded, leave in
// times that differ by a few per cent, and by 10 to 25 % where a clog forms and clears. So every full-house time the
// film compares is the mean of several runs that differ only in those pushes, and a difference counts as a change
// only when the runs do not overlap (every run on one side faster than every run on the other).
export const REPEAT = { calm: 3, sweep: 2, fix: 3 };
const pushSeed = (seed, k) => seed + 101 * k;
const finished = (an) => an.total != null && !an.clogged && an.out === an.n;
export function repOf(ans) {
  const T = ans.map((a) => (finished(a) ? a.total : Infinity)), f = T.filter(Number.isFinite);
  const stop = Math.max(0, ...ans.filter((a) => !finished(a)).map((a) => a.tEnd));   // (when a clogged run was stopped)
  return { T, n: T.length, clogged: T.length - f.length, stop, mean: f.length === T.length ? f.reduce((q, v) => q + v, 0) / f.length : Infinity, lo: Math.min(...T), hi: Math.max(...T) };
}
// a fix against the base: the relative change of the mean, and whether it is clear of the run-to-run spread
export function compareRuns(base, fix) {
  const d = Number.isFinite(base.mean) && Number.isFinite(fix.mean) ? (fix.mean - base.mean) / base.mean : null;
  return { d, real: fix.hi < base.lo || fix.lo > base.hi };
}

export function* runCrowd(C) {
  const tm = {}; let t0 = PERF(); const lap = (k) => { tm[k] = Math.round(PERF() - t0); t0 = PERF(); };
  const { model, seed, clutter, W, G } = C;
  const people = occupancy(model, W, seed, { perFlat: FULL }); C.full = { people, sweep: [] };
  const UNITS = REPEAT.calm + REPEAT.sweep * (SWEEP.length - 1) + FIXES.length * (REPEAT.fix + 1); let u = 0;
  const pr = () => ({ p0: u / UNITS, p1: ++u / UNITS });
  // the same scene several times, with the random pushes reseeded; the first run keeps its frames for the film
  function* repeated(Wr, Gr, ppl, k, o) { const runs = []; for (let j = 0; j < k; j++) runs.push(yield* crowdRun(Wr, Gr, ppl, { ...o, seed: pushSeed(seed, j), keep: j === 0 && o.keep, ...pr() })); return { first: runs[0], rep: repOf(runs.map((r) => r.an)) }; }
  // ---- the desired speed, raised: the same 80 people, 1.3 to 5 m/s
  const runs = [];
  for (let q = 0; q < SWEEP.length; q++) { const v0 = SWEEP[q]; const r = yield* repeated(W, G, people, v0 === CALM ? REPEAT.calm : REPEAT.sweep, { v0, clutter, keep: true, label: `Full house at ${v0} m/s` }); runs.push(r.first); C.full.sweep.push({ v0, an: r.first.an, rep: r.rep }); }
  lap('sweep');
  // faster is slower? the mean leaving time at the highest speed against the best speed below it; it counts only when
  // every run at the highest speed is slower than every run at the best one
  const R = C.full.sweep.map((s) => s.rep);
  let best = 0; for (let q = 1; q < SWEEP.length; q++) if (R[q].mean < R[best].mean) best = q;
  const last = SWEEP.length - 1, tb = R[best].mean, tl = R[last].mean;
  const emerges = best < last && R[last].lo > R[best].hi && tl > tb * 1.05;
  C.full.fis = { best: SWEEP[best], bestT: tb, bestLo: R[best].lo, bestHi: R[best].hi, last: SWEEP[last], lastT: tl, lastLo: R[last].lo, lastHi: R[last].hi, lastClogged: runs[last].an.clogged, lastClogs: R[last].clogged, lastLeft: runs[last].an.n - runs[last].an.out, emerges, close: best < last && !emerges && tl > tb * 1.05, ratio: Number.isFinite(tl) ? tl / tb : null, runs: R[last].n };
  C.full.frames = { calm: runs[0].res, best: runs[best].res, last: runs[last].res };
  // ---- the fixes, on the crowd: the full house (repeated) and the night, both at walking pace
  const base = runs[0].an; C.full.calm = base; C.full.calmRep = R[0];
  const wd = pickWiden(C, base); C.widenDoor = wd.door; C.widenTo = wd.to; C.widen = wd;
  const hot = base.bottlenecks[0], nightHot = C.night.calm.bottlenecks[0];
  C.fixes = {};
  for (let q = 0; q < FIXES.length; q++) {
    const f = FIXES[q]; const { G: Gf, W: Wf } = worldFor(C, [f.id]);
    const r = yield* repeated(Wf, Gf, people, REPEAT.fix, { v0: CALM, clutter: f.id === 'clear' ? null : clutter, keep: f.id === 'clear', label: `${f.short}: full house` }), rf = r.first;
    const rn = yield* crowdRun(Wf, Gf, C.night.people, { v0: CALM, seed, clutter: f.id === 'clear' ? null : clutter, label: `${f.short}: night`, ...pr() });
    const gr = f.id === 'widen' ? graphFor(C, ['widen']) : null;
    C.fixes[f.id] = { full: rf.an, rep: r.rep, cmp: compareRuns(R[0], r.rep), night: rn.an, rhoHot: hot ? rhoNear(rf.raw, Wf, hot.dom, hot.x, hot.z) : null, rhoHotNight: nightHot ? rhoNear(rn.raw, Wf, nightHot.dom, nightHot.x, nightHot.z) : null, frames: rf.res, graph: gr ? { betti: gr.perc.betti, perc: summarize(gr.perc, gr.G) } : C.fixGraph[f.id] };
  }
  C.rhoHot = hot ? hot.rho : null; C.rhoHotNight = nightHot ? nightHot.rho : null;
  lap('fixes');
  C.timings.crowd = tm; C.timings.crowdTotal = Object.values(tm).reduce((s, v) => s + v, 0);
  return C;
}
export function runSync(seed) { const a = runCore(seed); let C; for (;;) { const r = a.next(); if (r.done) { C = r.value; break; } } const b = runCrowd(C); for (;;) { const r = b.next(); if (r.done) break; } return C; }
