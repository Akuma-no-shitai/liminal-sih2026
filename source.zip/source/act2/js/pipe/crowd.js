// The crowd model: Helbing, Farkas and Vicsek (2000), "Simulating dynamical features of escape panic", Nature 407:
// the social-force model with its published parameters (A = 2000 N, B = 0.08 m, k = 1.2e5 kg/s², κ = 2.4e5 kg/(m s),
// τ = 0.5 s, m = 80 kg, radii 0.25-0.35 m). Each person is pushed toward a desired velocity v0·e (e from a floor field:
// the shortest walkable way to an exit), and away from other people and from walls by an exponential social force, a
// body force and sliding friction when they touch. Pure JS (no DOM, no three.js): it runs in node for the sweep and in
// slices in the browser for the sandbox.
//   Space is a set of 2-D domains: one per floor and one per stair (the U-shaped flights and mid-landing, unfolded into
//   plan). Each domain is a grid (5 cm) with its walls, their distance field (for the wall forces) and the floor field
//   (for the desired direction). People cross between domains at portals (the top of each flight).
// Deterministic for a seed. Nothing here knows about a particular building: plan.js builds the domains.

export const HELBING = { A: 2000, B: 0.08, k: 1.2e5, kappa: 2.4e5, tau: 0.5, m: 80, rMin: 0.25, rMax: 0.35 };
export let DT = 0.004;             // s; explicit steps (the contact forces are stiff: k/m gives a 0.16 s period, so 40 steps per period)
export const setDT = (v) => { DT = v; };
const CUT = 0.6;                   // m beyond contact where the social force is dropped (A e^(-0.6/0.08) = 1 N)
const HCELL = 1.2;                 // m, the neighbour hash cell
const INF = 1e9;

// ------------------------------------------------------------------ distance transforms
// squared EDT (Felzenszwalb-Huttenlocher) of the cells where mask = 1, in cells²
export function edt2(mask, nx, nz) {
  const n = Math.max(nx, nz), f = new Float64Array(n), v = new Int32Array(n), zz = new Float64Array(n + 1), D = new Float64Array(nx * nz), BIG = 1e12;
  const pass = (len, get, set) => { for (let q = 0; q < len; q++) f[q] = get(q); let k = 0; v[0] = 0; zz[0] = -BIG; zz[1] = BIG;
    for (let q = 1; q < len; q++) { let s = ((f[q] + q * q) - (f[v[k]] + v[k] * v[k])) / (2 * q - 2 * v[k]); while (s <= zz[k]) { k--; s = ((f[q] + q * q) - (f[v[k]] + v[k] * v[k])) / (2 * q - 2 * v[k]); } k++; v[k] = q; zz[k] = s; zz[k + 1] = BIG; }
    k = 0; for (let q = 0; q < len; q++) { while (zz[k + 1] < q) k++; set(q, (q - v[k]) * (q - v[k]) + f[v[k]]); } };
  for (let b = 0; b < nz; b++) pass(nx, (q) => (mask[b * nx + q] ? 0 : BIG), (q, val) => { D[b * nx + q] = val; });
  for (let a = 0; a < nx; a++) pass(nz, (q) => D[q * nx + a], (q, val) => { D[q * nx + a] = val; });
  return D;
}

// a domain: { x0, z0, nx, nz, h, solid, slow (speed factor 0-255 per cell, 255 = 1), ... } -> adds dist (m to the
// nearest wall surface, negative inside walls)
export function prepDomain(d) {
  const { nx, nz, h, solid } = d, N = nx * nz;
  const out = edt2(solid, nx, nz), inv = new Uint8Array(N); for (let c = 0; c < N; c++) inv[c] = solid[c] ? 0 : 1;
  const inn = edt2(inv, nx, nz), dist = new Float32Array(N);
  for (let c = 0; c < N; c++) dist[c] = solid[c] ? -(Math.sqrt(inn[c]) - .5) * h : (Math.sqrt(out[c]) - .5) * h;
  d.dist = dist; if (!d.slow) d.slow = new Uint8Array(N).fill(255);
  wallSegments(d);
  return d;
}
// the walls as segments (Helbing sums a force from each wall, from its nearest point): the maximal straight runs of
// the boundary between solid and free cells, bucketed on a 0.5 m grid (each bucket lists the walls within reach)
const WB = 0.25, REACH = 0.36 + CUT;
function wallSegments(d) {
  const { nx, nz, h, solid, x0, z0 } = d, S = [];
  const sol = (i, k) => (i < 0 || k < 0 || i >= nx || k >= nz ? 1 : solid[k * nx + i]);
  // horizontal edges (between rows k-1 and k), then vertical edges (between columns i-1 and i)
  for (let k = 0; k <= nz; k++) { let run = -1, kind = 0; for (let i = 0; i <= nx; i++) { const a = i < nx ? sol(i, k - 1) : 0, b = i < nx ? sol(i, k) : 0, q = i < nx && a !== b ? (a ? 1 : 2) : 0;
    if (q !== kind) { if (kind) S.push(x0 + run * h, z0 + k * h, x0 + i * h, z0 + k * h); run = i; kind = q; } } }
  for (let i = 0; i <= nx; i++) { let run = -1, kind = 0; for (let k = 0; k <= nz; k++) { const a = k < nz ? sol(i - 1, k) : 0, b = k < nz ? sol(i, k) : 0, q = k < nz && a !== b ? (a ? 1 : 2) : 0;
    if (q !== kind) { if (kind) S.push(x0 + i * h, z0 + run * h, x0 + i * h, z0 + k * h); run = k; kind = q; } } }
  // each wall as [axis (0: x = const, a vertical line in plan; 1: z = const), the constant, lo, hi]
  for (let q = 0; q < S.length; q += 4) { const v = S[q] === S[q + 2]; const a = v ? [0, S[q], Math.min(S[q + 1], S[q + 3]), Math.max(S[q + 1], S[q + 3])] : [1, S[q + 1], Math.min(S[q], S[q + 2]), Math.max(S[q], S[q + 2])]; S[q] = a[0]; S[q + 1] = a[1]; S[q + 2] = a[2]; S[q + 3] = a[3]; }
  const segs = Float64Array.from(S), ns = segs.length / 4, bx = Math.ceil(nx * h / WB) + 1, bz = Math.ceil(nz * h / WB) + 1, lists = Array.from({ length: bx * bz }, () => []);
  for (let s = 0; s < ns; s++) { const v = segs[s * 4] === 0, cst = segs[s * 4 + 1], lo = segs[s * 4 + 2], hi = segs[s * 4 + 3];
    const a0 = (v ? cst : lo) - REACH, a1 = (v ? cst : hi) + REACH, b0 = (v ? lo : cst) - REACH, b1 = (v ? hi : cst) + REACH;
    for (let b = Math.max(0, Math.floor((b0 - z0) / WB)); b <= Math.min(bz - 1, Math.floor((b1 - z0) / WB)); b++) for (let a = Math.max(0, Math.floor((a0 - x0) / WB)); a <= Math.min(bx - 1, Math.floor((a1 - x0) / WB)); a++) lists[b * bx + a].push(s); }
  const start = new Int32Array(bx * bz + 1); for (let q = 0; q < lists.length; q++) start[q + 1] = start[q] + lists[q].length;
  const items = new Int32Array(start[bx * bz]); for (let q = 0; q < lists.length; q++) items.set(lists[q], start[q]);
  d.walls = { segs, ns, bx, bz, start, items };
}

// ------------------------------------------------------------------ the floor field (Dijkstra, 8 neighbours)
// cost per metre grows within 0.4 m of a wall so routes go through the middle of a door; cells closer than
// 0.14 m to a wall are not walkable. sources: [[cell, value]] (exits at 0, a portal at the downstream field's value).
// cells with block = 1 are excluded (a barrier the viewer placed is solid already; this is for "no entry" masks)
const heap = { k: new Float64Array(1 << 16), v: new Int32Array(1 << 16), n: 0 };
function hpush(key, val) { if (heap.n >= heap.k.length) { const k2 = new Float64Array(heap.k.length * 2); k2.set(heap.k); heap.k = k2; const v2 = new Int32Array(heap.v.length * 2); v2.set(heap.v); heap.v = v2; }
  let i = heap.n++; const K = heap.k, V = heap.v; while (i > 0) { const p = (i - 1) >> 1; if (K[p] <= key) break; K[i] = K[p]; V[i] = V[p]; i = p; } K[i] = key; V[i] = val; }
function hpop() { const K = heap.k, V = heap.v, top = V[0], n = --heap.n; if (n > 0) { const key = K[n], val = V[n]; let i = 0; for (;;) { let c = 2 * i + 1; if (c >= n) break; if (c + 1 < n && K[c + 1] < K[c]) c++; if (K[c] >= key) break; K[i] = K[c]; V[i] = V[c]; i = c; } K[i] = key; V[i] = val; } return top; }
export function floorField(d, sources) {
  const { nx, nz, h, dist } = d, N = nx * nz, phi = new Float64Array(N).fill(INF), W = new Float32Array(N);   // (float64 while it runs: a float32 copy would make live heap entries look stale)
  const dc = 0.3, wk = 1.0;
  // (and per unit of time, not length: a cell walked at half speed costs double, so people take the quickest way)
  for (let c = 0; c < N; c++) { const q = dist[c]; W[c] = q < 0.14 ? -1 : (1 + wk * Math.max(0, (dc - q) / dc)) * 255 / Math.max(32, d.slow[c]); }
  heap.n = 0;
  for (const [c, v] of sources) { if (c < 0 || c >= N || W[c] < 0) continue; if (v < phi[c]) { phi[c] = v; hpush(v, c); } }
  const D2 = Math.SQRT2;
  while (heap.n) {
    const key = heap.k[0], c = hpop(); if (key > phi[c] + 1e-6) continue;
    const i = c % nx, k = (c - i) / nx;
    for (let dk = -1; dk <= 1; dk++) { const kk = k + dk; if (kk < 0 || kk >= nz) continue;
      for (let di = -1; di <= 1; di++) { if (!di && !dk) continue; const ii = i + di; if (ii < 0 || ii >= nx) continue; const q = kk * nx + ii; const w = W[q]; if (w < 0) continue;
        if (di && dk && (W[k * nx + ii] < 0 || W[kk * nx + i] < 0)) continue;   // no corner cutting
        const nv = key + (di && dk ? D2 : 1) * h * (w + W[c]) * .5; if (nv < phi[q]) { phi[q] = nv; hpush(nv, q); } } }
  }
  d.phi = Float32Array.from(phi); dirField(d); return d.phi;
}
// the way down the floor field at every cell (a 3x3 least-squares slope over walkable neighbours; where the cell itself
// is too close to a wall to have a value, toward its lowest neighbour)
function dirField(d) {
  const RG = 1;
  const { nx, nz, phi } = d, N = nx * nz, ex = new Float32Array(N), ez = new Float32Array(N);
  for (let k = 0; k < nz; k++) for (let i = 0; i < nx; i++) {
    const c = k * nx + i, p0 = phi[c] < INF ? phi[c] : null; let gx = 0, gz = 0, best = p0 == null ? INF : p0, bx = 0, bz = 0;
    for (let dk = -RG; dk <= RG; dk++) for (let di = -RG; di <= RG; di++) { if (!di && !dk) continue; const ii = i + di, kk = k + dk; if (ii < 0 || kk < 0 || ii >= nx || kk >= nz) continue; const p = phi[kk * nx + ii]; if (p >= INF) continue;
      const w = 1 / (di * di + dk * dk); if (p0 != null) { gx += w * di * (p - p0); gz += w * dk * (p - p0); } if (Math.abs(di) <= 1 && Math.abs(dk) <= 1 && p < best) { best = p; bx = di; bz = dk; } }
    let L = Math.hypot(gx, gz);
    if (p0 == null || L < 1e-9) { gx = -bx; gz = -bz; L = Math.hypot(gx, gz); }
    if (L > 1e-9) { ex[c] = -gx / L; ez[c] = -gz / L; }
  }
  d.ex = ex; d.ez = ez;
}
// bilinear sample of a cell array at (x, z)
export function sample(d, A, x, z) {
  const fx = (x - d.x0) / d.h - .5, fz = (z - d.z0) / d.h - .5; let i = Math.floor(fx), k = Math.floor(fz);
  if (i < 0) i = 0; if (k < 0) k = 0; if (i > d.nx - 2) i = d.nx - 2; if (k > d.nz - 2) k = d.nz - 2;
  const u = Math.min(1, Math.max(0, fx - i)), w = Math.min(1, Math.max(0, fz - k)), c = k * d.nx + i;
  return (A[c] * (1 - u) + A[c + 1] * u) * (1 - w) + (A[c + d.nx] * (1 - u) + A[c + d.nx + 1] * u) * w;
}
export const cellOf = (d, x, z) => { const i = Math.floor((x - d.x0) / d.h), k = Math.floor((z - d.z0) / d.h); return i < 0 || k < 0 || i >= d.nx || k >= d.nz ? -1 : k * d.nx + i; };
// ------------------------------------------------------------------ the simulation
// world: { domains: [...], transfer(dom, x, z) -> new dom index or -1 (stay), exitOf(dom, x, z) -> exit id or -1,
//          links(dom, x, z) -> [dom indices whose people can touch this one here], doorLines: [{ id, dom, axis, at, a0, a1 }] }
// people: [{ x, z, dom, r }]
// opts: { v0, seed-free (people carry their own radius), tMax, record: seconds between frames, watch: s without progress }
export function createSim(world, people, opts = {}) {
  const P = HELBING, n = people.length;
  const x = new Float64Array(n), z = new Float64Array(n), vx = new Float64Array(n), vz = new Float64Array(n), r = new Float64Array(n), dom = new Int16Array(n);
  const outT = new Float64Array(n).fill(-1), exitId = new Int8Array(n).fill(-1), trapped = new Uint8Array(n), bestPhi = new Float64Array(n), lastProg = new Float64Array(n), stuck = new Uint8Array(n);
  const fx = new Float64Array(n), fz = new Float64Array(n);
  const v0 = opts.v0 ?? 1.3, tau = P.tau, m = P.m;
  // the sliding friction in one step can at most stop the sliding, never reverse it (explicit steps at large overlaps
  // would otherwise overshoot): half the relative tangential velocity per body for a pair, all of it against a wall
  const FCAP = opts.fricCap ?? .5, WCAP = opts.wallFricCap ?? 1;
  // a small random push per person, redrawn every half second (10 % of the calm driving force, m·1.3/τ): people never
  // stand perfectly still in a crowd, and in the model a perfectly balanced standoff would otherwise last forever
  const NOISE = opts.noise ?? 0.1 * m * 1.3 / tau, nzx = new Float64Array(n), nzz = new Float64Array(n);
  let rs = (opts.seed ?? 1) * 2654435761 >>> 0; const rnd = () => { rs = (rs + 0x6D2B79F5) | 0; let q = Math.imul(rs ^ (rs >>> 15), 1 | rs); q = (q + Math.imul(q ^ (q >>> 7), 61 | q)) ^ q; return ((q ^ (q >>> 14)) >>> 0) / 4294967296; };
  const gauss = () => { let u = 0; while (u < 1e-12) u = rnd(); return Math.sqrt(-2 * Math.log(u)) * Math.cos(2 * Math.PI * rnd()); };
  let nextNoise = 0;
  // easing off: someone who has made no headway toward the exit for 3 s (a standoff at a door, an arch of bodies, a
  // knot where two streams meet) eases off for 1.2 s, stepping half-speed in a direction up to 90° off their way;
  // Helbing's model has no such rule, and without it a balanced standoff of a few people lasts forever. (Headway is
  // measured on the floor field, so people jostling on the spot count as stuck too.) easeRule 'speed': the older rule,
  // a person slower than 0.15 m/s for 3 s.
  const still = new Float64Array(n), ease = new Float64Array(n), eang = new Float64Array(n), STILL = opts.still ?? 3, EASE = 1.2;
  const BYSPEED = opts.easeRule === 'speed', eRef = new Float64Array(n), eT = new Float64Array(n), eDom = new Int16Array(n).fill(-1), HEAD = 0.15;
  people.forEach((p, i) => { x[i] = p.x; z[i] = p.z; r[i] = p.r; dom[i] = p.dom; });
  const D = world.domains;
  // people with no route to an exit (their cell has no floor field) are cut off: they stay where they are
  for (let i = 0; i < n; i++) { const d = D[dom[i]]; const ph = sample(d, d.phi, x[i], z[i]); const c = cellOf(d, x[i], z[i]); if (c < 0 || d.phi[c] >= INF * .5 || !(ph < INF * .5)) trapped[i] = 1; bestPhi[i] = ph; }
  const rec = opts.record ?? 0.1, frames = [], tFrames = []; let nextRec = 0;
  const doorLines = world.doorLines || [], crossings = doorLines.map(() => []), linesOf = D.map((d, k) => doorLines.map((dl, L) => (dl.dom === k ? L : -1)).filter((L) => L >= 0));
  const watch = opts.watch ?? 30;
  // waiting: time lost against free walking, binned on a 0.5 m grid per domain
  const LB = 0.5, lost = D.map((d) => ({ nx: Math.ceil(d.nx * d.h / LB), nz: Math.ceil(d.nz * d.h / LB), a: null })); for (const q of lost) q.a = new Float32Array(q.nx * q.nz);
  const peakRho = D.map((d, k) => new Float32Array(lost[k].nx * lost[k].nz));
  let badCross = 0, easings = 0, t = 0, done = false, lastOut = 0, nOut = 0, nTrapped = 0, violations = 0, steps = 0, clogged = false; for (let i = 0; i < n; i++) nTrapped += trapped[i];
  const NQ = new Float64Array(64);
  // neighbour hash per domain (rebuilt each step): cell -> linked list
  const hashes = D.map((d) => { const hx = Math.ceil(d.nx * d.h / HCELL) + 1, hz = Math.ceil(d.nz * d.h / HCELL) + 1; return { hx, hz, head: new Int32Array(hx * hz), next: new Int32Array(n) }; });
  const active = (i) => outT[i] < 0 && !trapped[i];
  function rebuild() {
    for (const H of hashes) H.head.fill(-1);
    for (let i = 0; i < n; i++) { if (outT[i] >= 0) continue; const d = D[dom[i]], H = hashes[dom[i]]; const a = Math.max(0, Math.min(H.hx - 1, Math.floor((x[i] - d.x0) / HCELL))), b = Math.max(0, Math.min(H.hz - 1, Math.floor((z[i] - d.z0) / HCELL))); const c = b * H.hx + a; H.next[i] = H.head[c]; H.head[c] = i; }
  }
  // the force between two people (social repulsion, and when they touch the body force and sliding friction), added
  // to i, and with the opposite sign to j when both = true (Newton's third law: one evaluation per pair)
  function pairForce(i, j, both) {
    const dx = x[i] - x[j], dz = z[i] - z[j], d2 = dx * dx + dz * dz, rij = r[i] + r[j];
    if (d2 > (rij + CUT) * (rij + CUT) || d2 < 1e-12) return;
    const d = Math.sqrt(d2), nx = dx / d, nz = dz / d, ov = rij - d;
    let f = P.A * Math.exp(ov / P.B), ftx = 0, ftz = 0;
    if (ov > 0) { f += P.k * ov; const tx = -nz, tz = nx; const dvt = (vx[j] - vx[i]) * tx + (vz[j] - vz[i]) * tz; let ft = P.kappa * ov * dvt;
      // (a friction impulse never reverses the sliding in one step: stability at large overlaps)
      const cap = Math.abs(dvt) * m * FCAP / DT; if (ft > cap) ft = cap; else if (ft < -cap) ft = -cap; ftx = ft * tx; ftz = ft * tz; }
    const Fx = f * nx + ftx, Fz = f * nz + ftz; fx[i] += Fx; fz[i] += Fz; if (both) { fx[j] -= Fx; fz[j] -= Fz; }
  }
  function step() {
    if (t >= nextNoise) { for (let i = 0; i < n; i++) { nzx[i] = gauss() * NOISE; nzz[i] = gauss() * NOISE; } nextNoise += 0.5; }
    rebuild(); fx.fill(0); fz.fill(0);
    for (let i = 0; i < n; i++) { if (outT[i] >= 0) continue; if (active(i)) own(i); pairs(i, false); }
    integrate();
  }
  // people near i: the same domain (each pair once), and across a portal (force on i only; rare)
  function pairs(i, all) {
    const dd = D[dom[i]], H = hashes[dom[i]], a0 = Math.floor((x[i] - dd.x0) / HCELL), b0 = Math.floor((z[i] - dd.z0) / HCELL);
    for (let b = b0 - 1; b <= b0 + 1; b++) { if (b < 0 || b >= H.hz) continue; for (let a = a0 - 1; a <= a0 + 1; a++) { if (a < 0 || a >= H.hx) continue;
      for (let j = H.head[b * H.hx + a]; j >= 0; j = H.next[j]) { if (j === i) continue; if (all) pairForce(i, j, false); else if (j > i) pairForce(i, j, true); } } }
    if (!active(i) || !world.links) return; const doms = world.links(dom[i], x[i], z[i]); if (!doms) return;
    for (let q = 0; q < doms.length; q++) { const dk = doms[q], de = D[dk], He = hashes[dk], a1 = Math.floor((x[i] - de.x0) / HCELL), b1 = Math.floor((z[i] - de.z0) / HCELL);
      for (let b = b1 - 1; b <= b1 + 1; b++) { if (b < 0 || b >= He.hz) continue; for (let a = a1 - 1; a <= a1 + 1; a++) { if (a < 0 || a >= He.hx) continue;
        for (let j = He.head[b * He.hx + a]; j >= 0; j = He.next[j]) { if (world.sameSide && !world.sameSide(dom[i], x[i], dk, x[j])) continue; pairForce(i, j, false); } } } }
  }
  // the person's own forces: the drive toward the desired velocity, the random push, the walls
  function own(i) {
    {
      const d = D[dom[i]];
      const c = cellOf(d, x[i], z[i]); const sl = c >= 0 ? d.slow[c] / 255 : 1; let ex = c >= 0 ? d.ex[c] : 0, ez = c >= 0 ? d.ez[c] : 0, vd = v0 * sl;
      if (ease[i] > t) { const ca = Math.cos(eang[i]), sa = Math.sin(eang[i]), qx = ex * ca - ez * sa; ez = ex * sa + ez * ca; ex = qx; vd *= 0.5; }
      fx[i] += m * (vd * ex - vx[i]) / tau + nzx[i]; fz[i] += m * (vd * ez - vz[i]) / tau + nzz[i];
      // walls: one force from each wall within reach, from its nearest point (a corner shared by two walls counts once)
      { const Wl = d.walls, a = Math.floor((x[i] - d.x0) / WB), b = Math.floor((z[i] - d.z0) / WB);
        if (a >= 0 && b >= 0 && a < Wl.bx && b < Wl.bz) { const q0 = Wl.start[b * Wl.bx + a], q1 = Wl.start[b * Wl.bx + a + 1]; let nq = 0;
          const xi = x[i], zi = z[i], R = r[i] + CUT, sg = Wl.segs;
          for (let q = q0; q < q1; q++) { const s = Wl.items[q] * 4, vert = sg[s] === 0, cst = sg[s + 1], lo = sg[s + 2], hi = sg[s + 3];
            const perp = (vert ? xi : zi) - cst; if (perp > R || perp < -R) continue;
            const along = vert ? zi : xi, cl = along < lo ? lo : along > hi ? hi : along, end = along < lo || along > hi;
            const px = vert ? cst : cl, pz = vert ? cl : cst;
            const ddx = xi - px, ddz = zi - pz, dd = Math.sqrt(ddx * ddx + ddz * ddz); if (dd > R || dd < 1e-9) continue;
            // Helbing's wall force pushes along n_iW, perpendicular to the wall: it acts where a person is alongside a wall
            // face. A wall's end (a door edge, an outside corner) has no perpendicular: there only the body force and
            // the sliding friction act, when the body touches it. (With the exponential force also coming from the
            // edges, a single person with r = 0.35 m could not pass a 0.9 m door at 1.3 m/s.)
            if (end && dd >= r[i]) continue;
            let dup = false; for (let u = 0; u < nq; u++) if (Math.abs(NQ[u * 2] - px) < 1e-3 && Math.abs(NQ[u * 2 + 1] - pz) < 1e-3) { dup = true; break; } if (dup) continue; NQ[nq * 2] = px; NQ[nq * 2 + 1] = pz; nq++;
            const nx = ddx / dd, nz = ddz / dd, ov = r[i] - dd; let f = end ? 0 : P.A * Math.exp(ov / P.B);
            if (ov > 0) { f += P.k * ov; const tx = -nz, tz = nx, vt = vx[i] * tx + vz[i] * tz; let ft = P.kappa * ov * vt; const cap = Math.abs(vt) * m * WCAP / DT; if (ft > cap) ft = cap; else if (ft < -cap) ft = -cap; fx[i] -= ft * tx; fz[i] -= ft * tz; }
            fx[i] += f * nx; fz[i] += f * nz; } } }
    }
  }
  function integrate() {
    // integrate (semi-implicit Euler) and keep every centre out of the walls
    for (let i = 0; i < n; i++) {
      if (!active(i)) continue;
      vx[i] += fx[i] / m * DT; vz[i] += fz[i] / m * DT;
      const sp = Math.hypot(vx[i], vz[i]); if (sp > 12) { vx[i] *= 12 / sp; vz[i] *= 12 / sp; }
      if (BYSPEED) { if (sp > 0.15 || ease[i] > t) still[i] = 0; else if ((still[i] += DT) > STILL) { still[i] = 0; ease[i] = t + EASE; eang[i] = (rnd() * 2 - 1) * Math.PI / 2; easings++; } }
      const d = D[dom[i]]; let nxp = x[i] + vx[i] * DT, nzp = z[i] + vz[i] * DT;
      const c0 = cellOf(d, nxp, nzp), wd = c0 >= 0 && d.dist[c0] > 0.12 ? 1 : sample(d, d.dist, nxp, nzp);
      if (wd < 0.03) {   // a centre must never enter a wall: push it back out along the wall normal
        const hh = d.h * .5, gx = sample(d, d.dist, nxp + hh, nzp) - sample(d, d.dist, nxp - hh, nzp), gz = sample(d, d.dist, nxp, nzp + hh) - sample(d, d.dist, nxp, nzp - hh), gl = Math.hypot(gx, gz) || 1;
        nxp += gx / gl * (0.03 - wd); nzp += gz / gl * (0.03 - wd); const vn = (vx[i] * gx + vz[i] * gz) / gl; if (vn < 0) { vx[i] -= vn * gx / gl; vz[i] -= vn * gz / gl; }
        if (sample(d, d.dist, nxp, nzp) < -0.02) { nxp = x[i]; nzp = z[i]; vx[i] = 0; vz[i] = 0; violations++; }
      }
      // door lines crossed (flow counts)
      const myLines = linesOf[dom[i]];
      for (let q = 0; q < myLines.length; q++) { const L = myLines[q], dl = doorLines[L];
        const a1 = dl.axis === 'z' ? x[i] : z[i], b0 = dl.axis === 'z' ? z[i] : x[i], b1 = dl.axis === 'z' ? nzp : nxp; const a2 = dl.axis === 'z' ? nxp : nzp;
        if ((b0 - dl.at) * (b1 - dl.at) < 0 && (a1 + a2) * .5 >= dl.a0 && (a1 + a2) * .5 <= dl.a1) crossings[L].push(t, (b1 - b0) * dl.sign > 0 ? 1 : -1); }
      x[i] = nxp; z[i] = nzp;
      // portals and exits
      const ex = world.exitOf(dom[i], x[i], z[i]); if (ex >= 0) { outT[i] = t; exitId[i] = ex; nOut++; lastOut = t; continue; }
      // (a crossing only lands on free space in the other domain; anything else would be a geometry error, counted)
      const nd = world.transfer(dom[i], x[i], z[i]); if (nd >= 0 && nd !== dom[i]) { const cn = cellOf(D[nd], x[i], z[i]); if (cn >= 0 && !D[nd].solid[cn]) dom[i] = nd; else badCross++; }
    }
    t += DT; steps++;
  }
  // the local density each person stands in (people within 0.75 m on the same domain, over that disc's area) and
  // time lost against free walking, binned for the bottleneck search
  const RHO_R = 0.75, RHO_A = Math.PI * RHO_R * RHO_R;
  function measure(dtm) {
    for (let i = 0; i < n; i++) {
      if (!active(i)) continue; const d = D[dom[i]], H = hashes[dom[i]], Lb = lost[dom[i]];
      let cnt = 1; const a0 = Math.floor((x[i] - d.x0) / HCELL), b0 = Math.floor((z[i] - d.z0) / HCELL);
      for (let b = b0 - 1; b <= b0 + 1; b++) { if (b < 0 || b >= H.hz) continue; for (let a = a0 - 1; a <= a0 + 1; a++) { if (a < 0 || a >= H.hx) continue; for (let j = H.head[b * H.hx + a]; j >= 0; j = H.next[j]) if (j !== i && (x[i] - x[j]) ** 2 + (z[i] - z[j]) ** 2 < RHO_R * RHO_R) cnt++; } }
      const rho = cnt / RHO_A; const c = cellOf(d, x[i], z[i]); const sl = c >= 0 ? d.slow[c] / 255 : 1;
      const lb = Math.max(0, Math.min(Lb.nx - 1, Math.floor((x[i] - d.x0) / LB))) + Math.max(0, Math.min(Lb.nz - 1, Math.floor((z[i] - d.z0) / LB))) * Lb.nx;
      const sp = Math.hypot(vx[i], vz[i]), free = Math.max(0.05, v0 * sl); Lb.a[lb] += Math.max(0, 1 - sp / free) * dtm;
      if (rho > peakRho[dom[i]][lb]) peakRho[dom[i]][lb] = rho;
      // watchdog: progress along the floor field
      const ph = sample(d, d.phi, x[i], z[i]); if (ph < bestPhi[i] - 0.3) { bestPhi[i] = ph; lastProg[i] = t; } else if (t - lastProg[i] > watch) stuck[i] = 1;
      // easing off (above): no headway for STILL seconds
      if (!BYSPEED && ease[i] <= t) { if (ph < eRef[i] - HEAD || dom[i] !== eDom[i]) { eRef[i] = ph; eT[i] = t; eDom[i] = dom[i]; } else if (t - eT[i] > STILL) { ease[i] = t + EASE; eang[i] = (rnd() * 2 - 1) * Math.PI / 2; easings++; eRef[i] = ph; eT[i] = t + EASE; } }
    }
  }
  function record() { const f = new Float32Array(n * 3); for (let i = 0; i < n; i++) { f[i * 3] = x[i]; f[i * 3 + 1] = z[i]; f[i * 3 + 2] = outT[i] >= 0 ? -1 : dom[i]; } frames.push(f); tFrames.push(t); }
  const tMax = opts.tMax ?? 600, clogAfter = opts.clogAfter ?? 120;
  let nextMeasure = 0;
  // advance by up to `simSeconds` (or until done); returns true when finished
  function run(simSeconds = Infinity, wallMs = Infinity) {
    const t1 = t + simSeconds, w0 = Date.now();
    while (!done && t < t1) {
      if (t >= nextRec - 1e-9) { record(); nextRec += rec; }
      step();
      if (t >= nextMeasure) { measure(0.1); nextMeasure += 0.1; }
      if (nOut + nTrapped >= n) done = true;
      else if (t > tMax) done = true;
      else if (t - lastOut > clogAfter && t > clogAfter) { done = true; clogged = true; }
      if ((steps & 63) === 0 && Date.now() - w0 > wallMs) break;
    }
    if (done && (!tFrames.length || tFrames[tFrames.length - 1] < t - 1e-9)) record();
    return done;
  }
  // (tests) the forces on one person right now
  function probe(i) { const d = D[dom[i]]; const cc = cellOf(d, x[i], z[i]); const out = { e: cc >= 0 ? [d.ex[cc], d.ez[cc]] : [0, 0], phi: sample(d, d.phi, x[i], z[i]), dist: sample(d, d.dist, x[i], z[i]) };
    const kx = fx.slice(), kz = fz.slice(); rebuild(); fx[i] = 0; fz[i] = 0; if (active(i)) own(i); pairs(i, true); out.f = [fx[i], fz[i]]; fx.set(kx); fz.set(kz); return out; }
  return {
    run, probe, get t() { return t; }, get done() { return done; }, n, x, z, dom, r, vx, vz, outT, exitId, trapped, stuck,
    get nOut() { return nOut; }, get nTrapped() { return nTrapped; }, get violations() { return violations; },
    get frames() { return frames; }, get tFrames() { return tFrames; },   // (the recorded frames so far, for streaming a run)
    result() {
      const times = []; for (let i = 0; i < n; i++) if (outT[i] >= 0) times.push(outT[i]); times.sort((a, b) => a - b);
      const flows = doorLines.map((dl, L) => { const c = crossings[L], bins = new Float32Array(Math.ceil(t) + 1); let net = 0; for (let q = 0; q < c.length; q += 2) { bins[Math.floor(c[q])] += c[q + 1]; net += c[q + 1]; }
        let peak = 0; for (let b = 0; b < bins.length; b++) { const s = (bins[b] + (bins[b + 1] || 0) + (bins[b - 1] || 0)) / 3; if (s > peak) peak = s; }   // 3 s running mean
        // the sustained flow: people over the time between the 10th and 90th percentile crossing
        const ts = []; for (let q = 0; q < c.length; q += 2) if (c[q + 1] > 0) ts.push(c[q]); let sustained = 0; if (ts.length >= 6) { const a = ts[Math.floor(ts.length * .1)], b = ts[Math.floor(ts.length * .9)]; if (b > a) sustained = (Math.floor(ts.length * .9) - Math.floor(ts.length * .1)) / (b - a); }
        return { id: dl.id, n: net, peak, sustained, width: dl.a1 - dl.a0, bins }; });
      return { n, out: times.length, trapped: nTrapped, stuck: stuck.reduce((s, v) => s + v, 0), clogged, tEnd: t, times, total: times.length ? times[times.length - 1] : NaN, outT: Array.from(outT), exitId: Array.from(exitId),
        easings, badCross, frames, tFrames, flows, lost: lost.map((q) => ({ nx: q.nx, nz: q.nz, a: q.a, cell: LB })), peakRho, violations, steps };
    },
  };
}
