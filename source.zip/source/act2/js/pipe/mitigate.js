// Change one thing: each fix is applied to the plan, then the access graph (β₁, weak links, percolation margin) and
// the crowd are run again from the same people (three runs, the random pushes reseeded), and compared with the building
// as surveyed.
import { accessGraph, crowdWorld } from './plan.js';
import { percolation } from './percolation.js';

export const FIXES = [
  { id: 'clear', name: 'Move the scooters out of the lobby', short: 'Lobby cleared' },
  { id: 'rear', name: 'Keep the rear door unlocked at night', short: 'Rear door unlocked' },
  { id: 'widen', name: 'Widen the bottleneck door', short: 'Door widened' },
];
// the plan options for a set of fixes (and the viewer's blocks and door width in the sandbox)
export function planOpts(C, fixes = [], extra = {}) {
  const o = { clutter: fixes.includes('clear') ? null : C.clutter, rearOpen: fixes.includes('rear'), widen: {}, blocked: extra.blocked || null };
  if (fixes.includes('widen') && C.widenDoor != null) o.widen[C.widenDoor] = C.widenTo;
  if (extra.doorWidth && C.widenDoor != null) o.widen[C.widenDoor] = extra.doorWidth;
  return o;
}
// which door the "widen" fix acts on: the door with the most time lost at it in the full-house run (or, if the worst
// place is not a door, the busiest door on the way out), widened to 1.2 m (a door that is already 1.2 m or more by 0.4 m)
export function pickWiden(C, an) {
  const doorHot = (an.bottlenecks || []).find((b) => b.kind === 'door');
  let link = doorHot ? C.G.links[doorHot.link] : null;
  if (!link) { const f = (an.flows || []).find((q) => q.kind === 'door'); link = f ? C.G.links[f.link] : C.G.links.find((l) => l.exit === 'street'); }
  const o = C.model.openings[link.door], to = o.w < 1.2 ? 1.2 : Math.round((o.w + 0.4) * 10) / 10;
  return { door: o.id, link: link.id, from: o.w, to, label: link.label };
}
export function graphFor(C, fixes, extra = {}) {
  const o = planOpts(C, fixes, extra), G = accessGraph(C.model, o);
  const pc = percolation(G, C.night.people, { seed: C.seed, trials: extra.trials || 1200, blocked: o.blocked });
  return { G, o, perc: pc };
}
export function worldFor(C, fixes, extra = {}) { const o = planOpts(C, fixes, extra), G = extra.G || accessGraph(C.model, o); return { G, W: crowdWorld(C.model, G, o), o }; }
