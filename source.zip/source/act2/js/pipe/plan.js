// The building as the crowd model and the access graph see it, built from the semantic model (act7's buildBuilding):
//   - crowd domains: one 2-D plan per floor (rooms, halls, the stair core, the door openings, columns, anything parked
//     in the lobby, and the yard just outside each exit) and one per stair (the two flights and the mid-landing between
//     two floors, unfolded into plan). People change domain at the top of each flight.
//   - the access graph: rooms, hall junctions, the core of each floor, the stair landings and the outside, joined by
//     doors, corridor segments and stair flights. β₁ (independent loops = alternative routes), bridges (one blockage
//     cuts something off) and dead ends are counted on it.
// Options (the fixes and the sandbox): { rearOpen, clutter: [...boxes] | null, widen: { door id: width }, blocked: Set(link ids) }
import { floorTop, NS, T_EXT, T_INT, SH } from '../../../act7/js/building/building.js';
import { rngFor } from '../../../act7/js/building/geom.js';
import { prepDomain, floorField, sample, cellOf } from './crowd.js';

export const H = 0.05;                      // crowd grid, m
export const STAIR_K = 1.2, LEVEL_K = 1.4;  // SFPE speed constants: stairs of this rise/run, level floors (speed ∝ k)
export const STOOP = 0.5;                   // speed factor under the 1.3 m stair landing (our assumption)
export const HEADROOM = 2.0;                // m: less than this is walked stooping
const FLOOR_NAME = ['ground', 'first', 'second', 'third'];

// ------------------------------------------------------------------ geometry shared by the domains and the graph
export function stairGeom(model) {
  const { D, c, zb } = model.dims, zL = -D / 2 + T_EXT, zTop = -D / 2 + 1.3, run = zb - zTop, theta = Math.atan2(1.5, run);
  const inX = c - T_EXT / 2;                                     // the core's inner wall face
  const f = STAIR_K / LEVEL_K * Math.cos(theta);                // desired speed in plan on a flight, as a share of level walking
  // headroom on the ground floor under the flight that rises from the landing (zTop, 1.5 m up) to the first floor (zb)
  const y0 = floorTop(0), yM = y0 + 1.5, yB = floorTop(1);
  const head = (z) => (z <= zTop ? (yM - 0.2) - y0 : (yM + (yB - yM) * (z - zTop) / run) - 0.27 - y0);
  return { zL, zTop, run, theta, inX, f, head, zb, c };
}
// the lobby clutter for a seed: two or three scooters parked along the core walls between the flat entries and the
// street door (an everyday sight; on survey day the drones map them like everything else)
export function lobbyClutter(model, seed) {
  const r = rngFor(seed, 'clutter'), { D, zf, c } = model.dims, inX = c - T_EXT / 2;
  const n = r() < 0.62 ? 3 : 2, out = [];
  // parked in a row: the same stretch of the lobby, square to the walls
  const zMin = zf + 0.35, zMax = D / 2 - T_EXT - 0.45, len = 1.75, z0 = zMin + r() * Math.max(0, zMax - zMin - len), w = () => 0.58 + r() * 0.08;
  const a = w(); out.push({ x0: -inX + 0.04, x1: -inX + 0.04 + a, z0, z1: z0 + len, kind: 'scooter' });
  const b = w(); out.push({ x0: inX - 0.04 - b, x1: inX - 0.04, z0, z1: z0 + len, kind: 'scooter' });
  if (n === 3) { const q = w(); out.push({ x0: -inX + 0.08 + a, x1: -inX + 0.08 + a + q, z0, z1: z0 + len, kind: 'scooter' }); }
  return out;
}
// the clear width left between the clutter and the core walls (the narrowest cross-section of the lobby)
export function lobbyGap(model, clutter) {
  const inX = model.dims.c - T_EXT / 2; if (!clutter || !clutter.length) return 2 * inX;
  let best = 2 * inX; const zs = new Set(); for (const b of clutter) { zs.add(b.z0 + 0.01); zs.add(b.z1 - 0.01); zs.add((b.z0 + b.z1) / 2); }
  for (const z of zs) { const iv = clutter.filter((b) => z >= b.z0 && z <= b.z1).map((b) => [b.x0, b.x1]).sort((p, q) => p[0] - q[0]); let x = -inX, gap = 0; for (const [a0, a1] of iv) { gap = Math.max(gap, a0 - x); x = Math.max(x, a1); } gap = Math.max(gap, inX - x); best = Math.min(best, gap); }
  return best;
}

// ------------------------------------------------------------------ the access graph
// nodes: { id, kind: room|junction|core|lobby|landing|rearp|out, storey, p: [x, y, z], room? }
// links: { id, a, b, kind: door|corridor|flight|exit, storey, p (midpoint), len, width, label, door?: opening id }
export function accessGraph(model, opts = {}) {
  const { L, D, c, zb, zf, flats } = model.dims, S = stairGeom(model), nodes = [], links = [];
  const node = (o) => { o.id = nodes.length; nodes.push(o); return o.id; };
  const link = (a, b, o) => { const A = nodes[a].p, B = nodes[b].p; const l = { id: links.length, a, b, len: o.len ?? Math.hypot(A[0] - B[0], A[2] - B[2]), p: o.p || [(A[0] + B[0]) / 2, (A[1] + B[1]) / 2, (A[2] + B[2]) / 2], ...o }; links.push(l); return l.id; };
  const out = node({ kind: 'out', storey: 0, p: [0, 0, D / 2 + 2.6], name: 'outside' });
  const core = [], landing = [];
  for (let s = 0; s < NS; s++) core.push(node({ kind: 'core', storey: s, p: [0, floorTop(s), (zb + zf) / 2], name: `${FLOOR_NAME[s]}-floor landing` }));
  for (let s = 0; s < NS - 1; s++) landing.push(node({ kind: 'landing', storey: s, p: [0, floorTop(s) + 1.5, (S.zL + S.zTop) / 2], name: `half-landing above the ${FLOOR_NAME[s]} floor` }));
  // the flats: rooms on their halls
  const doorOf = (room) => model.openings.find((o) => o.kind === 'door' && o.rooms.includes(room.id));
  for (let s = 0; s < NS; s++) for (const F of ['A', 'B']) {
    const hall = model.rooms.find((q) => q.storey === s && q.flat === F && q.kind === 'hall'), sg = F === 'A' ? -1 : 1;
    const entry = model.openings.find((o) => o.kind === 'entry' && o.storey === s && o.rooms.includes(hall.id));
    const hz = (hall.z0 + hall.z1) / 2, y = floorTop(s);
    const rooms = model.rooms.filter((q) => q.storey === s && q.flat === F && q.kind !== 'hall').map((q) => ({ room: q, door: doorOf(q) })).filter((q) => q.door);
    // junctions along the hall: the entry, then each door position (doors within 0.4 m share one)
    const us = [...new Set(rooms.map((q) => Math.round(Math.abs((q.door.o0 + q.door.o1) / 2) * 10) / 10))].sort((a, b) => a - b), J = [];
    const j0 = node({ kind: 'junction', storey: s, p: [sg * (c + 0.35), y, hz], flat: F, name: `flat ${F} hall, at its door` }); J.push({ u: c, id: j0 });
    for (const u of us) { if (u - J[J.length - 1].u < 0.4) continue; J.push({ u, id: node({ kind: 'junction', storey: s, p: [sg * u, y, hz], flat: F, name: `flat ${F} hall` }) }); }
    link(core[s], j0, { kind: 'door', storey: s, door: entry.id, width: entry.w, label: `flat ${F} front door, ${FLOOR_NAME[s]} floor`, p: [sg * c, y, (entry.o0 + entry.o1) / 2] });
    for (let k = 1; k < J.length; k++) link(J[k - 1].id, J[k].id, { kind: 'corridor', storey: s, width: hall.z1 - hall.z0, label: `flat ${F} hall, ${FLOOR_NAME[s]} floor`, flat: F, cut: { axis: 'x', at: sg * (J[k - 1].u + J[k].u) / 2, a0: hall.z0, a1: hall.z1 } });
    for (const q of rooms) {
      const u = Math.abs((q.door.o0 + q.door.o1) / 2); let jb = J[0]; for (const j of J) if (Math.abs(j.u - u) < Math.abs(jb.u - u)) jb = j;
      const rn = node({ kind: 'room', storey: s, p: [(q.room.x0 + q.room.x1) / 2, y, (q.room.z0 + q.room.z1) / 2], room: q.room.id, flat: F, name: q.room.name });
      link(jb.id, rn, { kind: 'door', storey: s, door: q.door.id, width: q.door.w, label: `${q.room.short.toLowerCase()} door, flat ${F}, ${FLOOR_NAME[s]} floor`, p: [(q.door.o0 + q.door.o1) / 2, y, q.door.off] });
    }
    // the hall beyond its last door leads nowhere: a dead-end stub
    const last = J[J.length - 1].u, end = L / 2 - T_EXT; if (end - last > 1.0) nodes[J[J.length - 1].id].stub = { len: end - last, p: [sg * (last + end) / 2, y, hz] };
  }
  // the stair: from each floor down to the half-landing, then down to the floor below
  const fl = [];
  for (let s = 0; s < NS - 1; s++) {
    fl.push(link(core[s + 1], landing[s], { kind: 'flight', storey: s, upper: true, width: S.inX - 0.05, label: `stair, ${FLOOR_NAME[s + 1]} floor down to the half-landing`, p: [(0.05 + S.inX) / 2, floorTop(s) + 2.25, (S.zTop + zb) / 2], len: Math.hypot(S.run, 1.5) }));
    fl.push(link(landing[s], core[s], { kind: 'flight', storey: s, upper: false, width: S.inX - 0.05, label: `stair, half-landing down to the ${FLOOR_NAME[s]} floor`, p: [-(0.05 + S.inX) / 2, floorTop(s) + 0.75, (S.zTop + zb) / 2], len: Math.hypot(S.run, 1.5) }));
  }
  // the ground floor: the lobby to the street door, and the passage under the stair to the rear door
  const y0 = floorTop(0);
  const lobby = node({ kind: 'lobby', storey: 0, p: [0, y0, D / 2 - T_EXT - 0.6], name: 'lobby, at the street door' });
  const street = model.openings.find((o) => o.kind === 'street'), rear = model.openings.find((o) => o.kind === 'rear');
  const gap = lobbyGap(model, opts.clutter);
  link(core[0], lobby, { kind: 'corridor', storey: 0, width: gap, label: 'the lobby', lobby: true, cut: { axis: 'z', at: (zf + D / 2) / 2 + 0.6, a0: -S.inX, a1: S.inX } });
  link(lobby, out, { kind: 'door', storey: 0, door: street.id, width: (opts.widen && opts.widen[street.id]) || street.w, label: 'the street door', exit: 'street', p: [0, y0, D / 2] });
  const rp = node({ kind: 'rearp', storey: 0, p: [0.45, y0, -D / 2 + T_EXT + 0.5], name: 'under the stair, at the rear door' });
  link(core[0], rp, { kind: 'corridor', storey: 0, width: S.inX - 0.05, label: 'the passage under the stair', under: true, low: S.head(S.zTop), cut: { axis: 'z', at: (S.zTop + zb) / 2, a0: 0.05, a1: S.inX } });
  const rl = link(rp, out, { kind: 'door', storey: 0, door: rear.id, width: rear.w, label: 'the rear door', exit: 'rear', p: [(rear.o0 + rear.o1) / 2, y0, -D / 2], locked: !opts.rearOpen });
  return { nodes, links, out, core, landing, lobby, rearLink: rl, flights: fl, gap };
}
// connectivity with some links removed (blocked or locked): which nodes still reach the outside
export function reachOut(G, off) {
  const adj = G.adj || (G.adj = (() => { const a = G.nodes.map(() => []); for (const l of G.links) { a[l.a].push(l.id); a[l.b].push(l.id); } return a; })());
  const seen = new Uint8Array(G.nodes.length), st = [G.out]; seen[G.out] = 1;
  while (st.length) { const u = st.pop(); for (const li of adj[u]) { if (off[li]) continue; const l = G.links[li], v = l.a === u ? l.b : l.a; if (!seen[v]) { seen[v] = 1; st.push(v); } } }
  return seen;
}
export const offOf = (G, blocked) => { const off = new Uint8Array(G.links.length); for (const l of G.links) if (l.locked || (blocked && blocked.has(l.id))) off[l.id] = 1; return off; };
// β₀ (pieces), β₁ (independent loops) of the graph without the off links; per floor too (the outside counts on the
// ground floor, so a second exit is a loop there)
export function betti(G, off) {
  const count = (keepNode) => {
    const par = G.nodes.map((n, i) => i), find = (u) => { while (par[u] !== u) { par[u] = par[par[u]]; u = par[u]; } return u; };
    let V = 0, E = 0; for (const n of G.nodes) if (keepNode(n)) V++;
    for (const l of G.links) { if (off[l.id] || !keepNode(G.nodes[l.a]) || !keepNode(G.nodes[l.b])) continue; E++; const a = find(l.a), b = find(l.b); if (a !== b) par[a] = b; }
    let Cc = 0; G.nodes.forEach((n, i) => { if (keepNode(n) && find(i) === i) Cc++; });
    return { V, E, C: Cc, b1: E - V + Cc };
  };
  const all = count(() => true), floors = [];
  for (let s = 0; s < NS; s++) floors.push(count((n) => (n.kind === 'landing' ? false : n.kind === 'out' ? s === 0 : n.storey === s)).b1);
  return { b0: all.C, b1: all.b1, floors };
}
// bridges (Tarjan): links whose loss splits the graph
export function bridges(G, off) {
  const n = G.nodes.length, disc = new Int32Array(n).fill(-1), low = new Int32Array(n), adj = G.adj || reachOut(G, off) && G.adj, out = []; let t = 0;
  const dfs = (u, pl) => { disc[u] = low[u] = t++; for (const li of adj[u]) { if (off[li] || li === pl) continue; const l = G.links[li], v = l.a === u ? l.b : l.a; if (disc[v] < 0) { dfs(v, li); low[u] = Math.min(low[u], low[v]); if (low[v] > disc[u]) out.push(li); } else low[u] = Math.min(low[u], disc[v]); } };
  for (let u = 0; u < n; u++) if (disc[u] < 0) dfs(u, -1);
  return out;
}

// ------------------------------------------------------------------ the crowd domains
// returns { domains, transfer, exitOf, links, sameSide, doorLines, heightAt, F (floor domain index per storey), U (stair domain per flight) }
export function crowdWorld(model, G, opts = {}) {
  const { L, D, c, zb, zf } = model.dims, S = stairGeom(model), inX = S.inX, blocked = opts.blocked || new Set();
  const domains = [], F = [], U = [];
  // a rectangle covers the cells whose centres lie inside it (so widths are right to within half a cell)
  const rect = (d, x0, z0, x1, z1, v) => { const i0 = Math.max(0, Math.ceil((x0 - d.x0) / H - .5)), i1 = Math.min(d.nx - 1, Math.floor((x1 - d.x0) / H - .5)), k0 = Math.max(0, Math.ceil((z0 - d.z0) / H - .5)), k1 = Math.min(d.nz - 1, Math.floor((z1 - d.z0) / H - .5)); for (let k = k0; k <= k1; k++) for (let i = i0; i <= i1; i++) d.solid[k * d.nx + i] = v; };
  const mk = (kind, storey, x0, z0, x1, z1) => { const nx = Math.ceil((x1 - x0) / H), nz = Math.ceil((z1 - z0) / H); return { kind, storey, x0, z0, nx, nz, h: H, solid: new Uint8Array(nx * nz).fill(1), slow: new Uint8Array(nx * nz).fill(255) }; };
  const doorRect = (o, w) => { const t = model.walls[o.unit].t, m = (o.o0 + o.o1) / 2, hw = (w ?? o.w) / 2; return o.axis === 'x' ? [o.off - t / 2 - 0.02, m - hw, o.off + t / 2 + 0.02, m + hw] : [m - hw, o.off - t / 2 - 0.02, m + hw, o.off + t / 2 + 0.02]; };
  const widthOf = (o) => (opts.widen && opts.widen[o.id]) || o.w;
  const linkByDoor = new Map(); for (const l of G.links) if (l.door != null) linkByDoor.set(l.door, l);
  // ---- floors
  for (let s = 0; s < NS; s++) {
    const d = mk('floor', s, -L / 2 - 0.3, -D / 2 - 2.6, L / 2 + 0.3, D / 2 + 2.6);
    for (const room of model.rooms) { if (room.storey !== s || room.kind === 'core') continue; rect(d, room.x0, room.z0, room.x1, room.z1, 0); }
    rect(d, -inX, zb, inX, D / 2 - T_EXT, 0);                               // the core's floor in front of the stair
    if (s >= 1) rect(d, 0.05, zb - 1.0, inX, zb, 0);                        // the top of the flight down (east)
    if (s <= NS - 2) rect(d, -inX, zb - 1.0, -0.05, zb, 0);                 // the foot of the flight from above (west)
    if (s === 0) rect(d, 0.05, S.zL, inX, zb, 0);                           // under the stair, to the rear door
    for (const o of model.openings) {
      if (o.storey !== s || !['door', 'entry', 'street', 'rear'].includes(o.kind)) continue;
      if (o.kind === 'rear' && !opts.rearOpen) continue;
      const lk = linkByDoor.get(o.id); if (lk && blocked.has(lk.id)) continue;
      const [a, b, cc, e] = doorRect(o, widthOf(o)); rect(d, a, b, cc, e, 0);
    }
    if (s === 0) { rect(d, -1.9, D / 2, 1.9, D / 2 + 2.6, 0); if (opts.rearOpen) rect(d, -1.0, -D / 2 - 2.6, 1.9, -D / 2, 0); }
    // columns (they stand a few centimetres proud of the walls), parked things, barriers
    for (const p of model.parts) if (p.kind === 'column' && p.storey === s) rect(d, p.aabb[0], p.aabb[2], p.aabb[3], p.aabb[5], 1);
    if (s === 0 && opts.clutter) for (const b of opts.clutter) rect(d, b.x0, b.z0, b.x1, b.z1, 1);
    for (const l of G.links) if (blocked.has(l.id) && l.storey === s && l.cut && l.kind === 'corridor') { const q = l.cut; if (q.axis === 'x') rect(d, q.at - 0.08, q.a0 - 0.05, q.at + 0.08, q.a1 + 0.05, 1); else rect(d, q.a0 - 0.05, q.at - 0.08, q.a1 + 0.05, q.at + 0.08, 1); }
    // stooping under the landing on the ground floor
    if (s === 0) for (let k = 0; k < d.nz; k++) { const z = d.z0 + (k + .5) * H; if (z >= zb || S.head(z) >= HEADROOM) continue; for (let i = 0; i < d.nx; i++) { const x = d.x0 + (i + .5) * H; if (x > 0 && x < inX + 0.01) d.slow[k * d.nx + i] = Math.round(255 * STOOP); } }
    F.push(domains.length); domains.push(prepDomain(d));
  }
  // ---- stairs (flight s joins floor s+1, above, to floor s)
  for (let s = 0; s < NS - 1; s++) {
    const d = mk('stair', s, -c - 0.1, -D / 2 - 0.1, c + 0.1, zb + 1.1);
    rect(d, 0.05, S.zL, inX, zb, 0); rect(d, -inX, S.zL, -0.05, zb, 0); rect(d, -inX, S.zL, inX, S.zTop, 0);
    rect(d, -inX, zb, -0.05, zb + 1.0, 0); rect(d, 0.05, zb, inX, zb + 1.0, 0);   // past the top of each flight: two different floors, so the divider carries on
    for (const l of G.links) if (blocked.has(l.id) && l.kind === 'flight' && l.storey === s) { const xa = l.upper ? 0.05 : -inX, xb = l.upper ? inX : -0.05, zm = (S.zTop + zb) / 2; rect(d, xa - 0.05, zm - 0.08, xb + 0.05, zm + 0.08, 1); }
    for (let k = 0; k < d.nz; k++) { const z = d.z0 + (k + .5) * H; if (z <= S.zTop || z >= zb) continue; for (let i = 0; i < d.nx; i++) d.slow[k * d.nx + i] = Math.round(255 * S.f); }
    U.push(domains.length); domains.push(prepDomain(d));
  }
  // ---- floor fields, from the exits up: floor 0, flight 0, floor 1, flight 1, ...
  const exitFront = D / 2 + 1.5, exitRear = -D / 2 - 1.5;
  { const d = domains[F[0]], src = []; for (let k = 0; k < d.nz; k++) { const z = d.z0 + (k + .5) * H; if (z > exitFront + 0.1 || (opts.rearOpen && z < exitRear - 0.1)) for (let i = 0; i < d.nx; i++) if (!d.solid[k * d.nx + i]) src.push([k * d.nx + i, 0]); } floorField(d, src); }
  const copy = (to, from, pred) => { const src = []; for (let k = 0; k < to.nz; k++) for (let i = 0; i < to.nx; i++) { const c2 = k * to.nx + i; if (to.solid[c2]) continue; const x = to.x0 + (i + .5) * H, z = to.z0 + (k + .5) * H; if (!pred(x, z)) continue; const cf = cellOf(from, x, z); if (cf < 0 || from.phi[cf] >= 1e8) continue; src.push([c2, from.phi[cf]]); } return src; };
  for (let s = 0; s < NS - 1; s++) {
    const u = domains[U[s]]; floorField(u, copy(u, domains[F[s]], (x, z) => x < -0.05 && z > zb + 0.05));
    const f = domains[F[s + 1]]; floorField(f, copy(f, u, (x, z) => x > 0.05 && z < zb - 0.05 && z > zb - 0.9));
  }
  // ---- crossings
  const transfer = (di, x, z) => {
    const d = domains[di];
    if (d.kind === 'stair') { if (z > zb) return x < 0 ? F[d.storey] : F[d.storey + 1]; return -1; }
    // (only inside the stair well: behind the block, outside the rear door, is not the foot of a flight)
    if (z < zb && z > S.zL - 0.05 && Math.abs(x) < inX + 0.05) { if (x > 0 && d.storey >= 1) return U[d.storey - 1]; if (x < 0 && d.storey <= NS - 2) return U[d.storey]; }
    return -1;
  };
  const exitOf = (di, x, z) => (di !== F[0] ? -1 : z > exitFront ? 0 : z < exitRear ? 1 : -1);
  // people on either side of a flight's top can touch (same side of the stair divider only)
  const one = domains.map(() => [0]); const L1 = (k) => { const a = one[k]; a[0] = k; return a; };
  const links = (di, x, z) => { if (Math.abs(z - zb) > 1.25 || Math.abs(x) > inX + 0.1) return null; const d = domains[di];
    if (d.kind === 'stair') return L1(x < 0 ? F[d.storey] : F[d.storey + 1]);
    if (x > 0 && d.storey >= 1) return L1(U[d.storey - 1]); if (x < 0 && d.storey <= NS - 2) return L1(U[d.storey]); return null; };
  const sameSide = (di, xi, dj, xj) => (xi < 0) === (xj < 0);
  // door lines for the flow counts: every door the crowd uses, the lobby's narrowest cross-section and each flight
  const doorLines = [];
  for (const l of G.links) {
    if (l.kind === 'door') { const o = model.openings[l.door]; if (o.kind === 'rear' && !opts.rearOpen) continue; const w = widthOf(o), m = (o.o0 + o.o1) / 2; const sign = o.kind === 'street' ? 1 : o.kind === 'rear' ? -1 : o.kind === 'entry' ? (o.off < 0 ? 1 : -1) : 0;
      doorLines.push({ id: l.id, dom: F[o.storey], axis: o.axis === 'x' ? 'x' : 'z', at: o.off, a0: m - w / 2, a1: m + w / 2, sign: sign || (o.axis === 'z' ? (o.off > (zb + zf) / 2 ? -1 : 1) : 1) }); }
    else if (l.kind === 'flight') doorLines.push({ id: l.id, dom: U[l.storey], axis: 'z', at: (S.zTop + zb) / 2, a0: l.upper ? 0.05 : -inX, a1: l.upper ? inX : -0.05, sign: l.upper ? -1 : 1 });
    else if (l.lobby) doorLines.push({ id: l.id, dom: F[0], axis: 'z', at: l.cut.at, a0: -inX, a1: inX, sign: 1 });
  }
  // height of a point (for drawing people): floors flat, flights sloping
  const heightAt = (di, x, z) => {
    const d = domains[di]; if (d.kind === 'floor') return floorTop(d.storey);
    const s = d.storey, yA = floorTop(s), yM = yA + 1.5, yB = floorTop(s + 1);
    if (z > zb) return x < 0 ? yA : yB; if (z <= S.zTop) return yM; const u = (z - S.zTop) / S.run;
    return x > 0 ? yM + (yB - yM) * u : yM + (yA - yM) * u;
  };
  return { domains, F, U, transfer, exitOf, links, sameSide, doorLines, heightAt, stair: S };
}

// ------------------------------------------------------------------ night-time occupancy
// people per flat (seeded, 2-4 by default), asleep in the bedroom first, then the living room, then the kitchen;
// each spot clear of walls and of each other (radii 0.25-0.35 m, uniform, as in Helbing et al.)
export function occupancy(model, W, seed, { perFlat = null, min = 2, max = 4 } = {}) {
  const r = rngFor(seed, 'people'), people = [];
  for (let s = 0; s < NS; s++) for (const Fl of ['A', 'B']) {
    const n = perFlat ?? (min + Math.floor(r() * (max - min + 1)));
    const order = ['bedroom', 'living', 'kitchen', 'hall'].map((k) => model.rooms.find((q) => q.storey === s && q.flat === Fl && q.kind === k));
    const cap = [3, 4, 2, 2]; let left = n;
    for (let q = 0; q < order.length && left > 0; q++) {
      const room = order[q], take = q === order.length - 1 ? left : Math.min(left, cap[q] + (n > 8 ? Math.ceil((n - 8) / 3) : 0)); let placed = 0, tries = 0;
      const d = W.domains[W.F[s]];
      while (placed < take && tries < 600) { tries++;
        const rad = 0.25 + r() * 0.1, x = room.x0 + 0.1 + r() * (room.x1 - room.x0 - 0.2), z = room.z0 + 0.1 + r() * (room.z1 - room.z0 - 0.2);
        if (sample(d, d.dist, x, z) < rad + 0.12) continue; if (people.some((p) => p.dom === W.F[s] && (p.x - x) ** 2 + (p.z - z) ** 2 < (p.r + rad + 0.12) ** 2)) continue;
        people.push({ x, z, r: rad, dom: W.F[s], storey: s, flat: Fl, room: room.id }); placed++; }
      left -= placed;
    }
  }
  return people;
}
