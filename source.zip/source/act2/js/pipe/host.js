// The crowd host: the crowd runs the film does not need before it starts (the full house at five speeds, the three
// fixes) and the sandbox's runs, away from the page's main thread. Pure JS, no DOM: it runs inside a Web Worker
// (worker.js), or, when no worker can start, in time-budgeted slices on the main thread (crowdclient.js). It rebuilds
// the building, its access graph and crowd world from the seed with the same code the page used, so a run here gives
// the same numbers as the same run on the page.
// Messages in:  { type: 'ping' } | { type: 'init', token, seed, nightHot, fixGraph } | { type: 'background', token }
//               | { type: 'sandbox', id, o: { clutter, rearOpen, widen, blocked: [link ids] }, perFlat, v0 } | { type: 'stopSandbox' }
// Messages out: pong | progress { token, p, label } | done { token, out, work } | sbxStart { id, n, r, trapped }
//               | sbxChunk { id, frames, tFrames, t, nOut } | sbxDone { id, an, work } | error { where, message }
// A sandbox run takes priority: while one is going, the background work waits.
import { buildBuilding } from '../../../act7/js/building/building.js';
import { accessGraph, crowdWorld, occupancy, lobbyClutter } from './plan.js';
import { runCrowd, NIGHT } from './run.js';
import { createSim } from './crowd.js';
import { analyse } from './analyse.js';

const NOW = () => (typeof performance !== 'undefined' ? performance.now() : Date.now());

export function createHost(post, { budget = 40, tick = (f) => setTimeout(f, 0) } = {}) {
  let C = null, token = null, bg = null, sb = null, scheduled = false;
  const slice = () => (typeof budget === 'function' ? budget() : budget);   // ms of work per slice
  function caseFor(m) {
    const model = buildBuilding({ seed: m.seed }), clutter = lobbyClutter(model, m.seed);
    const G = accessGraph(model, { clutter }), W = crowdWorld(model, G, { clutter });
    return { seed: m.seed, model, clutter, G, W, night: { people: occupancy(model, W, m.seed, NIGHT), calm: { bottlenecks: m.nightHot ? [m.nightHot] : [] } }, fixGraph: m.fixGraph, timings: {} };
  }
  const schedule = () => { if (!scheduled && (sb || bg)) { scheduled = true; tick(loop); } };
  function loop() {
    scheduled = false;
    try { if (sb) stepSandbox(); else if (bg) stepBackground(); }
    catch (e) { const where = sb ? 'sandbox' : 'background'; if (sb) { post({ type: 'error', where, id: sb.id, message: String(e && e.message || e) }); sb = null; } else { post({ type: 'error', where, token: bg && bg.token, message: String(e && e.message || e) }); bg = null; } }
    schedule();
  }
  // ------------------------------------------------------------------ the background runs
  function stepBackground() {
    const t0 = NOW(), B = slice(); let r;
    do { r = bg.gen.next(); if (r.done) break; bg.p = r.value.p ?? bg.p; bg.label = r.value.label || bg.label; } while (NOW() - t0 < B);
    bg.work += NOW() - t0;
    if (r.done) {
      const c = bg.C, out = { full: c.full, widenDoor: c.widenDoor, widenTo: c.widenTo, widen: c.widen, fixes: c.fixes, rhoHot: c.rhoHot, rhoHotNight: c.rhoHotNight, timings: { crowd: c.timings.crowd, crowdTotal: c.timings.crowdTotal } };
      post({ type: 'done', token: bg.token, out, work: Math.round(bg.work) }, transferables(out)); bg = null; return;
    }
    if (NOW() - bg.lastPost > 150 || bg.p - (bg.postedP || 0) > .02) { bg.lastPost = NOW(); bg.postedP = bg.p; post({ type: 'progress', token: bg.token, p: bg.p, label: bg.label }); }
  }
  // ------------------------------------------------------------------ a sandbox run
  function startSandbox(m) {
    const t0 = NOW(), o = { ...m.o, blocked: new Set(m.o.blocked || []) };
    const G = accessGraph(C.model, o), W = crowdWorld(C.model, G, o), people = occupancy(C.model, W, C.seed, { perFlat: m.perFlat });
    const sim = createSim(W, people, { v0: m.v0, seed: C.seed, clogAfter: 40, tMax: 400 });
    sb = { id: m.id, sim, W, G, clutter: m.o.clutter, v0: m.v0, sent: 0, work: NOW() - t0 };
    post({ type: 'sbxStart', id: m.id, n: people.length, r: people.map((p) => p.r), trapped: Array.from(sim.trapped) });
  }
  function stepSandbox() {
    const t0 = NOW(), s = sb.sim; s.run(Infinity, slice()); sb.work += NOW() - t0;
    const F = s.frames, T = s.tFrames, frames = F.slice(sb.sent).map((f) => f.slice()), tFrames = T.slice(sb.sent); sb.sent = F.length;
    post({ type: 'sbxChunk', id: sb.id, frames, tFrames, t: s.t, nOut: s.nOut }, frames.map((f) => f.buffer));
    if (s.done) { const res = s.result(), an = analyse(res, sb.W, sb.G, { clutter: sb.clutter, v0: sb.v0 }); post({ type: 'sbxDone', id: sb.id, an, work: Math.round(sb.work) }); sb = null; }
  }
  return {
    onMessage(m) {
      try {
        if (m.type === 'ping') post({ type: 'pong' });
        else if (m.type === 'init') { if (token !== m.token || !C) { C = caseFor(m); token = m.token; bg = null; sb = null; } }
        else if (m.type === 'background') { if (C && m.token === token && !bg) { bg = { token, C, gen: runCrowd(C), p: 0, label: '', work: 0, lastPost: 0 }; schedule(); } }
        else if (m.type === 'sandbox') { if (C) { sb = null; startSandbox(m); schedule(); } }
        else if (m.type === 'stopSandbox') { sb = null; schedule(); }
      } catch (e) { post({ type: 'error', where: m.type, id: m.id, token: m.token, message: String(e && e.message || e) }); }
    },
    get busy() { return !!(sb || bg); },
  };
}
// the typed arrays in a result (moved, not copied, to the page)
function transferables(o, out = [], seen = new Set()) {
  if (!o || typeof o !== 'object') return out;
  if (ArrayBuffer.isView(o)) { if (!seen.has(o.buffer)) { seen.add(o.buffer); out.push(o.buffer); } return out; }
  for (const v of Array.isArray(o) ? o : Object.values(o)) transferables(v, out, seen);
  return out;
}
