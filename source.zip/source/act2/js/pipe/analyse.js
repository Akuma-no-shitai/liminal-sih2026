// What a crowd run says: the evacuation curve, where people lost time (the bottlenecks, named after the nearest door,
// stair flight or the lobby clutter), the peak density, and the flow through every door.
import { floorTop } from '../../../act7/js/building/building.js';

const FLOOR = ['ground', 'first', 'second', 'third'];
export function nameOfLink(l) { return l.label; }

// the 1.5 m windows (3 x 3 bins of 0.5 m) with the most time lost against free walking, at least 1.5 m apart
function hotspots(res, W, k = 3) {
  const out = [];
  res.lost.forEach((q, di) => { const d = W.domains[di];
    for (let b = 0; b < q.nz; b++) for (let a = 0; a < q.nx; a++) { let s = 0, rho = 0; for (let db = -1; db <= 1; db++) for (let da = -1; da <= 1; da++) { const bb = b + db, aa = a + da; if (bb < 0 || aa < 0 || bb >= q.nz || aa >= q.nx) continue; s += q.a[bb * q.nx + aa]; rho = Math.max(rho, res.peakRho[di][bb * q.nx + aa]); }
      if (s > 0.5) out.push({ dom: di, x: d.x0 + (a + .5) * q.cell, z: d.z0 + (b + .5) * q.cell, lost: s, rho }); } });
  out.sort((p, q) => q.lost - p.lost);
  const keep = [];
  for (const h of out) { if (keep.some((q) => q.dom === h.dom && Math.hypot(q.x - h.x, q.z - h.z) < 1.6)) continue; keep.push(h); if (keep.length >= k) break; }
  return keep;
}
// the feature a hot spot belongs to: the lobby clutter, a stair flight, or the nearest door or corridor link
function featureOf(h, W, G, clutter) {
  const d = W.domains[h.dom];
  if (d.kind === 'stair') { const up = h.x > 0; const l = G.links.find((q) => q.kind === 'flight' && q.storey === d.storey && !!q.upper === up); return { link: l.id, label: l.label, kind: 'flight' }; }
  const s = d.storey;
  if (s === 0 && clutter && clutter.length) { const z0 = Math.min(...clutter.map((b) => b.z0)), z1 = Math.max(...clutter.map((b) => b.z1)); if (h.z > z0 - 1.6 && h.z < z1 + 0.6 && Math.abs(h.x) < 1.6) { const l = G.links.find((q) => q.lobby); return { link: l.id, label: 'the gap between the scooters in the lobby', kind: 'lobby' }; } }
  let best = null, bd = 1e9;
  for (const l of G.links) { if (l.storey !== s && !(l.kind === 'flight')) continue; if (l.kind === 'flight') continue; const p = l.kind === 'corridor' && l.cut ? (l.cut.axis === 'x' ? [l.cut.at, 0, (l.cut.a0 + l.cut.a1) / 2] : [(l.cut.a0 + l.cut.a1) / 2, 0, l.cut.at]) : l.p;
    const dd = Math.hypot(p[0] - h.x, p[2] - h.z) + (l.kind === 'door' ? 0 : 0.4); if (dd < bd) { bd = dd; best = l; } }
  // near the foot or the top of a flight, in the core: the stair
  const S = W.stair; if (Math.abs(h.x) < S.inX + 0.1 && h.z < S.zb + 1.2 && h.z > S.zb - 1.2) { const up = h.x > 0, fl = G.links.find((q) => q.kind === 'flight' && (up ? q.storey === s - 1 && q.upper : q.storey === s && !q.upper)); if (fl && bd > 0.9) return { link: fl.id, label: fl.label, kind: 'flight' }; }
  return best ? { link: best.id, label: best.label, kind: best.kind } : { link: -1, label: `${FLOOR[s]} floor`, kind: 'area' };
}

export function analyse(res, W, G, { clutter = null, v0 = 1.3 } = {}) {
  const hs = hotspots(res, W, 4).map((h) => ({ ...h, ...featureOf(h, W, G, clutter), y: floorTop(W.domains[h.dom].storey) + (W.domains[h.dom].kind === 'stair' ? 1.5 : 0) }));
  let peak = 0, peakAt = null; res.peakRho.forEach((A, di) => { const q = res.lost[di]; for (let c = 0; c < A.length; c++) if (A[c] > peak) { peak = A[c]; const a = c % q.nx, b = (c - a) / q.nx; peakAt = { dom: di, x: W.domains[di].x0 + (a + .5) * q.cell, z: W.domains[di].z0 + (b + .5) * q.cell }; } });
  const flows = res.flows.filter((f) => f.n > 0).map((f) => { const l = G.links[f.id]; const eff = Math.max(0.1, f.width - 0.3); return { link: f.id, label: l.label, kind: l.kind, n: f.n, peak: f.peak, sustained: f.sustained, width: f.width, specific: f.sustained / f.width, specificEff: f.sustained / eff, bins: Array.from(f.bins) }; }).sort((a, b) => b.n - a.n);
  const lostTotal = res.lost.reduce((s, q) => s + q.a.reduce((t, v) => t + v, 0), 0);
  const ok = Number.isFinite(res.total);
  return {
    v0, n: res.n, out: res.out, trapped: res.trapped, stuck: res.stuck, clogged: res.clogged, easings: res.easings, violations: res.violations, badCross: res.badCross,
    total: ok ? res.total : null, tEnd: res.tEnd, t50: res.times.length ? res.times[Math.floor(res.times.length / 2)] : null, times: res.times,
    curve: res.times, bottlenecks: hs, peak, peakAt, flows, lostTotal, exits: res.exitId.reduce((a, e) => { if (e >= 0) a[e] = (a[e] || 0) + 1; return a; }, {}),
  };
}
// the peak density within 1.5 m of a place (for "peak density at the bottleneck, before and after")
export function rhoNear(res, W, dom, x, z, r = 1.0) {
  const q = res.lost[dom], A = res.peakRho[dom], d = W.domains[dom]; let m = 0;
  for (let b = 0; b < q.nz; b++) for (let a = 0; a < q.nx; a++) { const px = d.x0 + (a + .5) * q.cell, pz = d.z0 + (b + .5) * q.cell; if (Math.hypot(px - x, pz - z) <= r) m = Math.max(m, A[b * q.nx + a]); }
  return m;
}
