// Act 2's styles: Act 7's (imported, injected once as #a7css) plus what Act 2 adds (#a2css): the sandbox panel, the link
// markers, the assumptions panel and a few card rows.
export const CSS2 = `
.a2 .a7chipsim .s { display: none; }
@media (max-width: 760px) { .a2 .a7chipsim .l { display: none; } .a2 .a7chipsim .s { display: inline; } }
.a2 .a7card .q4 .r.on { background: rgba(var(--teal-rgb),.1); border-radius: 8px; margin: -3px -5px; padding: 3px 5px; }
.a2 .a7card .lab.as { border-color: rgba(var(--heat-rgb),.45); }
.a2 .a7card .q4 b { color: var(--paper); }
.a2 .a7card .st { flex-wrap: wrap; row-gap: 2px; }
.a2 .a7card h4 { flex: none; white-space: nowrap; }
.a2 .a7card .tag { flex: 1; min-width: 0; text-align: right; line-height: 1.25; }
.a2 .a7card .st span { white-space: nowrap; }
.a2 .a7card[data-card="fix"] .q4 b, .a2 .a7card[data-card="graph"] .q4 b { color: var(--heat-txt); }
.a2 .a7card[data-card="fix"] .q4 .r.nr b { color: var(--muted); }
.a2 .a7chip.a2sbx.on { background: var(--paper); color: var(--ink); border-color: var(--paper); }
.a2 .a7tog button[disabled] { opacity: .45; cursor: default; }
/* the sandbox panel: where the cards are on a desktop, under the dock on a phone */
.a2sb { position: absolute; right: 16px; top: calc(var(--top) + 6px); max-height: calc(100% - var(--top) - var(--dock) - 20px); width: calc(var(--cards) - 24px); z-index: 8; overflow-y: auto; padding: 14px 14px 12px; border-radius: 16px; background: var(--glass); backdrop-filter: blur(14px) saturate(1.1); -webkit-backdrop-filter: blur(14px) saturate(1.1); border: 1px solid rgba(var(--line-rgb),.16); box-shadow: 0 14px 34px rgba(var(--shadow2-rgb),.28); display: flex; flex-direction: column; gap: 10px; scrollbar-width: thin; }
.a2sb[hidden] { display: none; }
.a7.sbx .a7cards, .a7.sbx .a7cap { visibility: hidden; }
.a2sb header { display: flex; align-items: center; gap: 8px; }
.a2sb h4 { margin: 0; font: 400 19px/1.15 var(--serif); flex: 1; }
.a2sb .tag { font: 11.5px/1 var(--sans); color: var(--faint); }
.a2sb .x { width: 28px; height: 28px; border-radius: 50%; border: 1px solid var(--line); background: transparent; color: var(--muted); cursor: pointer; font: 16px/1 var(--sans); }
.a2sb .hint { margin: 0; font: 12.5px/1.45 var(--sans); color: var(--muted); }
.a2sb .ctl { display: grid; gap: 9px; }
.a2sb label { display: grid; grid-template-columns: 1fr auto; gap: 3px 10px; align-items: baseline; font: 12.5px/1.25 var(--sans); color: var(--paper); }
.a2sb label output { font: 12px/1.2 var(--mono); color: var(--teal-txt); }
.a2sb input[type=range] { grid-column: 1 / -1; width: 100%; accent-color: var(--teal); height: 22px; margin: 0; }
.a2sb .tg { display: flex; flex-wrap: wrap; gap: 6px; }
.a2sb .tg button { height: 30px; padding: 0 11px; border-radius: 999px; border: 1px solid var(--line); background: transparent; color: var(--muted); font: 500 12px/1 var(--sans); cursor: pointer; }
.a2sb .tg button.on { background: var(--paper); color: var(--ink); border-color: var(--paper); }
.a2sb .blk { display: flex; flex-wrap: wrap; gap: 6px; align-items: center; font: 12px/1.3 var(--sans); }
.a2sb .blk .k { color: var(--faint); margin-right: 2px; }
.a2sb .blk .none { color: var(--faint); }
.a2sb .blk button { height: 26px; padding: 0 9px; border-radius: 999px; border: 1px solid rgba(var(--danger-rgb),.45); background: rgba(var(--danger-rgb),.12); color: var(--danger-on); font: 11.5px/1 var(--sans); cursor: pointer; max-width: 100%; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
.a2sb .blk button.all { border-color: var(--line); background: transparent; color: var(--muted); }
.a2sb .read { display: grid; grid-template-columns: repeat(3, 1fr); gap: 8px; padding: 9px 10px; border-radius: 10px; background: rgba(var(--well-rgb),.45); }
.a2sb .read b { display: block; font: 500 15px/1.15 var(--mono); color: var(--paper); white-space: nowrap; }
.a2sb .read b.bad { color: var(--danger-txt); }
.a2sb .read small { font: 11px/1.25 var(--sans); color: var(--faint); }
.a2sb .nt { margin: 0; padding: 8px 10px; border-radius: 10px; background: rgba(var(--heat-rgb),.1); font: 12.5px/1.45 var(--sans); color: rgba(var(--fg-rgb),.9); }
.a2sb .nt[hidden] { display: none; }
.a2sb .cv { width: 100%; height: 96px; border-radius: 10px; background: rgba(var(--well-rgb),.45); display: block; flex: none; }
.a2sb .row { display: flex; gap: 8px; flex-wrap: wrap; }
.a2sb .row .a7pri, .a2sb .row .a7sec { min-height: 40px; font-size: 13.5px; padding: 0 12px; white-space: nowrap; }
.a2sb .row { flex-wrap: nowrap; gap: 6px; }
/* (Run stays in reach when the panel scrolls on a short screen) */
.a2sb .row { position: sticky; bottom: -12px; margin: 0 -14px -12px; padding: 10px 14px 12px; background: rgba(var(--card-rgb),.94); border-top: 1px solid rgba(var(--line-rgb),.1); border-radius: 0 0 16px 16px; z-index: 1; }
/* link markers over the view (sandbox) */
.a2marks { position: absolute; inset: 0; z-index: 4; pointer-events: none; overflow: hidden; }
.a2mk { position: absolute; left: 0; top: 0; width: 22px; height: 22px; padding: 0; border-radius: 50%; border: 1.5px solid rgba(var(--fg-rgb),.85); background: rgba(var(--panel-rgb),.62); pointer-events: auto; cursor: pointer; box-shadow: 0 2px 8px rgba(var(--shadow-rgb),.35); }
.a2mk::after { content: ""; position: absolute; left: 50%; top: 50%; width: 8px; height: 8px; margin: -4px 0 0 -4px; border-radius: 50%; background: var(--teal); }
.a2mk.kf::after { border-radius: 2px; background: var(--apricot); }
.a2mk.kc::after { width: 10px; height: 4px; margin: -2px 0 0 -5px; border-radius: 2px; }
.a2mk:hover { transform-origin: center; border-color: var(--paper); background: rgba(var(--hover-rgb),.9); }
.a2mk.on { border-color: var(--danger); background: rgba(var(--danger-rgb),.35); }
.a2mk.on::after { width: 12px; height: 3px; margin: -1.5px 0 0 -6px; border-radius: 2px; background: var(--danger-on); transform: rotate(-45deg); }
.a7:not(.sbx) .a2marks { display: none; }
/* the assumptions panel */
.a2asm { position: absolute; inset: 0; z-index: 30; display: grid; place-items: center; background: rgba(var(--bar-rgb),.45); }
.a2asm[hidden] { display: none; }
.a2asm .box { position: relative; width: min(560px, calc(100% - 32px)); max-height: calc(100% - 80px); overflow-y: auto; padding: 22px 24px 18px; border-radius: 20px; background: rgba(var(--card-rgb),.97); border: 1px solid rgba(var(--line-rgb),.2); box-shadow: 0 30px 70px rgba(var(--shadow-rgb),.5); }
.a2asm .x { position: absolute; right: 12px; top: 12px; width: 30px; height: 30px; border-radius: 50%; border: 1px solid var(--line); background: transparent; color: var(--muted); cursor: pointer; font: 16px/1 var(--sans); }
.a2asm .k { font: 500 12.5px/1 var(--sans); color: var(--teal-txt); margin: 0 0 8px; }
.a2asm h3 { font: 400 24px/1.1 var(--serif); margin: 0 0 12px; }
.a2asm dl { margin: 0; display: grid; gap: 8px; }
.a2asm dt { font: 500 12.5px/1.2 var(--sans); color: var(--haze-txt); }
.a2asm dd { margin: 0 0 4px; font: 13px/1.5 var(--sans); color: rgba(var(--fg-rgb),.88); }
.a2 .a7rep .cmd .draft { display: inline; }
@media (max-width: 760px) {
  .a2sb { position: relative; grid-area: cards; right: auto; top: auto; bottom: auto; max-height: none; width: auto; margin: 8px 10px 12px; border-radius: 14px; }
  .a7.sbx .a7cards, .a7.sbx .a7cap { display: none; }
  .a2sb .read b { font-size: 13.5px; }
  .a2sb .row { position: static; margin: 0; padding: 0; background: none; border: 0; }
  .a2 .a7rep .row { background: rgb(var(--card-rgb)); box-shadow: 0 -10px 18px rgba(var(--card-rgb),.9); }
  .a2 .a7tog { top: calc(var(--top) + 52svh - 82px); }   /* (a row above the floors bar: Act 2's choices are wider) */
  .a2mk { width: 26px; height: 26px; }
}
`;
