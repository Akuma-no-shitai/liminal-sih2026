// The film, written from the case: seven chapters (about two and a half minutes at 1x). Each segment says which
// overlays the World lens shows, how dim the clay gets, which cards are up, where the camera goes, and what the people
// are doing (which recorded crowd run plays, and how fast). Captions are one plain sentence each, with this run's
// numbers. Everything is a pure function of the case, so scrubbing is exact. The full-house runs finish in the
// background after the film starts; until then the script carries "being computed" captions for chapters 5 to 7, and is
// rebuilt once they are in.
import { reachOut, offOf } from '../pipe/plan.js';
import { peopleAt } from '../pipe/percolation.js';
const FLOOR = ['ground', 'first', 'second', 'third'];
export const mmss = (s) => `${String(Math.floor(s / 60)).padStart(2, '0')}:${String(Math.floor(s % 60)).padStart(2, '0')}`;
const sec = (v) => (v == null || !Number.isFinite(v) ? 'more than the run allowed' : `${Math.round(v)} s`);
const r1 = (v) => (v == null ? '?' : v.toFixed(1));
const lower = (s) => s.replace(/^The /, 'the ');
// a number stays on the line with its unit
const keepUnits = (s) => s.replace(/(\d) (?=(s|m\/s|m|cm|MB|minutes|people per m²)(?![\w]))/g, '$1\u00a0').replace(/(\d) %/g, '$1\u00a0%');
const theL = (s) => { const l = lower(s); return /^the /.test(l) ? l : `the ${l}`; };   // a link's label as a noun phrase

export function buildScript(C) {
  const SV = C.survey.stats, B = C.base, PS = C.percSummary, nc = C.night.calm, ready = !!C.fixes;
  const site = C.model.site, ctr = [0, 5.2, 0], AZ = 0.62;
  const S = (t0, t1, o) => ({ t0, t1, layers: {}, dim: 0, cards: [], people: 0, ...o });
  const CH = [];
  const chapter = (id, title, label, len, segs, caps, beats = {}) => CH.push({ id, title, label, len, segs, caps, beats });
  const hot = nc.bottlenecks[0];
  // ---------------------------------------------------------------- 1 peacetime
  chapter('peace', 'Peacetime', 'Peacetime', 15, [
    S(0, 8, { shot: { kind: 'wide', az: AZ, el: .42, dist: 47, drift: .02, target: ctr }, extras: 1 }),
    S(8, 15, { shot: { kind: 'focus', target: [site.pad.x * .45 + site.table.x * .25, 1.2, site.pad.z - 1.2], az: .15, el: .62, dist: 23, drift: .012 }, extras: 1 }),
  ], [
    [0, 'No disaster yet. This is when the map should be made.'],
    [5, 'An ordinary apartment block: the same building Act 7 judges after an earthquake.'],
    [10, 'Surveys like this start with schools and hospitals. Here: one block, eight drones and the anchor robot.'],
  ]);
  // ---------------------------------------------------------------- 2 the survey
  const tl = C.survey.timeline, b0max = Math.max(...tl.map((q) => q.b0));
  // the storey the swarm worked on inside the building in each part of the flight (for the cutaway shots); the survey
  // is complete 25 s into the chapter
  const SU = 25, inside = (p) => Math.abs(p[0]) < C.model.dims.L / 2 && Math.abs(p[2]) < C.model.dims.D / 2 && p[1] < 12.1;
  const lvAt = (u0, u1) => { const T = SV.flightS, st = C.survey.stops.filter((q) => q.t >= u0 * T && q.t < u1 * T && inside(q.p)); if (st.length < 3) return null; const lv = st.map((q) => Math.max(0, Math.min(3, Math.floor((q.p[1] - 0.15) / 3)))).sort((a, b) => a - b); return lv[lv.length >> 1]; };
  const cutShot = (t0, t1, az) => { const lv = lvAt(t0 / SU, t1 / SU); return lv == null ? { kind: 'wide', az, el: .55, dist: 42, drift: .02, target: ctr } : { kind: 'cutaway', level: lv, target: [0, lv * 3 + 1, 0], az, el: 1.0, dist: 31, drift: .01 }; };
  chapter('survey', 'The survey', 'Survey', 30, [
    S(0, 6, { layers: { tracks: 1, cloud: .9 }, dim: .35, cards: ['survey'], survey: 1, shot: { kind: 'wide', az: AZ - .25, el: .5, dist: 44, drift: .025, target: ctr } }),
    S(6, 12, { layers: { tracks: 1, cloud: .9 }, dim: .45, cards: ['survey'], survey: 1, shot: cutShot(6, 12, .45) }),
    S(12, 18, { layers: { tracks: 1, cloud: .9 }, dim: .45, cards: ['survey'], survey: 1, shot: cutShot(12, 18, .55) }),
    S(18, 24, { layers: { tracks: 1, cloud: .9 }, dim: .45, cards: ['survey'], survey: 1, shot: cutShot(18, 24, .65) }),
    S(24, 30, { layers: { tracks: 1, cloud: 1 }, dim: .5, cards: ['survey'], survey: 1, shot: { kind: 'wide', az: AZ + .4, el: .62, dist: 42, drift: .02, target: ctr } }),
  ], [
    [0, 'No set route: each drone flies to the nearest edge of the unknown, on the map they all share.'],
    [7, 'That map merges in any order (a CRDT), so every drone knows where the others have already looked.'],
    [13, `Floor by floor the unexplored space splits into separate regions, up to ${b0max}, and they close one by one. β₀ counts them.`],
    [25.2, `β₀ = 0 after ${Math.round(SV.minutes)} minutes of flight: nothing a drone can reach is left unseen. ${(SV.points / 1e3).toFixed(0)} thousand points, ${SV.mb.toFixed(1)} MB.`],
  ]);
  // ---------------------------------------------------------------- 3 the baseline
  const em = B.doors.filter((d) => d.measured != null).map((d) => Math.abs(d.err)).sort((a, b) => a - b), errMed = em.length ? em[em.length >> 1] : null;
  chapter('baseline', 'The baseline', 'Baseline', 15, [
    S(0, 7, { layers: { cloud: 1 }, dim: .7, cards: ['base'], shot: { kind: 'wide', az: AZ + .1, el: .55, dist: 40, drift: .015, target: ctr } }),
    S(7, 15, { layers: { vox: 1, doors: 1 }, dim: .8, cards: ['base'], shot: { kind: 'cutaway', level: 0, target: [0, 1, 0.8], az: .45, el: 1.0, dist: 27, drift: .01 } }),
  ], [
    [0, 'The finished baseline: every room, door, stair and exit, to a few centimetres.'],
    [5, B.gap != null ? `Widths come straight off the cloud: ${B.measured} doors, typically within ${Math.max(1, Math.round(errMed * 100))} cm, and ${B.gap.toFixed(2)} m clear between the scooters in the lobby.` : `Door widths come straight off the cloud: ${B.measured} doors, typically within ${Math.max(1, Math.round(errMed * 100))} cm.`],
    [10.5, 'This is what Act 7 will compare against after a disaster.'],
  ]);
  // ---------------------------------------------------------------- 4 routes and loops
  const b1 = C.betti.floors, allZero = b1.every((v) => v === 0);
  chapter('routes', 'Routes and loops', 'Routes', 20, [
    S(0, 8, { layers: { skeleton: 1 }, dim: .6, cards: ['graph'], shot: { kind: 'cutaway', level: 1, target: [0, 4, 0.3], az: .12, el: 1.25, dist: 29, drift: .006 } }),
    S(8, 15, { layers: { skeleton: .3, graph: 1 }, dim: .62, cards: ['graph'], shot: { kind: 'cutaway', level: 1, target: [0, 4, 0.3], az: .25, el: 1.12, dist: 30, drift: .008 } }),
    S(15, 20, { layers: { skeleton: .3, graph: 1 }, dim: .62, cards: ['graph'], shot: { kind: 'cutaway', level: 0, target: [0.3, 1, -1.2], az: .35, el: 1.15, dist: 21, drift: .008 } }),
  ], [
    [0, 'Free space a person fits through, thinned to a path network: the access graph.'],
    [5, 'β₁ counts its independent loops. Each loop is an alternative route.'],
    [9, allZero ? 'Here β₁ = 0 on every floor: one way out of each flat, one stair, one usable exit.' : `β₁ per floor: ${b1.join(', ')}.`],
    [12.5, `So every link is a weak link (warm): block any one of the ${PS.links} and something is cut off. Dead-end hall ends are dashed.`],
    [15.5, `On the plan there is a rear door. It was shut on survey day, and it opens under the stair landing: ${C.stair.head(C.stair.zTop).toFixed(1)} m of headroom.`],
  ]);
  // ---------------------------------------------------------------- 5 the crowd model
  const F = C.full, fis = F && F.fis, place = (an) => (an && an.bottlenecks[0] ? theL(an.bottlenecks[0].label) : 'the narrowest spot');
  const fullLast = F && F.sweep.find((s) => s.v0 === fis.last), fullBest = F && F.sweep.find((s) => s.v0 === fis.best);
  // faster is slower, as the repeated runs have it (every run at the top speed slower than every run at the best one)
  const span = (lo, hi) => (Math.round(lo) === Math.round(hi) ? `${Math.round(lo)} s` : `${Math.round(lo)} to ${Math.round(hi)} s`);
  const fisCap = () => {
    const at = place(fullLast.an), k = fis.lastClogs, n = fis.runs, rest = n - k, fin = F.sweep.find((q) => q.v0 === fis.last).rep.T.filter(Number.isFinite);
    const lastRuns = k ? `${k === n ? 'every run' : k === 1 ? 'one run' : `${k} runs`} clogged${rest ? `, ${rest === 1 ? 'the other' : 'the rest'} took ${span(Math.min(...fin), Math.max(...fin))}` : ''}` : `the runs took ${span(fis.lastLo, fis.lastHi)}`;
    if (fis.emerges) return fis.lastClogged ? `Pushing at ${fis.last} m/s, a clog forms at ${at}: ${fis.lastLeft} people are still wedged there when the run stops. Slower in every run: faster is slower.` : `Pushing at ${fis.last} m/s, a clog forms at ${at}: ${lastRuns}, slower in every run than at ${fis.best} m/s. Faster is slower.`;
    if (fis.close) return `At ${fis.last} m/s ${lastRuns}; at ${fis.best} m/s, ${span(fis.bestLo, fis.bestHi)}. The runs overlap: no clear faster-is-slower here.`;
    return `Here even pushing at ${fis.last} m/s did not slow them (${Number.isFinite(fis.lastT) ? sec(fis.lastT) : lastRuns}): no lasting clog formed in this building.`;
  };
  // the night and the full house are seen in the section view (the block cut open along its length, from the street a
  // little above: every floor, the stair, the street door and everyone on them); the faster-is-slower beat closes in on
  // its bottleneck. The night opens with everyone asleep, then the alarm, then the run.
  const SEC = { kind: 'focus', section: 1, target: [0, 5.8, 0], az: .03, el: .075, dist: 72, fov: 18, drift: .0008 };
  SEC.phone = { ...SEC, target: [0, 6.0, 0], dist: 70, fov: 20.5, fovPhone: 20.5 };
  const nEnd = nc.tEnd + 4, nMid = nEnd * (6.3 / 13.3);
  chapter('crowd', 'The crowd model', 'Crowd', 38, [
    S(0, 3.5, { layers: {}, dim: .5, people: 1, cards: ['crowd'], night: 'asleep', crowd: { run: 'night', t0: 0, t1: 3.5, s0: 0, s1: 0 }, shot: SEC }),
    S(3.5, 4.7, { layers: {}, dim: .45, people: 1, cards: ['crowd'], night: 'wake', crowd: { run: 'night', t0: 3.5, t1: 4.7, s0: 0, s1: 0 }, shot: SEC }),
    S(4.7, 11, { layers: { heat: 1, flows: 1 }, dim: .4, people: 1, cards: ['crowd'], night: 'run', crowd: { run: 'night', t0: 4.7, t1: 11, s0: 0, s1: nMid }, shot: SEC }),
    S(11, 18, { layers: { heat: 1, flows: 1 }, dim: .4, people: 1, hot: 1, cards: ['crowd'], night: 'run', crowd: { run: 'night', t0: 11, t1: 18, s0: nMid, s1: nEnd }, shot: SEC }),
    S(18, 24, { layers: { heat: 1, flows: 1 }, dim: .4, people: 1, cards: ['crowd', 'fis'], crowd: { run: 'fullLast', t0: 18, t1: 24, s0: 0, s1: 18 }, shot: SEC }),
    S(24, 38, { layers: { heat: 1, flows: 1 }, dim: .35, people: 1, hot: 1, cards: ['crowd', 'fis'], crowd: { run: 'fullLast', t0: 24, t1: 38, s0: 18, s1: fullLast ? fullLast.an.tEnd + 4 : 120 }, shot: fullLast && fullLast.an.bottlenecks[0] ? { kind: 'cutaway', level: Math.min(3, Math.floor(fullLast.an.bottlenecks[0].y / 3)), target: [fullLast.an.bottlenecks[0].x, fullLast.an.bottlenecks[0].y + .5, fullLast.an.bottlenecks[0].z], az: .55, el: .85, dist: 16, drift: .01 } : { kind: 'cutaway', level: 0, target: [0, 1, 1], az: .55, el: .9, dist: 18 } }),
  ], [
    [0, `Night: ${nc.n} people asleep, 2 to 4 to a flat.`],
    [3.5, 'The alarm goes, and everyone walks out at 1.3 m/s.'],
    [7, 'The Helbing social-force model: each person steers for the exit, keeps clear of others and of walls, and pushes and rubs when bodies touch.'],
    [12.5, nc.total != null ? `Everyone is out in ${sec(nc.total)}. The slowest spot is ${hot ? theL(hot.label) : 'nowhere in particular'}, ${r1(hot ? hot.rho : nc.peak)} people per m² at its busiest.` : `${nc.out} of ${nc.n} got out in the time the run allowed.`],
    [18, 'Helbing’s best-known result needs a crowd at a narrow exit: faster is slower.'],
    [22, !F ? 'The full-house runs are still being computed…' : fis.best === fis.last ? `With 80 people in the block (a festival night), every step up in speed got them out sooner: ${sec(fis.bestT)} at ${fis.best} m/s.` : `With 80 people in the block (a festival night), hurrying helps up to ${fis.best} m/s: everyone out in ${sec(fis.bestT)} on average.`],
    [29, !F ? 'The full-house runs are still being computed…' : fisCap()],
    [34, 'Tamás Vicsek, whose alignment rule steers our swarm, co-wrote this escape-panic model.'],
  ]);
  // ---------------------------------------------------------------- 6 how close to cut off
  const pc = C.perc, order = trialOrder(C), wl = PS.worst;
  // (the trial's shot leans towards where it ends: the room cut off, or the last link blocked)
  const trialAt = order.rooms.length ? C.G.nodes[order.rooms[0]].p : order.order.length ? C.G.links[order.order[order.order.length - 1]].p : [0, 0, 0.3];
  const lvOf = (l) => (l.kind === 'flight' ? (l.upper ? l.storey + 1 : l.storey) : l.storey), trialLv = order.order.length ? lvOf(C.G.links[order.order[order.order.length - 1]]) : 0, wlLv = wl ? lvOf(C.G.links[wl.link]) : 0;
  chapter('risk', 'How close to cut off', 'Cut off', 20, [
    S(0, 9, { layers: { graph: .7 }, dim: .6, cards: ['perc'], trial: 1, shot: { kind: 'cutaway', level: trialLv, target: [trialAt[0] * .55, trialLv * 3 + 1, 0.3 + (trialAt[2] - 0.3) * .4], az: .3, el: 1.12, dist: 28, drift: .008 } }),
    S(9, 20, { layers: { risk: 1 }, dim: .62, cards: ['perc'], shot: wl ? { kind: 'cutaway', level: wlLv, target: [C.G.links[wl.link].p[0] * .5, wlLv * 3 + 1, C.G.links[wl.link].p[2] * .5], az: .4, el: 1.1, dist: 24, drift: .008 } : { kind: 'wide', az: AZ, el: .6, dist: 38, target: ctr } }),
  ], [
    [0, 'Percolation: block doors, corridors and stair flights at random, one at a time, until someone has no way out.'],
    [6, `Over ${pc.trials} random trials it took ${PS.median === 1 ? 'a single blockage' : `${PS.median} blockages`} (the median). ${Math.round(PS.p1 * 100)}\u00a0% of single blockages already cut someone off.`],
    [12, wl ? `The worst single link: ${lower(wl.label)}, with ${wl.people} people behind it.` : 'No single link cuts anyone off.'],
    [16, 'That is the percolation margin: how close the routes are to being cut.'],
  ], { trialOrder: order });
  // ---------------------------------------------------------------- 7 change one thing
  const fx = C.fixes, fg = C.fixGraph;
  const fClear = fx && fx.clear, fRear = fx && fx.rear, fWide = fx && fx.widen;
  // (full-house times are means of repeated runs; a fix counts as a change only when its runs and the base runs do not overlap)
  const B0 = F && F.calmRep, tFull = B0 ? B0.mean : null;
  // a full-house time as words: the mean, or the clog (a run that had not finished when it was stopped)
  const tTxt = (rep) => { if (Number.isFinite(rep.mean)) return sec(rep.mean); if (rep.clogged === rep.n) return 'a clog in every run'; const f = rep.T.filter(Number.isFinite); return `${span(Math.min(...f), Math.max(...f))}, with a clog in ${rep.clogged === 1 ? 'one' : rep.clogged} of ${rep.n} runs`; };
  const verdict = (f) => { if (!f) return ''; if (!f.cmp.real) return 'no clear change (the runs with and without it overlap)'; const sooner = f.rep.hi < B0.lo; return f.cmp.d != null ? `${Math.round(Math.abs(f.cmp.d) * 100)}\u00a0% ${sooner ? 'sooner' : 'later'}` : `${sooner ? 'sooner' : 'later'} in every run`; };
  const hotB = F && F.calm.bottlenecks[0], atHot = hotB ? (hotB.kind === 'lobby' ? 'at the gap' : `at ${theL(hotB.label)}`) : 'at the busiest spot';
  const rhoTxt = fClear && C.rhoHot != null && fClear.rhoHot != null ? `; ${atHot}, ${r1(C.rhoHot)} people per m² at the peak becomes ${r1(fClear.rhoHot)}` : '';
  const capClear = !fClear ? 'The fixes are still being computed…' : !(C.clutter && C.clutter.length) ? 'Nothing is parked in this lobby, so clearing it changes nothing.'
    : !fClear.cmp.real ? `Move the scooters: ${tTxt(fClear.rep)} instead of ${tTxt(B0)}, inside the spread between runs${rhoTxt}.`
    : fClear.rep.hi < B0.lo ? `Move the scooters: the full house is out in ${tTxt(fClear.rep)} instead of ${tTxt(B0)}${rhoTxt}.`
    : `Move the scooters: here the full house is out a little later, ${tTxt(fClear.rep)} against ${tTxt(B0)}${hotB && hotB.kind !== 'lobby' ? ': the lobby was not where the time was lost' : ''}.`;
  const wb = PS.worst;
  const capRear = !fRear ? '' : `Keep the rear door unlocked at night: β₁ on the ground floor goes from ${C.betti.floors[0]} to ${fg.rear.betti.floors[0]}, and ${wb ? lower(wb.label) : 'the street door'} is no longer a single point of failure for everyone. The full house: ${verdict(fRear)}.`;
  const capWide = !fWide ? '' : `Widen one door, ${lower(C.widen.label)}, from ${C.widen.from.toFixed(1)} to ${C.widen.to.toFixed(1)} m: ${verdict(fWide)}.`;
  chapter('fix', 'Change one thing', 'Change one thing', 20, [
    S(0, 6, { layers: { heat: 1 }, dim: .3, cards: ['fix'], fix: 'clear', people: 1, crowd: fClear && fClear.frames ? { run: 'fixClear', t0: 0, t1: 6, s0: 8, s1: Math.min(fClear.full.tEnd, 70) } : null, shot: { kind: 'cutaway', level: 0, target: [0, 1, (C.model.dims.zb + C.model.dims.D / 2) / 2], az: .45, el: 1.05, dist: 20, drift: .01 } }),
    S(6, 13, { layers: { loop: 1 }, dim: .5, cards: ['fix'], fix: 'rear', graphFix: 'rear', shot: { kind: 'cutaway', level: 0, target: [1.2, 1, -0.4], az: .25, el: 1.3, dist: 31, drift: .008 } }),
    S(13, 20, { layers: {}, dim: .2, cards: ['fix'], fix: 'widen', shot: fWide ? { kind: 'cutaway', level: C.model.openings[C.widen.door].storey, target: [...doorPos(C, C.widen.door)].map((v, i) => (i === 1 ? v - .5 : v)), az: .45, el: 1.05, dist: 18, drift: .01 } : { kind: 'wide', az: AZ, el: .5, dist: 40, target: ctr } }),
  ], [
    [0, capClear], [6, capRear || 'The fixes are still being computed…'], [13, capWide || 'The fixes are still being computed…'],
    [17, 'Before turns a survey into a plan: this is the Sendai Framework’s first priority, understanding disaster risk.'],
  ]);
  // ---------------------------------------------------------------- flatten
  const chapters = [], segs = [], captions = [], beats = {}; let t = 0;
  for (const ch of CH) {
    chapters.push({ id: ch.id, title: ch.title, label: ch.label, p0: t, p1: t + ch.len });
    for (const sg of ch.segs) { const o = { ...sg, t0: t + sg.t0, t1: t + sg.t1, ch: ch.id }; if (sg.crowd) o.crowd = { ...sg.crowd, t0: t + sg.crowd.t0, t1: t + sg.crowd.t1 }; segs.push(o); }
    for (const [tt, text] of ch.caps) captions.push({ t: t + tt, text: keepUnits(text) });
    beats[ch.id] = [t, t + ch.len]; for (const [k, v] of Object.entries(ch.beats)) beats[k] = v;
    t += ch.len;
  }
  const dur = t; beats.fis = beats.crowd[0] + 18;   // (the faster-is-slower beat: the full-house runs are needed from here)
  // survey time (s of flight) at film time p
  const surveyAt = (p) => { const [a] = beats.survey; return Math.max(0, Math.min(1, (p - a) / 25)) * SV.flightS; };
  return { chapters, segs, captions, dur, beats, surveyAt, ready, events: [{ p: beats.crowd[0] + 18, color: 'var(--heat)' }, { p: beats.survey[0] + 22, color: 'var(--teal)' }] };
}
// one random trial, replayed in chapter 6: links in the order they were blocked, up to the first that leaves someone
// without a way out (and who that is)
function trialOrder(C) {
  let h = (C.seed * 7919 + 11) >>> 0; const rnd = () => { h = (h + 0x6D2B79F5) | 0; let q = Math.imul(h ^ (h >>> 15), 1 | h); q = (q + Math.imul(q ^ (q >>> 7), 61 | q)) ^ q; return ((q ^ (q >>> 14)) >>> 0) / 4294967296; };
  const G = C.G, at = peopleAt(G, C.night.people), off = offOf(G), links = G.links.filter((l) => !off[l.id]).map((l) => l.id), order = [];
  for (let i = links.length - 1; i > 0; i--) { const j = Math.floor(rnd() * (i + 1)); const t = links[i]; links[i] = links[j]; links[j] = t; }
  for (const id of links) { off[id] = 1; order.push(id); const ok = reachOut(G, off); let cut = 0; const rooms = []; for (let i = 0; i < at.length; i++) if (at[i] && !ok[i]) { cut += at[i]; rooms.push(i); } if (cut) return { order, cut, rooms }; }
  return { order, cut: 0, rooms: [] };
}
export function doorPos(C, id) { const o = C.model.openings[id]; return o.axis === 'x' ? [o.off, o.y0 + 1, (o.o0 + o.o1) / 2] : [(o.o0 + o.o1) / 2, o.y0 + 1, o.off]; }
