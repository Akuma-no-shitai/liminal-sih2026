// LIMINAL Act 2: before it falls. Peacetime: eight drones survey an apartment block with no set route and make the
// baseline map Act 7 compares against; the map becomes an access graph (β₁ loops, weak links, dead ends), a crowd model
// (Helbing, Farkas & Vicsek 2000, with simulated occupancy) finds the bottlenecks, percolation trials measure how close
// the routes are to being cut, and each fix is computed again. Then the viewer can play with it in a sandbox.
//   createBefore(host, opts) -> { play, pause, resume, destroy, seek, chapter, speed, lens, director, takeCamera,
//     sandbox(on), state, renderNow(settle), frameStats() }
//   opts: { base: 'assets/', onExit(), onLab(id), onNext(), music, seed, theme, quality, onReady(), test }
// The building comes from act7 (buildBuilding({ seed })), so the same seed gives the same block in both acts.
import * as THREE from 'three';
import { GLTFLoader } from 'three/addons/loaders/GLTFLoader.js';
import { MeshoptDecoder } from 'three/addons/libs/meshopt_decoder.module.js';
import { CSS as CSS7 } from '../../act7/js/style.js';
import { CSS2 } from './style.js';
import { createMusic } from '../../act7/js/music.js';
import { createRenderer } from '../../act7/js/engine/renderer.js';
import { createDirector } from '../../act7/js/engine/director.js';
import { createLabels } from '../../act7/js/ui/labels.js';
import { createCaptions } from '../../act7/js/ui/captions.js';
import { getTheme, applyTheme } from '../../act7/js/theme.js';
import { floorTop } from '../../act7/js/building/building.js';
import { createLenses, LENSES, LAYERS } from './engine/lenses.js';
import { buildWorld } from './engine/world.js';
import { createLayers } from './engine/layers.js';
import { createPeople, playRun } from './engine/people.js';
import { createDock } from './ui/dock.js';
import { createCards } from './ui/cards.js';
import { createSimOverlay, createReport, createAssumptions } from './ui/overlay.js';
import { createSandbox } from './ui/sandbox.js';
import { buildScript, mmss, doorPos } from './film/script.js';
import { runCore, runCrowd } from './pipe/run.js';
import { createCrowdClient } from './crowdclient.js';
import { accessGraph } from './pipe/plan.js';
import { FIXES, graphFor } from './pipe/mitigate.js';

const ICON = {
  note: '<svg viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.4" stroke-linecap="round" stroke-linejoin="round"><path d="M6 12V3.5l7-1.5v8.5"/><circle cx="4.3" cy="12" r="1.7"/><circle cx="11.3" cy="10.5" r="1.7"/></svg>',
  back: '<svg viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"><path d="M10 3 5 8l5 5"/></svg>',
};
const LENS_CARDS = { survey: ['survey'], baseline: ['base'], routes: ['graph'], crowd: ['crowd'], risk: ['perc'] };
// the section view (the Crowd lens and the sandbox's runs use the film's): the block cut open along its length
const SECTION = { kind: 'focus', section: 1, target: [0, 5.8, 0], az: .03, el: .075, dist: 72, fov: 18, drift: .0008 };
SECTION.phone = { ...SECTION, target: [0, 6.0, 0], dist: 70, fov: 20.5, fovPhone: 20.5 };
const ease = (x) => { x = Math.max(0, Math.min(1, x)); return x * x * (3 - 2 * x); };

export async function createBefore(host, opts = {}) {
  const base = opts.base || 'assets/';
  if (!document.getElementById('a7css')) { const st = document.createElement('style'); st.id = 'a7css'; st.textContent = CSS7; document.head.appendChild(st); }
  if (!document.getElementById('a2css')) { const st = document.createElement('style'); st.id = 'a2css'; st.textContent = CSS2; document.head.appendChild(st); }
  const PH = matchMedia('(max-width: 760px)').matches, TEST = !!opts.test, THEME = getTheme(opts.theme);
  const fit = (shot) => (PH && shot && shot.phone ? shot.phone : shot);   // (a shot's phone framing, when it has one)
  const h = (tag, cls, html) => { const e = document.createElement(tag); if (cls) e.className = cls; if (html != null) e.innerHTML = html; return e; };
  const exitAct = () => { if (opts.onExit) opts.onExit(); else if (history.length > 1) history.back(); };
  const onLab = (id) => { if (id === 'assumptions') { if (C) asm.show(C); return; } if (opts.onLab) opts.onLab(id); else toast(`Opens the swarm lab: ${id}`); };

  // ------------------------------------------------------------------ DOM
  const root = h('div', 'a7 a2 nomis' + (TEST ? ' test' : '')); root.tabIndex = -1; root.setAttribute('role', 'region'); root.setAttribute('aria-label', 'Act 2: before it falls');
  const view = h('div', 'a7view'), canvas = h('canvas'), labelsEl = h('div', 'a7labels'), marksEl = h('div', 'a2marks');
  view.append(canvas, labelsEl, marksEl);
  const top = h('header', 'a7top', `<div class="a7brand">LIMINAL <i>Act 2, before it falls</i></div><span class="sp"></span>
    <button class="a7pill a7mus" type="button" data-a="music" aria-pressed="false" title="Music">${ICON.note}<span class="hideS">Music</span></button>
    <button class="a7pill" type="button" data-a="exit">${ICON.back}<span class="hideS">Back to the story</span><span class="showS">Back</span></button>`);
  const chip = h('div', 'a7chipsim', '<i></i><span class="l">Crowd model (Helbing 2000) with simulated occupancy, not a prediction for a real building</span><span class="s">Crowd model with simulated occupancy, not a prediction</span>');
  const floorsEl = h('div', 'a7floors'), togEl = h('div', 'a7tog'), capEl = h('div', 'a7cap'); capEl.setAttribute('aria-live', 'polite');
  const cardsEl = h('div', 'a7cards'), dockEl = h('div', 'a7dock'), sbxEl = h('div'), asmEl = h('div'), repEl = h('div'), simEl = h('div'), toastEl = h('div', 'a7toast');
  root.append(view, top, chip, floorsEl, togEl, capEl, cardsEl, sbxEl, dockEl, repEl, asmEl, simEl, toastEl);
  applyTheme(root, THEME); host.appendChild(root);
  let toastT = 0; function toast(s) { toastEl.textContent = s; toastEl.classList.add('on'); clearTimeout(toastT); toastT = setTimeout(() => toastEl.classList.remove('on'), 2600); }

  // ------------------------------------------------------------------ engine
  const R = createRenderer(canvas, { phone: PH || opts.quality === 'low', preserve: TEST }); R.renderer.setClearColor(THEME.sky.fog, 1);
  const onLost = (e) => { e.preventDefault(); toast('The graphics were reset. One moment…'); }; canvas.addEventListener('webglcontextlost', onLost);
  const { scene, camera, renderer } = R;
  let props = null;
  try { const gl = new GLTFLoader(); gl.setMeshoptDecoder(MeshoptDecoder); props = (await gl.loadAsync(base + 'props.glb')).scene; } catch (e) { props = null; console.warn('[act2] props.glb did not load; using simple shapes', e && e.message); }
  const lenses = createLenses(), labels = createLabels(labelsEl);
  const director = createDirector(camera, canvas, { phone: PH, onTake: (u) => dock.setUser(u), onCut: (lv) => { dirLevel = lv; if (userLevel === undefined) applyCut(lv); } });

  // ------------------------------------------------------------------ UI
  const captions = createCaptions(capEl);
  const cards = createCards(cardsEl, { onLab, phone: PH, theme: THEME });
  const idleEl = h('div', 'idle', '<h4>Before it falls</h4><p>The cards for each step appear here as the film reaches it.</p>'); cardsEl.appendChild(idleEl);
  const simOv = createSimOverlay(simEl);
  const dock = createDock(dockEl, {
    onPlay: () => (playing ? pause() : play()), onSpeed: (s) => setSpeed(s), onSeek: (p) => { if (sbOn) setSandbox(false); seek(p); }, onLens: (l) => setLens(l),
    onDirector: () => { if (director.user) director.giveBack(); else toast('The director has the camera. Drag the view to take over.'); },
    onShock: () => setSandbox(!sbOn), onStep: (d) => seek(P + d), onScrub: (on) => { scrubbing = on; },
  });
  const report = createReport(repEl, { hasNext: !!opts.onNext, onNext: () => opts.onNext && opts.onNext(), onReplay: () => { report.hide(); seek(0); play(); }, onSandbox: () => { report.hide(); setSandbox(true); }, onBack: exitAct });
  const asm = createAssumptions(asmEl, { onClose: () => asm.hide() });
  top.querySelector('[data-a="exit"]').addEventListener('click', exitAct);
  const music = createMusic('swarm'), musB = top.querySelector('[data-a="music"]');
  const paintMus = () => { musB.classList.toggle('on', music.on); musB.setAttribute('aria-pressed', String(music.on)); const t = musB.querySelector('span'); if (t) t.textContent = music.on ? 'Music on' : 'Music off'; };
  musB.addEventListener('click', () => { music.on ? music.stop() : music.start(); paintMus(); });
  if (opts.music) { try { music.start(); } catch (e) { /* needs a gesture */ } } paintMus();
  floorsEl.innerHTML = '<div class="k">Floors</div>' + [['auto', 'Auto'], ['all', 'All'], ['3', '3rd'], ['2', '2nd'], ['1', '1st'], ['0', 'Gnd']].map(([v, t]) => `<button type="button" data-f="${v}" class="${v === 'auto' ? 'auto' : ''}" title="${v === 'auto' ? 'The director chooses' : v === 'all' ? 'The whole building' : 'Hide every floor above this one'}">${t}</button>`).join('');
  floorsEl.addEventListener('click', (e) => { const b = e.target.closest('[data-f]'); if (!b) return; const v = b.dataset.f; userLevel = v === 'auto' ? undefined : v === 'all' ? null : +v; applyCut(userLevel === undefined ? dirLevel : userLevel); paintFloors(); wantRender = true; });
  const paintFloors = () => floorsEl.querySelectorAll('[data-f]').forEach((b) => { const v = b.dataset.f; const on = v === 'auto' ? userLevel === undefined : userLevel !== undefined && (v === 'all' ? userLevel === null : +v === userLevel); b.classList.toggle('on', on); });
  // lens extras: the baseline as cloud or voxels; which crowd run the Crowd lens plays
  const tog = { vox: false, run: 'night' };
  function paintTog() {
    const L = lenses.current; let html = '';
    if (L === 'baseline') html = `<span class="k">Show</span><button type="button" data-t="cloud" class="${!tog.vox ? 'on' : ''}">Point cloud</button><button type="button" data-t="vox" class="${tog.vox ? 'on' : ''}">Voxels</button>`;
    else if (L === 'crowd' && !sbOn) html = `<span class="k">Run</span><button type="button" data-t="night" class="${tog.run === 'night' ? 'on' : ''}">Night</button><button type="button" data-t="fullLast" class="${tog.run === 'fullLast' ? 'on' : ''}"${C && C.full ? '' : ' disabled'}>Full house, pushing</button>`;
    togEl.innerHTML = html; togEl.classList.toggle('on', !!html);
  }
  togEl.addEventListener('click', (e) => { const b = e.target.closest('[data-t]'); if (!b) return; const t = b.dataset.t; if (t === 'vox' || t === 'cloud') tog.vox = t === 'vox'; else { tog.run = t; lensRunT0 = performance.now(); } paintTog(); wantRender = true; });

  // ------------------------------------------------------------------ state
  let C = null, script = null, world = null, layers = null, people = null, seedUsed = 0;
  let P = 0, playing = false, speed = 1, dur = 1, chapters = [], scrubbing = false, readyFired = false, loading = false, loadId = 0, destroyed = false;
  let userLevel, dirLevel = null, cutLevel = null, segIdx = -1, curShot = null, lensRunT0 = 0, sbOn = false, crowdJob = null, crowdP = 0, graphKey = 'base';
  let lastRender = -1e9, wantRender = false;
  const plays = {};                 // recorded runs, ready to play
  function setSpeed(s) { speed = s; dock.setSpeed(s); }
  function setLens(id) { if (id === 'crowd' && lenses.current !== 'crowd') lensRunT0 = performance.now(); lenses.set(id); dock.setLens(lenses.current); paintTog(); wantRender = true; }
  setSpeed(1); setLens('world'); paintFloors();
  function applyCut(lv) { cutLevel = lv; if (world) world.cutaway(lv); if (layers) layers.setCut(lv); }
  const chapterAt = (p) => { const i = chapters.findIndex((c) => p >= c.p0 && p < c.p1); return i < 0 ? chapters.length - 1 : i; };
  const segAt = (p) => { if (!script) return -1; for (let i = 0; i < script.segs.length; i++) if (p < script.segs[i].t1) return i; return script.segs.length - 1; };

  // ------------------------------------------------------------------ the pipeline
  const newSeed = () => (TEST ? 7 : ((Math.random() * 1e6) | 0) + 1);
  const nextTask = (ms = 0) => new Promise((r) => setTimeout(r, ms));
  let loadInfo = null;
  async function pump(gen, my, onP, budget) {
    let lastP = -1, lastT = performance.now(); const t0 = performance.now(); let work = 0;
    for (;;) { const s0 = performance.now(); let r;
      do { r = gen.next(); if (r.done) break; if (r.value.p > lastP + 1e-4) { lastP = r.value.p; lastT = performance.now(); onP(r.value); } } while (performance.now() - s0 < budget);
      work += performance.now() - s0;
      if (r.done) return { v: r.value, work };
      if (performance.now() - lastT > 25000) throw new Error('the pipeline stopped making progress');
      if (performance.now() - t0 > 240000) throw new Error('the pipeline took too long');
      await nextTask(0); if (my !== loadId || destroyed) return null;
    }
  }
  async function start({ seed } = {}) {
    const my = ++loadId; report.hide(); pause(); root.classList.add('nomis'); loading = true; cards.clear(); captions.set(null, '', '');
    simOv.show('Surveying the building'); simOv.progress(.01, 'Starting');
    await nextTask(TEST ? 0 : 40); if (my !== loadId) return;
    const T0 = performance.now();
    for (let attempt = 0; attempt < 2; attempt++) {
      const s = attempt ? newSeed() + 1 : (seed ?? opts.seed ?? newSeed());
      try {
        const out = await pump(runCore(s), my, (v) => simOv.progress(.02 + v.p * .96, v.label), TEST ? 400 : 45); if (!out || my !== loadId) return;
        const c = out.v; c.coreWork = Math.round(out.work);
        if (TEST) { const o2 = await pump(runCrowd(c), my, (v) => simOv.progress(.5 + v.p * .49, v.label || 'Full-house runs'), 400); if (!o2 || my !== loadId) return; c.crowdWork = Math.round(o2.work); }
        simOv.progress(.99, 'Building the scene'); await nextTask(0); if (my !== loadId) return;
        const tb = performance.now(); begin(c);
        loadInfo = { seed: s, pipeline: c.coreWork, crowd: c.crowdWork || null, scene: Math.round(performance.now() - tb), total: Math.round(performance.now() - T0), timings: c.timings };
        await nextTask(TEST ? 0 : 200); if (my !== loadId) return;
        simOv.hide(); root.classList.remove('nomis'); loading = false; P = 0; segIdx = -1; director.giveBack(); play();
        if (!TEST) startCrowdJob(my);
        if (!readyFired) { readyFired = true; if (opts.onReady) opts.onReady(); }
        return;
      } catch (e) { console.warn(`[act2] seed ${s} failed:`, e); dropScene(); if (my !== loadId) return; }
    }
    loading = false;
    simOv.fail('This building could not be computed here. Another seed usually works.', () => start({ seed: newSeed() + 2 }), exitAct);
  }
  // the full-house runs and the fixes, in the background while the first chapters play: on the crowd host (a Web
  // Worker, so the film's frame rate does not matter; timed slices on the page if no worker can start)
  function startCrowdJob(my) {
    crowdJob = { my, t0: performance.now(), done: false };
    crowd.background(my);
  }
  function onCrowdEvent(m) {
    if (m.type === 'progress') { if (crowdJob && m.token === crowdJob.my) crowdP = m.p || crowdP; return; }
    if (m.type === 'done') {
      if (!crowdJob || m.token !== crowdJob.my || m.token !== loadId || !C) return;
      const o = m.out; Object.assign(C, { full: o.full, widenDoor: o.widenDoor, widenTo: o.widenTo, widen: o.widen, fixes: o.fixes, rhoHot: o.rhoHot, rhoHotNight: o.rhoHotNight });
      C.timings.crowd = o.timings.crowd; C.timings.crowdTotal = o.timings.crowdTotal; C.crowdWork = m.work; crowdJob.done = true;
      if (loadInfo) { loadInfo.crowd = m.work; loadInfo.crowdWall = Math.round(performance.now() - crowdJob.t0); loadInfo.crowdMode = crowd.mode; }
      crowdReady(); return;
    }
    if (m.type === 'error' && m.where !== 'sandbox' && crowdJob && m.token === crowdJob.my) { console.warn('[act2] crowd runs failed:', m.message); toast('The full-house runs could not be computed; chapters 5 to 7 show the night run only.'); crowdJob.done = true; waitCrowd = false; return; }
    sandbox.onHost(m);
  }
  function crowdReady() { script = buildScript(C); chapters = script.chapters; prepPlays(); cards.refresh(); paintTog(); wantRender = true; segIdx = -1; }
  function dropScene() {
    if (people) { people.dispose(); people = null; }
    if (layers) { try { layers.dispose(); } catch (e) { /* ignore */ } layers = null; }
    if (world) { scene.remove(world.group); try { world.dispose(); } catch (e) { /* ignore */ } world = null; }
    C = null; script = null; chapters = []; crowdJob = null; for (const k of Object.keys(plays)) delete plays[k];
  }
  function prepPlays() {
    if (C.night.frames) plays.night = playRun(C.night.frames, C.W, C.model);
    if (C.full) { plays.fullLast = playRun(C.full.frames.last, C.W, C.model); plays.fullBest = playRun(C.full.frames.best, C.W, C.model); }
    if (C.fixes && C.fixes.clear.frames) plays.fixClear = playRun(C.fixes.clear.frames, C.W, C.model);
  }
  function begin(c) {
    dropScene(); C = c; P = 0; playing = false; seedUsed = c.seed; segIdx = -1; curShot = null; userLevel = undefined; paintFloors(); graphKey = 'base';
    for (const n of LAYERS) lenses.W[n] = 0; lenses.S.dim = 0;
    world = buildWorld(C, props, { phone: PH, theme: THEME }); scene.add(world.group);
    R.setSky(world.sky, world.bounds, THEME.look);
    layers = createLayers(scene, C, world, { theme: THEME });
    people = createPeople(scene, { max: 128, theme: THEME, seed: C.seed });
    script = buildScript(C); chapters = script.chapters; dur = script.dur; prepPlays(); nightBeds = bedsFor(C);
    // the crowd host builds the same case from the seed (for the background runs and the sandbox)
    { const nh = C.night.calm.bottlenecks[0]; crowd.init({ token: loadId, seed: C.seed, nightHot: nh ? { dom: nh.dom, x: nh.x, z: nh.z, rho: nh.rho } : null, fixGraph: C.fixGraph }); }
    dock.setTimeline(chapters, dur, script.events); cards.setCase(C); sandbox.setCase(C);
    director.setScene(new THREE.Vector3(0, 5, 0), 15); director.setShot(script.segs[0].shot, { cut: true });
    applyCut(null); wantRender = true; paintTog();
    extras = makeExtras(C);
    if (!TEST) { const order = ['cloud', 'tracks', 'skeleton', 'graph', 'doors', 'heat', 'flows', 'risk', 'vox']; const my = loadId, L = layers;
      const step = () => { if (destroyed || my !== loadId || L !== layers || !order.length) return; const n = order.shift(); try { L.ensure(n); L.setW(n, lenses.W[n] || 0); } catch (e) { /* on demand */ } setTimeout(step, 90); }; setTimeout(step, 600); }
  }
  // a few neighbours in the yard and on the pavement, for the opening shot
  let extras = [];
  function makeExtras(c) { const { D } = c.model.dims; let hh = c.seed * 7 + 3; const r = () => { hh = (hh * 16807) % 2147483647; return hh / 2147483647; }; const out = []; for (let i = 0; i < 6; i++) out.push({ x: -6 + i * 2.4 + r() * 1.2, z: i < 3 ? D / 2 + 1.4 + r() * 1.2 : D / 2 + 3.2 + 1.2 + r() * .8, yaw: r() * 6.28, r: .26 + r() * .08 }); return out; }
  function play() { if (!C) return; if (P >= dur - .05) { P = 0; segIdx = -1; } report.hide(); playing = true; if (held) { held = false; running = true; last = performance.now(); } }
  function pause() { playing = false; }
  function seek(p) { if (!C) return; P = Math.max(0, Math.min(dur, p)); segIdx = -1; if (P < dur - .1) report.hide(); wantRender = true; }
  let held = false, heldPlaying = false, heldMusic = false;
  function hold() { if (held) { playing = false; return; } held = true; heldPlaying = playing; playing = false; running = false; heldMusic = music.on; if (music.on) { music.stop(); paintMus(); } }
  function unhold() { running = true; last = performance.now(); if (!held) return; held = false; if (heldPlaying) play(); if (heldMusic) { music.start(); paintMus(); } }

  // ------------------------------------------------------------------ the sandbox
  let crowdUrl = null; try { if (!opts.workerSrc) crowdUrl = new URL('./pipe/worker.js', import.meta.url); } catch (e) { /* no worker url: the page computes */ }
  const crowd = createCrowdClient({ workerSrc: opts.workerSrc || null, workerUrl: crowdUrl, onEvent: (m) => onCrowdEvent(m) });
  const sandbox = createSandbox(sbxEl, { phone: PH, theme: THEME, onClose: () => setSandbox(false), toast, onChange: () => { wantRender = true; }, crowd });
  // the sandbox's plan view (a still camera over the ground floor: the markers are for tapping), and its run view
  const SB_PLAN = { kind: 'cutaway', level: 0, target: [0, 1.5, 0.6], az: .3, el: 1.18, dist: PH ? 28 : 29, drift: 0 };
  let sbRunView = false;
  function setSandbox(on) {
    if (!C) return; if (on === sbOn) return; sbOn = on; root.classList.toggle('sbx', on); dock.setSandbox(on);
    if (on) { pause(); report.hide(); sandbox.open(); setLens('world'); if (userLevel === undefined) { userLevel = 0; applyCut(0); paintFloors(); } director.giveBack(); sbRunView = false; curShot = SB_PLAN; director.setShot(curShot, { cut: true }); }
    else { sandbox.close(); sbRunView = false; world.setSection(false); people.seeThrough(false); world.setRear(false); world.setClutter(true); world.setBarriers([]); layers.setGraph({ G: C.G, weak: C.percSummary.weak, bridges: C.perc.bridgeIds, dead: C.deadEnds }); graphKey = 'base'; userLevel = undefined; applyCut(dirLevel); paintFloors(); segIdx = -1; }
    paintTog(); wantRender = true;
  }

  // ------------------------------------------------------------------ per-frame playback
  const filmW = {}; for (const n of LAYERS) filmW[n] = 0;
  const st = { surveyT: 0, crowdT: 0, run: 'night', fix: null, graph: null };
  function playback(dt) {
    if (!C) return;
    if (!C.fixes && crowdJob && !crowdJob.done && P >= script.beats.fis && playing) { playing = false; waitCrowd = true; }
    if (waitCrowd && (C.fixes || !crowdJob || crowdJob.done)) { waitCrowd = false; playing = true; }
    crowd.setUrgent(waitCrowd);
    if (playing && !scrubbing && !sbOn) { P += dt * speed; if (P >= dur) { P = dur; playing = false; onEnded(); } }
    if (sbOn) { sandboxFrame(dt); return; }
    const ci = chapterAt(P), ch = chapters[ci], si = segAt(P), sg = script.segs[si];
    for (const n of LAYERS) filmW[n] = sg.layers[n] || 0; filmW.dim = sg.dim || 0; filmW.people = sg.people ? 1 : 0;
    lenses.update(dt, filmW);
    const W = lenses.W, Ln = lenses.current;
    for (const n of LAYERS) { let w = W[n]; if (Ln === 'baseline' && n === 'cloud') w = tog.vox ? 0 : w; if (Ln === 'baseline' && n === 'vox') w = tog.vox ? 1 : 0; layers.setW(n, w); }
    const secOn = Ln === 'crowd' || (Ln === 'world' && !!(sg.shot && sg.shot.section));
    world.setDim(lenses.S.dim); people.setDim(secOn ? 0 : Math.min(.6, lenses.S.dim * .6));
    // survey time: the drones fly their logged tracks; the cloud and the tracks grow with them
    const sT = P < script.beats.survey[0] ? 0 : script.surveyAt(P); st.surveyT = Ln === 'world' ? sT : C.survey.stats.flightS;
    const cl = layers.get('cloud'); if (cl) cl.material.uniforms.tReveal.value = Ln === 'world' && P < script.beats.survey[1] ? sT : 1e9;
    const tr = layers.get('tracks'); if (tr && W.tracks > .01) tr.userData.upto(Ln === 'world' && P < script.beats.survey[1] ? sT : 1e9);
    drones(P, sT);
    // floors in view for the per-floor overlays
    layers.floorsTo(cutLevel);
    // the fixes (chapter 7): the scooters, the rear door, the graph with the rear door open
    const fixNow = Ln === 'world' && ch.id === 'fix' ? sg.fix : null; st.fix = fixNow;
    world.setClutter(!(fixNow === 'clear' && P - sg.t0 > 1.2));
    world.setRear(fixNow === 'rear' && P - sg.t0 > 1.0);
    const gk = fixNow === 'rear' && P - sg.t0 > 1.0 ? 'rear' : 'base';
    if (gk !== graphKey) { graphKey = gk; if (gk === 'rear') { const r = graphFor(C, ['rear'], { trials: 300 }); layers.setGraph({ G: r.G, weak: r.perc.weak.map((q) => [q.link, q.people]), bridges: r.perc.bridgeIds, dead: [] }); st.graph = { betti: r.perc.betti, perc: { ...C.fixGraph.rear.perc } }; } else { layers.setGraph({ G: C.G, weak: C.percSummary.weak, bridges: C.perc.bridgeIds, dead: C.deadEnds }); st.graph = null; } }
    // the percolation trial (chapter 6): barriers appear one at a time
    const trial = Ln === 'world' && sg.trial ? script.beats.trialOrder : null; let shownB = [];
    if (trial) { const k = Math.min(trial.order.length, Math.floor((P - sg.t0) / 0.9) + 1); shownB = trial.order.slice(0, k); st.trialK = k; st.trialDone = k >= trial.order.length && trial.cut > 0; } else st.trialDone = false;
    world.setBarriers(shownB.map((id) => barrierOf(C.G.links[id])));
    // the cut-open building for the crowd (chapter 5's night and full house, and the Crowd lens)
    world.setSection(secOn); people.seeThrough(secOn);
    // people
    crowdFrame(sg, ch, secOn);
    nightScene(Ln === 'world' && sg.night ? { phase: sg.night, u: (P - sg.t0) / Math.max(.01, sg.t1 - sg.t0) } : Ln === 'crowd' && st.run === 'night' ? lensNight : null);
    // captions, shots, cards
    let cap = null; for (const c of script.captions) { if (c.t <= P + .05) cap = c; else break; }
    captions.set(ci, ch.title, cap ? cap.text : '');
    const wantShot = fit(Ln === 'crowd' ? SECTION : sg.shot);
    if (si !== segIdx || wantShot !== curShot) { segIdx = si; curShot = wantShot; director.setShot(curShot, { cut: !!(sg.shot && sg.shot.cut) }); }
    cards.show(Ln === 'world' ? sg.cards : LENS_CARDS[Ln] || []);
  }
  let waitCrowd = false;
  // people: the extras (chapter 1), a recorded crowd run, or nobody
  const heatPts = [], flowPts = [];
  // the night opens asleep: where each person's bed is (beds in a row against one wall of the room they start in,
  // along its length so the section view sees them side-on), the room lights, and the alarm
  let nightBeds = null, lensNight = null;
  function bedsFor(c) {
    const out = [], byRoom = new Map(); c.night.people.forEach((p, i) => { if (!byRoom.has(p.room)) byRoom.set(p.room, []); byRoom.get(p.room).push(i); });
    for (const [rid, ids] of byRoom) {
      const rm = c.model.rooms[rid], alongX = rm.x1 - rm.x0 >= 2.4 || rm.x1 - rm.x0 >= rm.z1 - rm.z0, a0 = alongX ? rm.x0 : rm.z0, a1 = alongX ? rm.x1 : rm.z1, b0 = alongX ? rm.z0 : rm.x0, b1 = alongX ? rm.z1 : rm.x1;
      // the head against the wall nearer the middle of the block, the beds side by side across the room
      const headLo = Math.abs(a0) < Math.abs(a1), along = headLo ? Math.min(a1 - 1.08, a0 + 1.12) : Math.max(a0 + 1.08, a1 - 1.12);
      ids.sort((p, q) => (alongX ? c.night.people[p].z - c.night.people[q].z : c.night.people[p].x - c.night.people[q].x));
      const span = (ids.length - 1) * 1.05, mid = Math.max(b0 + 0.55 + span / 2, Math.min(b1 - 0.55 - span / 2, (b0 + b1) / 2));
      ids.forEach((i, k) => { const across = mid - span / 2 + k * 1.05, yaw = alongX ? (headLo ? Math.PI / 2 : -Math.PI / 2) : (headLo ? 0 : Math.PI);
        out[i] = { x: alongX ? along : across, z: alongX ? across : along, y: floorTop(c.night.people[i].storey), yaw, storey: c.night.people[i].storey, room: rid }; });
    }
    return out;
  }
  const smooth = (u) => { u = Math.max(0, Math.min(1, u)); return u * u * (3 - 2 * u); };
  function crowdFrame(sg, ch, secOn) {
    const Ln = lenses.current; let run = null, t = 0, phase = null, wake = 1;
    if (Ln === 'world' && sg.crowd) { const q = sg.crowd; run = plays[q.run]; t = q.s0 + (q.s1 - q.s0) * Math.max(0, Math.min(1, (P - q.t0) / (q.t1 - q.t0))); st.run = q.run; phase = sg.night || null; if (phase === 'wake') wake = smooth((P - sg.t0) / Math.max(.01, sg.t1 - sg.t0)); }
    else if (Ln === 'crowd') {
      run = plays[tog.run] || plays.night; st.run = plays[tog.run] ? tog.run : 'night'; wantRender = true;
      // the lens loops the run at 4x; the night starts with 2.5 s asleep and 1 s waking
      const wall = (performance.now() - lensRunT0) / 1000, pre = st.run === 'night' ? 3.5 : 0, loop = pre + (run.tEnd + 6) / 4, u = wall % loop;
      if (u < pre) { phase = u < 2.5 ? 'asleep' : 'wake'; wake = phase === 'wake' ? smooth(u - 2.5) : 0; t = 0; } else { phase = st.run === 'night' ? 'run' : null; t = (u - pre) * 4; }
      lensNight = st.run === 'night' ? { phase, u: phase === 'wake' ? u - 2.5 : phase === 'run' ? (u - pre) / 2 : u / 2.5 } : null;
    }
    st.crowdT = run ? t : null;
    heatPts.length = 0; flowPts.length = 0;
    const beds = run && run === plays.night && phase && nightBeds ? nightBeds : null;
    world.setBeds(beds ? beds.filter(Boolean) : []);
    if (run && (Ln === 'crowd' || sg.people)) {
      let n = 0; const pos = [];
      run.at(t, (i, x, y, z, hd, mv, gone) => {
        const rr = run === plays.night ? C.night.people[i].r : C.full.people[i].r;
        if (gone) { people.set(i, x, y, z, rr, hd, false); n = Math.max(n, i + 1); return; }
        if (beds && beds[i] && (phase === 'asleep' || phase === 'wake')) { const b = beds[i], w = phase === 'asleep' ? 0 : wake;
          const up = smooth(w * 2), go = smooth(w * 1.6 - .6); people.set(i, b.x + (x - b.x) * go, b.y + world.BED_TOP * (1 - up), b.z + (z - b.z) * go, rr, up > .5 ? hd : b.yaw, belowCut(b.y), 0, 1 - up); n = Math.max(n, i + 1); return; }
        const bob = mv > .2 ? Math.abs(Math.sin((t * 7 + i) * 1.3)) * .03 : 0; people.set(i, x, y, z, rr, hd, belowCut(y), bob); n = Math.max(n, i + 1); if (y > 0.1 || z < C.model.dims.D / 2 + 1) pos.push(x, y, z); }, secOn);
      people.count(n); people.done(); people.visible(true);
      // density per person (within 0.75 m on the same floor), and the doors' current flow
      for (let a = 0; a < pos.length; a += 3) { let k = 1; for (let b = 0; b < pos.length; b += 3) if (b !== a && Math.abs(pos[a + 1] - pos[b + 1]) < 1 && (pos[a] - pos[b]) ** 2 + (pos[a + 2] - pos[b + 2]) ** 2 < .5625) k++; heatPts.push({ x: pos[a], y: pos[a + 1], z: pos[a + 2], rho: k / 1.767 }); }
      const an = run === plays.night ? C.night.calm : run === plays.fixClear ? C.fixes.clear.full : (C.full && C.full.sweep.find((s) => s.v0 === C.full.fis.last).an);
      if (an) for (const f of an.flows) { const b = f.bins, k = Math.floor(t); const rate = ((b[k - 1] || 0) + (b[k] || 0) + (b[k + 1] || 0)) / 3; if (rate > 0.05) { const l = C.G.links[f.link]; flowPts.push({ p: l.p, rate, label: l.label }); } }
    } else if (Ln === 'world' && sg.extras) { extras.forEach((e, i) => people.set(i, e.x, 0.02, e.z, e.r, e.yaw, true)); people.count(extras.length); people.done(); people.visible(true); }
    else people.visible(false);
    const ht = layers.get('heat'); if (ht && lenses.W.heat > .01) ht.userData.set(cutFilter(heatPts), secOn ? .5 : 1);
    const fl = layers.get('flows'); if (fl && lenses.W.flows > .01) fl.userData.set(flowPts.filter((q) => cutLevel == null || q.p[1] < (cutLevel + 1) * 3));
  }
  // room lights: faint in the rooms where people sleep, then (after the alarm) on in those rooms and in the stair hall of
  // each floor; the alarm itself is a red pulse in the stair hall of every floor
  const lightPts = [];
  function nightScene(ns) {
    const L = layers.ensure('lights'); if (!L) return; lightPts.length = 0;
    if (ns && nightBeds) {
      const { zb, zf } = C.model.dims, warm = layers.warm, red = layers.alarm, lit = new Set();
      for (const b of nightBeds) if (b) lit.add(b.room);
      const on = ns.phase === 'asleep' ? 0 : ns.phase === 'wake' ? smooth(ns.u * 1.5) : 1;
      for (const rid of lit) { const rm = C.model.rooms[rid]; if (cutLevel != null && rm.storey > cutLevel) continue; lightPts.push({ x: (rm.x0 + rm.x1) / 2, y: floorTop(rm.storey) + 2.15, z: (rm.z0 + rm.z1) / 2, c: warm, a: .2 + .32 * on, s: 2.6 + .8 * on }); }
      for (let f = 0; f < 4; f++) { if (cutLevel != null && f > cutLevel) continue; const y = floorTop(f) + 2.25, zc = (zb + zf) / 2;
        if (on > 0) lightPts.push({ x: 0, y, z: zc, c: warm, a: .4 * on, s: 2.4 });
        const pulse = ns.phase === 'wake' || (ns.phase === 'run' && ns.u < .25) ? (.5 + .5 * Math.sin(clockT * 9)) * (ns.phase === 'run' ? 1 - ns.u / .25 : 1) : 0;
        if (pulse > .02) lightPts.push({ x: 0, y, z: zc, c: red, a: .85 * pulse, s: 3.2 }); }
      wantRender = true;
    }
    L.userData.set(lightPts); L.visible = lightPts.length > 0;
  }
  const cutFilter = (pts) => (cutLevel == null ? pts : pts.filter((q) => q.y < (cutLevel + 1) * 3));
  // people stand on a floor that is cut away, above the level in view: hide them with it
  const belowCut = (y) => cutLevel == null || y < (cutLevel + 1) * 3 - 0.4;
  // drones: on the pad, then along their logged tracks during the survey, then back on the pad
  function drones(p, sT) {
    const slots = world.padSlots, tracks = C.survey.tracks, inSurvey = p >= script.beats.survey[0] && p < script.beats.survey[1] + .5;
    for (let i = 0; i < 8; i++) {
      if (!inSurvey) { const s = slots[i]; world.setDrone(i, s[0], s[1], s[2], i * .8, true); continue; }
      const tr = tracks[i]; let k = 0; while (k < tr.length - 2 && tr[k + 1].t < sT) k++;
      const a = tr[k], b = tr[k + 1] || a, u = Math.max(0, Math.min(1, (sT - a.t) / Math.max(1e-3, b.t - a.t)));
      const x = a.p[0] + (b.p[0] - a.p[0]) * u, y = a.p[1] + (b.p[1] - a.p[1]) * u, z = a.p[2] + (b.p[2] - a.p[2]) * u;
      world.setDrone(i, x, y, z, Math.atan2(b.p[0] - a.p[0], b.p[2] - a.p[2]) || i, true);
    }
    world.drones.instanceMatrix.needsUpdate = true;
  }
  // where a barrier stands for a blocked link
  function barrierOf(l) {
    if (l.kind === 'door') { const o = C.model.openings[l.door]; const m = (o.o0 + o.o1) / 2; return { p: o.axis === 'x' ? [o.off, floorTop(o.storey), m] : [m, floorTop(o.storey), o.off], along: o.axis === 'x' ? 'z' : 'x', w: o.o1 - o.o0 + .1, storey: o.storey }; }
    if (l.kind === 'corridor' && l.cut) { const q = l.cut; return { p: q.axis === 'x' ? [q.at, floorTop(l.storey), (q.a0 + q.a1) / 2] : [(q.a0 + q.a1) / 2, floorTop(l.storey), q.at], along: q.axis === 'x' ? 'z' : 'x', w: q.a1 - q.a0, storey: l.storey }; }
    const S = C.stair, zm = (S.zTop + S.zb) / 2, x = l.upper ? (0.05 + S.inX) / 2 : -(0.05 + S.inX) / 2, u = (zm - S.zTop) / S.run, yA = floorTop(l.storey), yM = yA + 1.5, yB = floorTop(l.storey + 1);
    return { p: [x, l.upper ? yM + (yB - yM) * u : yM + (yA - yM) * u, zm], along: 'x', w: S.inX - .05, storey: l.upper ? l.storey + 1 : l.storey };
  }
  function sandboxFrame(dt) {
    lenses.update(dt, { heat: 1, flows: 0, graph: sandbox.showGraph && !sbRunView ? 1 : 0, dim: .3, people: 1 });
    for (const n of LAYERS) layers.setW(n, n === 'heat' ? lenses.W.heat : n === 'graph' ? lenses.W.graph : 0);
    world.setDim(lenses.S.dim); people.setDim(.1);
    const sb = sandbox.frame(dt, C, { cutLevel }); crowd.setUrgent(sandbox.api.state.computing);
    if (sb.runView !== sbRunView) { sbRunView = sb.runView; director.giveBack(); if (sbRunView) { applyCut(null); curShot = fit(SECTION); } else { applyCut(userLevel ?? 0); curShot = SB_PLAN; } director.setShot(curShot, { cut: true }); }   // (a cut: a change of view, not a move)
    world.setSection(sbRunView); people.seeThrough(sbRunView); world.setBeds([]); nightScene(null);
    world.setRear(sb.rear); world.setClutter(!sb.clear); world.setBarriers(sb.blocked.map((id) => barrierOf(sb.G.links[id])));
    if (sb.graphChanged) layers.setGraph({ G: sb.G, weak: sb.weak, bridges: sb.bridges, dead: [] });
    layers.floorsTo(cutLevel);
    heatPts.length = 0; let n = 0;
    if (sb.live) { const L = sb.live, pos = []; L.at((i, x, z, dom, hd, out) => { if (out) { const sp = sandbox.spotOf(i); people.set(i, sp[0], 0.02, sp[2], L.r[i], 0, !sbRunView); return; } const y = C.W.heightAt(dom, x, z); people.set(i, x, y, z, L.r[i], hd, belowCut(y)); pos.push(x, y, z); }); n = L.n;
      for (let a = 0; a < pos.length; a += 3) { let k = 1; for (let b = 0; b < pos.length; b += 3) if (b !== a && Math.abs(pos[a + 1] - pos[b + 1]) < 1 && (pos[a] - pos[b]) ** 2 + (pos[a + 2] - pos[b + 2]) ** 2 < .5625) k++; heatPts.push({ x: pos[a], y: pos[a + 1], z: pos[a + 2], rho: k / 1.767 }); } }
    else if (sb.people) { sb.people.forEach((p, i) => people.set(i, p.x, floorTop(p.storey), p.z, p.r, 0, belowCut(floorTop(p.storey)))); n = sb.people.length; }
    people.count(n); people.done(); people.visible(n > 0);
    const ht = layers.get('heat'); if (ht) ht.userData.set(cutFilter(heatPts), sbRunView ? .5 : 1);
    st.run = 'sandbox'; st.sbAn = sb.an; captions.set(null, 'Sandbox', '');
    wantRender = true;
  }
  function onEnded() { report.show(C); }

  // ------------------------------------------------------------------ labels in the scene
  function sceneLabels() {
    const r = canvas.getBoundingClientRect(); labels.begin(camera, r.width, r.height);
    if (!C || !world) { labels.end(); return; }
    if (sbOn) { if (sbRunView) sandbox.hideMarks(); else sandbox.labels(labels, camera, r, cutLevel); labels.end(); return; }
    const W = lenses.W, world0 = lenses.current === 'world', B = script.beats, sg = script.segs[segAt(P)];
    const inCh = (id, a = 0, b = 1e9) => world0 && P >= B[id][0] + a && P < Math.min(B[id][1], B[id][0] + b);
    if (inCh('peace', 7)) { const m = world.anchors.mast, t = world.anchors.table, pd = world.anchors.pad; labels.add(m[0], m[1] + .3, m[2], '<b>Anchor robot</b><small>its mast relays to the ground station</small>', 'apr', 1, 6); labels.add(t[0], t[1] + .6, t[2], '<b>Ground station</b><small>a laptop on a folding table</small>', 'teal', 1, 6); labels.add(pd[0], 1.0, pd[2], '<b>Eight drones</b><small>tilting LiDAR, camera, thermal</small>', 'teal', 1, 6); }
    // the baseline: the lobby gap and the street door, as measured
    if (inCh('baseline', 7) || (lenses.current === 'baseline')) {
      if (C.base.gap != null && C.base.gapZ != null) labels.add(0.2, 1.2, C.base.gapZ, `<b>${C.base.gap.toFixed(2)} m clear</b><small>between the parked scooters</small>`, 'heat', Math.min(1, W.vox + W.cloud), 8);
      const sd = C.base.doors.find((d) => d.kind === 'street'); if (sd && sd.measured) { const p = doorPos(C, sd.id); labels.add(p[0], p[1] + .9, p[2] + .3, `<b>Street door ${sd.measured.toFixed(2)} m</b><small>plan ${sd.plan.toFixed(2)} m</small>`, 'teal', Math.min(1, W.vox + W.cloud), 8); }
      const rd = C.base.doors.find((d) => d.kind === 'rear'); if (rd) { const p = doorPos(C, rd.id); labels.add(p[0], p[1] + .4, p[2] - .3, `<b>Rear door, shut</b><small>${C.stair.head(C.stair.zTop).toFixed(1)} m headroom under the landing</small>`, 'caution', Math.min(1, W.vox + W.cloud), 8); }
    }
    if (inCh('routes', 15)) { const rd = C.base.doors.find((d) => d.kind === 'rear'); const p = doorPos(C, rd.id); labels.add(p[0], p[1] + .4, p[2] + .2, `<b>Rear door</b><small>shut; ${C.stair.head(C.stair.zTop).toFixed(1)} m of headroom</small>`, 'caution', 1, 8); }
    // the cut-open view: where the street door is (its wall is cut away)
    if (world.section && !sbOn) labels.add(0, 0.35, C.model.dims.D / 2 + 0.5, '<b>Street door</b>', 'teal', 1, 5);
    // the bottleneck
    if (world0 && sg.crowd && sg.hot) {   // (named once the camera is there)
       const an = sg.crowd.run === 'night' ? C.night.calm : C.full && C.full.sweep.find((s) => s.v0 === C.full.fis.last).an; const hb = an && an.bottlenecks[0]; if (hb && P - sg.crowd.t0 > 2) labels.add(hb.x, hb.y + 1.6, hb.z, `<b>${hb.label.replace(/^./, (m) => m.toUpperCase())}</b><small>${hb.rho.toFixed(1)} people/m² at the peak</small>`, 'heat', 1, 8); }
    // the trial and the worst link
    if (world0 && sg.trial) { const tr = B.trialOrder; const k = st.trialK || 0; tr.order.slice(0, k).forEach((id, i) => { const b = barrierOf(C.G.links[id]); if (cutLevel == null || b.storey <= cutLevel) labels.add(b.p[0], b.p[1] + 1.3, b.p[2], `<b>Blocked ${i + 1}</b><small>${C.G.links[id].label}</small>`, 'noentry', i === k - 1 ? 1 : .75, 6); }); if (st.trialDone && tr.rooms.length) { const n = C.G.nodes[tr.rooms[0]]; labels.add(n.p[0], n.p[1] + 1.4, n.p[2], `<b>Cut off: ${tr.cut} ${tr.cut === 1 ? 'person' : 'people'}</b><small>after ${tr.order.length} random ${tr.order.length === 1 ? 'blockage' : 'blockages'}</small>`, 'noentry', 1, 8); } }
    if ((world0 && script.segs[segAt(P)].ch === 'risk' && !sg.trial) || lenses.current === 'risk') { const w = C.percSummary.worst; if (w) { const l = C.G.links[w.link]; labels.add(l.p[0], l.p[1] + 1.2, l.p[2], `<b>Worst single link</b><small>${l.label}: ${w.people} people behind it</small>`, 'noentry', 1, 8); } }
    if (world0 && sg.fix === 'widen' && C.widen) { const p = doorPos(C, C.widen.door); labels.add(p[0], p[1] + .9, p[2], `<b>${C.widen.from.toFixed(1)} m to ${C.widen.to.toFixed(1)} m</b><small>${C.widen.label}</small>`, 'teal', 1, 8); }
    if (world0 && sg.fix === 'rear' && P - sg.t0 > 1) { const rd = C.base.doors.find((d) => d.kind === 'rear'); const p = doorPos(C, rd.id); labels.add(p[0], p[1] + .5, p[2], '<b>Rear door unlocked</b><small>a second way out: a loop</small>', 'teal', 1, 8); }
    if (world0 && sg.fix === 'clear' && C.base.gapZ != null) labels.add(0.2, 1.4, C.base.gapZ, '<b>Lobby cleared</b><small>the scooters parked outside</small>', 'teal', Math.min(1, (P - sg.t0) / 1.5), 8);
    labels.end();
  }

  // ------------------------------------------------------------------ frame loop
  let raf = 0, last = performance.now(), clockT = 0, running = true, frames = 0, fpsT = 0, fps = 0, frameErr = 0;
  const prof = {};
  function frame(now) { raf = requestAnimationFrame(frame); if (!running || document.hidden) { last = now; return; } try { frameBody(now); } catch (e) { resetGL(); if (frameErr++ < 3) console.warn('[act2] frame failed', e); } }
  let offNow = 0, cardsHalf = 0, viewW = 1, viewH = 1;
  // a longer lens for shots that ask for one (the section view: from further away and nearly level, so every floor is
  // seen almost straight on and the floor above hides little of the one below); eased, so a cut to it is not a jump
  const FOV0 = PH ? 50 : 38; let fovNow = FOV0;
  function shotLens(dt) { const want = curShot && curShot.fov && !director.user ? (PH ? curShot.fovPhone || curShot.fov * 1.35 : curShot.fov) : FOV0; fovNow += (want - fovNow) * (1 - Math.exp(-dt * 3)); if (Math.abs(fovNow - want) < .05) fovNow = want; if (Math.abs(fovNow - FOV0) > .01) { camera.fov = fovNow; camera.updateProjectionMatrix(); } }
  function frameBody(now) {
    const dt = Math.min(TEST ? 1 : .4, (now - last) / 1000); last = now; clockT += dt; frames++;
    if (now - fpsT > 1000) { fps = frames; frames = 0; fpsT = now; }
    const idle = loading || !C;
    if (!TEST && !idle) R.adapt(dt); else if (!TEST) R.resetAdapt();
    const q0 = performance.now();
    if (C && !loading) { try { playback(dt); } catch (e) { if (frameErr++ < 3) console.warn('[act2] playback failed', e); } }
    { const goal = (cards.active.length || sbOn) && !PH ? cardsHalf : 0; const n = offNow + (goal - offNow) * (1 - Math.exp(-dt * 1.6)); if (Math.abs(n - offNow) > .05) { offNow = n; director.setFrame(viewW, viewH, offNow, PH ? 0 : 22); } }
    director.update(dt, 0); shotLens(dt); if (world) world.fadeNeighbours(camera.position, director.tgt, TEST ? 1 : dt);
    prof.play = performance.now() - q0;
    if (!idle && (!TEST || wantRender || (playing && now - lastRender > (opts.testRenderMs ?? 2500)))) { safeDraw(); lastRender = now; wantRender = false; }
    if (C) { dock.update(P, playing, waitCrowd ? `computing the crowd runs ${Math.round(crowdP * 100)} %` : sbOn ? 'sandbox' : ''); cards.update(st, TEST); }
    prof.frame = performance.now() - q0;
  }
  function syncUniforms() {
    const dpr = R.dpr, H = R.h; const f = (o) => { const m = o.material; if (!m || !m.uniforms) return; const u = m.uniforms; if (u.res) u.res.value.set(R.w, R.h); if (u.time) u.time.value = clockT; if (u.hh) u.hh.value = H * dpr; if (u.px) u.px.value = dpr; };
    if (layers) layers.root.traverse(f);
  }
  function draw() { syncUniforms(); camera.updateMatrixWorld(); R.render(clockT); sceneLabels(); }
  function resetGL() { renderer.setRenderTarget(null); renderer.setScissorTest(false); renderer.setViewport(0, 0, R.w, R.h); renderer.autoClear = true; }
  function safeDraw() { try { draw(); } catch (e) { resetGL(); if (frameErr++ < 3) console.warn('[act2] frame failed', e); } }
  function resize() {
    const r = view.getBoundingClientRect(); const w = Math.max(16, r.width), hh = Math.max(16, r.height);
    R.setSize(w, hh); viewW = w; viewH = hh; cardsHalf = PH ? 0 : Math.min(190, (parseFloat(getComputedStyle(root).getPropertyValue('--cards')) || 336) * .5);
    director.setFrame(w, hh, offNow, PH ? 0 : 22); dock.layout(); wantRender = true;
  }
  const ro = new ResizeObserver(resize); ro.observe(view); resize();
  raf = requestAnimationFrame(frame);
  const typing = (t) => t && t.closest && t.closest('input, textarea, select');
  const onKey = (e) => {
    if (typing(e.target) || e.ctrlKey || e.metaKey || e.altKey) return;
    if (e.key === ' ' && C) { e.preventDefault(); if (sbOn) sandbox.run(); else playing ? pause() : play(); }
    else if (e.key === 'ArrowRight' && C && !sbOn) seek(P + 5); else if (e.key === 'ArrowLeft' && C && !sbOn) seek(P - 5);
    else if (/^[1-6]$/.test(e.key) && C) { const L = LENSES.find((l) => l.key === e.key); if (L) { if (sbOn) setSandbox(false); setLens(L.id); } }
    else if (e.key === 'd' || e.key === 'D') director.giveBack();
    else if ((e.key === 's' || e.key === 'S') && C) setSandbox(!sbOn);
    else if (e.key === 'Escape') { if (asm.shown) asm.hide(); else if (sbOn) setSandbox(false); else exitAct(); }
  };
  addEventListener('keydown', onKey);
  start({ seed: opts.seed });
  root.focus({ preventScroll: true });

  const api = {
    root,
    play: () => { held = false; running = true; if (sbOn) setSandbox(false); play(); }, pause: () => hold(), resume: () => unhold(),
    seek: (p) => { if (sbOn) setSandbox(false); seek(p); }, lens: (id) => { if (sbOn) setSandbox(false); setLens(id); }, speed: setSpeed,
    chapter: (i) => { const c = chapters[i]; if (c) { if (sbOn) setSandbox(false); seek(c.p0 + .01); } },
    director: () => director.giveBack(), takeCamera: () => director.take(),
    floors: (lv) => { userLevel = lv === 'auto' ? undefined : lv; applyCut(userLevel === undefined ? dirLevel : userLevel); paintFloors(); wantRender = true; },
    sandbox: (on = true) => { setSandbox(!!on); return sandbox.api; },
    showReport: () => { if (C) report.show(C); },
    // (tests) the Crowd lens's loop: which run, and how many seconds into its loop
    lensClock: (s, run) => { if (run) { tog.run = run; paintTog(); } lensRunT0 = performance.now() - s * 1000; wantRender = true; },
    assumptions: () => { if (C) asm.show(C); },
    get state() { return { seed: seedUsed, P, dur, playing, waiting: waitCrowd, crowdP, crowdMode: crowd.mode, section: !!(world && world.section), chapter: chapters[chapterAt(P)]?.id, lens: lenses.current, cards: cards.active, caption: captions.text, shot: curShot && curShot.kind, cut: cutLevel, user: director.user, sandbox: sbOn, crowdReady: !!(C && C.fixes), fps, dpr: R.dpr, calls: renderer.info.render.calls, tris: renderer.info.render.triangles, load: loadInfo }; },
    renderNow(settle = 0) {
      if (!C) { R.render(clockT); return api.state; }
      playback(0); offNow = (cards.active.length || sbOn) && !PH ? cardsHalf : 0; director.setFrame(viewW, viewH, offNow, PH ? 0 : 22);
      for (let i = 0; i < settle; i++) { lenses.update(.1, filmW); playback(0); director.update(.1, 0); shotLens(.1); }
      playback(0); director.update(.016, 0); shotLens(.016); if (world) world.fadeNeighbours(camera.position, director.tgt, 5); draw(); dock.update(P, playing, sbOn ? 'sandbox' : ''); cards.update(st, true); return api.state;
    },
    frameStats() {
      if (C && world) { try { draw(); } catch (e) { /* stats of whatever is on screen */ } }
      const stat = (sx, sy, sw, sh, W, H) => { const c = document.createElement('canvas'); c.width = W; c.height = H; const x = c.getContext('2d', { willReadFrequently: true }); x.drawImage(canvas, sx, sy, sw, sh, 0, 0, W, H); const d = x.getImageData(0, 0, W, H).data, L = new Float32Array(W * H);
        let m = 0; for (let i = 0; i < W * H; i++) { L[i] = (.2126 * d[i * 4] + .7152 * d[i * 4 + 1] + .0722 * d[i * 4 + 2]) / 255; m += L[i]; } m /= W * H; let v = 0, e = 0, n = 0;
        for (let k = 1; k < H - 1; k++) for (let i = 1; i < W - 1; i++) { const q = k * W + i; v += (L[q] - m) ** 2; const g = Math.abs(L[q + 1] - L[q - 1]) + Math.abs(L[q + W] - L[q - W]); if (g > .06) e++; n++; }
        return { mean: +m.toFixed(3), std: +Math.sqrt(v / n).toFixed(3), edge: +(e / n).toFixed(3) }; };
      const cw = canvas.width, ch = canvas.height; return { main: stat(0, 0, cw * (PH ? 1 : .72), ch * .82, 192, 120), chapter: chapters[chapterAt(P)]?.id };
    },
    get caseData() { return C; }, get script() { return script; }, get prof() { return prof; },
    _dbg: { scene, camera, renderer, R, director, lenses, get layers() { return layers; }, get world() { return world; }, get people() { return people; } },
    destroy() {
      if (destroyed) return; destroyed = true; loadId++;
      canvas.removeEventListener('webglcontextlost', onLost); cancelAnimationFrame(raf); running = false; playing = false; ro.disconnect(); removeEventListener('keydown', onKey); clearTimeout(toastT);
      try { music.destroy(); } catch (e) { /* ignore */ } dock.dispose(); director.dispose(); sandbox.dispose(); crowd.dispose();
      dropScene();
      scene.traverse((o) => { if (o.geometry) o.geometry.dispose(); if (o.material) (Array.isArray(o.material) ? o.material : [o.material]).forEach((m) => { for (const k in m) if (m[k] && m[k].isTexture) m[k].dispose(); m.dispose(); }); });
      if (props) props.traverse((o) => { if (o.geometry) o.geometry.dispose(); if (o.material) (Array.isArray(o.material) ? o.material : [o.material]).forEach((m) => m.dispose()); });
      R.dispose(); root.remove();
    },
  };
  return api;
}
