// Ground truth for scoring: the baseline and post-event worlds rasterised into voxel grids, the space a drone could
// reach, the true voids (enclosed empty space a drone cannot enter, big enough for a curled person), true removed /
// added voxels, and every room's true status from its true tilt, sag, damage, crushing and debris with fixed rules.
// The pipeline never reads any of this; only score.js and the Truth lens do.
import { makeGrid, rasterBox, erode, dilate, flood, components } from './voxel.js';
import { tApply, tiltOf, DEG, boxAABB, qToMat } from './geom.js';
import { NS, SH } from './building.js';

export const L_FREE = 0, L_STRUCT = 1, L_DEBRIS = 2, L_STATIC = 3, L_DOOR = 4;
// the room-status rules (shared by the truth and, with conservative margins, by the pipeline's drafts)
export const RULES = {
  tiltNoEntry: 2.0, tiltCaution: 0.5,          // degrees
  sagNoEntry: 0.05, sagCaution: 0.015,         // metres
  crushNoEntry: 0.08, crushCaution: 0.01,      // share of the room's volume taken by structure that moved into it
  debrisNoEntry: 0.25, debrisCaution: 0.03,    // share of the floor covered by debris
  goneNoEntry: 0.12,                           // share of a wall that fell
  dmgNoEntry: 0.5, dmgCaution: 0.1,            // wall damage index
  crackCaution: 0.3,                           // metres of cracks in its walls
};

export function rasteriseWorld(model, parts, g, { post = false } = {}) {
  const G = new Uint8Array(g.N);
  // the ground layer (y < 0) is static everywhere
  for (let c = 0; c < g.nx * g.nz; c++) G[c] = L_STATIC;
  for (const p of parts) {
    if (p.kind === 'site') { rasterBox(g, p.box, G, L_STATIC, { ymin: 0 }); continue; }
    const lab = post && p.debris ? L_DEBRIS : post && p.kind === 'door' ? L_DOOR : L_STRUCT;
    rasterBox(g, p.box, G, lab, { ymin: 0, keep: lab === L_DEBRIS });
  }
  return G;
}

// drone-reachable space in a labelled grid: free space shrunk by the drone's half size (1 voxel each way: ~0.3 m
// openings pass at 0.1 m voxels), flooded from the open air at the domain's sides and top, then grown back by the
// drone's body. Returns { centre: where a drone's centre can be, body: what its body can sweep }.
export function reachable(g, free, k = 1) {
  const er = erode(g, free, k, k, k, 1);
  const seeds = []; const { nx, ny, nz } = g;
  // seeds one layer in from the domain's top and sides (the outermost layer is cleared by the flood)
  for (let k2 = 1; k2 < nz - 1; k2++) for (let i = 1; i < nx - 1; i++) seeds.push(i + nx * (k2 + nz * (ny - 2)));
  for (let j = 1; j < ny - 1; j++) { for (let i = 1; i < nx - 1; i++) { seeds.push(i + nx * (1 + nz * j)); seeds.push(i + nx * (nz - 2 + nz * j)); } for (let k2 = 1; k2 < nz - 1; k2++) { seeds.push(1 + nx * (k2 + nz * j)); seeds.push(nx - 2 + nx * (k2 + nz * j)); } }
  const centre = flood(g, er, seeds);
  const body = dilate(g, centre, k, k, k, 0); for (let c = 0; c < g.N; c++) body[c] &= free[c];
  return { centre, body };
}

// enclosed voids: free, not reachable by a drone, at least minVol, with a core where a curled person fits
export function findVoids(g, free, body, { minVol = 0.3, minCore = 0.03, labels = null } = {}) {
  const cand = new Uint8Array(g.N); for (let c = 0; c < g.N; c++) cand[c] = free[c] && !body[c] ? 1 : 0;
  const minN = Math.round(minVol / g.V3);
  const { labels: lab, comps } = components(g, cand, { minKeep: minN, keepCells: true, labels });
  const core = erode(g, cand, 1, 1, 1, 0);
  const out = [];
  for (const cp of comps) {
    let nc = 0; for (const c of cp.cells) if (core[c]) nc++;
    if (nc * g.V3 < minCore) continue;
    const cen = [g.x0 + (cp.ci + .5) * g.vox, g.y0 + (cp.cj + .5) * g.vox, g.z0 + (cp.ck + .5) * g.vox];
    out.push({ id: out.length, n: cp.n, vol: cp.n * g.V3, core: nc * g.V3, centre: cen, bb: cp.bb, cells: cp.cells });
  }
  return out;
}

// sample the voxels of a room's (moved) interior: returns counts by label and debris coverage of its floor
function roomSample(g, G, room, T, Tc) {
  const n = { tot: 0, free: 0, struct: 0, debris: 0 }; const cellD = 0.25;
  const nxr = Math.max(1, Math.round((room.x1 - room.x0 - 0.1) / cellD)), nzr = Math.max(1, Math.round((room.z1 - room.z0 - 0.1) / cellD));
  const cov = new Uint8Array(nxr * nzr); const H = room.y1 - room.y0, ny = Math.max(2, Math.round(H / g.vox));
  for (let a = 0; a < nxr; a++) for (let b = 0; b < nzr; b++) {
    const lx = room.x0 + 0.05 + (a + .5) * (room.x1 - room.x0 - 0.1) / nxr, lz = room.z0 + 0.05 + (b + .5) * (room.z1 - room.z0 - 0.1) / nzr;
    for (let s = 0; s < ny; s++) {
      const ly = room.y0 + 0.05 + (s + .5) * (H - 0.1) / ny;
      const p = tApply(ly > room.y0 + H * .6 && Tc ? Tc : T, lx, ly, lz); const c = g.cell(p[0], p[1], p[2]); if (c < 0) continue;
      n.tot++; const v = G[c]; if (v === L_FREE) n.free++; else if (v === L_DEBRIS) { n.debris++; if (ly < room.y0 + 1.5) cov[a * nzr + b] = 1; } else if (v !== L_STATIC) n.struct++;
    }
  }
  let cv = 0; for (const v of cov) cv += v;
  return { ...n, debrisShare: cv / cov.length };
}

export function roomStatus(m, R = RULES) {
  const why = [];
  if (m.tilt >= R.tiltNoEntry) why.push('tilt');
  if (m.sag >= R.sagNoEntry) why.push('sag');
  if (m.crush >= R.crushNoEntry) why.push('crushed');
  if (m.debrisShare >= R.debrisNoEntry) why.push('debris');
  if (m.gone >= R.goneNoEntry) why.push('wall fell');
  if (m.dmg >= R.dmgNoEntry) why.push('wall damage');
  if (why.length) return { status: 'noentry', why };
  if (m.tilt >= R.tiltCaution) why.push('tilt');
  if (m.sag >= R.sagCaution) why.push('sag');
  if (m.crush >= R.crushCaution) why.push('crushed');
  if (m.debrisShare >= R.debrisCaution) why.push('debris');
  if (m.crackLen >= R.crackCaution) why.push('cracks');
  if (m.dmg >= R.dmgCaution) why.push('wall damage');
  if (why.length) return { status: 'caution', why };
  return { status: 'safe', why };
}

export function truthRooms(model, post, g, P) {
  const out = [];
  const panelsUnder = (room, level) => model.parts.filter((p) => p.kind === 'slab' && p.level === level && p.aabb[0] < room.x1 && p.aabb[3] > room.x0 && p.aabb[2] < room.z1 && p.aabb[5] > room.z0);
  for (const room of model.rooms) {
    const s = room.storey, T = post.motions[s], Tc = post.motions[Math.min(NS, s + 1)];
    const smp = roomSample(g, P, room, T, Tc);
    const tilt = Math.max(tiltOf(T.R), tiltOf(Tc.R)) / DEG;
    let wt = 0, dmg = 0, gone = 0, crackLen = 0;
    for (const wid of room.walls) { const w = post.walls[wid]; wt = Math.max(wt, w.tilt); dmg = Math.max(dmg, w.damage); gone = Math.max(gone, w.gone); crackLen += w.crackLen; }
    let sag = 0, fell = false;
    for (const lv of [s, s + 1]) for (const p of panelsUnder(room, lv)) { if (post.sag.has(p.id)) sag = Math.max(sag, post.sag.get(p.id)); const pp = post.parts.find((q) => q.src === p.id); if (!pp || pp.state === 'fallen') fell = true; }
    const crush = smp.tot ? smp.struct / smp.tot : 0;
    const m = { tilt: Math.max(tilt, wt), sag, crush: fell ? Math.max(crush, 0.5) : crush, debrisShare: smp.debrisShare, gone, dmg, crackLen, freeShare: smp.tot ? smp.free / smp.tot : 0 };
    const st = roomStatus(m);
    out.push({ id: room.id, ...m, status: st.status, why: st.why });
  }
  return out;
}

// everything at once (called by the pipeline runner; returns the grids so the scanner and the scorer can share them)
// the same reach measured with one physical drone, the way the pipeline measures it: a 0.35 m drone (0.175 m from its
// centre to any surface), tested against the exact true geometry (every box grown by 0.175 m, and the ground) instead of
// shrinking a rasterisation that thickens thin parts by whole voxels.
export const DRONE_CLEAR = 0.175;
export function reachableExact(g, free, parts, r = DRONE_CLEAR) {
  const blocked = new Uint8Array(g.N);
  for (const p of parts) {
    const h = p.box.h;
    if (Math.min(h[0], h[1], h[2]) < 0.6) { rasterBox(g, { c: p.box.c, h: [h[0] + r, h[1] + r, h[2] + r], q: p.box.q }, blocked, 1); continue; }
    // a big box (a neighbouring block, a slab panel): only a shell around its faces matters, its inside is solid anyway
    const m = qToMat(p.box.q), ax = [[m[0], m[3], m[6]], [m[1], m[4], m[7]], [m[2], m[5], m[8]]];
    for (let a = 0; a < 3; a++) for (const sg of [-1, 1]) {
      const inner = h[a] - g.vox, outer = h[a] + r, off = (inner + outer) / 2, hh = [h[0] + r, h[1] + r, h[2] + r]; hh[a] = (outer - inner) / 2;
      rasterBox(g, { c: [p.box.c[0] + ax[a][0] * off * sg, p.box.c[1] + ax[a][1] * off * sg, p.box.c[2] + ax[a][2] * off * sg], h: hh, q: p.box.q }, blocked, 1);
    }
  }
  const SY = g.nx * g.nz; for (let j = 0; j < g.ny; j++) { if (g.y0 + (j + .5) * g.vox >= r) break; blocked.fill(1, j * SY, (j + 1) * SY); }
  const cand = new Uint8Array(g.N); for (let c = 0; c < g.N; c++) cand[c] = free[c] && !blocked[c] ? 1 : 0;
  const seeds = []; const { nx, ny, nz } = g;
  for (let k2 = 1; k2 < nz - 1; k2++) for (let i = 1; i < nx - 1; i++) seeds.push(i + nx * (k2 + nz * (ny - 2)));
  for (let j = 1; j < ny - 1; j++) { for (let i = 1; i < nx - 1; i++) { seeds.push(i + nx * (1 + nz * j)); seeds.push(i + nx * (nz - 2 + nz * j)); } for (let k2 = 1; k2 < nz - 1; k2++) { seeds.push(1 + nx * (k2 + nz * j)); seeds.push(nx - 2 + nx * (k2 + nz * j)); } }
  const centre = flood(g, cand, seeds);
  // the drone's body sweeps everything within its half-width of a centre: up to two voxels (0.175 m plus half a voxel)
  const body = dilate(g, centre, 2, 2, 2, 0); for (let c = 0; c < g.N; c++) body[c] &= free[c];
  return { centre, body };
}
export function computeTruth(model, post) {
  const g = makeGrid(model.grid);
  const B = rasteriseWorld(model, model.parts, g, { post: false });
  const P = rasteriseWorld(model, post.parts, g, { post: true });
  const freeP = new Uint8Array(g.N); for (let c = 0; c < g.N; c++) freeP[c] = P[c] === L_FREE ? 1 : 0;
  // voids and the search-certified share use one exact 0.35 m drone (TRUTHDRONE=voxel reproduces the old whole-voxel
  // test for the before/after comparison in the README)
  const TD = (typeof process !== 'undefined' && process.env && process.env.TRUTHDRONE) || 'exact';
  const reachFly = reachable(g, freeP, 1);
  const reach = TD === 'voxel' ? reachFly : reachableExact(g, freeP, post.parts);
  // (reachFly: where the replayed search flight of Acts 4-6 placed its drones, the whole-voxel test as before, so the
  // scans themselves do not change with the scoring rule)
  let voids = findVoids(g, freeP, reach.body);
  // only voids the collapse made: a nook that was already there in the surveyed building (behind the generator box,
  // say) is not one
  // (a void the collapse made touches structure that truly changed: moved, fallen or gone)
  const altered0 = new Uint8Array(g.N); for (let c = 0; c < g.N; c++) { const b = B[c] === L_STRUCT, p = P[c] === L_STRUCT || P[c] === L_DEBRIS || P[c] === L_DOOR; if (b !== p) altered0[c] = 1; }
  if (TD !== 'voxel' && voids.length) {
    const SYv = g.nx * g.nz, nb6 = [1, -1, g.nx, -g.nx, SYv, -SYv];
    voids = voids.filter((v) => { for (const c of v.cells) for (const d of nb6) if (altered0[c + d]) return true; return false; }); voids.forEach((v, i) => { v.id = i; });
  }
  const rooms = truthRooms(model, post, g, P);
  // altered voxels (static never changes)
  let removed = 0, added = 0; const altered = new Uint8Array(g.N);
  for (let c = 0; c < g.N; c++) { const b = B[c] === L_STRUCT, p = P[c] === L_STRUCT || P[c] === L_DEBRIS || P[c] === L_DOOR; if (b && !p) { altered[c] = 1; removed++; } else if (p && !b) { altered[c] = 2; added++; } }
  // the search area: the building's post-event footprint (+0.6 m), ground to roof
  let x0 = 1e9, x1 = -1e9, z0 = 1e9, z1 = -1e9, y1 = 0;
  for (const p of post.parts) { if (p.kind === 'site' || p.debris) continue; const bb = p.aabb || boxAABB(p.box); x0 = Math.min(x0, bb[0]); x1 = Math.max(x1, bb[3]); z0 = Math.min(z0, bb[2]); z1 = Math.max(z1, bb[5]); y1 = Math.max(y1, bb[4]); }
  const area = { x0: x0 - 0.6, x1: x1 + 0.6, z0: z0 - 0.6, z1: z1 + 0.6, y0: 0, y1: y1 + 0.5 };
  let debrisVox = 0; for (let c = 0; c < g.N; c++) if (P[c] === L_DEBRIS) debrisVox++;
  return { g, B, P, freeP, reach, reachFly, voids, rooms, altered, removed, added, area, debrisVolume: post.debrisVolume, debrisVoxVolume: debrisVox * g.V3 };
}
