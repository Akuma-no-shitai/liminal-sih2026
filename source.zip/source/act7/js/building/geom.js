// Small maths helpers shared by the building, the collapse and the pipeline (pure JS, no three.js, runs in node).
// Conventions: metres, y up. Quaternions are [x, y, z, w]. 3x3 matrices are row-major arrays of 9.
// A rigid transform is { R: [9], t: [3] } and maps x -> R x + t.
export const DEG = Math.PI / 180;

// ------------------------------------------------------------------ seeded random numbers
export function hash32(...xs) {
  let h = 0x811c9dc5;
  for (const x of xs) {
    const s = String(x);
    for (let i = 0; i < s.length; i++) { h ^= s.charCodeAt(i); h = Math.imul(h, 0x01000193); }
    h ^= h >>> 13; h = Math.imul(h, 0x5bd1e995); h ^= h >>> 15;
  }
  return h >>> 0;
}
// mulberry32: fast, good enough, deterministic
export function rng(seed) {
  let a = seed >>> 0;
  const r = () => { a |= 0; a = (a + 0x6D2B79F5) | 0; let t = Math.imul(a ^ (a >>> 15), 1 | a); t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t; return ((t ^ (t >>> 14)) >>> 0) / 4294967296; };
  r.range = (lo, hi) => lo + (hi - lo) * r();
  r.int = (lo, hi) => lo + Math.floor(r() * (hi - lo + 1));
  r.pick = (arr) => arr[Math.floor(r() * arr.length)];
  r.chance = (p) => r() < p;
  let spare = null;
  r.gauss = () => { if (spare != null) { const s = spare; spare = null; return s; } let u = 0, v = 0; while (u < 1e-12) u = r(); v = r(); const m = Math.sqrt(-2 * Math.log(u)); spare = m * Math.sin(2 * Math.PI * v); return m * Math.cos(2 * Math.PI * v); };
  r.weighted = (items, weights) => { let s = 0; for (const w of weights) s += w; let x = r() * s; for (let i = 0; i < items.length; i++) { x -= weights[i]; if (x <= 0) return items[i]; } return items[items.length - 1]; };
  r.shuffle = (arr) => { for (let i = arr.length - 1; i > 0; i--) { const j = Math.floor(r() * (i + 1)); const t = arr[i]; arr[i] = arr[j]; arr[j] = t; } return arr; };
  return r;
}
export const rngFor = (seed, ...salt) => rng(hash32(seed, ...salt));

// ------------------------------------------------------------------ quaternions
export const Q_ID = () => [0, 0, 0, 1];
export function qAxis(ax, ay, az, a) { const n = Math.hypot(ax, ay, az) || 1, s = Math.sin(a / 2); return [ax / n * s, ay / n * s, az / n * s, Math.cos(a / 2)]; }
export function qMul(a, b) {
  return [a[3] * b[0] + a[0] * b[3] + a[1] * b[2] - a[2] * b[1], a[3] * b[1] - a[0] * b[2] + a[1] * b[3] + a[2] * b[0], a[3] * b[2] + a[0] * b[1] - a[1] * b[0] + a[2] * b[3], a[3] * b[3] - a[0] * b[0] - a[1] * b[1] - a[2] * b[2]];
}
export function qNorm(q) { const n = Math.hypot(q[0], q[1], q[2], q[3]) || 1; return [q[0] / n, q[1] / n, q[2] / n, q[3] / n]; }
export function qToMat(q, m = new Array(9)) {
  const [x, y, z, w] = q, xx = x * x, yy = y * y, zz = z * z, xy = x * y, xz = x * z, yz = y * z, wx = w * x, wy = w * y, wz = w * z;
  m[0] = 1 - 2 * (yy + zz); m[1] = 2 * (xy - wz); m[2] = 2 * (xz + wy);
  m[3] = 2 * (xy + wz); m[4] = 1 - 2 * (xx + zz); m[5] = 2 * (yz - wx);
  m[6] = 2 * (xz - wy); m[7] = 2 * (yz + wx); m[8] = 1 - 2 * (xx + yy);
  return m;
}
export function matToQ(m) {
  const tr = m[0] + m[4] + m[8]; let x, y, z, w;
  if (tr > 0) { const s = Math.sqrt(tr + 1) * 2; w = .25 * s; x = (m[7] - m[5]) / s; y = (m[2] - m[6]) / s; z = (m[3] - m[1]) / s; }
  else if (m[0] > m[4] && m[0] > m[8]) { const s = Math.sqrt(1 + m[0] - m[4] - m[8]) * 2; w = (m[7] - m[5]) / s; x = .25 * s; y = (m[1] + m[3]) / s; z = (m[2] + m[6]) / s; }
  else if (m[4] > m[8]) { const s = Math.sqrt(1 + m[4] - m[0] - m[8]) * 2; w = (m[2] - m[6]) / s; x = (m[1] + m[3]) / s; y = .25 * s; z = (m[5] + m[7]) / s; }
  else { const s = Math.sqrt(1 + m[8] - m[0] - m[4]) * 2; w = (m[3] - m[1]) / s; x = (m[2] + m[6]) / s; y = (m[5] + m[7]) / s; z = .25 * s; }
  return qNorm([x, y, z, w]);
}
export function qRot(q, v) { const m = qToMat(q); return [m[0] * v[0] + m[1] * v[1] + m[2] * v[2], m[3] * v[0] + m[4] * v[1] + m[5] * v[2], m[6] * v[0] + m[7] * v[1] + m[8] * v[2]]; }

// ------------------------------------------------------------------ rigid transforms
export const T_ID = () => ({ R: [1, 0, 0, 0, 1, 0, 0, 0, 1], t: [0, 0, 0] });
export function tApply(T, x, y, z, out = [0, 0, 0]) { const R = T.R; out[0] = R[0] * x + R[1] * y + R[2] * z + T.t[0]; out[1] = R[3] * x + R[4] * y + R[5] * z + T.t[1]; out[2] = R[6] * x + R[7] * y + R[8] * z + T.t[2]; return out; }
export function tRotate(T, x, y, z, out = [0, 0, 0]) { const R = T.R; out[0] = R[0] * x + R[1] * y + R[2] * z; out[1] = R[3] * x + R[4] * y + R[5] * z; out[2] = R[6] * x + R[7] * y + R[8] * z; return out; }
export function mMul(A, B) { const C = new Array(9); for (let i = 0; i < 3; i++) for (let j = 0; j < 3; j++) C[i * 3 + j] = A[i * 3] * B[j] + A[i * 3 + 1] * B[3 + j] + A[i * 3 + 2] * B[6 + j]; return C; }
export function mT(A) { return [A[0], A[3], A[6], A[1], A[4], A[7], A[2], A[5], A[8]]; }
// (A after B): x -> A(B(x))
export function tCompose(A, B) { const R = mMul(A.R, B.R); const t = tApply(A, B.t[0], B.t[1], B.t[2]); return { R, t }; }
export function tInvert(T) { const R = mT(T.R); const t = tRotate({ R }, -T.t[0], -T.t[1], -T.t[2]); return { R, t }; }
// rotation by angle a about the axis (ax, ay, az) through point p, then a translation d
export function tAxisPivot(axis, a, p, d = [0, 0, 0]) {
  const R = qToMat(qAxis(axis[0], axis[1], axis[2], a));
  const rp = [R[0] * p[0] + R[1] * p[1] + R[2] * p[2], R[3] * p[0] + R[4] * p[1] + R[5] * p[2], R[6] * p[0] + R[7] * p[1] + R[8] * p[2]];
  return { R, t: [p[0] - rp[0] + d[0], p[1] - rp[1] + d[1], p[2] - rp[2] + d[2]] };
}
// small-angle rotation (rx, ry, rz radians, applied as Rz Ry Rx) and translation
export function tFromEuler(rx, ry, rz, tx, ty, tz) {
  const cx = Math.cos(rx), sx = Math.sin(rx), cy = Math.cos(ry), sy = Math.sin(ry), cz = Math.cos(rz), sz = Math.sin(rz);
  const R = [cz * cy, cz * sy * sx - sz * cx, cz * sy * cx + sz * sx, sz * cy, sz * sy * sx + cz * cx, sz * sy * cx - cz * sx, -sy, cy * sx, cy * cx];
  return { R, t: [tx, ty, tz] };
}
export function rotAngle(R) { return Math.acos(Math.max(-1, Math.min(1, (R[0] + R[4] + R[8] - 1) / 2))); }
// angle between the rotated "up" and true up: how far a transform tips things over
export function tiltOf(R) { return Math.acos(Math.max(-1, Math.min(1, R[4]))); }
export function orthonormalize(R) {
  // Gram-Schmidt on the columns
  let a = [R[0], R[3], R[6]], b = [R[1], R[4], R[7]];
  const na = Math.hypot(...a); a = a.map((v) => v / na);
  const d = a[0] * b[0] + a[1] * b[1] + a[2] * b[2]; b = [b[0] - d * a[0], b[1] - d * a[1], b[2] - d * a[2]]; const nb = Math.hypot(...b); b = b.map((v) => v / nb);
  const c = [a[1] * b[2] - a[2] * b[1], a[2] * b[0] - a[0] * b[2], a[0] * b[1] - a[1] * b[0]];
  return [a[0], b[0], c[0], a[1], b[1], c[1], a[2], b[2], c[2]];
}
export function tToArray12(T) { const R = T.R, t = T.t; return [R[0], R[1], R[2], t[0], R[3], R[4], R[5], t[1], R[6], R[7], R[8], t[2]]; }

// ------------------------------------------------------------------ boxes { c:[3], h:[3] half sizes, q:[4] }
export function boxT(T, box) { const R = mMul(T.R, qToMat(box.q)); return { c: tApply(T, box.c[0], box.c[1], box.c[2]), h: box.h.slice(), q: matToQ(R) }; }
export function boxAxes(box) { const m = qToMat(box.q); return [[m[0], m[3], m[6]], [m[1], m[4], m[7]], [m[2], m[5], m[8]]]; }
export function boxAABB(box) {
  const m = qToMat(box.q), h = box.h, e = [0, 0, 0];
  for (let i = 0; i < 3; i++) e[i] = Math.abs(m[i * 3]) * h[0] + Math.abs(m[i * 3 + 1]) * h[1] + Math.abs(m[i * 3 + 2]) * h[2];
  return [box.c[0] - e[0], box.c[1] - e[1], box.c[2] - e[2], box.c[0] + e[0], box.c[1] + e[1], box.c[2] + e[2]];
}
export function boxCorners(box) {
  const ax = boxAxes(box), out = [];
  for (const sx of [-1, 1]) for (const sy of [-1, 1]) for (const sz of [-1, 1]) out.push([0, 1, 2].map((i) => box.c[i] + ax[0][i] * box.h[0] * sx + ax[1][i] * box.h[1] * sy + ax[2][i] * box.h[2] * sz));
  return out;
}
export const boxVol = (b) => 8 * b.h[0] * b.h[1] * b.h[2];
// an axis-aligned box from min/max corners
export function aabox(x0, y0, z0, x1, y1, z1) { return { c: [(x0 + x1) / 2, (y0 + y1) / 2, (z0 + z1) / 2], h: [Math.abs(x1 - x0) / 2, Math.abs(y1 - y0) / 2, Math.abs(z1 - z0) / 2], q: [0, 0, 0, 1] }; }

// ------------------------------------------------------------------ linear algebra
// symmetric 3x3 eigen-decomposition (Jacobi). a = [a00, a01, a02, a11, a12, a22]. Returns values descending and vectors (columns).
export function eigSym3(a00, a01, a02, a11, a12, a22) {
  const A = [[a00, a01, a02], [a01, a11, a12], [a02, a12, a22]], V = [[1, 0, 0], [0, 1, 0], [0, 0, 1]];
  for (let sweep = 0; sweep < 12; sweep++) {
    const off = A[0][1] * A[0][1] + A[0][2] * A[0][2] + A[1][2] * A[1][2]; if (off < 1e-22) break;
    for (let p = 0; p < 2; p++) for (let q = p + 1; q < 3; q++) {
      if (Math.abs(A[p][q]) < 1e-30) continue;
      const th = (A[q][q] - A[p][p]) / (2 * A[p][q]), t = Math.sign(th || 1) / (Math.abs(th) + Math.sqrt(th * th + 1)), c = 1 / Math.sqrt(t * t + 1), s = t * c;
      for (let k = 0; k < 3; k++) { const akp = A[k][p], akq = A[k][q]; A[k][p] = c * akp - s * akq; A[k][q] = s * akp + c * akq; }
      for (let k = 0; k < 3; k++) { const apk = A[p][k], aqk = A[q][k]; A[p][k] = c * apk - s * aqk; A[q][k] = s * apk + c * aqk; }
      for (let k = 0; k < 3; k++) { const vkp = V[k][p], vkq = V[k][q]; V[k][p] = c * vkp - s * vkq; V[k][q] = s * vkp + c * vkq; }
    }
  }
  const idx = [0, 1, 2].sort((i, j) => A[j][j] - A[i][i]);
  return { vals: idx.map((i) => A[i][i]), vecs: idx.map((i) => [V[0][i], V[1][i], V[2][i]]) };
}
// solve A x = b for small dense n x n (row-major A of n*n), Gaussian elimination with partial pivoting
export function solveN(A, b, n) {
  const M = A.slice(), x = b.slice();
  for (let c = 0; c < n; c++) {
    let p = c, best = Math.abs(M[c * n + c]); for (let r = c + 1; r < n; r++) { const v = Math.abs(M[r * n + c]); if (v > best) { best = v; p = r; } }
    if (best < 1e-14) return null;
    if (p !== c) { for (let k = 0; k < n; k++) { const t = M[c * n + k]; M[c * n + k] = M[p * n + k]; M[p * n + k] = t; } const t = x[c]; x[c] = x[p]; x[p] = t; }
    for (let r = c + 1; r < n; r++) { const f = M[r * n + c] / M[c * n + c]; if (!f) continue; for (let k = c; k < n; k++) M[r * n + k] -= f * M[c * n + k]; x[r] -= f * x[c]; }
  }
  for (let c = n - 1; c >= 0; c--) { let s = x[c]; for (let k = c + 1; k < n; k++) s -= M[c * n + k] * x[k]; x[c] = s / M[c * n + c]; }
  return x;
}
export const clamp = (v, lo, hi) => (v < lo ? lo : v > hi ? hi : v);
export const lerp = (a, b, t) => a + (b - a) * t;
export function median(arr) { if (!arr.length) return NaN; const s = Float64Array.from(arr).sort(); const m = s.length >> 1; return s.length % 2 ? s[m] : (s[m - 1] + s[m]) / 2; }
export function quantile(arr, q) { if (!arr.length) return NaN; const s = Float64Array.from(arr).sort(); const i = clamp((s.length - 1) * q, 0, s.length - 1), lo = Math.floor(i), hi = Math.ceil(i); return s[lo] + (s[hi] - s[lo]) * (i - lo); }
// fit a plane to points (flat xyz array, indices list): returns { n:[3], d, c:[3], rms } with n·x = d
export function fitPlane(P, idx, w = null) {
  let sx = 0, sy = 0, sz = 0, sw = 0;
  for (let k = 0; k < idx.length; k++) { const i = idx[k] * 3, ww = w ? w[k] : 1; sx += P[i] * ww; sy += P[i + 1] * ww; sz += P[i + 2] * ww; sw += ww; }
  if (sw <= 0) return null; const cx = sx / sw, cy = sy / sw, cz = sz / sw;
  let a00 = 0, a01 = 0, a02 = 0, a11 = 0, a12 = 0, a22 = 0;
  for (let k = 0; k < idx.length; k++) { const i = idx[k] * 3, ww = w ? w[k] : 1, dx = P[i] - cx, dy = P[i + 1] - cy, dz = P[i + 2] - cz; a00 += dx * dx * ww; a01 += dx * dy * ww; a02 += dx * dz * ww; a11 += dy * dy * ww; a12 += dy * dz * ww; a22 += dz * dz * ww; }
  const e = eigSym3(a00 / sw, a01 / sw, a02 / sw, a11 / sw, a12 / sw, a22 / sw); const n = e.vecs[2];
  return { n, d: n[0] * cx + n[1] * cy + n[2] * cz, c: [cx, cy, cz], rms: Math.sqrt(Math.max(0, e.vals[2])), ev: e.vals };
}
