// Voxel grids (pure data): rasterise oriented boxes, 3-D DDA traversal, flood fills, erosion / dilation and connected
// components. Index layout: i (x) fastest, then k (z), then j (y): idx = i + nx * (k + nz * j), so a horizontal slice
// at one height is contiguous.
import { qToMat, boxAABB } from './geom.js';

export function makeGrid({ x0, y0, z0, nx, ny, nz, vox }) {
  const g = { x0, y0, z0, nx, ny, nz, vox, N: nx * ny * nz, SX: 1, SZ: nx, SY: nx * nz, V3: vox * vox * vox };
  g.idx = (i, j, k) => i + nx * (k + nz * j);
  g.cell = (x, y, z) => { const i = Math.floor((x - x0) / vox), j = Math.floor((y - y0) / vox), k = Math.floor((z - z0) / vox); return i < 0 || j < 0 || k < 0 || i >= nx || j >= ny || k >= nz ? -1 : i + nx * (k + nz * j); };
  g.ijk = (c, out = [0, 0, 0]) => { out[0] = c % nx; const r = (c - out[0]) / nx; out[2] = r % nz; out[1] = (r - out[2]) / nz; return out; };
  g.centre = (c, out = [0, 0, 0]) => { g.ijk(c, out); out[0] = x0 + (out[0] + .5) * vox; out[1] = y0 + (out[1] + .5) * vox; out[2] = z0 + (out[2] + .5) * vox; return out; };
  return g;
}

// Rasterise an oriented box by voxel-centre sampling. Thin parts (any half-size under half a voxel) are thickened to
// one voxel so a door leaf or a thin wall never vanishes. opts.keep: only write empty voxels. opts.ymin: clip below.
const _m = new Array(9);
export function rasterBox(g, box, arr, val, opts = {}) {
  const m = qToMat(box.q, _m), hv = g.vox * .5 + 1e-4;
  const hx = Math.max(box.h[0], hv), hy = Math.max(box.h[1], hv), hz = Math.max(box.h[2], hv);
  const bb = boxAABB({ c: box.c, h: [hx, hy, hz], q: box.q });
  const i0 = Math.max(0, Math.floor((bb[0] - g.x0) / g.vox - .5)), i1 = Math.min(g.nx - 1, Math.ceil((bb[3] - g.x0) / g.vox - .5));
  const j0 = Math.max(0, Math.floor((bb[1] - g.y0) / g.vox - .5), opts.ymin != null ? Math.ceil((opts.ymin - g.y0) / g.vox - .5) : 0), j1 = Math.min(g.ny - 1, Math.ceil((bb[4] - g.y0) / g.vox - .5));
  const k0 = Math.max(0, Math.floor((bb[2] - g.z0) / g.vox - .5)), k1 = Math.min(g.nz - 1, Math.ceil((bb[5] - g.z0) / g.vox - .5));
  const cx = box.c[0], cy = box.c[1], cz = box.c[2], keep = !!opts.keep; let n = 0;
  for (let j = j0; j <= j1; j++) {
    const dy = g.y0 + (j + .5) * g.vox - cy;
    for (let k = k0; k <= k1; k++) {
      const dz = g.z0 + (k + .5) * g.vox - cz, base = g.nx * (k + g.nz * j);
      for (let i = i0; i <= i1; i++) {
        const dx = g.x0 + (i + .5) * g.vox - cx;
        // local = R^T d
        const lx = m[0] * dx + m[3] * dy + m[6] * dz; if (lx > hx || lx < -hx) continue;
        const ly = m[1] * dx + m[4] * dy + m[7] * dz; if (ly > hy || ly < -hy) continue;
        const lz = m[2] * dx + m[5] * dy + m[8] * dz; if (lz > hz || lz < -hz) continue;
        const c = base + i; if (keep && arr[c]) continue; arr[c] = val; n++;
      }
    }
  }
  return n;
}
// count (or list) voxels of a box without writing: used for part-support checks
export function boxVoxels(g, box, out = null) {
  const m = qToMat(box.q, _m), hv = g.vox * .5 + 1e-4;
  const hx = Math.max(box.h[0], hv), hy = Math.max(box.h[1], hv), hz = Math.max(box.h[2], hv);
  const bb = boxAABB({ c: box.c, h: [hx, hy, hz], q: box.q });
  const i0 = Math.max(0, Math.floor((bb[0] - g.x0) / g.vox - .5)), i1 = Math.min(g.nx - 1, Math.ceil((bb[3] - g.x0) / g.vox - .5));
  const j0 = Math.max(0, Math.floor((bb[1] - g.y0) / g.vox - .5)), j1 = Math.min(g.ny - 1, Math.ceil((bb[4] - g.y0) / g.vox - .5));
  const k0 = Math.max(0, Math.floor((bb[2] - g.z0) / g.vox - .5)), k1 = Math.min(g.nz - 1, Math.ceil((bb[5] - g.z0) / g.vox - .5));
  const res = out || []; const cx = box.c[0], cy = box.c[1], cz = box.c[2];
  for (let j = j0; j <= j1; j++) { const dy = g.y0 + (j + .5) * g.vox - cy;
    for (let k = k0; k <= k1; k++) { const dz = g.z0 + (k + .5) * g.vox - cz, base = g.nx * (k + g.nz * j);
      for (let i = i0; i <= i1; i++) { const dx = g.x0 + (i + .5) * g.vox - cx;
        const lx = m[0] * dx + m[3] * dy + m[6] * dz; if (lx > hx || lx < -hx) continue;
        const ly = m[1] * dx + m[4] * dy + m[7] * dz; if (ly > hy || ly < -hy) continue;
        const lz = m[2] * dx + m[5] * dy + m[8] * dz; if (lz > hz || lz < -hz) continue;
        res.push(base + i); } } }
  return res;
}

// ------------------------------------------------------------------ morphology on 0/1 masks (box structuring elements)
// One step along one axis is an AND (erode) or OR (dilate) of a voxel with its two neighbours; k steps compose to a box
// of half-width k. `edge` is the value assumed outside the grid.
function step1(g, src, dst, axis, edge, isOr) {
  const { nx, ny, nz } = g, SY = nx * nz, N = g.N;
  if (axis === 0) {
    for (let r = 0, base = 0; r < ny * nz; r++, base += nx) {
      const e = base + nx - 1;
      dst[base] = isOr ? (src[base] | src[base + 1] | edge) : (src[base] & src[base + 1] & edge);
      if (isOr) for (let c = base + 1; c < e; c++) dst[c] = src[c - 1] | src[c] | src[c + 1];
      else for (let c = base + 1; c < e; c++) dst[c] = src[c - 1] & src[c] & src[c + 1];
      dst[e] = isOr ? (src[e - 1] | src[e] | edge) : (src[e - 1] & src[e] & edge);
    }
  } else if (axis === 1) {   // z: stride nx inside each layer
    for (let j = 0; j < ny; j++) {
      const L0 = j * SY, L1 = L0 + SY;
      for (let c = L0; c < L0 + nx; c++) dst[c] = isOr ? (src[c] | src[c + nx] | edge) : (src[c] & src[c + nx] & edge);
      if (isOr) for (let c = L0 + nx; c < L1 - nx; c++) dst[c] = src[c - nx] | src[c] | src[c + nx];
      else for (let c = L0 + nx; c < L1 - nx; c++) dst[c] = src[c - nx] & src[c] & src[c + nx];
      for (let c = L1 - nx; c < L1; c++) dst[c] = isOr ? (src[c - nx] | src[c] | edge) : (src[c - nx] & src[c] & edge);
    }
  } else {                   // y: stride nx*nz
    for (let c = 0; c < SY; c++) dst[c] = isOr ? (src[c] | src[c + SY] | edge) : (src[c] & src[c + SY] & edge);
    if (isOr) for (let c = SY; c < N - SY; c++) dst[c] = src[c - SY] | src[c] | src[c + SY];
    else for (let c = SY; c < N - SY; c++) dst[c] = src[c - SY] & src[c] & src[c + SY];
    for (let c = N - SY; c < N; c++) dst[c] = isOr ? (src[c - SY] | src[c] | edge) : (src[c - SY] & src[c] & edge);
  }
}
function morph(g, mask, kx, ky, kz, edge, isOr, out) {
  const steps = []; for (let t = 0; t < kx; t++) steps.push(0); for (let t = 0; t < kz; t++) steps.push(1); for (let t = 0; t < ky; t++) steps.push(2);
  const res = out || new Uint8Array(g.N);
  if (!steps.length) { res.set(mask); return res; }
  const tmp = steps.length > 1 ? new Uint8Array(g.N) : null;
  // ping-pong so the last step lands in res
  let src = mask; const e = edge ? 1 : 0;
  steps.forEach((ax, i) => { const left = steps.length - 1 - i; const dst = left % 2 === 0 ? res : tmp; step1(g, src, dst, ax, e, isOr); src = dst; });
  return res;
}
export const erode = (g, mask, kx, ky, kz, edge = 1, out = null) => morph(g, mask, kx, ky, kz, edge, false, out);
export const dilate = (g, mask, kx, ky, kz, edge = 0, out = null) => morph(g, mask, kx, ky, kz, edge, true, out);
// clear the outermost layer of a mask (flood fills and components then need no bounds checks)
export function zeroBorder(g, m) {
  const { nx, ny, nz } = g, SY = nx * nz;
  m.fill(0, 0, SY); m.fill(0, g.N - SY, g.N);
  for (let j = 1; j < ny - 1; j++) { const L = j * SY; m.fill(0, L, L + nx); m.fill(0, L + SY - nx, L + SY); for (let k = 1; k < nz - 1; k++) { m[L + k * nx] = 0; m[L + k * nx + nx - 1] = 0; } }
  return m;
}

// ------------------------------------------------------------------ flood fill and components (6-connected)
// Both clear the border of the mask they are given (it must be a scratch mask).
let QBUF = null;
const queue = (N) => { if (!QBUF || QBUF.length < N) QBUF = new Int32Array(N); return QBUF; };
export function freeWork() { QBUF = null; }
export function flood(g, mask, seeds, out = null) {
  zeroBorder(g, mask);
  const vis = out || new Uint8Array(g.N), q = queue(g.N); let h = 0, t = 0;
  for (const s of seeds) if (s >= 0 && mask[s] && !vis[s]) { vis[s] = 1; q[t++] = s; }
  const nx = g.nx, SY = g.nx * g.nz;
  while (h < t) {
    const c = q[h++]; let d;
    d = c - 1; if (mask[d] && !vis[d]) { vis[d] = 1; q[t++] = d; }
    d = c + 1; if (mask[d] && !vis[d]) { vis[d] = 1; q[t++] = d; }
    d = c - nx; if (mask[d] && !vis[d]) { vis[d] = 1; q[t++] = d; }
    d = c + nx; if (mask[d] && !vis[d]) { vis[d] = 1; q[t++] = d; }
    d = c - SY; if (mask[d] && !vis[d]) { vis[d] = 1; q[t++] = d; }
    d = c + SY; if (mask[d] && !vis[d]) { vis[d] = 1; q[t++] = d; }
  }
  return vis;
}
// connected components of mask; returns { labels: Int32Array (0 = none), comps: [{ id, n, ci, cj, ck, bb, cells? }] }
export function components(g, mask, { minKeep = 1, keepCells = false, labels = null } = {}) {
  zeroBorder(g, mask);
  const lab = labels || new Int32Array(g.N); if (labels) lab.fill(0);
  const q = queue(g.N), { nx, nz } = g, SY = nx * nz; const comps = []; let next = 1;
  for (let s = 0; s < g.N; s++) {
    if (!mask[s] || lab[s]) continue;
    const id = next; lab[s] = id; let h = 0, t = 0; q[t++] = s;
    while (h < t) {
      const c = q[h++]; let d;
      d = c - 1; if (mask[d] && !lab[d]) { lab[d] = id; q[t++] = d; }
      d = c + 1; if (mask[d] && !lab[d]) { lab[d] = id; q[t++] = d; }
      d = c - nx; if (mask[d] && !lab[d]) { lab[d] = id; q[t++] = d; }
      d = c + nx; if (mask[d] && !lab[d]) { lab[d] = id; q[t++] = d; }
      d = c - SY; if (mask[d] && !lab[d]) { lab[d] = id; q[t++] = d; }
      d = c + SY; if (mask[d] && !lab[d]) { lab[d] = id; q[t++] = d; }
    }
    if (t < minKeep) { for (let a = 0; a < t; a++) lab[q[a]] = -1; continue; }
    let sx = 0, sy = 0, sz = 0, i0 = 1e9, j0 = 1e9, k0 = 1e9, i1 = -1, j1 = -1, k1 = -1;
    for (let a = 0; a < t; a++) { const c = q[a]; const i = c % nx, r = (c - i) / nx, k = r % nz, j = (r - k) / nz; sx += i; sy += j; sz += k; if (i < i0) i0 = i; if (i > i1) i1 = i; if (j < j0) j0 = j; if (j > j1) j1 = j; if (k < k0) k0 = k; if (k > k1) k1 = k; }
    const comp = { id, n: t, ci: sx / t, cj: sy / t, ck: sz / t, bb: [i0, j0, k0, i1, j1, k1] };
    if (keepCells) comp.cells = q.slice(0, t);
    comps.push(comp); next++;
  }
  for (let c = 0; c < g.N; c++) if (lab[c] < 0) lab[c] = 0;
  return { labels: lab, comps };
}
export const ijkToWorld = (g, i, j, k) => [g.x0 + (i + .5) * g.vox, g.y0 + (j + .5) * g.vox, g.z0 + (k + .5) * g.vox];
