// buildBuilding({ seed }): an ordinary apartment block as a semantic model (pure data, no three.js). Shared with Act 2
// (the Before-phase baseline survey), so it only describes the building and its site; nothing here knows about
// collapses or scans.
//   Ground + 3 floors, RC frame with brick infill, ~20 m x 11 m, storey 3.0 m, slab 0.15 m, external walls 0.23 m,
//   internal 0.115 m, columns 0.3 x 0.3 m on a regular grid, beams. Central stair core; two flats per floor (A west,
//   B east), each with a living room, a bedroom, a kitchen, a bathroom and an entrance hall; doors (0.9 m), windows,
//   front balconies, a street door and a rear exit, a small yard and street around it.
// Coordinates: metres, y up, origin at the ground centre. The street is on +z (the front), the yard on -z.
// Returns { parts, rooms, openings, walls, levels, site, dims, grid }; every part is an oriented box
//   { id, kind, storey, mat, box: { c, h, q }, unit, rooms, ext }.
import { rngFor, aabox, qAxis, boxAABB } from './geom.js';

export const FLOORS = ['Ground floor', 'First floor', 'Second floor', 'Third floor'];
export const FLOOR_SHORT = ['ground', 'first', 'second', 'third'];
export const SH = 3.0, ST = 0.15, NS = 4, T_EXT = 0.23, T_INT = 0.115, COL = 0.3, BEAM_D = 0.35;
export const floorTop = (s) => SH * s + ST;      // walking level of storey s
export const ceilingOf = (s) => SH * (s + 1);    // underside of the slab above storey s
const r2 = (v) => Math.round(v * 100) / 100;

export function buildBuilding({ seed = 1 } = {}) {
  const r = rngFor(seed, 'building');
  const L = r2(19.2 + r() * 1.6), D = r2(10.4 + r() * 1.0), c = 1.5;
  const flatW = L / 2 - c;
  const zh = r2(-0.7 + r() * 0.8), hw = 1.3, zb = r2(zh - hw / 2), zf = r2(zh + hw / 2);
  // partitions run along the middle column line of each flat (infill sits on the beam lines, as in most RC frames)
  const uM = r2(c + flatW * (0.44 + r() * 0.14));
  // per flat: which room sits on the outer (end-wall) side of each band ("layout mirroring")
  const FL = {};
  for (const flat of ['A', 'B']) {
    const fOuter = r() < 0.7 ? 'living' : 'bedroom', bOuter = r() < 0.6 ? 'kitchen' : 'bathroom';
    FL[flat] = { fOuter, fInner: fOuter === 'living' ? 'bedroom' : 'living', bOuter, bInner: bOuter === 'kitchen' ? 'bathroom' : 'kitchen', uF: uM, uB: uM };
  }
  const balcony = []; for (let s = 1; s < NS; s++) balcony.push([r() < 0.8, r() < 0.8]);
  const winW = { living: r2(1.5 + r() * 0.3), bedroom: r2(1.2 + r() * 0.3), kitchen: r2(1.0 + r() * 0.3), end: r2(1.1 + r() * 0.4) };
  const winShift = r2((r() - 0.5) * 0.6);
  const parts = [], rooms = [], openings = [], walls = [];
  let pid = 0;
  const add = (kind, box, o = {}) => { const p = { id: pid++, kind, storey: o.storey ?? -1, mat: o.mat || kind, box, unit: o.unit ?? -1, rooms: o.rooms || [], ext: !!o.ext, ...o.extra }; parts.push(p); return p; };
  // flat x mapping: u = distance from the centre line (c .. L/2). Flat A is west (x < 0), flat B east.
  const xOf = (flat, u) => (flat === 'A' ? -u : u);
  const xr = (flat, u0, u1) => { const a = xOf(flat, u0), b = xOf(flat, u1); return [Math.min(a, b), Math.max(a, b)]; };

  // ------------------------------------------------------------------ rooms
  const roomAt = {}; // key `${s}|${flat}|${kind}` -> room
  const mkRoom = (s, flat, kind, name, x0, x1, z0, z1) => {
    const y0 = floorTop(s), y1 = ceilingOf(s);
    const room = { id: rooms.length, storey: s, flat, kind, name: `${FLOORS[s]}, ${flat === 'core' ? 'stair and landing' : `flat ${flat}, ${name}`}`, short: flat === 'core' ? 'Stair' : name.replace(/^./, (m) => m.toUpperCase()),
      x0: r2(x0), x1: r2(x1), z0: r2(z0), z1: r2(z1), y0, y1, poly: [[x0, z0], [x1, z0], [x1, z1], [x0, z1]], doors: [], windows: [], walls: [] };
    rooms.push(room); roomAt[`${s}|${flat}|${kind}`] = room; return room;
  };
  const NAME = { living: 'living room', bedroom: 'bedroom', kitchen: 'kitchen', bathroom: 'bathroom' };
  for (let s = 0; s < NS; s++) {
    for (const flat of ['A', 'B']) {
      const F = FL[flat];
      const [ox0, ox1] = xr(flat, F.uF + T_INT / 2, L / 2 - T_EXT), [ix0, ix1] = xr(flat, c + T_EXT / 2, F.uF - T_INT / 2);
      const [kx0, kx1] = xr(flat, F.uB + T_INT / 2, L / 2 - T_EXT), [jx0, jx1] = xr(flat, c + T_EXT / 2, F.uB - T_INT / 2);
      const [hx0, hx1] = xr(flat, c + T_EXT / 2, L / 2 - T_EXT);
      mkRoom(s, flat, F.fOuter, NAME[F.fOuter], ox0, ox1, zf + T_INT / 2, D / 2 - T_EXT);
      mkRoom(s, flat, F.fInner, NAME[F.fInner], ix0, ix1, zf + T_INT / 2, D / 2 - T_EXT);
      mkRoom(s, flat, F.bOuter, NAME[F.bOuter], kx0, kx1, -D / 2 + T_EXT, zb - T_INT / 2);
      mkRoom(s, flat, F.bInner, NAME[F.bInner], jx0, jx1, -D / 2 + T_EXT, zb - T_INT / 2);
      mkRoom(s, flat, 'hall', 'hall', hx0, hx1, zb + T_INT / 2, zf - T_INT / 2);
    }
    mkRoom(s, 'core', 'core', 'stair', -c + T_EXT / 2, c - T_EXT / 2, -D / 2 + T_EXT, D / 2 - T_EXT);
  }
  const R = (s, flat, kind) => roomAt[`${s}|${flat}|${kind}`];

  // ------------------------------------------------------------------ walls: units split into boxes around openings
  // axis 'x': plane x = off, runs along z from a0 to a1. axis 'z': plane z = off, runs along x.
  const wallUnit = (s, axis, off, a0, a1, t, ext, roomList, ops = []) => {
    const y0 = floorTop(s), y1 = ceilingOf(s), H = y1 - y0;
    const unit = { id: walls.length, storey: s, axis, off: r2(off), a0: r2(Math.min(a0, a1)), a1: r2(Math.max(a0, a1)), y0, y1, t, ext, rooms: roomList.map((q) => q.id), parts: [], openings: [] };
    walls.push(unit); for (const q of roomList) q.walls.push(unit.id);
    const box = (u0, u1, h0, h1) => {
      if (u1 - u0 < 0.02 || h1 - h0 < 0.02) return;
      const p = axis === 'x' ? add('wall', aabox(off - t / 2, y0 + h0, u0, off + t / 2, y0 + h1, u1), { storey: s, mat: ext ? 'wallExt' : 'wallInt', unit: unit.id, rooms: unit.rooms, ext })
        : add('wall', aabox(u0, y0 + h0, off - t / 2, u1, y0 + h1, off + t / 2), { storey: s, mat: ext ? 'wallExt' : 'wallInt', unit: unit.id, rooms: unit.rooms, ext });
      unit.parts.push(p.id);
    };
    const list = ops.map((o) => ({ ...o, o0: Math.max(unit.a0 + 0.12, o.o0), o1: Math.min(unit.a1 - 0.12, o.o1) })).filter((o) => o.o1 - o.o0 > 0.3).sort((p, q) => p.o0 - q.o0);
    let u = unit.a0;
    for (const o of list) {
      if (o.o0 < u + 0.05) continue;
      box(u, o.o0, 0, H);
      box(o.o0, o.o1, 0, o.h0); box(o.o0, o.o1, o.h1, H);
      const op = { id: openings.length, kind: o.kind, storey: s, unit: unit.id, axis, off: unit.off, o0: r2(o.o0), o1: r2(o.o1), y0: y0 + o.h0, y1: y0 + o.h1, rooms: unit.rooms.slice(), w: r2(o.o1 - o.o0) };
      openings.push(op); unit.openings.push(op.id);
      for (const q of roomList) (o.kind === 'window' ? q.windows : q.doors).push(op.id);
      u = o.o1;
    }
    box(u, unit.a1, 0, H);
    return unit;
  };
  const door = (centre, w = 0.9, kind = 'door', h = 2.1) => ({ kind, o0: centre - w / 2, o1: centre + w / 2, h0: 0, h1: h });
  const win = (centre, w, kind = 'window', h0 = 0.9, h1 = 2.1) => ({ kind, o0: centre - w / 2, o1: centre + w / 2, h0, h1 });
  const frontOps = (kind, x0, x1, hasBal, flat) => {
    const mid = (x0 + x1) / 2, w = x1 - x0, sd = flat === 'A' ? 1 : -1;
    if (kind === 'living' && hasBal) return [door(mid + sd * 0.85 * Math.min(1, w / 4.5), 1.0, 'balcony'), win(mid - sd * 0.95 * Math.min(1, w / 4.5), Math.min(winW.living, w * .3))];
    return [win(mid + winShift * .3, kind === 'living' ? Math.min(winW.living, w * .55) : Math.min(winW.bedroom, w * .55))];
  };
  const backOps = (kind, x0, x1) => { const mid = (x0 + x1) / 2; return kind === 'bathroom' ? [win(mid, 0.6, 'window', 1.5, 2.1)] : [win(mid - winShift * .3, Math.min(winW.kitchen, (x1 - x0) * .5))]; };

  for (let s = 0; s < NS; s++) {
    for (const flat of ['A', 'B']) {
      const F = FL[flat];
      const fo = R(s, flat, F.fOuter), fi = R(s, flat, F.fInner), bo = R(s, flat, F.bOuter), bi = R(s, flat, F.bInner), hall = R(s, flat, 'hall'), core = R(s, 'core', 'core');
      const hasBal = s > 0 && balcony[s - 1][flat === 'A' ? 0 : 1];
      // front external wall (z = +D/2): one unit per room; back (z = -D/2)
      { const [x0, x1] = xr(flat, F.uF, L / 2); wallUnit(s, 'z', D / 2 - T_EXT / 2, x0, x1, T_EXT, true, [fo], frontOps(F.fOuter, x0, x1, hasBal, flat)); }
      { const [x0, x1] = xr(flat, c, F.uF); wallUnit(s, 'z', D / 2 - T_EXT / 2, x0, x1, T_EXT, true, [fi], frontOps(F.fInner, x0, x1, hasBal, flat)); }
      { const [x0, x1] = xr(flat, F.uB, L / 2); wallUnit(s, 'z', -D / 2 + T_EXT / 2, x0, x1, T_EXT, true, [bo], backOps(F.bOuter, x0, x1)); }
      { const [x0, x1] = xr(flat, c, F.uB); wallUnit(s, 'z', -D / 2 + T_EXT / 2, x0, x1, T_EXT, true, [bi], backOps(F.bInner, x0, x1)); }
      // end wall (x = -+L/2): front-outer room, hall, back-outer room
      const xe = xOf(flat, L / 2 - T_EXT / 2);
      wallUnit(s, 'x', xe, zf, D / 2 - T_EXT, T_EXT, true, [fo], [win((zf + D / 2) / 2 + winShift * .5, winW.end)]);
      wallUnit(s, 'x', xe, zb, zf, T_EXT, true, [hall], [win((zb + zf) / 2, 0.6)]);
      wallUnit(s, 'x', xe, -D / 2 + T_EXT, zb, T_EXT, true, [bo], [F.bOuter === 'bathroom' ? win((zb - D / 2) / 2, 0.6, 'window', 1.5, 2.1) : win((zb - D / 2) / 2, winW.end * .8)]);
      // hall walls (z = zf: front rooms; z = zb: back rooms)
      { const [x0, x1] = xr(flat, F.uF, L / 2 - T_EXT); wallUnit(s, 'z', zf, x0, x1, T_INT, false, [fo, hall], [door(xOf(flat, F.uF + 0.75))]); }
      { const [x0, x1] = xr(flat, c + T_EXT / 2, F.uF); wallUnit(s, 'z', zf, x0, x1, T_INT, false, [fi, hall], [door(xOf(flat, F.uF - 0.75))]); }
      { const [x0, x1] = xr(flat, F.uB, L / 2 - T_EXT); wallUnit(s, 'z', zb, x0, x1, T_INT, false, [bo, hall], [door(xOf(flat, F.uB + 0.75), F.bOuter === 'bathroom' ? 0.8 : 0.9)]); }
      { const [x0, x1] = xr(flat, c + T_EXT / 2, F.uB); wallUnit(s, 'z', zb, x0, x1, T_INT, false, [bi, hall], [door(xOf(flat, F.uB - 0.75), F.bInner === 'bathroom' ? 0.8 : 0.9)]); }
      // partitions between the two rooms of each band
      wallUnit(s, 'x', xOf(flat, F.uF), zf + T_INT / 2, D / 2 - T_EXT, T_INT, false, [fo, fi]);
      wallUnit(s, 'x', xOf(flat, F.uB), -D / 2 + T_EXT, zb - T_INT / 2, T_INT, false, [bo, bi]);
      // core wall (x = -+c): inner rooms and the hall (the flat's entry door)
      const xc = xOf(flat, c);
      wallUnit(s, 'x', xc, zf, D / 2 - T_EXT, T_EXT, false, [fi, core]);
      wallUnit(s, 'x', xc, zb, zf, T_EXT, false, [hall, core], [door((zb + zf) / 2, 0.9, 'entry')]);
      wallUnit(s, 'x', xc, -D / 2 + T_EXT, zb, T_EXT, false, [bi, core]);
    }
    // core front and back walls
    const core = R(s, 'core', 'core');
    wallUnit(s, 'z', D / 2 - T_EXT / 2, -c, c, T_EXT, true, [core], s === 0 ? [door(0, 1.3, 'street', 2.3)] : [win(0, 1.2)]);
    wallUnit(s, 'z', -D / 2 + T_EXT / 2, -c, c, T_EXT, true, [core], s === 0 ? [door(0.45, 0.9, 'rear')] : [win(0, 1.0, 'window', 1.6, 2.6)]);
  }

  // ------------------------------------------------------------------ columns, beams
  const xLines = [-L / 2, -uM, -c, c, uM, L / 2], zLines = [-D / 2, zb, zf, D / 2];
  const colX = (x) => (x <= -L / 2 + 1e-6 ? -L / 2 + COL / 2 : x >= L / 2 - 1e-6 ? L / 2 - COL / 2 : x);
  const colZ = (z) => (z <= -D / 2 + 1e-6 ? -D / 2 + COL / 2 : z >= D / 2 - 1e-6 ? D / 2 - COL / 2 : z);
  for (let s = 0; s < NS; s++) {
    const y0 = floorTop(s), y1 = ceilingOf(s);
    for (const x of xLines) for (const z of zLines) {
      const cx = colX(x), cz = colZ(z);
      add('column', aabox(cx - COL / 2, y0, cz - COL / 2, cx + COL / 2, y1, cz + COL / 2), { storey: s, mat: 'column', ext: Math.abs(x) > L / 2 - 1e-6 || Math.abs(z) > D / 2 - 1e-6, extra: { line: [x, z] } });
    }
    // beams along every column line, just under the slab
    for (const x of xLines) { const cx = colX(x), bw = Math.abs(x) > L / 2 - 1e-6 ? T_EXT : 0.23; const xx = Math.abs(x) > L / 2 - 1e-6 ? Math.sign(x) * (L / 2 - T_EXT / 2) : cx;
      for (let k = 0; k < zLines.length - 1; k++) add('beam', aabox(xx - bw / 2, y1 - BEAM_D, colZ(zLines[k]) + COL / 2, xx + bw / 2, y1, colZ(zLines[k + 1]) - COL / 2), { storey: s, mat: 'beam', ext: Math.abs(x) > L / 2 - 1e-6 }); }
    for (const z of zLines) { const cz = colZ(z), ext = Math.abs(z) > D / 2 - 1e-6; const zz = ext ? Math.sign(z) * (D / 2 - T_EXT / 2) : cz, bw = ext ? T_EXT : 0.23;
      for (let k = 0; k < xLines.length - 1; k++) add('beam', aabox(colX(xLines[k]) + COL / 2, y1 - BEAM_D, zz - bw / 2, colX(xLines[k + 1]) - COL / 2, y1, zz + bw / 2), { storey: s, mat: 'beam', ext }); }
  }

  // ------------------------------------------------------------------ slabs (one panel per column bay and level)
  // level k (0 = ground slab on grade, NS = roof) occupies y in [k*SH, k*SH + ST]. The stair well (core, back band)
  // stays open on the upper levels. Panels carry their bay so a collapse can drop one bay.
  const panels = [];
  for (let k = 0; k <= NS; k++) {
    const y0 = k * SH, y1 = y0 + ST;
    for (let a = 0; a < xLines.length - 1; a++) for (let b = 0; b < zLines.length - 1; b++) {
      const x0 = xLines[a], x1 = xLines[a + 1]; let z0 = zLines[b], z1 = zLines[b + 1];
      const core = a === 2; // x in [-c, c]
      if (core && k > 0 && k < NS && b === 0) continue;             // stair well
      if (core && b === 1 && k > 0 && k < NS) { z0 = zb; }            // core landing panel starts at zb
      const p = add('slab', aabox(x0, y0, z0, x1, y1, z1), { storey: Math.min(k, NS), mat: 'slab', ext: k === NS, extra: { level: k, bay: [a, b] } });
      panels.push(p.id);
    }
  }
  // stairs: two flights and a mid-landing in the core's back band, per storey (the last one rises to the roof)
  for (let s = 0; s < NS; s++) {
    const yA = floorTop(s), yM = yA + 1.5, yB = floorTop(s + 1) - (s === NS - 1 ? 0 : 0);
    const zTop = -D / 2 + 1.3, zLow = zb;
    const lane = (x0, x1, za, ya, zz, yz) => {
      const len = Math.hypot(za - zz, ya - yz), ang = Math.atan2(yz - ya, zz - za); // rising along z
      const cx = (x0 + x1) / 2, cy = (ya + yz) / 2 - 0.12, cz = (za + zz) / 2;
      return add('stair', { c: [cx, cy, cz], h: [(x1 - x0) / 2, 0.12, len / 2], q: qAxis(1, 0, 0, -ang) }, { storey: s, mat: 'stair' });
    };
    lane(-c + T_EXT / 2, -0.05, zLow, yA, zTop, yM);
    add('stair', aabox(-c + T_EXT / 2, yM - 0.2, -D / 2 + T_EXT, c - T_EXT / 2, yM, zTop), { storey: s, mat: 'stair', extra: { landing: true } });
    lane(0.05, c - T_EXT / 2, zTop, yM, zLow, yB);
  }
  // balconies (front, storeys 1-3) with a solid parapet
  for (let s = 1; s < NS; s++) for (const flat of ['A', 'B']) {
    if (!balcony[s - 1][flat === 'A' ? 0 : 1]) continue;
    const liv = R(s, flat, 'living'); const x0 = liv.x0 + 0.25, x1 = liv.x1 - 0.25, y = s * SH, dz = 1.2;
    add('balcony', aabox(x0, y, D / 2, x1, y + ST, D / 2 + dz), { storey: s, mat: 'balcony', rooms: [liv.id], ext: true });
    add('parapet', aabox(x0, y + ST, D / 2 + dz - T_INT, x1, y + ST + 1.0, D / 2 + dz), { storey: s, mat: 'parapet', rooms: [liv.id], ext: true, extra: { balcony: true } });
    add('parapet', aabox(x0, y + ST, D / 2, x0 + T_INT, y + ST + 1.0, D / 2 + dz - T_INT), { storey: s, mat: 'parapet', rooms: [liv.id], ext: true, extra: { balcony: true } });
    add('parapet', aabox(x1 - T_INT, y + ST, D / 2, x1, y + ST + 1.0, D / 2 + dz - T_INT), { storey: s, mat: 'parapet', rooms: [liv.id], ext: true, extra: { balcony: true } });
  }
  // roof: parapet all round, the stair head room over the core, a water tank
  { const y = NS * SH + ST, hP = 0.9;
    add('parapet', aabox(-L / 2, y, D / 2 - T_INT, L / 2, y + hP, D / 2), { storey: NS, mat: 'parapet', ext: true });
    add('parapet', aabox(-L / 2, y, -D / 2, L / 2, y + hP, -D / 2 + T_INT), { storey: NS, mat: 'parapet', ext: true });
    add('parapet', aabox(-L / 2, y, -D / 2 + T_INT, -L / 2 + T_INT, y + hP, D / 2 - T_INT), { storey: NS, mat: 'parapet', ext: true });
    add('parapet', aabox(L / 2 - T_INT, y, -D / 2 + T_INT, L / 2, y + hP, D / 2 - T_INT), { storey: NS, mat: 'parapet', ext: true });
    // head room (mumty): walls and a lid around the top of the stair
    const hz0 = -D / 2, hz1 = zb + 0.9, hh = 2.2;
    add('wall', aabox(-c, y, hz0, -c + T_EXT, y + hh, hz1), { storey: NS, mat: 'wallExt', ext: true, extra: { roofroom: true } });
    add('wall', aabox(c - T_EXT, y, hz0, c, y + hh, hz1), { storey: NS, mat: 'wallExt', ext: true, extra: { roofroom: true } });
    add('wall', aabox(-c + T_EXT, y, hz0, c - T_EXT, y + hh, hz0 + T_EXT), { storey: NS, mat: 'wallExt', ext: true, extra: { roofroom: true } });
    add('wall', aabox(-c + T_EXT, y + 2.1, hz1 - T_EXT, c - T_EXT, y + hh, hz1), { storey: NS, mat: 'wallExt', ext: true, extra: { roofroom: true } });
    add('slab', aabox(-c - 0.2, y + hh, hz0 - 0.2, c + 0.2, y + hh + 0.12, hz1 + 0.2), { storey: NS, mat: 'slab', ext: true, extra: { level: NS + 1, roofroom: true } });
    const tx = (r() < 0.5 ? -1 : 1) * (c + 2.2 + r() * 2), tz = -D / 2 + 1.6;
    add('tank', aabox(tx - 0.6, y, tz - 0.6, tx + 0.6, y + 1.15, tz + 0.6), { storey: NS, mat: 'tank', ext: true });
  }
  // plinth / foundation (mostly below ground; shows if the block heaves)
  add('plinth', aabox(-L / 2 - 0.3, -1.2, -D / 2 - 0.3, L / 2 + 0.3, 0, D / 2 + 0.3), { storey: 0, mat: 'plinth' });

  // ------------------------------------------------------------------ site: boundary walls, neighbours, street
  const yb = 3.2, xb = L / 2 + 2.8, siteParts = [];
  const site = (box, mat = 'site', extra = {}) => { const p = add('site', box, { storey: -1, mat, extra }); siteParts.push(p.id); return p; };
  site(aabox(-xb, 0, -D / 2 - yb - 0.2, xb, 1.8, -D / 2 - yb));                       // back yard wall
  site(aabox(-xb - 0.2, 0, -D / 2 - yb, -xb, 1.8, D / 2 + yb));                         // side walls
  site(aabox(xb, 0, -D / 2 - yb, xb + 0.2, 1.8, D / 2 + yb));
  site(aabox(-xb, 0, D / 2 + yb, -1.6, 1.0, D / 2 + yb + 0.2));                         // front low wall with the gate
  site(aabox(1.6, 0, D / 2 + yb, xb, 1.0, D / 2 + yb + 0.2));
  site(aabox(-xb - 0.3, 0, D / 2 + yb - 0.1, -xb + 0.1, 1.6, D / 2 + yb + 0.3)); site(aabox(xb - 0.1, 0, D / 2 + yb - 0.1, xb + 0.3, 1.6, D / 2 + yb + 0.3));
  site(aabox(-1.9, 0, D / 2 + yb - 0.1, -1.6, 1.5, D / 2 + yb + 0.3)); site(aabox(1.6, 0, D / 2 + yb - 0.1, 1.9, 1.5, D / 2 + yb + 0.3));
  // kerb and pavement edge
  site(aabox(-40, 0, D / 2 + yb + 2.0, 40, 0.14, D / 2 + yb + 2.25), 'kerb');
  // neighbours: two blocks either side and a lower one behind
  const nH = [9 + r() * 3.5, 8 + r() * 4.5, 6.5 + r() * 2.5];
  site(aabox(-xb - 14, 0, -D / 2 - 1.2, -xb - 1.4, nH[0], D / 2 + 0.6), 'neighbour', { neighbour: 0 });
  site(aabox(xb + 1.4, 0, -D / 2 - 0.4, xb + 13, nH[1], D / 2 + 1.1), 'neighbour', { neighbour: 1 });
  site(aabox(-13, 0, -D / 2 - yb - 14, 11, nH[2], -D / 2 - yb - 2.4), 'neighbour', { neighbour: 2 });
  // small static things in the yard (a pump room, a generator box): good references for the registration
  site(aabox(-xb + 0.3, 0, -D / 2 - yb + 0.25, -xb + 2.1, 2.2, -D / 2 - yb + 1.6), 'site', { shed: true });
  site(aabox(xb - 1.5, 0, -D / 2 - 1.2, xb - 0.35, 1.1, -D / 2 - 0.2), 'site', { genbox: true });

  // ------------------------------------------------------------------ the voxel domain the pipeline works in
  const VOX = 0.12;
  const gx0 = -(L / 2 + 3.0), gx1 = L / 2 + 3.0, gz0 = -(D / 2 + 3.6), gz1 = D / 2 + 4.9, gy0 = -0.12, gy1 = 14.6;
  const grid = { x0: gx0, y0: gy0, z0: gz0, nx: Math.ceil((gx1 - gx0) / VOX), ny: Math.ceil((gy1 - gy0) / VOX), nz: Math.ceil((gz1 - gz0) / VOX), vox: VOX };

  // every part's world AABB (used by collapses, scanners and renderers)
  for (const p of parts) p.aabb = boxAABB(p.box);
  const levels = []; for (let s = 0; s <= NS; s++) levels.push(floorTop(s));
  return {
    seed, dims: { L, D, c, zb, zf, zh, uM, NS, SH, ST, flats: FL, xLines, zLines, flatW },
    parts, rooms, openings, walls, panels, levels, siteParts, grid,
    site: {
      street: { z0: D / 2 + yb + 2.25, z1: D / 2 + yb + 12 }, yard: { z0: -D / 2 - yb, z1: D / 2 + yb }, gate: { x: 0, z: D / 2 + yb },
      anchor: { x: 3.2, z: D / 2 + yb + 2.9 }, table: { x: -4.6, z: D / 2 + yb + 3.4 }, van: { x: -9.5, z: D / 2 + yb + 4.6 }, pad: { x: 5.6, z: D / 2 + yb + 3.0 },
      bounds: { x0: -xb - 16, x1: xb + 16, z0: -D / 2 - yb - 16, z1: D / 2 + yb + 14 },
    },
    footprint: { x0: -L / 2, x1: L / 2, z0: -D / 2, z1: D / 2 },
  };
}
