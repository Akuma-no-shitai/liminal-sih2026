// collapse(model, mode, seed): a plausible (not FEM) post-event state of the building, made of procedural rigid moves.
//   softstorey  ground-floor columns on one side fail; the upper floors drop and tilt toward that side
//   pancake     one corner bay's slabs come down through every floor, stacked with leaning gaps (lean-to voids)
//   lean        the block still stands, tilted 2-5 degrees about its base, with cracked infill and a few fallen panels
// Returns { parts, motions, cracks, jammed, sag, walls (truth per wall unit), fire, tank, info, debrisVolume }.
// Every post part keeps its baseline id in `src` (debris chunks carry the id of the part they came from).
import { rngFor, DEG, T_ID, tApply, tAxisPivot, tCompose, boxT, boxAABB, aabox, qAxis, qMul, qToMat, boxVol, mMul, tiltOf } from './geom.js';
import { floorTop, ceilingOf, SH, ST, NS, T_INT } from './building.js';

export const MODES = {
  softstorey: { id: 'softstorey', title: 'Soft storey', line: 'Ground-floor columns on one side fail; the upper floors drop and tilt toward that side.', why: 'Debris at the base, tilted upper floors, the ground floor mostly gone.' },
  pancake: { id: 'pancake', title: 'Corner pancake', line: 'One corner bay’s slabs come down through every floor.', why: 'A deep debris pile with lean-to voids between the slabs.' },
  lean: { id: 'lean', title: 'Leaning block', line: 'Still standing, tilted a few degrees, with cracked infill and a few fallen panels.', why: 'The hardest call: it looks fine from the street, and it is not.' },
};
export const MODE_ORDER = ['softstorey', 'pancake', 'lean'];

// ------------------------------------------------------------------ surfaces of oriented boxes
// height of a box's top (or bottom) face above (x, z), or NaN if the vertical line misses that face
function faceHeightAt(box, x, z, top) {
  const m = qToMat(box.q), hy = top ? box.h[1] : -box.h[1];
  // x = c0 + m0 lx + m1 hy + m2 lz ; z = c2 + m6 lx + m7 hy + m8 lz
  const bx = x - box.c[0] - m[1] * hy, bz = z - box.c[2] - m[7] * hy, det = m[0] * m[8] - m[2] * m[6];
  if (Math.abs(det) < 1e-9) return NaN;
  const lx = (bx * m[8] - m[2] * bz) / det, lz = (m[0] * bz - bx * m[6]) / det;
  if (Math.abs(lx) > box.h[0] + 1e-6 || Math.abs(lz) > box.h[2] + 1e-6) return NaN;
  return box.c[1] + m[3] * lx + m[4] * hy + m[5] * lz;
}
export const topAt = (b, x, z) => faceHeightAt(b, x, z, true);
export const bottomAt = (b, x, z) => faceHeightAt(b, x, z, false);

// ------------------------------------------------------------------ a 2.5-D heightmap for stacking debris
// floor: what a chunk would rest on; ceil: what it must stay under. Chunks drop, roll downhill while the slope is
// steeper than the angle of repose, then settle on the highest point under their footprint.
function makeHM(x0, z0, x1, z1, cell = 0.1, base = 0) {
  const nx = Math.max(1, Math.ceil((x1 - x0) / cell)), nz = Math.max(1, Math.ceil((z1 - z0) / cell));
  const fl = new Float32Array(nx * nz).fill(base), ce = new Float32Array(nx * nz).fill(1e9);
  const hm = { x0, z0, nx, nz, cell, fl, ce };
  const cellsOf = (bb, fn) => {
    const i0 = Math.max(0, Math.floor((bb[0] - x0) / cell)), i1 = Math.min(nx - 1, Math.floor((bb[3] - x0) / cell));
    const k0 = Math.max(0, Math.floor((bb[2] - z0) / cell)), k1 = Math.min(nz - 1, Math.floor((bb[5] - z0) / cell));
    for (let k = k0; k <= k1; k++) for (let i = i0; i <= i1; i++) fn(i, k, x0 + (i + .5) * cell, z0 + (k + .5) * cell);
  };
  hm.support = (box) => { const bb = boxAABB(box); cellsOf(bb, (i, k, x, z) => { const y = topAt(box, x, z); if (y === y && y > fl[k * nx + i]) fl[k * nx + i] = y; }); };
  // standing structure: nothing may be placed overlapping it (its cells become forbidden)
  hm.block = (box) => { const bb = boxAABB(box); cellsOf(bb, (i, k) => { fl[k * nx + i] = 1e7; }); };
  // a conservative ceiling: the lowest point of the box over its whole footprint (walls, columns, tilted things)
  hm.ceilingBox = (box) => { const bb = boxAABB(box); cellsOf(bb, (i, k) => { if (bb[1] < ce[k * nx + i]) ce[k * nx + i] = bb[1]; }); };
  hm.ceiling = (box) => { const bb = boxAABB(box); cellsOf(bb, (i, k, x, z) => { const y = bottomAt(box, x, z); if (y === y && y < ce[k * nx + i]) ce[k * nx + i] = y; }); };
  hm.at = (x, z) => { const i = Math.floor((x - x0) / cell), k = Math.floor((z - z0) / cell); return i < 0 || k < 0 || i >= nx || k >= nz ? NaN : fl[k * nx + i]; };
  // place a chunk of half sizes h with orientation q, dropped at (x, z). It rolls toward lower ground while the step
  // to a neighbouring spot (judged on the highest point under its whole footprint) is steeper than the angle of
  // repose, then settles there. Returns the box or null (it does not fit under the ceiling, or lands too high).
  const footMax = (bb, px, pz) => {
    const dx = px - (bb[0] + bb[3]) / 2, dz = pz - (bb[2] + bb[5]) / 2;
    let base = -1e9, ceil = 1e9, n = 0;
    cellsOf([bb[0] + dx, 0, bb[2] + dz, bb[3] + dx, 0, bb[5] + dz], (i, k) => { const f = fl[k * nx + i], c = ce[k * nx + i]; if (f > base) base = f; if (c < ceil) ceil = c; n++; });
    return n ? [base, ceil] : [NaN, NaN];
  };
  hm.place = (h, q, x, z, r, repose = 37 * DEG, maxRoll = 30, maxTop = 1e9) => {
    const tanR = Math.tan(repose); let px = x, pz = z;
    const box = { c: [px, 0, pz], h, q }; const bb = boxAABB(box); const hh = (bb[4] - bb[1]) / 2;
    let [here] = footMax(bb, px, pz); if (here !== here || here > 1e6) return null;
    for (let it = 0; it < maxRoll; it++) {
      let best = 0, bx = 0, bz = 0, bh = 0;
      for (let a = 0; a < 8; a++) { const ang = a * Math.PI / 4 + r() * .4, d = 0.25; const qx = px + Math.cos(ang) * d, qz = pz + Math.sin(ang) * d; const [v] = footMax(bb, qx, qz); if (v !== v || v > 1e6) continue; const drop = here - v - tanR * d; if (drop > best) { best = drop; bx = qx; bz = qz; bh = v; } }
      if (best <= 0) break; px = bx; pz = bz; here = bh;
    }
    const [base, ceil] = footMax(bb, px, pz);
    if (!(base > -1e8) || base > 1e6) return null;
    const top = base + 2 * hh;
    if (top > ceil - 0.01 || top > maxTop) return null;
    box.c = [px, base + hh, pz];
    const bb2 = boxAABB(box);
    cellsOf(bb2, (i, k) => { if (top > fl[k * nx + i]) fl[k * nx + i] = Math.min(top, ce[k * nx + i]); });
    return box;
  };
  return hm;
}
// a random rubble chunk: half sizes and an orientation (yaw any, pitch/roll a little)
function chunkShape(r, scale = 1) {
  const a = (0.13 + r() * 0.3) * scale, b = a * (0.5 + r() * 0.5), c = a * (0.32 + r() * 0.45);
  const q = qMul(qAxis(0, 1, 0, r() * Math.PI * 2), qMul(qAxis(1, 0, 0, (r() - .5) * 0.5), qAxis(0, 0, 1, (r() - .5) * 0.5)));
  return { h: [a, c, b], q };
}

// ------------------------------------------------------------------ damaged walls: a panel broken into slightly rotated tiles
function tileBox(box, dmg, r, tile = 0.45) {
  // tiles over the two large dimensions of the box; the thin one is the wall thickness
  const h = box.h, thin = h[0] < h[2] ? 0 : 2, along = thin === 0 ? 2 : 0;
  const na = Math.max(1, Math.round(2 * h[along] / tile)), nv = Math.max(1, Math.round(2 * h[1] / tile));
  const m = qToMat(box.q), out = [];
  const ax = [[m[0], m[3], m[6]], [m[1], m[4], m[7]], [m[2], m[5], m[8]]];
  for (let a = 0; a < na; a++) for (let v = 0; v < nv; v++) {
    const la = -h[along] + (a + .5) * 2 * h[along] / na, lv = -h[1] + (v + .5) * 2 * h[1] / nv;
    const hh = [0, 0, 0]; hh[along] = h[along] / na - 0.006; hh[1] = h[1] / nv - 0.006; hh[thin] = h[thin];
    const k = dmg * (0.5 + r() * 0.7);
    const off = (r() - .5) * 0.08 * k;
    const lc = [0, 0, 0]; lc[along] = la; lc[1] = lv; lc[thin] = off;
    const c = [0, 1, 2].map((i) => box.c[i] + ax[0][i] * lc[0] + ax[1][i] * lc[1] + ax[2][i] * lc[2]);
    const spin = qMul(qAxis(...ax[along], (r() - .5) * 2 * 40 * DEG * k), qAxis(...ax[1], (r() - .5) * 2 * 30 * DEG * k));
    out.push({ c, h: hh, q: qMul(spin, box.q) });
  }
  return out;
}

// ------------------------------------------------------------------ cracks on a wall unit (in baseline coordinates)
function crackLines(unit, model, r) {
  const ops = unit.openings.map((id) => model.openings[id]);
  const len = unit.a1 - unit.a0, H = unit.y1 - unit.y0, lines = [];
  const P = (a, y) => (unit.axis === 'x' ? [unit.off, y, a] : [a, y, unit.off]);
  const zig = (a0, y0, a1, y1) => { const n = Math.max(3, Math.round(Math.hypot(a1 - a0, y1 - y0) / 0.22)); const pts = []; for (let i = 0; i <= n; i++) { const t = i / n, j = i && i < n ? (r() - .5) * 0.09 : 0; pts.push(P(a0 + (a1 - a0) * t + j, y0 + (y1 - y0) * t + j * .5)); } return pts; };
  if (ops.length) {
    for (const o of ops) { if (r() < 0.35) continue; const top = o.y1 < unit.y1 - 0.2, sgn = r() < .5 ? -1 : 1, a = sgn < 0 ? o.o0 : o.o1, run = Math.min(1.4, (sgn < 0 ? a - unit.a0 : unit.a1 - a) * .9);
      if (run < 0.4) continue;
      if (top) lines.push(zig(a, o.y1, a + sgn * run, Math.min(unit.y1 - 0.05, o.y1 + run * 0.8)));
      if (o.y0 > unit.y0 + 0.3 && r() < 0.6) lines.push(zig(a, o.y0, a + sgn * run * .8, Math.max(unit.y0 + 0.05, o.y0 - run * 0.7))); }
  }
  if (!lines.length || r() < 0.4) {
    if (len < 0.8) return lines;
    const a0 = unit.a0 + len * (0.1 + r() * 0.15), a1 = unit.a1 - len * (0.1 + r() * 0.15);
    if (r() < 0.5) lines.push(zig(a0, unit.y0 + 0.15, a1, unit.y1 - 0.15)); else lines.push(zig(a1, unit.y0 + 0.15, a0, unit.y1 - 0.15));
    if (r() < 0.35) lines.push(zig(a0, unit.y1 - 0.2, a1, unit.y0 + 0.2));
  }
  return lines;
}
const polyLen = (pts) => { let s = 0; for (let i = 1; i < pts.length; i++) s += Math.hypot(pts[i][0] - pts[i - 1][0], pts[i][1] - pts[i - 1][1], pts[i][2] - pts[i - 1][2]); return s; };

// ------------------------------------------------------------------ the collapse
export function collapse(model, mode, seed) {
  const r = rngFor(seed, 'collapse', mode);
  const { L, D } = model.dims;
  const base = model.parts;
  const motions = []; for (let s = 0; s <= NS; s++) motions.push(T_ID());
  const st = base.map((p) => ({ state: 'intact', T: null, dmg: 0, cut: null }));   // per baseline part
  const walls = model.walls.map((u) => ({ id: u.id, tilt: 0, damage: 0, gone: 0, cracked: false, crackLen: 0, partsGone: 0 }));
  const cracks = [], jammed = [], sag = new Map(), extra = [], info = { mode };
  let debrisVol = 0;
  const destroy = (p) => { if (st[p.id].state === 'gone') return 0; st[p.id].state = 'gone'; const v = boxVol(p.box); if (p.unit >= 0) walls[p.unit].partsGone += v; return v; };
  const isBuilding = (p) => p.kind !== 'site';

  if (mode === 'softstorey') {
    const side = r.weighted(['+z', '-z', '+x', '-x'], [.45, .2, .175, .175]), ax = side[1], sg = side[0] === '+' ? 1 : -1;
    const span = ax === 'z' ? D : L, drop = 2.0 + r() * 0.6, th = Math.asin(drop / span), slide = 0.15 + r() * 0.35;
    const hinge = ax === 'z' ? [0, SH, -sg * D / 2] : [-sg * L / 2, SH, 0];
    const axis = ax === 'z' ? [1, 0, 0] : [0, 0, 1], ang = ax === 'z' ? sg * th : -sg * th;
    const T1 = tAxisPivot(axis, ang, hinge, ax === 'z' ? [0, 0, sg * slide] : [sg * slide, 0, 0]);
    const roll = (r() - .5) * 1.4 * DEG; const T2 = tAxisPivot(ax === 'z' ? [0, 0, 1] : [1, 0, 0], roll, hinge);
    const Tup = tCompose(T1, T2);
    for (let s = 1; s <= NS; s++) motions[s] = Tup;
    Object.assign(info, { side, drop, angle: th / DEG, slide, roll: roll / DEG, span });
    // the underside of the dropped block: slab 1's bottom plane, moved
    const n = tApply({ R: Tup.R, t: [0, 0, 0] }, 0, 1, 0), p0 = tApply(Tup, 0, SH, 0), dd = n[0] * p0[0] + n[1] * p0[1] + n[2] * p0[2];
    const under = (x, z) => (dd - n[0] * x - n[2] * z) / n[1];
    const along = (x, z) => (ax === 'z' ? (z - hinge[2]) * sg : (x - hinge[0]) * sg);   // distance from the hinge toward the failed side
    const failFrac = 0.52 + r() * 0.16;
    for (const p of base) {
      if (!isBuilding(p)) continue;
      if (p.storey >= 1 || (p.storey === 0 && p.kind === 'beam')) { st[p.id].state = 'moved'; st[p.id].T = Tup; continue; }
      if (p.kind === 'slab' || p.kind === 'plinth') continue;                      // ground slab stays
      const bb = p.aabb; let hmin = 1e9, far = -1e9;
      for (const [x, z] of [[bb[0], bb[2]], [bb[3], bb[2]], [bb[0], bb[5]], [bb[3], bb[5]]]) { hmin = Math.min(hmin, under(x, z)); far = Math.max(far, along(x, z)); }
      const failed = far > span * failFrac && (p.kind === 'column' || p.kind === 'wall' || p.kind === 'stair');
      if (failed || hmin - bb[1] < 0.9) { debrisVol += destroy(p); continue; }
      if (bb[4] > hmin - 0.01) {
        // squashed: cut down to what is left under the block, and racked a little toward the failed side
        const newTop = hmin - 0.03, h = (newTop - bb[1]) / 2; const lost = boxVol(p.box) * (1 - (newTop - bb[1]) / (bb[4] - bb[1]));
        debrisVol += lost; st[p.id].cut = { y0: bb[1], y1: newTop }; st[p.id].state = 'squashed';
        const box = aabox(bb[0], bb[1], bb[2], bb[3], newTop, bb[5]);
        const rack = (1.5 + r() * 3) * DEG; const T = tAxisPivot(axis, ax === 'z' ? sg * rack : -sg * rack, [box.c[0], bb[1], box.c[2]]);
        st[p.id].box = boxT(T, box); st[p.id].rack = rack / DEG;
        if (p.unit >= 0) { walls[p.unit].damage = Math.max(walls[p.unit].damage, 0.5); }
      }
    }
    // the first floor above the soft storey takes the hammering: damaged infill, cracks; balconies on the failed side break
    for (const u of model.walls) {
      if (u.storey === 1 || (u.storey === 2 && r() < 0.35)) {
        const nearFail = (ax === 'z' ? (u.axis === 'z' ? sg * u.off > 0 : true) : (u.axis === 'x' ? sg * u.off > 0 : true));
        if (r() < (nearFail ? 0.75 : 0.35)) { walls[u.id].cracked = true; walls[u.id].dmgWant = (u.storey === 1 ? 0.25 : 0.12) + r() * 0.25; }
      }
    }
    for (const p of base) if (p.kind === 'parapet' && p.balcony && p.storey === 1 && r() < 0.6) { const mv = tApply(Tup, ...p.box.c); if ((ax === 'z' ? mv[2] * sg : mv[0] * sg) > 0) debrisVol += destroy(p); }
    // debris: inside the squashed ground floor (under the block) and spilled beyond the failed edge
    const hmIn = makeHM(-L / 2 - 4, -D / 2 - 4, L / 2 + 4, D / 2 + 5, 0.1, 0);
    for (const p of base) {
      if (st[p.id].state === 'gone' || !isBuilding(p)) continue;
      const b = st[p.id].box || (st[p.id].T ? boxT(st[p.id].T, p.box) : p.box);
      if (p.storey === 0 || p.kind === 'plinth') { if (p.kind === 'slab' || p.kind === 'plinth') hmIn.support(b); else hmIn.block(b); }
      else if (p.kind === 'slab' || p.kind === 'balcony') hmIn.ceiling(b);
      else hmIn.ceilingBox(b);
    }
    for (const id of model.siteParts) hmIn.block(base[id].box);
    const target = debrisVol * (0.92 + r() * 0.1); let placed = 0, tries = 0;
    while (placed < target && tries < 6000) {
      tries++;
      const sh = chunkShape(r, 1 + r() * 0.4);
      // drop near the failed edge: inside (under the block) or just outside it
      const t = r(), outside = t < 0.4;
      const u = outside ? span + r() * 2.6 * r() : span * (failFrac - 0.2 + r() * (1.0 - failFrac + 0.2));
      const w = (r() - .5) * (ax === 'z' ? L - 0.6 : D - 0.6);
      const x = ax === 'z' ? w : hinge[0] + sg * u, z = ax === 'z' ? hinge[2] + sg * u : w;
      const box = hmIn.place(sh.h, sh.q, x, z, r, 37 * DEG, 30, outside ? 2.6 : 1e9); if (!box) continue;
      extra.push({ kind: 'debris', box, from: 'ground floor', srcStorey: 0 }); placed += boxVol(box);
    }
    info.debrisPlaced = placed; info.debrisWanted = target;
  }

  if (mode === 'pancake') {
    // the corner away from the roof tank
    const tank = base.find((p) => p.kind === 'tank');
    const sx = tank ? -Math.sign(tank.box.c[0]) || 1 : (r() < .5 ? -1 : 1), sz = r() < 0.6 ? 1 : -1;
    const xl = model.dims.xLines, zl = model.dims.zLines;
    const bx0 = sx < 0 ? xl[0] : xl[4], bx1 = sx < 0 ? xl[1] : xl[5], bz0 = sz < 0 ? zl[0] : zl[2], bz1 = sz < 0 ? zl[1] : zl[3];
    const innerX = sx < 0 ? bx1 : bx0, innerZ = sz < 0 ? bz1 : bz0;           // the bay's two inner edges
    const inBay = (x, z, m = 0) => x > bx0 + m && x < bx1 - m && z > bz0 + m && z < bz1 - m;
    // hinge edge: the longer inner edge; panels lean down toward the opposite (outer) edge
    const hingeIsX = (bz1 - bz0) > (bx1 - bx0) ? true : r() < 0.4;               // hinge along the inner x line (runs in z)
    const span = hingeIsX ? bx1 - bx0 : bz1 - bz0;
    Object.assign(info, { corner: [sx, sz], bay: [bx0, bx1, bz0, bz1], hingeIsX, span });
    const nearInner = (p) => { const bb = p.aabb; const onX = Math.abs((bb[0] + bb[3]) / 2 - innerX) < 0.2, onZ = Math.abs((bb[2] + bb[5]) / 2 - innerZ) < 0.2; return { onX, onZ }; };
    const panels = [];
    for (const p of base) {
      if (!isBuilding(p) || p.kind === 'plinth') continue;
      const bb = p.aabb, cx = (bb[0] + bb[3]) / 2, cz = (bb[2] + bb[5]) / 2;
      if (p.kind === 'slab') { if (p.level >= 1 && p.level <= NS && inBay(cx, cz)) panels.push(p); continue; }
      if (p.kind === 'tank' || (p.roofroom && !inBay(cx, cz))) continue;
      const ni = nearInner(p);
      // columns: the corner column fails on every floor; the others (shared with the neighbouring bays) stay
      if (p.kind === 'column') { const [lx, lz] = p.line; if (lx === (sx < 0 ? xl[0] : xl[5]) && lz === (sz < 0 ? zl[0] : zl[3])) debrisVol += destroy(p); continue; }
      const inside = inBay(cx, cz, 0.05);
      const onOuter = (Math.abs(cx - (sx < 0 ? -L / 2 : L / 2)) < 0.3 && cz > bz0 - 0.1 && cz < bz1 + 0.1) || (Math.abs(cz - (sz < 0 ? -D / 2 : D / 2)) < 0.3 && cx > bx0 - 0.1 && cx < bx1 + 0.1);
      const onOuterBal = p.kind === 'balcony' || (p.kind === 'parapet' && p.balcony) ? (cx > bx0 - 0.3 && cx < bx1 + 0.3 && sz > 0) : false;
      if ((inside || onOuter || onOuterBal) && !ni.onX && !ni.onZ) { debrisVol += destroy(p); continue; }
      if ((ni.onX && cz > bz0 && cz < bz1) || (ni.onZ && cx > bx0 && cx < bx1)) {
        if (p.kind === 'wall' && p.unit >= 0) { walls[p.unit].cracked = true; walls[p.unit].dmgWant = Math.max(walls[p.unit].dmgWant || 0, 0.25 + r() * 0.3); }
      }
    }
    // the stack: panels from the bottom (level 1) up, each leaning down from the hinge edge to the outer edge
    panels.sort((a, b) => a.level - b.level);
    const g0 = 0.22 + r() * 0.3; let yIn = ST + g0 + 0.45 + r() * 0.5, yOut = ST + g0;
    const stack = [];
    const sealK = r.int(1, Math.max(1, panels.length - 2));
    for (let k = 0; k < panels.length; k++) {
      const p = panels[k]; st[p.id].state = 'fallen';
      if (k > 0) { yIn += ST + 0.25 + r() * 0.65; yOut += ST + 0.05 + r() * 0.13; }
      const tilt = Math.atan2(yIn - yOut, span), cx = (bx0 + bx1) / 2, cz = (bz0 + bz1) / 2;
      // tilt about the hinge axis so the outer edge is lower; small yaw; slide outward a little
      const out = 0.06 + r() * 0.3;
      let q; if (hingeIsX) q = qAxis(0, 0, 1, sx < 0 ? -tilt : tilt); else q = qAxis(1, 0, 0, sz < 0 ? tilt : -tilt);
      q = qMul(qAxis(0, 1, 0, (r() - .5) * 5 * DEG), q);
      const midY = (yIn + yOut) / 2 + ST / 2;
      const h = [p.box.h[0] - 0.04, p.box.h[1], p.box.h[2] - 0.04];
      if (hingeIsX) h[0] = h[0] / Math.cos(tilt) * 0.995; else h[2] = h[2] / Math.cos(tilt) * 0.995;
      const box = { c: [cx + (hingeIsX ? sx * out : 0), midY, cz + (hingeIsX ? 0 : sz * out)], h, q };
      st[p.id].box = box; st[p.id].fall = { yIn, yOut, tilt: tilt / DEG };
      stack.push({ part: p.id, box, yIn, yOut });
    }
    info.stack = stack.map((s) => ({ yIn: +s.yIn.toFixed(2), yOut: +s.yOut.toFixed(2) }));
    // rubble: a little between the panels near their low ends, most of it spilled round the corner outside
    const hm = makeHM(-L / 2 - 4, -D / 2 - 4, L / 2 + 4, D / 2 + 5, 0.1, 0);
    for (const p of base) {
      if (!isBuilding(p) || st[p.id].state === 'gone') continue;
      const b = st[p.id].box || p.box;
      if (st[p.id].state === 'fallen') continue;
      if (p.kind === 'slab' && p.level === 0) { hm.support(b); continue; }
      if (p.storey === 0 || p.kind === 'plinth' || p.kind === 'column') hm.block(b);
    }
    for (const id of model.siteParts) hm.block(base[id].box);
    // ground-floor rubble under the first panel
    const hmLow = makeHM(bx0, bz0, bx1, bz1, 0.1, ST);
    hmLow.ceiling(stack[0].box);
    let placed = 0; const target = debrisVol * (0.92 + r() * 0.1);
    for (let t = 0; t < 900 && placed < target * 0.22; t++) { const sh = chunkShape(r, 0.8); const box = hmLow.place(sh.h, sh.q, bx0 + r() * (bx1 - bx0), bz0 + r() * (bz1 - bz0), r); if (box) { extra.push({ kind: 'debris', box, from: 'ground floor', srcStorey: 0 }); placed += boxVol(box); } }
    // between panels: near the low (outer) edge
    for (let k = 0; k < stack.length - 1; k++) {
      const hmK = makeHM(bx0 - 0.5, bz0 - 0.5, bx1 + 0.5, bz1 + 0.5, 0.1, -1e9);
      hmK.support(stack[k].box); hmK.ceiling(stack[k + 1].box);
      for (let t = 0; t < 120; t++) { const u = span * (0.62 + r() * 0.36); const w = r();
        const x = hingeIsX ? innerX + sx * u : bx0 + w * (bx1 - bx0), z = hingeIsX ? bz0 + w * (bz1 - bz0) : innerZ + sz * u;
        const sh = chunkShape(r, 0.55); const box = hmK.place(sh.h, sh.q, x, z, r, 37 * DEG, 0); if (box) { extra.push({ kind: 'debris', box, from: 'between the slabs', srcStorey: k + 1 }); placed += boxVol(box); } }
    }
    // seal one wedge's open side with a row of chunks that leaves only narrow slots (LiDAR sees in, no drone fits)
    const sealed = [];
    for (const k of [sealK, ...(r() < 0.5 && stack.length > 2 ? [Math.min(stack.length - 2, sealK + 1)] : [])]) {
      if (k >= stack.length - 1 || sealed.includes(k)) continue; sealed.push(k);
      const lo = stack[k].box, hi = stack[k + 1].box;
      // the open lateral edge: the bay's outer side parallel to the slope
      for (let u = 0.05; u < span - 0.3;) {
        const x = hingeIsX ? innerX + sx * u : (sx < 0 ? bx0 + 0.18 : bx1 - 0.18), z = hingeIsX ? (sz < 0 ? bz0 + 0.18 : bz1 - 0.18) : innerZ + sz * u;
        const y0 = topAt(lo, x, z), y1 = bottomAt(hi, x, z); if (!(y0 === y0 && y1 === y1)) { u += 0.3; continue; }
        const gap = y1 - y0; if (gap < 0.22) break;
        const w = 0.22 + r() * 0.2, hh = (gap - 0.025) / 2;
        const c = [x, y0 + hh + 0.005, z]; const h = hingeIsX ? [w / 2, hh, 0.16] : [0.16, hh, w / 2];
        extra.push({ kind: 'debris', box: { c, h, q: qAxis(0, 1, 0, (r() - .5) * 0.15) }, from: 'wedged rubble', srcStorey: k + 1, seal: k });
        placed += 8 * h[0] * h[1] * h[2]; u += w + 0.1 + r() * 0.12;
      }
    }
    info.sealed = sealed;
    // the rest spills round the corner, outside the footprint, against the stack
    for (const s of stack) hm.support(s.box);
    for (const e of extra) hm.support(e.box);
    let tries = 0;
    while (placed < target && tries < 8000) {
      tries++; const sh = chunkShape(r, 1 + r() * 0.5);
      const ang = Math.atan2(sz, sx) + (r() - .5) * 2.0, rad = Math.max(0, r() * r() * 3.2);
      const cxo = sx < 0 ? bx0 : bx1, czo = sz < 0 ? bz0 : bz1;
      const x = cxo - sx * r() * (bx1 - bx0) * 0.8 + Math.cos(ang) * rad, z = czo - sz * r() * (bz1 - bz0) * 0.8 + Math.sin(ang) * rad;
      if (inBay(x, z, 0.3) && r() < 0.6) continue;
      const box = hm.place(sh.h, sh.q, x, z, r, 37 * DEG, 30, 3.2); if (!box) continue;
      extra.push({ kind: 'debris', box, from: 'the corner bay', srcStorey: 1 }); placed += boxVol(box);
    }
    info.debrisPlaced = placed; info.debrisWanted = target;
    // the bays next to the stack sag a little; walls round the bay crack
    for (const p of base) {
      if (p.kind !== 'slab' || st[p.id].state !== 'intact' || p.level < 1 || p.level > NS) continue;
      const bb = p.aabb, adjX = (Math.abs(bb[0] - innerX) < 0.05 || Math.abs(bb[3] - innerX) < 0.05) && bb[2] < bz1 && bb[5] > bz0;
      const adjZ = (Math.abs(bb[2] - innerZ) < 0.05 || Math.abs(bb[5] - innerZ) < 0.05) && bb[0] < bx1 && bb[3] > bx0;
      if (adjX || adjZ) sag.set(p.id, 0.02 + r() * 0.05);
    }
    for (const u of model.walls) {
      if (walls[u.id].cracked) continue;
      const mx = u.axis === 'x' ? u.off : (u.a0 + u.a1) / 2, mz = u.axis === 'z' ? u.off : (u.a0 + u.a1) / 2;
      const d = Math.hypot(Math.max(0, Math.abs(mx - (bx0 + bx1) / 2) - (bx1 - bx0) / 2), Math.max(0, Math.abs(mz - (bz0 + bz1) / 2) - (bz1 - bz0) / 2));
      if (d < 2.5 && r() < 0.55) { walls[u.id].cracked = true; walls[u.id].dmgWant = r() < 0.35 ? 0.15 + r() * 0.2 : 0; }
    }
  }

  if (mode === 'lean') {
    const dir = r.weighted(['+z', '-z', '+x', '-x'], [.4, .3, .15, .15]), ax = dir[1], sg = dir[0] === '+' ? 1 : -1;
    const th = (2 + r() * 3) * DEG, span = ax === 'z' ? D : L;
    const pivot = ax === 'z' ? [0, 0, sg * (D / 2 - 0.3 * span)] : [sg * (L / 2 - 0.3 * span), 0, 0];
    const axis = ax === 'z' ? [1, 0, 0] : [0, 0, 1], ang = ax === 'z' ? sg * th : -sg * th;
    const T = tAxisPivot(axis, ang, pivot);
    for (let s = 0; s <= NS; s++) motions[s] = T;
    Object.assign(info, { dir, angle: th / DEG, pivot, span });
    for (const p of base) if (isBuilding(p)) { st[p.id].state = 'moved'; st[p.id].T = T; }
    // cracked infill, more on the lower floors
    for (const u of model.walls) {
      const pc = [0.5, 0.32, 0.18, 0.08][u.storey] ?? 0;
      if (r() < pc) { walls[u.id].cracked = true; walls[u.id].dmgWant = r() < 0.35 ? 0.12 + r() * 0.22 : 0; }
    }
    // a few infill panels fall out: outward for external walls (onto the ground), into the room for internal ones
    const cands = model.walls.filter((u) => u.storey <= 2 && u.parts.length && (u.a1 - u.a0) > 1.2);
    const nFall = r.int(2, 4); r.shuffle(cands);
    const fallen = [];
    for (const u of cands.slice(0, nFall)) {
      const piers = u.parts.map((id) => base[id]).filter((p) => p.box.h[1] > 1.0).sort((a, b) => boxVol(b.box) - boxVol(a.box));
      const p = piers[0]; if (!p) continue;
      debrisVol += destroy(p); walls[u.id].cracked = true; walls[u.id].dmgWant = Math.max(walls[u.id].dmgWant || 0, 0.3);
      fallen.push({ unit: u.id, part: p.id, ext: u.ext });
      const pb = boxT(T, p.box), vol = boxVol(p.box);
      if (u.ext) {
        // outward: onto the ground in front of the facade; sometimes the panel leans against it whole (a lean-to)
        const nrm = u.axis === 'x' ? [Math.sign(u.off), 0, 0] : [0, 0, Math.sign(u.off)];
        const foot = [pb.c[0] + nrm[0] * 0.5, 0, pb.c[2] + nrm[2] * 0.5];
        if (u.storey === 0 && r() < 0.6) {
          // leaning panel: bottom edge on the ground ~1.1 m out, top resting on the wall
          const hgt = p.box.h[1] * 2, out = 0.9 + r() * 0.5, lean = Math.acos(Math.min(1, out / hgt));
          const wl = u.axis === 'x' ? p.box.h[2] : p.box.h[0];
          const rot = u.axis === 'x' ? qAxis(0, 0, 1, Math.sign(u.off) * (Math.PI / 2 - lean)) : qAxis(1, 0, 0, -Math.sign(u.off) * (Math.PI / 2 - lean));
          const yc = Math.sin(lean) * hgt / 2 + 0.06;
          const c = u.axis === 'x' ? [Math.sign(u.off) * (Math.abs(pb.c[0]) + out / 2 + 0.24), yc, pb.c[2]] : [pb.c[0], yc, Math.sign(u.off) * (Math.abs(pb.c[2]) + out / 2 + 0.24)];
          extra.push({ kind: 'debris', box: { c, h: u.axis === 'x' ? [0.11, hgt / 2, wl] : [wl, hgt / 2, 0.11], q: qMul(rot, qAxis(0, 1, 0, 0)) }, from: 'fallen panel', srcStorey: u.storey, panel: true, leaning: true });
          // keep the rest of the volume as small chunks at its feet
          const hmF = makeHM(foot[0] - 3, foot[2] - 3, foot[0] + 3, foot[2] + 3, 0.1, 0); let pv = 0;
          for (let t = 0; t < 200 && pv < vol * 0.05; t++) { const sh = chunkShape(r, 0.6); const b = hmF.place(sh.h, sh.q, foot[0] + nrm[0] * (0.2 + r() * 1.2) + (r() - .5) * 2.2 * (1 - Math.abs(nrm[0])), foot[2] + nrm[2] * (0.2 + r() * 1.2) + (r() - .5) * 2.2 * (1 - Math.abs(nrm[2])), r); if (b) { extra.push({ kind: 'debris', box: b, from: 'fallen panel', srcStorey: u.storey }); pv += boxVol(b); } }
        } else {
          const hmF = makeHM(foot[0] - 4, foot[2] - 4, foot[0] + 4, foot[2] + 4, 0.1, 0);
          for (const id of model.siteParts) hmF.block(base[id].box);
          let pv = 0; const want = vol * (0.9 + r() * 0.15);
          for (let t = 0; t < 700 && pv < want; t++) { const sh = chunkShape(r, 0.9); const d = 0.3 + r() * 2.3 * Math.sqrt(1 + u.storey);
            const b = hmF.place(sh.h, sh.q, foot[0] + nrm[0] * d + (r() - .5) * (1 - Math.abs(nrm[0])) * (2 * (u.a1 - u.a0) / 3), foot[2] + nrm[2] * d + (r() - .5) * (1 - Math.abs(nrm[2])) * (2 * (u.a1 - u.a0) / 3), r);
            if (b) { extra.push({ kind: 'debris', box: b, from: 'fallen panel', srcStorey: u.storey }); pv += boxVol(b); } }
        }
      } else {
        // inside: chunks on the floors either side (the floor is tilted with the block)
        const rms = u.rooms.map((id) => model.rooms[id]);
        let pv = 0; const want = vol * (0.9 + r() * 0.15);
        for (const rm of rms) {
          const hmR = makeHM(rm.x0 - 0.6, rm.z0 - 0.6, rm.x1 + 0.6, rm.z1 + 0.6, 0.1, -1e9);
          for (const q of base) { if (q.storey !== u.storey && !(q.kind === 'slab' && (q.level === u.storey || q.level === u.storey + 1))) continue; if (st[q.id].state === 'gone') continue; const b = boxT(T, q.box);
            if (q.kind === 'slab' && q.level === u.storey) hmR.support(b); else if (q.kind === 'slab') hmR.ceiling(b); else if (q.kind === 'wall' || q.kind === 'column') hmR.block(b); }
          for (let t = 0; t < 400 && pv < want * (rm === rms[0] ? 0.55 : 1); t++) { const sh = chunkShape(r, 0.8); const tt = r();
            const x = u.axis === 'x' ? u.off + Math.sign((rm.x0 + rm.x1) / 2 - u.off) * (0.25 + tt * 1.3) : rm.x0 + r() * (rm.x1 - rm.x0), z = u.axis === 'z' ? u.off + Math.sign((rm.z0 + rm.z1) / 2 - u.off) * (0.25 + tt * 1.3) : rm.z0 + r() * (rm.z1 - rm.z0);
            const xy = tApply(T, x, rm.y0, z); const b = hmR.place(sh.h, sh.q, xy[0], xy[2], r); if (b) { extra.push({ kind: 'debris', box: b, from: 'fallen panel', srcStorey: u.storey, room: rm.id }); pv += boxVol(b); } }
        }
      }
    }
    info.fallen = fallen;
    for (const p of base) if (p.kind === 'slab' && p.level >= 1 && p.level < NS && r() < 0.22) sag.set(p.id, 0.008 + r() * 0.032);
  }

  // ------------------------------------------------------------------ common: jammed doors, damaged walls, cracks, sag
  const jamP = { softstorey: 0.3, pancake: 0.12, lean: 0.38 }[mode];
  for (const o of model.openings) {
    if (o.kind !== 'door' && o.kind !== 'entry') continue;
    const unitParts = model.walls[o.unit].parts; if (unitParts.some((id) => st[id].state === 'gone')) continue;
    const s = o.storey; if (mode === 'softstorey' && s === 0) continue;
    if (mode === 'pancake') { const u = model.walls[o.unit]; const bb = info.bay; const mx = u.axis === 'x' ? u.off : (o.o0 + o.o1) / 2, mz = u.axis === 'z' ? u.off : (o.o0 + o.o1) / 2; if (Math.hypot(Math.max(0, Math.abs(mx - (bb[0] + bb[1]) / 2) - (bb[1] - bb[0]) / 2), Math.max(0, Math.abs(mz - (bb[2] + bb[3]) / 2) - (bb[3] - bb[2]) / 2)) > 3) continue; }
    if (r() >= jamP) continue;
    const t = 0.05, y0 = o.y0, y1 = o.y1 - 0.02;
    const box = o.axis === 'x' ? aabox(o.off - t / 2, y0, o.o0 + 0.02, o.off + t / 2, y1, o.o1 - 0.02) : aabox(o.o0 + 0.02, y0, o.off - t / 2, o.o1 - 0.02, y1, o.off + t / 2);
    const T = motions[Math.max(0, Math.min(NS, s))];
    extra.push({ kind: 'door', box: boxT(T, box), from: 'jammed door', srcStorey: s, opening: o.id }); jammed.push(o.id);
  }
  // cracks (truth polylines, post coordinates) and damaged infill tiles
  for (const u of model.walls) {
    const w = walls[u.id]; const T = motions[Math.max(0, Math.min(NS, u.storey))];
    const alive = u.parts.filter((id) => st[id].state !== 'gone');
    if (!alive.length) { w.gone = 1; continue; }
    if (w.partsGone > 0) { const tot = u.parts.reduce((s2, id) => s2 + boxVol(base[id].box), 0); w.gone = w.partsGone / tot; }
    if (w.cracked) {
      const lines = crackLines(u, model, r).filter((l) => l.length > 1);
      for (const pts of lines) { const post = pts.map((p) => tApply(T, p[0], p[1], p[2])); const len = polyLen(post); cracks.push({ unit: u.id, pts: post, len, n: u.axis === 'x' ? 0 : 2 }); w.crackLen += len; }
      if (!lines.length) w.cracked = false;
    }
    if (w.dmgWant > 0) { w.damage = Math.max(w.damage, w.dmgWant); for (const id of alive) if (st[id].state !== 'squashed') { st[id].dmg = w.dmgWant; } }
  }
  // tilt of every wall unit (out of plumb: how far its normal tips out of the horizontal plane)
  for (const u of model.walls) {
    const T = motions[Math.max(0, Math.min(NS, u.storey))]; const n0 = u.axis === 'x' ? [1, 0, 0] : [0, 0, 1];
    let R = T.R; const first = u.parts.find((id) => st[id].state === 'squashed'); if (first != null && st[first].box) R = qToMat(st[first].box.q);
    const n = [R[0] * n0[0] + R[1] * n0[1] + R[2] * n0[2], R[3] * n0[0] + R[4] * n0[1] + R[5] * n0[2], R[6] * n0[0] + R[7] * n0[1] + R[8] * n0[2]];
    walls[u.id].tilt = Math.asin(Math.min(1, Math.abs(n[1]))) / DEG;
  }

  // ------------------------------------------------------------------ assemble the post parts
  const parts = [];
  const push = (p, box, o = {}) => { parts.push({ id: parts.length, src: p ? p.id : -1, kind: o.kind || p.kind, storey: o.storey ?? (p ? p.storey : -1), mat: o.mat || (p ? p.mat : 'debris'), unit: p ? p.unit : -1, rooms: p ? p.rooms : [], ext: p ? p.ext : false, box, state: o.state || 'intact', debris: !!o.debris, tile: !!o.tile, ...o.extra }); };
  for (const p of base) {
    const s = st[p.id]; if (s.state === 'gone') continue;
    let box = s.box || (s.T ? boxT(s.T, p.box) : p.box);
    if (s.state === 'fallen') { push(p, box, { state: 'fallen', debris: true, kind: 'slab', mat: 'debrisSlab', extra: { level: p.level, fall: s.fall } }); continue; }
    if (sag.has(p.id)) {
      // a sagging panel: two halves tilted toward the middle of its shorter span
      const sv = sag.get(p.id), b0 = p.box, alongX = b0.h[0] < b0.h[2]; const half = alongX ? b0.h[0] : b0.h[2], a = Math.atan2(sv, half);
      for (const sgn of [-1, 1]) {
        const c = b0.c.slice(); if (alongX) c[0] += sgn * half / 2; else c[2] += sgn * half / 2; c[1] -= sv / 2;
        const h = alongX ? [half / 2 / Math.cos(a), b0.h[1], b0.h[2]] : [b0.h[0], b0.h[1], half / 2 / Math.cos(a)];
        const q = alongX ? qAxis(0, 0, 1, sgn * a) : qAxis(1, 0, 0, -sgn * a);
        const hb = { c, h, q }; push(p, s.T ? boxT(s.T, hb) : hb, { state: 'sagging', extra: { sag: sv, level: p.level } });
      }
      continue;
    }
    if (s.dmg > 0 && p.kind === 'wall') { for (const tb of tileBox(p.box, s.dmg, r)) push(p, s.T ? boxT(s.T, tb) : tb, { state: 'damaged', tile: true, extra: { dmg: s.dmg } }); continue; }
    push(p, box, { state: s.state === 'moved' ? 'moved' : s.state, extra: p.kind === 'slab' ? { level: p.level } : {} });
  }
  for (const e of extra) push(null, e.box, { kind: e.kind, storey: e.srcStorey ?? -1, mat: e.kind === 'door' ? 'door' : e.panel ? 'debrisSlab' : 'debris', state: e.kind === 'door' ? 'jammed' : 'debris', debris: e.kind !== 'door', extra: { from: e.from, panel: !!e.panel, leaning: !!e.leaning, seal: e.seal ?? -1, opening: e.opening ?? -1 } });

  // ------------------------------------------------------------------ fire (gas line in a kitchen) and a burst tank
  const kitchens = model.rooms.filter((q) => q.kind === 'kitchen');
  const roomOK = (q) => { const T = motions[q.storey]; const c = tApply(T, (q.x0 + q.x1) / 2, q.y0 + 1, (q.z0 + q.z1) / 2);
    if (mode === 'pancake') { const b = info.bay; if (c[0] > b[0] - 1 && c[0] < b[1] + 1 && c[2] > b[2] - 1 && c[2] < b[3] + 1) return false; }
    if (mode === 'softstorey' && q.storey === 0) return false; return true; };
  const okK = kitchens.filter(roomOK); const fk = okK.length ? okK[Math.floor(r() * okK.length)] : kitchens[0];
  const fT = motions[fk.storey];
  const fireLocal = [fk.x0 + (fk.x1 - fk.x0) * (0.3 + r() * 0.4), fk.y0 + 0.9, fk.z0 + 0.35];
  const fire = { room: fk.id, pos: tApply(fT, ...fireLocal), radius: [0.45, 0.8, 1.2], peak: [170, 250, 320] };
  const tk = base.find((p) => p.kind === 'tank'); const tkT = motions[NS];
  const tank = tk ? { pos: tApply(tkT, tk.box.c[0], NS * SH + ST, tk.box.c[2]), radius: [0.9, 1.5, 2.1], dT: [-4.5, -6, -7.5] } : null;

  let dv = 0; for (const p of parts) if (p.debris) dv += boxVol(p.box);
  return { mode, seed, parts, motions, cracks, jammed, sag, walls, fire, tank, info, debrisVolume: dv, destroyedVolume: debrisVol };
}
export { faceHeightAt };
