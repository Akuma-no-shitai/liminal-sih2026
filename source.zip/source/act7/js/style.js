// Act 7 styles, scoped under .a7 (copied from Act 4 and extended). Injected once by the module as #a7css, so the act also
// works inside Act 1's page and in the single-file build. Same palette and type conventions (sentence case, Fraunces /
// Geist / Geist Mono).
import { THEMES, cssVarText } from './theme.js';
export const CSS = `
.a7 { ${cssVarText(THEMES.dusk)}
  --serif:"Fraunces", Georgia, serif; --sans:"Geist", ui-sans-serif, system-ui, sans-serif; --mono:"Geist Mono", ui-monospace, monospace; --ease: cubic-bezier(.2,.7,.1,1);
  --top: 56px; --dock: 104px; --cards: 336px;
  position: absolute; inset: 0; z-index: 60; background: var(--ink); color: var(--paper); font: 15px/1.5 var(--sans); -webkit-font-smoothing: antialiased; overflow: hidden; user-select: none; -webkit-user-select: none; }
.a7 *, .a7 *::before, .a7 *::after { box-sizing: border-box; }
.a7 button { font-family: inherit; }
.a7 :focus-visible { outline: 2px solid var(--teal); outline-offset: 2px; }
/* the 3-D view: full bleed under everything on desktop */
.a7view { position: absolute; inset: 0; z-index: 1; background: radial-gradient(120% 90% at 50% 40%, var(--view1) 0%, var(--view2) 60%, var(--ink) 100%); }
.a7view canvas { position: absolute; inset: 0; width: 100%; height: 100%; display: block; touch-action: none; cursor: grab; }
.a7view canvas:active { cursor: grabbing; }
.a7labels { position: absolute; inset: 0; z-index: 3; pointer-events: none; overflow: hidden; }
.a7lab { position: absolute; left: 0; top: 0; transform: translate(-50%, -100%); white-space: nowrap; font: 500 12px/1.25 var(--sans); color: var(--paper); padding: 4px 8px 4px 8px; border-radius: 8px; background: rgba(var(--panel-rgb),var(--lab-a)); backdrop-filter: blur(6px); -webkit-backdrop-filter: blur(6px); border: 1px solid rgba(var(--line-rgb),.14); opacity: 0; transition: opacity .35s; }
.a7lab small { display: block; font: 11px/1.25 var(--mono); color: var(--muted); margin-top: 1px; }
.a7lab.heat { border-color: rgba(var(--heat-rgb),.45); } .a7lab.heat b { color: var(--heat-on); font-weight: 500; }
.a7lab.lav { border-color: rgba(var(--lav-rgb),.45); } .a7lab.lav b { color: var(--lav-on); font-weight: 500; }
.a7lab.apr b { color: var(--apricot-txt); font-weight: 500; }
.a7lab.teal b { color: var(--teal-on); font-weight: 500; }
.a7lab.rose { border-color: rgba(var(--rose-rgb),.5); } .a7lab.rose b { color: var(--rose-on); font-weight: 500; }
.a7lab::after { content: ""; position: absolute; left: 50%; bottom: -5px; width: 1px; height: 5px; background: rgba(var(--line-rgb),.4); }
.a7num { position: absolute; left: 0; top: 0; transform: translate(-50%, -50%); width: 24px; height: 24px; border-radius: 50%; display: grid; place-items: center; font: 600 12px/1 var(--sans); color: var(--ink); background: var(--lav); box-shadow: 0 0 0 4px rgba(var(--lav-rgb),.25), 0 0 18px rgba(var(--lav-rgb),.6); opacity: 0; transition: opacity .3s; }
/* top bar */
.a7top { position: absolute; left: 0; right: 0; top: 0; height: var(--top); z-index: 25; display: flex; align-items: center; gap: 14px; padding: 0 22px; background: linear-gradient(rgba(var(--bar-rgb),.86), rgba(var(--bar-rgb),.55) 70%, rgba(var(--bar-rgb),0)); }
.a7brand { font: 500 14px/1 var(--sans); letter-spacing: .01em; white-space: nowrap; }
.a7brand i { font: italic 400 15px/1 var(--serif); color: var(--haze-txt); margin-left: 6px; }
.a7top .sp { flex: 1; }
.a7pill { color: var(--paper); display: inline-flex; align-items: center; gap: 8px; height: 36px; padding: 0 14px; border-radius: 999px; border: 1px solid var(--line); background: rgba(var(--panel-rgb),.35); color: var(--paper); font: 500 13.5px/1 var(--sans); cursor: pointer; white-space: nowrap; transition: border-color .2s, background .2s, color .2s; }
.a7pill:hover { border-color: rgba(var(--fg-rgb),.5); background: rgba(var(--fg-rgb),.07); }
.a7pill svg { width: 15px; height: 15px; flex: none; }
.a7pill.on { color: var(--teal-txt); border-color: rgba(var(--teal-rgb),.55); }
.a7mis { position: relative; }
.a7mis .a7pill { background: rgba(var(--fg-rgb),.06); }
.a7mis .cur { max-width: 300px; overflow: hidden; text-overflow: ellipsis; }
.a7menu { position: absolute; top: 44px; left: 0; min-width: 320px; padding: 6px; border-radius: 14px; background: rgba(var(--panel2-rgb),.97); border: 1px solid var(--line); box-shadow: 0 20px 50px rgba(var(--shadow-rgb),.5); display: none; z-index: 30; }
.a7menu.on { display: block; }
.a7menu button { display: grid; grid-template-columns: 26px 1fr; gap: 2px 8px; width: 100%; text-align: left; padding: 9px 10px; border: 0; background: transparent; border-radius: 10px; cursor: pointer; }
.a7menu button:hover, .a7menu button.on { background: rgba(var(--fg-rgb),.07); }
.a7menu button i { font: italic 300 18px/1.1 var(--serif); color: var(--haze-txt); grid-row: span 2; }
.a7menu button i.pl { color: var(--teal-txt); } .a7menu button i.pl svg { width: 12px; height: 12px; margin-top: 4px; }
.a7menu button b { font: 500 14px/1.3 var(--sans); } .a7menu button span { font: 12px/1.3 var(--sans); color: var(--faint); }
/* caption: lower third */
.a7cap { position: absolute; left: 30px; bottom: calc(var(--dock) + 22px); z-index: 6; max-width: min(620px, calc(100% - var(--cards) - 320px)); pointer-events: none; }
.a7cap .ch { font: 500 12.5px/1.2 var(--sans); color: var(--teal-txt); margin: 0 0 8px; display: flex; gap: 10px; align-items: baseline; opacity: .95; }
.a7cap .ch i { font: italic 300 20px/1 var(--serif); color: var(--haze-txt); }
.a7cap p { margin: 0; font: 400 clamp(19px, 1.6vw, 23px)/1.36 var(--serif); color: var(--paper); text-wrap: pretty; text-shadow: 0 1px 18px rgba(var(--halo-rgb),.9), 0 0 2px rgba(var(--halo-rgb),.6); transition: opacity .5s var(--ease), transform .5s var(--ease); }
.a7cap p.out { opacity: 0; transform: translateY(6px); }
/* concept cards */
.a7cards { position: absolute; right: 16px; top: calc(var(--top) + 6px); bottom: calc(var(--dock) + 14px); width: calc(var(--cards) - 24px); z-index: 7; display: flex; flex-direction: column; gap: 10px; pointer-events: none; }
.a7card { pointer-events: auto; background: var(--glass); backdrop-filter: blur(14px) saturate(1.1); -webkit-backdrop-filter: blur(14px) saturate(1.1); border: 1px solid rgba(var(--line-rgb),.16); border-radius: 16px; padding: 13px 14px 12px; transition: opacity .45s var(--ease), transform .45s var(--ease); box-shadow: 0 14px 34px rgba(var(--shadow2-rgb),.28); }
.a7card.enter { opacity: 0; transform: translateX(24px); } .a7card.leave { opacity: 0; transform: translateX(24px); }
.a7card header { display: flex; align-items: center; gap: 8px; margin: 0 0 8px; }
.a7card header i { width: 7px; height: 7px; border-radius: 50%; background: var(--teal); box-shadow: 0 0 0 3px rgba(var(--teal-rgb),.18); animation: a7live 1.6s ease-in-out infinite; flex: none; }
.a7card h4 { margin: 0; font: 400 18px/1.15 var(--serif); letter-spacing: -.005em; flex: 1; }
.a7card .tag { font: 11.5px/1 var(--sans); color: var(--faint); }
.a7card canvas { display: block; width: 100%; height: 92px; border-radius: 10px; background: rgba(var(--well-rgb),.45); }
.a7card .st { display: flex; justify-content: space-between; gap: 10px; margin: 8px 0 0; font: 12px/1.3 var(--mono); color: var(--muted); }
.a7card .st b { color: var(--paper); font-weight: 500; }
.a7card p { margin: 6px 0 0; font: 13px/1.45 var(--sans); color: rgba(var(--fg-rgb),.8); }
.a7card:not(:first-child) p, .a7card:not(:first-child) .labs { display: none; }
.a7card:not(:first-child) canvas { height: 64px; }
.a7cards { overflow: hidden; }
.a7card .lab { margin-top: 9px; display: inline-flex; align-items: center; gap: 6px; height: 28px; padding: 0 11px; border-radius: 999px; border: 1px solid var(--line); background: transparent; font: 500 12px/1 var(--sans); cursor: pointer; color: var(--paper); }
.a7card .lab:hover { border-color: rgba(var(--teal-rgb),.6); color: var(--teal-txt); }
@keyframes a7live { 0%,100% { opacity: 1; } 50% { opacity: .35; } }
/* picture in picture: the drone's eye */
.a7pip { position: absolute; z-index: 6; right: var(--cards); bottom: calc(var(--dock) + 18px); width: 252px; height: 158px; border-radius: 14px; border: 1px solid rgba(var(--line-rgb),.22); box-shadow: 0 14px 30px rgba(var(--shadow-rgb),.4); overflow: hidden; pointer-events: none; opacity: 0; transition: opacity .4s; }
.a7pip.on { opacity: 1; }
.a7pip .t { position: absolute; left: 8px; top: 7px; font: 500 11.5px/1.2 var(--sans); color: var(--paper); text-shadow: 0 1px 6px rgba(var(--halo-rgb),.9); }
.a7pip .t small { display: block; font: 10.5px/1.2 var(--mono); color: var(--muted); }
.a7pip .rec { position: absolute; right: 9px; top: 9px; width: 7px; height: 7px; border-radius: 50%; background: var(--danger); animation: a7live 1.2s infinite; }
.a7pip .ret { position: absolute; inset: 0; background: radial-gradient(transparent 62%, rgba(var(--halo-rgb),.45)); }
/* dock */
.a7.nomis .a7dock, .a7.nomis .a7cap, .a7.nomis .a7cards, .a7.nomis .a7pip { visibility: hidden; }
.a7dock { position: absolute; left: 0; right: 0; bottom: 0; height: var(--dock); z-index: 9; padding: 12px 22px 12px; display: grid; grid-template-rows: 40px 34px; gap: 8px; background: linear-gradient(rgba(var(--bar-rgb),0), rgba(var(--bar-rgb),.78) 32%, rgba(var(--bar-rgb),.92)); }
.a7row1 { display: grid; grid-template-columns: auto auto 1fr auto; align-items: center; gap: 14px; min-width: 0; }
.a7row2 { display: flex; align-items: center; gap: 12px; min-width: 0; }
.a7play { width: 40px; height: 40px; border-radius: 50%; border: 0; background: var(--paper); color: var(--ink); display: grid; place-items: center; cursor: pointer; transition: transform .2s var(--ease); }
.a7play:hover { transform: scale(1.06); } .a7play svg { width: 16px; height: 16px; }
.a7seg { display: inline-flex; padding: 3px; border-radius: 999px; border: 1px solid var(--line); background: rgba(var(--panel-rgb),.4); }
.a7seg button { color: var(--muted); border: 0; background: transparent; height: 28px; min-width: 38px; padding: 0 9px; border-radius: 999px; font: 500 12.5px/1 var(--mono); color: var(--muted); cursor: pointer; }
.a7seg button.on { background: rgba(var(--fg-rgb),.14); color: var(--paper); }
.a7scrub { position: relative; height: 40px; min-width: 0; cursor: pointer; touch-action: none; }
.a7scrub .segs { position: absolute; left: 0; right: 0; top: 19px; height: 6px; display: flex; gap: 3px; }
.a7scrub .sg { position: relative; height: 6px; border-radius: 3px; background: rgba(var(--line-rgb),.16); overflow: hidden; flex: none; }
.a7scrub .sg s { position: absolute; left: 0; top: 0; bottom: 0; width: 0; background: rgba(var(--teal-rgb),.8); }
.a7scrub .sg.cur s { background: var(--accent2); }
.a7scrub .lbl { position: absolute; top: 2px; font: 11px/1.2 var(--sans); color: var(--faint); white-space: nowrap; overflow: hidden; text-overflow: ellipsis; pointer-events: none; }
.a7scrub .lbl.cur { color: var(--paper); }
.a7scrub .head { position: absolute; top: 14px; width: 2px; height: 16px; margin-left: -1px; border-radius: 1px; background: var(--paper); box-shadow: 0 0 0 3px rgba(var(--fg-rgb),.15); pointer-events: none; }
.a7scrub .ev { position: absolute; top: 30px; width: 5px; height: 5px; margin-left: -2.5px; border-radius: 50%; pointer-events: none; }
.a7scrub .tip { position: absolute; bottom: 44px; transform: translateX(-50%); padding: 6px 10px; border-radius: 9px; background: rgba(var(--panel2-rgb),.97); border: 1px solid var(--line); font: 12px/1.3 var(--sans); white-space: nowrap; opacity: 0; transition: opacity .15s; pointer-events: none; }
.a7scrub .tip small { display: block; font: 11px/1.3 var(--mono); color: var(--faint); }
.a7scrub:hover .tip { opacity: 1; }
.a7time { font: 12.5px/1.25 var(--mono); color: var(--muted); white-space: nowrap; text-align: right; }
.a7time b { color: var(--paper); font-weight: 500; }
.a7time span { display: block; color: var(--faint); font-size: 11.5px; }
.a7lens { display: flex; gap: 6px; align-items: center; min-width: 0; overflow-x: auto; scrollbar-width: none; flex: 1; }
.a7lens::-webkit-scrollbar { display: none; }
.a7lens .k { font: 12px/1 var(--sans); color: var(--faint); margin-right: 4px; white-space: nowrap; }
.a7chip { color: var(--muted); height: 30px; padding: 0 12px; border-radius: 999px; border: 1px solid var(--line); background: rgba(var(--panel-rgb),.35); font: 500 12.5px/1 var(--sans); color: var(--muted); cursor: pointer; white-space: nowrap; transition: background .2s, color .2s, border-color .2s; flex: none; }
.a7chip:hover { color: var(--paper); border-color: rgba(var(--fg-rgb),.4); }
.a7chip.on { background: var(--paper); color: var(--ink); border-color: var(--paper); }
.a7dir { display: inline-flex; align-items: center; gap: 8px; }
.a7dir i { width: 7px; height: 7px; border-radius: 50%; background: var(--teal); box-shadow: 0 0 0 3px rgba(var(--teal-rgb),.2); }
.a7dir.user { color: var(--accent2-on); background: var(--accent2); border-color: var(--accent2); } .a7dir.user i { background: var(--accent2-on); box-shadow: none; animation: a7live 1.2s infinite; }
/* overlays: picker, simulating, report */
.a7over { position: absolute; inset: 0; z-index: 20; display: grid; place-items: center; transition: opacity .6s var(--ease); }
.a7over.hide { opacity: 0; pointer-events: none; visibility: hidden; transition: opacity .6s var(--ease), visibility 0s .6s; }
.a7pick { background: radial-gradient(110% 80% at 50% 0%, rgba(var(--pick-rgb),.96), rgba(var(--panel-rgb),.985) 62%); overflow-y: auto; place-items: start center; }
.a7pick .in { width: min(1320px, 100%); padding: 86px 36px 40px; }
.a7pick .kick { font: 500 13px/1 var(--sans); color: var(--haze-txt); margin: 0 0 14px; }
.a7pick h1 { font: 300 clamp(36px, 4vw, 56px)/1.02 var(--serif); letter-spacing: -.02em; margin: 0 0 14px; }
.a7pick h1 em { font-style: italic; color: var(--apricot-txt); }
.a7pick .lede { font: 400 18px/1.5 var(--serif); color: rgba(var(--fg-rgb),.86); max-width: 62ch; margin: 0 0 22px; }
.a7pick .acts { display: flex; gap: 12px; flex-wrap: wrap; align-items: center; margin: 0 0 28px; }
.a7pri { display: inline-flex; align-items: center; gap: 10px; min-height: 46px; padding: 0 22px; border-radius: 999px; border: 0; background: var(--paper); color: var(--ink); font: 500 15px/1 var(--sans); cursor: pointer; transition: transform .2s var(--ease); }
.a7pri:hover { transform: translateY(-1px); }
.a7pri.auto { background: linear-gradient(90deg, rgba(var(--teal-rgb),.5), rgba(var(--teal-rgb),.5)) no-repeat 0 0 / 0% 100%, var(--paper); animation: a7auto var(--auto, 11s) linear forwards; }
@keyframes a7auto { to { background-size: 100% 100%, auto; } } .a7pri svg { width: 14px; height: 14px; }
.a7sec { display: inline-flex; align-items: center; min-height: 46px; padding: 0 20px; border-radius: 999px; border: 1px solid rgba(var(--fg-rgb),.35); background: transparent; color: var(--paper); font: 500 15px/1 var(--sans); cursor: pointer; }
.a7pick .note { font: 13px/1.4 var(--sans); color: var(--faint); }
.a7grid { display: grid; grid-template-columns: repeat(4, minmax(0, 1fr)); gap: 16px; }
.a7m { text-align: left; border: 1px solid rgba(var(--line-rgb),.16); background: rgba(var(--panel2-rgb),.55); border-radius: 18px; padding: 0 0 16px; cursor: pointer; overflow: hidden; display: flex; flex-direction: column; transition: transform .3s var(--ease), border-color .3s, background .3s; color: var(--paper); }
.a7m:hover { transform: translateY(-3px); border-color: rgba(var(--fg-rgb),.4); background: rgba(var(--hover-rgb),.7); }
.a7m canvas { width: 100%; aspect-ratio: 16 / 10; display: block; }
.a7m .b { padding: 14px 16px 0; display: flex; flex-direction: column; gap: 6px; flex: 1; }
.a7m .n { font: italic 300 15px/1 var(--serif); color: var(--haze-txt); }
.a7m h3 { font: 400 21px/1.15 var(--serif); margin: 0; letter-spacing: -.01em; }
.a7m .pl { font: 13px/1.35 var(--sans); color: var(--muted); margin: 0; }
.a7m .md { font: 12px/1.3 var(--mono); color: var(--teal-txt); margin: 2px 0 0; }
.a7m ul { list-style: none; margin: 6px 0 0; padding: 0; display: flex; flex-wrap: wrap; gap: 5px; }
.a7m li { font: 11.5px/1 var(--sans); padding: 5px 8px; border-radius: 999px; background: rgba(var(--fg-rgb),.07); color: rgba(var(--fg-rgb),.82); }
.a7m .go { margin-top: auto; padding-top: 12px; font: 500 13px/1 var(--sans); color: var(--paper); display: inline-flex; gap: 8px; align-items: center; }
.a7m .go svg { width: 13px; height: 13px; }
.a7sim { background: radial-gradient(60% 50% at 50% 50%, rgba(var(--panel-rgb),.55), rgba(var(--panel-rgb),.15) 70%, rgba(var(--panel-rgb),0)); pointer-events: none; }
.a7sim .box { text-align: center; padding: 26px 34px; border-radius: 20px; background: rgba(var(--panel-rgb),.58); backdrop-filter: blur(12px); -webkit-backdrop-filter: blur(12px); border: 1px solid rgba(var(--line-rgb),.14); min-width: 360px; }
.a7sim .row { display: none; gap: 10px; justify-content: center; margin-top: 16px; } .a7sim.failed { pointer-events: auto; } .a7sim.failed .row { display: flex; } .a7sim.failed .bar, .a7sim.failed .why { display: none; }
.a7sim .k { font: 500 12.5px/1 var(--sans); color: var(--haze-txt); margin: 0 0 10px; }
.a7sim h2 { font: 400 28px/1.12 var(--serif); margin: 0 0 6px; }
.a7sim .pl { font: 13.5px/1.4 var(--sans); color: var(--muted); margin: 0 0 18px; }
.a7sim .bar { height: 3px; border-radius: 2px; background: rgba(var(--line-rgb),.16); overflow: hidden; }
.a7sim .bar s { display: block; height: 100%; width: 0; background: linear-gradient(90deg, var(--teal), var(--teal-on2)); transition: width .2s; }
.a7sim .pc { font: 12.5px/1.2 var(--mono); color: var(--muted); margin: 10px 0 0; }
.a7sim .why { font: 12.5px/1.45 var(--sans); color: var(--faint); margin: 12px auto 0; max-width: 38ch; }
.a7rep { z-index: 15; background: linear-gradient(90deg, rgba(var(--bar-rgb),.0) 0%, rgba(var(--bar-rgb),.35) 40%, rgba(var(--bar-rgb),.86) 100%); place-items: center end; padding-right: 40px; }
.a7rep .card { width: min(560px, 100%); max-height: calc(100% - 140px); overflow-y: auto; padding: 26px 28px 22px; border-radius: 22px; background: rgba(var(--card-rgb),.94); border: 1px solid rgba(var(--line-rgb),.18); box-shadow: 0 30px 70px rgba(var(--shadow-rgb),.5); }
.a7rep .k { font: 500 12.5px/1 var(--sans); color: var(--teal-txt); margin: 0 0 10px; }
.a7rep h2 { font: 400 30px/1.08 var(--serif); margin: 0 0 6px; letter-spacing: -.01em; }
.a7rep .pl { font: 13.5px/1.4 var(--sans); color: var(--muted); margin: 0 0 18px; }
.a7rep dl { display: grid; grid-template-columns: repeat(3, 1fr); gap: 14px 16px; margin: 0 0 18px; }
.a7rep dt { font: 400 26px/1.05 var(--serif); color: var(--paper); } .a7rep dt.h { color: var(--heat-txt); } .a7rep dt.t { color: var(--teal-txt); } .a7rep dt.l { color: var(--lav-txt); }
.a7rep dd { margin: 4px 0 0; font: 12px/1.3 var(--sans); color: var(--faint); }
.a7rep h4 { font: 500 12.5px/1.2 var(--sans); color: var(--haze-txt); margin: 14px 0 8px; }
.a7rep ol { margin: 0; padding: 0; list-style: none; display: grid; gap: 7px; }
.a7rep li { display: grid; grid-template-columns: 22px 1fr auto; gap: 8px; align-items: baseline; font: 13.5px/1.4 var(--sans); color: rgba(var(--fg-rgb),.88); }
.a7rep li i { font: italic 300 16px/1 var(--serif); color: var(--heat-txt); }
.a7rep li small { font: 11.5px/1.3 var(--mono); color: var(--faint); }
.a7rep .row { display: flex; gap: 10px; flex-wrap: wrap; position: sticky; bottom: -22px; margin: 18px -28px -22px; padding: 16px 28px 20px; background: linear-gradient(rgba(var(--card-rgb),0), rgba(var(--card-rgb),.97) 26%); }
.a7rep .zero { margin: 16px 0 0; padding: 12px 14px; border-radius: 12px; background: rgba(var(--safe-rgb),.08); border: 1px solid rgba(var(--safe-rgb),.24); font: 13px/1.45 var(--sans); color: rgba(var(--fg-rgb),.88); }
.a7rep .zero b { font-family: var(--mono); color: var(--safe-txt); font-weight: 500; }
.a7toast { position: absolute; left: 50%; top: calc(var(--top) + 10px); transform: translateX(-50%); z-index: 12; padding: 8px 14px; border-radius: 999px; background: rgba(var(--panel2-rgb),.92); border: 1px solid var(--line); font: 12.5px/1.2 var(--sans); color: var(--muted); opacity: 0; transition: opacity .4s; pointer-events: none; white-space: nowrap; }
.a7toast.on { opacity: 1; }
.a7top .showS { display: none; }
/* medium widths: the top bar keeps every control on one line (the brand's subtitle and the button labels go first) */
@media (max-width: 1100px) and (min-width: 761px) { .a7brand i { display: none; } }
@media (max-width: 960px) and (min-width: 761px) { .a7top .a7mus .hideS { display: none; } .a7mis .cur { max-width: 200px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; } }
@media (max-width: 1180px) { .a7grid { grid-template-columns: repeat(2, minmax(0, 1fr)); } .a7 { --cards: 316px; } }
@media (max-width: 1320px) { .a7cap { max-width: min(560px, calc(100% - var(--cards) - 300px)); } }
/* phone: the view on top, the caption, the dock, then the cards as a strip */
@media (max-width: 760px) {
  .a7 { --top: 48px; display: grid; grid-template-rows: var(--top) 52svh auto auto minmax(0, 1fr); grid-template-areas: "top" "view" "cap" "dock" "cards"; }
  .a7top { position: relative; grid-area: top; padding: 0 10px; gap: 6px; background: rgba(var(--bar-rgb),.96); }
  .a7brand i, .a7top .hideS, .a7top .showS { display: none; }
  .a7brand { font-size: 13px; }
  .a7pill { height: 32px; padding: 0 9px; font-size: 12.5px; gap: 6px; }
  .a7top .sp { flex: 1 1 0; min-width: 0; }
  .a7mis { min-width: 0; flex: 0 1 auto; } .a7mis .a7pill { max-width: 100%; } .a7mis .cur { max-width: 112px; }
  .a7menu { position: fixed; left: 8px; right: 8px; top: 52px; min-width: 0; }
  .a7view { position: relative; grid-area: view; inset: auto; }
  .a7labels { position: absolute; }
  .a7lab { font-size: 11px; padding: 3px 7px; } .a7lab small { display: none; }
  .a7cap { position: relative; grid-area: cap; left: auto; bottom: auto; max-width: none; padding: 10px 14px 6px; background: var(--ink); }
  .a7cap .ch { margin-bottom: 4px; font-size: 11.5px; } .a7cap .ch i { font-size: 16px; }
  .a7cap p { font-size: 16px; line-height: 1.38; text-shadow: none; min-height: 2.76em; }
  .a7dock { position: relative; grid-area: dock; height: auto; padding: 8px 12px 8px; grid-template-rows: auto auto; background: var(--ink); border-top: 1px solid var(--line); gap: 6px; }
  .a7row1 { grid-template-columns: auto 1fr auto; gap: 10px; }
  .a7row2 { overflow-x: auto; scrollbar-width: none; } .a7row2::-webkit-scrollbar { display: none; }
  .a7lens { overflow: visible; flex: none; }
  .a7time .d, .a7time .slash { display: none !important; }
  .a7row1 .a7seg { display: none; }
  .a7play { width: 36px; height: 36px; }
  .a7time { font-size: 11px; } .a7time span { font-size: 10.5px; }
  .a7scrub .lbl { display: none; }
  .a7lens .k { display: none; }
  .a7row2 { gap: 8px; }
  .a7row2 .a7dirw { display: flex; gap: 6px; flex: none; }
  .a7chip { height: 30px; padding: 0 10px; font-size: 12px; }
  .a7cards { position: relative; grid-area: cards; right: auto; top: auto; bottom: auto; width: auto; flex-direction: row; overflow-x: auto; padding: 10px 12px 14px; gap: 10px; scroll-snap-type: x mandatory; background: var(--ink); scrollbar-width: none; }
  .a7cards::-webkit-scrollbar { display: none; }
  .a7card { flex: none; width: 82vw; max-width: 330px; scroll-snap-align: start; padding: 11px 12px 10px; background: rgba(var(--panel2-rgb),.75); }
  .a7card canvas { height: 64px; }
  .a7card p { display: none; }
  .a7card .labs { margin-top: 7px; } .a7card .lab { margin-top: 0; }
  .a7card .q4 small { display: none; }
  .a7pip { right: 8px; top: calc(var(--top) + 52svh - 104px); bottom: auto; width: 132px; height: 84px; border-radius: 10px; }
  .a7pip .t small { display: none; } .a7pip .t { font-size: 10px; }
  .a7pick .in { padding: 64px 16px 30px; }
  .a7pick .lede { font-size: 16px; }
  .a7grid { grid-template-columns: 1fr; gap: 12px; }
  .a7m { flex-direction: row; padding: 0; min-height: 132px; }
  .a7m canvas { width: 38%; aspect-ratio: auto; height: auto; }
  .a7m .b { padding: 12px 12px 12px; gap: 4px; }
  .a7m h3 { font-size: 17px; } .a7m .pl { font-size: 12px; } .a7m ul { display: none; } .a7m .go { padding-top: 6px; }
  .a7sim .box { min-width: 0; width: calc(100% - 32px); padding: 20px; }
  .a7rep { padding: 0; place-items: end center; background: rgba(var(--bar-rgb),.6); }
  .a7rep .card { width: 100%; max-height: 88%; border-radius: 20px 20px 0 0; padding: 20px 18px 18px; }
  .a7rep .row { bottom: -18px; margin: 14px -18px -18px; padding: 14px 18px 18px; }
  .a7rep h2 { font-size: 24px; } .a7rep dl { grid-template-columns: repeat(2, 1fr); } .a7rep dt { font-size: 22px; }
}

/* ---------------------------------------------------------------- Act 7 additions */
.a7chipsim { position: absolute; left: 22px; top: calc(var(--top) + 8px); z-index: 8; display: inline-flex; align-items: center; gap: 8px; height: 28px; padding: 0 12px; border-radius: 999px; background: rgba(var(--panel-rgb),.55); border: 1px solid var(--line); font: 12px/1 var(--sans); color: var(--muted); pointer-events: none; backdrop-filter: blur(8px); -webkit-backdrop-filter: blur(8px); }
.a7chipsim i { width: 6px; height: 6px; border-radius: 50%; background: var(--lav); box-shadow: 0 0 0 3px rgba(var(--lav-rgb),.2); }
.a7clock { position: absolute; left: 22px; top: calc(var(--top) + 44px); z-index: 8; padding: 8px 12px 9px; border-radius: 12px; background: rgba(var(--panel-rgb),.6); border: 1px solid var(--line); backdrop-filter: blur(8px); -webkit-backdrop-filter: blur(8px); pointer-events: none; min-width: 190px; }
.a7clock .k { font: 11.5px/1.2 var(--sans); color: var(--faint); }
.a7clock .t { font: 500 20px/1.15 var(--mono); color: var(--paper); letter-spacing: .01em; }
.a7clock .s { font: 11.5px/1.3 var(--sans); color: var(--teal-txt); margin-top: 2px; }
.a7clock .s.warn { color: var(--caution-txt); }
.a7.nomis .a7chipsim, .a7.nomis .a7clock, .a7.nomis .a7floors, .a7.nomis .a7tog { visibility: hidden; }
/* floor cutaway control: a small vertical strip on the left of the view */
.a7floors { position: absolute; left: 22px; top: 50%; transform: translateY(-50%); z-index: 8; display: flex; flex-direction: column; gap: 4px; padding: 6px; border-radius: 14px; background: rgba(var(--panel-rgb),.5); border: 1px solid var(--line); backdrop-filter: blur(8px); -webkit-backdrop-filter: blur(8px); }
.a7floors .k { font: 10.5px/1.2 var(--sans); color: var(--faint); text-align: center; padding: 2px 0 3px; }
.a7floors button { width: 40px; height: 28px; border-radius: 8px; border: 1px solid transparent; background: transparent; color: var(--muted); font: 500 12px/1 var(--sans); cursor: pointer; }
.a7floors button:hover { color: var(--paper); border-color: var(--line); }
.a7floors button.on { background: rgba(var(--fg-rgb),.14); color: var(--paper); }
.a7floors button.auto { font-size: 11px; }
/* lens extras (cloud toggles, thermal passes) above the dock, right of the caption */
.a7tog { position: absolute; right: calc(var(--cards) + 4px); bottom: calc(var(--dock) + 18px); z-index: 7; display: none; gap: 6px; align-items: center; padding: 5px; border-radius: 999px; background: rgba(var(--panel-rgb),.6); border: 1px solid var(--line); backdrop-filter: blur(8px); -webkit-backdrop-filter: blur(8px); }
.a7tog.on { display: inline-flex; }
.a7tog .k { font: 12px/1 var(--sans); color: var(--faint); padding: 0 6px 0 8px; }
.a7tog button { height: 28px; padding: 0 11px; border-radius: 999px; border: 1px solid var(--line); background: transparent; color: var(--muted); font: 500 12px/1 var(--sans); cursor: pointer; white-space: nowrap; }
.a7tog button.on { background: var(--paper); color: var(--ink); border-color: var(--paper); }
.a7tog button .sw { display: inline-block; width: 8px; height: 8px; border-radius: 50%; margin-right: 6px; vertical-align: 0; }
/* the aftershock button: in the caption during chapter 6, and in the dock once it has played */
.a7shock { pointer-events: auto; margin-top: 12px; display: inline-flex; align-items: center; gap: 8px; height: 36px; padding: 0 16px; border-radius: 999px; border: 1px solid rgba(var(--danger-rgb),.6); background: rgba(var(--danger-rgb),.14); color: var(--danger-on2); font: 500 13.5px/1 var(--sans); cursor: pointer; }
.a7shock:hover { background: rgba(var(--danger-rgb),.26); }
.a7shock svg { width: 15px; height: 15px; }
.a7shock[hidden] { display: none; }
.a7chip.a7dshock { color: var(--danger-on2); border-color: rgba(var(--danger-rgb),.5); }
.a7chip.a7dshock[hidden] { display: none; }
/* scene labels for rooms: status tones */
.a7lab.safe { border-color: rgba(var(--safe-rgb),.55); } .a7lab.safe b { color: var(--safe-on); font-weight: 500; }
.a7lab.caution { border-color: rgba(var(--caution-rgb),.55); } .a7lab.caution b { color: var(--caution-on); font-weight: 500; }
.a7lab.noentry { border-color: rgba(var(--danger-rgb),.6); } .a7lab.noentry b { color: var(--danger-on); font-weight: 500; }
.a7lab.unseen { border-color: rgba(var(--haze-rgb),.6); border-style: dashed; } .a7lab.unseen b { color: var(--haze-on2); font-weight: 500; }
.a7lab.room { pointer-events: auto; cursor: pointer; }
.a7lab.room:hover { background: rgba(var(--hover2-rgb),.85); }
.a7lab.lav b { color: var(--lav-on); font-weight: 500; } .a7lab.lav { border-color: rgba(var(--lav-rgb),.45); }
/* room card */
.a7room { position: absolute; z-index: 12; left: 30px; bottom: calc(var(--dock) + 22px); width: min(380px, calc(100% - 60px)); padding: 16px 18px 14px; border-radius: 18px; background: rgba(var(--card-rgb),.95); border: 1px solid rgba(var(--line-rgb),.2); box-shadow: 0 24px 50px rgba(var(--shadow-rgb),.45); display: none; }
.a7room.on { display: block; }
.a7.roomopen .a7cap { opacity: 0; }
.a7room .x { position: absolute; right: 10px; top: 10px; width: 30px; height: 30px; border-radius: 50%; border: 1px solid var(--line); background: transparent; color: var(--muted); cursor: pointer; font: 16px/1 var(--sans); }
.a7room .k { font: 500 12px/1.2 var(--sans); color: var(--haze-txt); margin: 0 0 6px; }
.a7room h3 { font: 400 20px/1.2 var(--serif); margin: 0 34px 10px 0; }
.a7room .st { display: inline-flex; align-items: center; gap: 8px; height: 28px; padding: 0 12px; border-radius: 999px; font: 500 12.5px/1 var(--sans); margin: 0 0 10px; }
.a7room .st.safe { background: rgba(var(--safe-rgb),.16); color: var(--safe-on); } .a7room .st.caution { background: rgba(var(--caution-rgb),.16); color: var(--caution-on); } .a7room .st.noentry { background: rgba(var(--danger-rgb),.18); color: var(--danger-on); } .a7room .st.unseen { background: rgba(var(--haze-rgb),.2); color: var(--haze-on); }
.a7room .why { font: 13.5px/1.45 var(--sans); color: rgba(var(--fg-rgb),.88); margin: 0 0 12px; }
.a7room dl { display: grid; grid-template-columns: repeat(3, 1fr); gap: 10px 12px; margin: 0; }
.a7room dt { font: 500 15px/1.1 var(--mono); color: var(--paper); } .a7room dd { margin: 3px 0 0; font: 11.5px/1.25 var(--sans); color: var(--faint); }
.a7room .truth { margin: 12px 0 0; padding: 10px 12px; border-radius: 10px; background: rgba(var(--lav-rgb),.1); border: 1px solid rgba(var(--lav-rgb),.25); font: 12.5px/1.4 var(--sans); color: rgba(var(--fg-rgb),.86); }
.a7room .truth b { color: var(--lav-on); font-weight: 500; }
/* scorecard (end card) */
.a7rep .card { width: min(600px, 100%); }
.a7score { display: grid; gap: 8px; margin: 0 0 16px; }
.a7score .row2 { display: grid; grid-template-columns: 1fr auto auto; gap: 12px; align-items: baseline; padding: 10px 12px; border-radius: 12px; background: rgba(var(--fg-rgb),.04); border: 1px solid rgba(var(--line-rgb),.1); }
.a7score .row2.hl { background: rgba(var(--teal-rgb),.08); border-color: rgba(var(--teal-rgb),.28); }
.a7score .row2.miss { background: rgba(var(--danger-rgb),.08); border-color: rgba(var(--danger-rgb),.3); }
.a7score .n { font: 13.5px/1.35 var(--sans); color: rgba(var(--fg-rgb),.9); } .a7score .n small { display: block; font: 11.5px/1.35 var(--sans); color: var(--faint); margin-top: 2px; }
.a7score .v { font: 500 18px/1 var(--mono); color: var(--paper); text-align: right; white-space: nowrap; }
.a7score .tg { font: 11.5px/1.2 var(--mono); color: var(--faint); text-align: right; white-space: nowrap; min-width: 82px; }
.a7score .ok { color: var(--safe-txt); } .a7score .bad { color: var(--danger-txt); }
.a7rep .note2 { font: 12.5px/1.45 var(--sans); color: var(--faint); margin: 0 0 6px; }
/* mode picker: three cards */
.a7grid3 { display: grid; grid-template-columns: repeat(3, minmax(0, 1fr)); gap: 16px; }
@media (max-width: 1100px) { .a7grid3 { grid-template-columns: repeat(2, minmax(0, 1fr)); } }
@media (max-width: 760px) {
  .a7grid3 { grid-template-columns: 1fr; gap: 12px; }
  .a7chipsim { left: 8px; top: calc(var(--top) + 6px); height: 24px; font-size: 11px; padding: 0 9px; }
  .a7clock { left: 8px; top: calc(var(--top) + 36px); min-width: 0; padding: 6px 9px; } .a7clock .t { font-size: 15px; } .a7clock .s { display: none; }
  .a7floors { left: 8px; right: auto; top: calc(var(--top) + 52svh - 42px); transform: none; flex-direction: row; padding: 3px; gap: 1px; } .a7floors .k { display: none; } .a7floors button { width: 34px; height: 28px; font-size: 11px; }
  .a7tog { right: 8px; bottom: auto; top: calc(var(--top) + 52svh - 44px); } .a7tog .k { display: none; }
  .a7room { left: 8px; right: 8px; width: auto; bottom: 8px; top: auto; position: fixed; }
  .a7score .row2 { grid-template-columns: 1fr auto; } .a7score .tg { grid-column: 2; }
}

.a7cards .idle { display: none; pointer-events: auto; flex: none; width: 82vw; max-width: 330px; padding: 12px 14px; border-radius: 16px; background: rgba(var(--panel2-rgb),.55); border: 1px dashed rgba(var(--line-rgb),.18); }
.a7cards:has(.a7card) .idle { display: none !important; }
.a7cards .idle h4 { margin: 0 0 4px; font: 400 17px/1.2 var(--serif); } .a7cards .idle p { margin: 0; font: 12.5px/1.45 var(--sans); color: var(--muted); }
@media (max-width: 760px) { .a7cards .idle { display: block; } .a7cards:has(.a7card) .idle { display: none; } }
/* the failure card: four quantities with a plain line each */
.a7card[data-card="swarm"]:first-child canvas { height: 116px; }
.a7card .labs { display: flex; flex-wrap: wrap; gap: 6px; margin-top: 9px; } .a7card .labs .lab { margin-top: 0; }
.a7card .q4 { display: grid; gap: 7px; padding: 9px 10px; border-radius: 10px; background: rgba(var(--well-rgb),.45); }
.a7card .q4 .r { display: grid; grid-template-columns: 1fr auto; gap: 1px 10px; align-items: baseline; }
.a7card .q4 .n { font: 12.5px/1.25 var(--sans); color: var(--paper); } .a7card .q4 b { font: 500 13px/1.2 var(--mono); color: var(--heat-txt); white-space: nowrap; }
.a7card .q4 small { grid-column: 1 / -1; font: 11.5px/1.3 var(--sans); color: var(--faint); }
.a7card:not(:first-child) .q4 small { display: none; }
/* the before / after swipe */
.a7swipe { position: absolute; inset: 0; z-index: 4; pointer-events: none; display: none; }
.a7swipe.on { display: block; }
.a7swipe .ln { position: absolute; top: 0; bottom: 0; width: 56px; margin-left: -28px; pointer-events: auto; cursor: ew-resize; touch-action: none; }
.a7swipe .ln::before { content: ""; position: absolute; top: 0; bottom: 0; left: 27px; width: 2px; background: rgba(var(--fg-rgb),.85); box-shadow: 0 0 0 1px rgba(var(--panel-rgb),.35), 0 0 14px rgba(var(--teal-rgb),.5); }
.a7swipe .hd { position: absolute; top: 50%; width: 46px; height: 46px; margin: -23px 0 0 -23px; border-radius: 50%; border: 1px solid rgba(var(--fg-rgb),.7); background: rgba(var(--panel-rgb),.82); color: var(--paper); display: grid; place-items: center; cursor: ew-resize; pointer-events: auto; touch-action: none; box-shadow: 0 8px 22px rgba(var(--shadow-rgb),.45); padding: 0; }
.a7swipe .hd svg { width: 22px; height: 22px; }
.a7swipe .hd::after { content: attr(data-hint); position: absolute; top: 52px; left: 50%; transform: translateX(-50%); white-space: nowrap; font: 500 12px/1 var(--sans); color: var(--paper); background: rgba(var(--panel-rgb),.78); padding: 6px 9px; border-radius: 999px; opacity: 0; transition: opacity .3s; }
.a7swipe.hint .hd::after { opacity: 1; }
.a7swipe .lb { position: absolute; top: calc(var(--top) + 86px); font: 500 12.5px/1 var(--sans); color: var(--paper); background: rgba(var(--panel-rgb),.7); border: 1px solid var(--line); padding: 7px 10px; border-radius: 999px; white-space: nowrap; }
.a7swipe .lb.l { transform: translateX(calc(-100% - 12px)); } .a7swipe .lb.r { transform: translateX(12px); }
.a7swipe .lb.l i, .a7swipe .lb.r i { display: inline-block; width: 7px; height: 7px; border-radius: 50%; margin-right: 6px; vertical-align: 1px; }
@media (max-width: 760px) { .a7swipe .lb { top: auto; bottom: 62px; font-size: 11.5px; padding: 6px 9px; } .a7swipe .lb.l { left: 8px !important; transform: none; } .a7swipe .lb.r { left: auto !important; right: 8px; transform: none; } .a7swipe .hd { width: 52px; height: 52px; margin: -26px 0 0 -26px; } }
.a7cards { overflow-anchor: none; }
/* room card: how close to failure */
.a7room .fq { margin: 12px 0 0; padding: 10px 12px; border-radius: 10px; background: rgba(var(--heat-rgb),.06); border: 1px solid rgba(var(--heat-rgb),.2); }
.a7room .fq h5 { margin: 0 0 7px; font: 500 12px/1.2 var(--sans); color: var(--heat-txt); }
.a7room .fq dl { grid-template-columns: repeat(2, 1fr); gap: 8px 12px; }
/* end card: two panels */
.a7rep .tabs { display: flex; gap: 6px; margin: 0 0 14px; padding: 4px; border-radius: 999px; background: rgba(var(--well-rgb),.5); border: 1px solid var(--line); width: max-content; max-width: 100%; }
.a7rep .tabs button { height: 32px; padding: 0 14px; border-radius: 999px; border: 0; background: transparent; color: var(--muted); font: 500 13px/1 var(--sans); cursor: pointer; white-space: nowrap; }
.a7rep .tabs button.on { background: rgba(var(--teal-rgb),.16); color: var(--paper); }
.a7rep .pane[hidden] { display: none; }
.a7rep .cmd { display: grid; gap: 10px; }
.a7rep .cmd section { padding: 10px 12px; border-radius: 12px; background: rgba(var(--well-rgb),.42); border: 1px solid rgba(var(--line-rgb),.1); }
.a7rep .cmd h5 { margin: 0 0 6px; font: 500 12.5px/1.2 var(--sans); color: var(--haze-txt); }
.a7rep .cmd p { margin: 0; font: 13px/1.45 var(--sans); color: rgba(var(--fg-rgb),.88); }
.a7rep .cmd p + p { margin-top: 4px; }
.a7rep .cmd b { font-family: var(--mono); font-weight: 500; color: var(--paper); }
.a7rep .cmd .chips { display: flex; flex-wrap: wrap; gap: 6px; margin-top: 6px; }
.a7rep .cmd .chips span { font: 12px/1 var(--sans); padding: 6px 9px; border-radius: 999px; background: rgba(var(--line-rgb),.08); color: rgba(var(--fg-rgb),.86); }
.a7rep .cmd .chips span.noentry { background: rgba(var(--danger-rgb),.16); color: var(--danger-on); } .a7rep .cmd .chips span.caution { background: rgba(var(--caution-rgb),.14); color: var(--caution-on); } .a7rep .cmd .chips span.safe { background: rgba(var(--safe-rgb),.14); color: var(--safe-on); } .a7rep .cmd .chips span.unseen { background: rgba(var(--haze-rgb),.2); color: var(--haze-on); }
.a7rep .cmd .draft { font: 12.5px/1.4 var(--sans); color: var(--faint); margin: 2px 0 0; }
.a7.test *, .a7.test *::before, .a7.test *::after { transition: none !important; animation: none !important; }
@media (prefers-reduced-motion: reduce) { .a7 * { transition-duration: .01s !important; animation: none !important; } }
`;
