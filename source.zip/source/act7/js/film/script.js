// The film, written from the case: seven chapters (about three and a half minutes at 1x), each made of segments that say which overlays the
// World lens shows, how dim the clay gets, which cards are up and where the camera goes; captions are one plain sentence
// each, with the numbers this run measured. Everything is a pure function of the case, so scrubbing is exact.
import { failureOf } from './failure.js';
// the floor the behaviour shot cuts at: the one with the lowest phi_swarm (else the worst forecast miss, else the first)
export const behaviourLevel = (W) => { const q = W.drops[0] || W.forecast.misses[0]; return q ? Math.max(0, Math.min(3, Math.floor(q.p[1] / 3))) : 1; };
const FLOOR = ['ground', 'first', 'second', 'third', 'roof'];
const pct = (v) => `${Math.round(v * 100)} %`;
const pct1 = (v) => (v > 0 && v < 0.01 ? 'Under 1 %' : `${Math.round(v * 100)} %`);
const m3 = (v) => (v >= 100 ? `${Math.round(v)} m³` : `${v.toFixed(1)} m³`);
export const mmss = (s) => `${String(Math.floor(s / 60)).padStart(2, '0')}:${String(Math.floor(s % 60)).padStart(2, '0')}`;
const tApply = (T, x, y, z) => { const R = T.R; return [R[0] * x + R[1] * y + R[2] * z + T.t[0], R[3] * x + R[4] * y + R[5] * z + T.t[1], R[6] * x + R[7] * y + R[8] * z + T.t[2]]; };

// a few places the camera and the labels need, from the case
export function anchorsOf(C) {
  const g = C.g, L = C.change.labels, { nx, nz } = g; let n = 0, sx = 0, sy = 0, sz = 0, top = 0;
  for (let c = 0; c < g.N; c += 3) { const l = L[c]; if (l !== 3 && l !== 4) continue; const i = c % nx, r = (c - i) / nx, k = r % nz, j = (r - k) / nz; const y = g.y0 + (j + .5) * g.vox; sx += g.x0 + (i + .5) * g.vox; sy += y; sz += g.z0 + (k + .5) * g.vox; n++; if (y > top) top = y; }
  const debris = n ? [sx / n, Math.max(1, sy / n), sz / n] : [0, 1, C.model.dims.D / 2 + 1];
  // the most-tilted storey and which way its top went
  let tilted = 0; C.storeys.forEach((f, s) => { if (s < 4 && (f.tilt || 0) > (C.storeys[tilted].tilt || 0)) tilted = s; });
  const F = C.storeys[tilted], R = F.T.R, hx = R[1], hz = R[7], hl = Math.hypot(hx, hz) || 1;
  const dirWord = Math.abs(hz) > Math.abs(hx) ? (hz > 0 ? 'the street' : 'the back yard') : (hx > 0 ? 'the east end' : 'the west end');
  const topOf = tApply(F.T, 0, (tilted + 1) * 3, 0);
  const pk = C.pockets.list[0]; const pocket = pk ? pk.centre : debris;
  const fire = C.thermal.passes[2].hotCentre || C.post.fire.pos, cold = C.thermal.passes[2].coldCentre || (C.post.tank && C.post.tank.pos) || [0, 12, 0];
  const podC = C.pods.list.length ? C.pods.list.reduce((a, p) => [a[0] + p.pos[0] / C.pods.list.length, a[1] + p.pos[1] / C.pods.list.length, a[2] + p.pos[2] / C.pods.list.length], [0, 0, 0]) : [0, 4, 0];
  const tg = C.confidence.targets || []; const refly = tg.length ? [0, 1, 2].map((i) => tg.reduce((a, t) => a + t.c[i], 0) / tg.length) : [0, 4, 0];
  // where to look from to see the damage: the debris side for a collapse, side-on to the lean for a leaning block
  const moved = C.mode === 'pancake' ? debris : null;   // a soft storey and a lean read best side-on to the tilt
  const damageAz = moved ? Math.atan2(moved[0], moved[2] + 0.001) : Math.atan2(hx / hl, hz / hl) + Math.PI / 2;
  const ts = C.storeys.slice(0, 4).map((f) => f.tilt || 0), mx = Math.max(...ts), ln = ts.map((t) => t > mx * .5 && t > .3);
  const leanWho = ln.every(Boolean) ? 'The whole block' : !ln[0] && ln[1] && ln[2] && ln[3] ? 'Everything above the ground floor' : `The ${FLOOR[tilted]} floor`;
  return { cold, leanWho, damageAz, debris, debrisTop: top, tilted, tiltDeg: F.tilt || 0, leanDir: [hx / hl, 0, hz / hl], dirWord, tiltTop: topOf, pocket, fire, pods: podC, refly };
}
// which storey to cut the floors above for the rooms: the lowest one with something worth seeing, never under debris
function roomLevel(C) {
  // the storey whose rooms have the most varied statuses (a mix of safe, caution, no entry reads best)
  let best = 1, bs = -1; for (let s = 0; s < 4; s++) { const st = new Set(C.rooms.filter((r) => C.model.rooms[r.id].storey === s).map((r) => r.status)); const sc = st.size + (s === 1 ? .3 : 0); if (sc > bs) { bs = sc; best = s; } }
  return best;
}
export function buildScript(C, names = { base: 'teal', post: 'rose', added: 'rose', empty: 'lavender' }) {
  const N = names;   // the theme's names for its colours (dusk: teal, rose, lavender)
  const A = anchorsOf(C), sc = C.score, d = C.debris, ck = C.clock, pk = C.pockets.list, mode = C.mode;
  const regErr = C.reg.errStart, drift = C.reg.drift; const driftCm = Math.hypot(...drift.t) * 100, driftDeg = Math.acos(Math.max(-1, Math.min(1, (drift.R[0] + drift.R[4] + drift.R[8] - 1) / 2))) * 180 / Math.PI;
  const lvl = roomLevel(C);
  const nSafe = C.rooms.filter((r) => r.status === 'safe').length, nNo = C.rooms.filter((r) => r.status === 'noentry').length, nCau = C.rooms.filter((r) => r.status === 'caution').length, nUn = C.rooms.filter((r) => r.status === 'unseen').length;
  const gap = pk.filter((p) => p.kind === 'gap').length, slab = pk.length - gap;
  const A1 = C.aftershocks[0], FQ = failureOf(C, 1), SW = C.swarm;
  const ctr = [0, 5.2, 0], site = C.model.site;
  // the wide shots look at the damage, but never straight down a party wall at a neighbour: keep within 50 degrees of the street or the back
  let dAz = A.damageAz; { const f = Math.cos(dAz) >= 0 ? 0 : Math.PI; let d = Math.atan2(Math.sin(dAz - f), Math.cos(dAz - f)); d = Math.max(-0.87, Math.min(0.87, d)); if (Math.abs(d) < 0.25) d = d < 0 ? -0.35 : 0.35; dAz = f + d; }
  // ------------------------------------------------------------------ chapters: segments and captions in seconds from each chapter's start
  // a segment says which overlays the World lens shows, how dim the clay gets, which cards are up and where the camera goes
  const S = (t0, t1, o) => ({ t0, t1, layers: {}, dim: 0, cards: [], ...o });
  const CH = [];
  const chapter = (id, title, label, len, segs, caps, beats = {}) => CH.push({ id, title, label, len, segs, caps, beats });
  chapter('touchdown', 'Touchdown', 'Touchdown', 21, [
    S(0, 7, { shot: { kind: 'wide', az: dAz, el: .55, dist: 46, drift: .018, target: ctr } }),
    S(7, 16, { layers: { packets: 1 }, cards: ['station'], shot: { kind: 'focus', target: [site.table.x * .6, 2.2, site.table.z * .7], az: .35, el: .38, dist: 26, drift: .012 } }),
    S(16, 21, { layers: { packets: 1 }, cards: ['station'], shot: { kind: 'focus', target: [site.anchor.x - .6, 6.3, site.anchor.z + 1], az: .45, el: .08, dist: 23, drift: .01 } }),
  ], [
    [0, 'The search is certified. Now the building itself has to be judged.'],
    [4, 'An ordinary apartment block; the same steps run on schools, hospitals and other critical sites.'],
    [8, 'The drones land by the anchor robot. Each carries a tilting LiDAR, an RGB camera and a thermal camera.'],
    [12, 'In flight they already shared one coverage map, merged in any order (a CRDT). Now the full-resolution scans come off.'],
    [16.5, 'Above the anchor, its tethered drone stays up as overwatch. The clock started at touchdown.'],
  ], { packets0: 6.5, offload0: 6, offload1: 19, labels1: 15, tether0: 16, tether1: 21 });
  chapter('register', 'Two scans, one frame', 'Two scans', 20, [
    S(0, 9, { layers: { base: 1, post: 1 }, dim: .85, cards: ['reg'], shot: { kind: 'focus', az: .62, el: .42, dist: 30, drift: .006, target: [-C.model.dims.L / 2 - 1, 4, C.model.dims.D / 2 - 2] } }),
    S(9, 20, { layers: { base: 1, post: 1 }, dim: .85, cards: ['reg'], shot: { kind: 'focus', az: .5, el: .4, dist: 24, drift: .006, target: [-C.model.dims.L / 2 - 1, 4, C.model.dims.D / 2 - 2] } }),
  ], [
    [0, `The survey made before the disaster (${N.base}) and today’s scan (${N.post}) do not line up yet.`],
    [4, `The drones’ map drifted ${Math.round(driftCm)} cm and ${driftDeg.toFixed(1)}° while they flew without GPS.`],
    [8.3, 'The anchor robot’s position gives a first guess; then the two scans are pulled together.'],
    [12.5, 'Only what did not move is used: the ground, the boundary walls, the neighbours.'],
    [16.5, `Aligned to within ${Math.max(0.1, C.reg.err.cm).toFixed(1)} cm of the truth. The leftover misfit feeds the confidence map.`],
  ], { regRaw: 3.5, regGuess: 6.5, regDone: 15, registered: 18 });
  const drop = -Math.min(...C.storeys.slice(1, 4).map((f, i) => tApply(f.T, 0, (i + 1) * 3 + 1.5, 0)[1] - ((i + 1) * 3 + 1.5)));
  chapter('change', 'What changed', 'What changed', 32, [
    S(0, 6, { swipe: true, cards: ['change'], shot: { kind: 'wide', az: dAz, el: .42, dist: 40, drift: .006, target: ctr } }),
    S(6, 18, { layers: { change: 1, ghost: .5 }, dim: .7, cards: ['station', 'change'], shot: { kind: 'wide', az: dAz, el: .5, dist: 42, drift: .014, target: ctr } }),
    S(18, 32, { layers: { debris: 1, ghost: .35 }, dim: .55, cards: ['change', 'debris'], shot: { kind: 'cutaway', level: 0, target: [A.debris[0] * .7, .8, A.debris[2] * .7], az: dAz, el: .85, dist: 27, drift: .012 } }),
  ], [
    [0, 'Drag the divider to compare: the survey on the left, the building today on the right.'],
    [6, `Voxel by voxel, in ${Math.round(C.g.vox * 100)} cm cubes: newly filled is ${N.added}, newly empty is ${N.empty}.`],
    [12, `First change map at ${mmss(ck.changeMap)} after touchdown; the target is under 10 minutes.`],
    ...(drop > 0.3 ? [[15, `The upper floors dropped ${drop.toFixed(1)} m, so each shows twice: ${N.empty} where it was, ${N.added} where it is now.`]] : []),
    [18, 'Debris comes as a range, because the inside of a pile is never seen.'],
    [23, `About ${m3(d.estimate)} of debris, roughly ${d.trucks} truck load${d.trucks === 1 ? '' : 's'}; the true volume was ${m3(sc.debrisTruth)}.`],
    [27.5, sc.iou > 0.7 ? `Against the real damage the change map scores ${sc.iou.toFixed(2)} (target over 0.7).` : `The change map scores ${sc.iou.toFixed(2)} against the real damage, under the 0.7 target: debris hidden inside the pile counts against it.`],
  ], { swipe0: 0, swipe1: 6, reveal0: 6, reveal1: 11, firstMap: 12, debris0: 18, debris1: 32 });
  chapter('walls', 'How the walls stand', 'The walls', 44, [
    S(0, 10, { layers: { arrows: 1, cracks: 1 }, dim: .3, cards: ['phi'], shot: { kind: 'focus', target: [0, 5, 0], az: dAz, el: .3, dist: 36, drift: .01 } }),
    S(10, 28, { layers: { order: 1, cracks: .6 }, dim: .45, cards: ['phi', 'xi'], shot: { kind: 'focus', target: ctr, az: .7, el: .35, dist: 34, drift: .014 } }),
    S(28, 38, { layers: { rooms: 1, arrows: .5 }, dim: .4, cards: ['phi', 'xi'], shot: { kind: 'cutaway', level: lvl, target: [0, lvl * 3 + 1, 0], az: .55, el: .95, dist: 30, drift: .01 }, roomLabels: lvl }),
    S(38, 44, { layers: { routes: 1, rooms: .25 }, dim: .55, cards: ['xi', 'routes'], shot: { kind: 'cutaway', level: 0, target: [0, 1, 0], az: .6, el: 1.05, dist: 29, drift: .01 } }),
  ], [
    [0, 'A plane is fitted to every wall, and its tilt compared with the same wall before.'],
    [4.5, A.tiltDeg > 0.3 ? `${A.leanWho} now leans ${A.tiltDeg.toFixed(1)}° toward ${A.dirWord}.` : 'The floors that are still standing are close to plumb.'],
    [7.5, 'Cracks are marked where a camera passed within 4 m; about 8 in 10 get caught.'],
    [10, 'Wall order φ_wall: the surface normals of a sound wall all point one way; damage scatters them.'],
    [14, 'It is the same order parameter that keeps the swarm at its tipping point, pointed at the walls instead of the drones.'],
    [18.5, 'Our hypothesis: a structure holds a measurable order that collapses at a threshold. We reuse the threshold tools; we don’t claim buildings are flocks.'],
    [23.5, C.condition.clusters.sizes.length ? `Damaged patches cluster about ${C.condition.clusters.xi.toFixed(1)} m across.` : 'No damaged patches cluster on the walls that were seen.'],
    [28, `Every room gets a draft status from simple, cautious rules: ${nSafe} safe, ${nCau} caution, ${nNo} no entry${nUn ? `, ${nUn} never seen` : ''}.`],
    [31.5, 'Space that was never seen is never called safe.'],
    [34.5, 'These are drafts: the incident commander makes the call (Act 8).'],
    [38, 'The access graph: where a person still fits, and which routes the collapse cut.'],
  ]);
  // swarm behaviour as data: phi_swarm and the forecast, in words
  const F = SW.forecast, nDrop = SW.drops.length;
  const phiLine = SW.phiSamples < 30 ? 'The drones seldom flew close enough together to measure φ_swarm, how well nearby drones’ headings agree.'
    : nDrop ? `φ_swarm, how well nearby drones’ headings agree, was ${SW.phiMedian.toFixed(2)} for most of the flight and fell under 0.5 at ${nDrop === 1 ? 'one spot' : `${nDrop} spots`} where they split up; the lowest, ${SW.phiLow.toFixed(2)}, is here.`
    : `φ_swarm, how well nearby drones’ headings agree, stayed near ${SW.phiMedian.toFixed(2)}; it never fell below 0.5 where it was measured.`;
  const fcLine = !F.made ? 'The speed forecast was skipped: the log had no pattern a small model could use, so nothing is claimed.'
    : F.skill >= 0.1 ? `A small Koopman forecast of the swarm’s speed came ${Math.round(F.skill * 100)} % closer than assuming no change. Where it missed most (${N.added}), the building surprised the swarm.`
    : `A small Koopman forecast of the swarm’s speed did no better than assuming no change. Its biggest misses (${N.added}) still show where the building surprised the swarm.`;
  chapter('pockets', 'Where someone could be', 'Pockets', 36, [
    S(0, 12, { layers: { pockets: 1, debris: .15 }, dim: .7, cards: ['pockets'], shot: { kind: 'cutaway', level: pk.length ? Math.max(0, Math.min(3, Math.floor((A.pocket[1] + .3) / 3))) : 0, target: pk.length ? A.pocket : [0, 1, 0], az: .45, el: .85, dist: pk.length ? 20 : 30, drift: .012 } }),
    S(12, 18, { layers: { thermal: .3, heat: 1 }, dim: .6, cards: ['pockets', 'thermal'], shot: { kind: 'focus', target: A.fire, az: Math.atan2(A.fire[0], A.fire[2] + 0.001) || .4, el: .32, dist: 14, drift: .01 } }),
    S(18, 23, { layers: { thermal: .3, heat: 1 }, dim: .6, cards: ['thermal'], shot: { kind: 'focus', target: A.cold, az: Math.atan2(A.cold[0], A.cold[2] + 0.001) || .6, el: .8, dist: 15, drift: .01 } }),
    S(23, 36, { layers: { behaviour: 1 }, dim: .55, cards: ['thermal', 'swarm'], shot: { kind: 'cutaway', level: behaviourLevel(SW), az: .4, el: 1.1, dist: 34, drift: .01, target: [0, behaviourLevel(SW) * 3 + 1, 0] } }),
  ], [
    [0, 'Pockets: space a person could be in that no drone could enter.'],
    [5, pk.length ? `${pk.length} found: ${gap ? `${gap} seen through a gap` : ''}${gap && slab ? ', ' : ''}${slab ? `${slab} possible under a leaning slab, inferred from its shape` : ''}.` : 'No enclosed pocket big enough for a person was found.'],
    [8, sc.voids ? `Checked against the true voids of this collapse: ${sc.voidsFound} of ${sc.voids} found${sc.falsePockets ? (pk.length === 1 ? ', and the one pocket claimed is not a real void' : (sc.falsePockets === 1 ? `, and 1 of the ${pk.length} is not a real void` : `, and ${sc.falsePockets} of the ${pk.length} are not real voids`)) : ''}.` : pk.length ? `This collapse left no enclosed void, so all ${pk.length} are false alarms; the search would check them and find nothing.` : 'This collapse left no enclosed void, and none was claimed.'],
    [12, 'Three thermal passes: a hot spot that grows between passes is a fire spreading.'],
    [15, C.thermal.spreading ? `The fire grew from ${C.thermal.passes[0].hotArea.toFixed(1)} to ${C.thermal.passes[2].hotArea.toFixed(1)} m² of hot surface between the first and third pass.` : 'The hot area stayed about the same between passes.'],
    [18, C.thermal.passes[2].coldArea > 0.3 ? `A cold patch that spreads is water: the burst roof tank, from ${C.thermal.passes[0].coldArea.toFixed(1)} to ${C.thermal.passes[2].coldArea.toFixed(1)} m².` : 'No cold patch: the water tank held.'],
    [23, 'Where the drones slowed, stalled or split during the search is data too: it shows what is passable.'],
    [27, phiLine],
    [31.5, fcLine],
  ], { fire0: 13, fire1: 17, cold0: 18.5, cold1: 22, behav0: 23, behav1: 36 });
  // how close to failure, in one sentence from the four quantities
  const fOrder = !Number.isFinite(FQ.phi.value) ? 'Too few walls were seen to measure their order.' : FQ.phi.value >= 0.9 ? `Most of the wall order holds (φ_wall ${FQ.phi.value.toFixed(2)}).` : `The walls have lost much of their order (φ_wall ${FQ.phi.value.toFixed(2)}).`;
  const fSpread = FQ.xi.verdict === 'few' ? (FQ.xi.n ? 'Too few damage clusters to tell whether damage is cascading.' : 'No damage clusters.') : FQ.xi.verdict === 'power' ? 'Damage sizes follow a power law, a sign of cascading.' : 'Damage stays in local patches.';
  const fPush = FQ.sus.n ? `The aftershock took the pods from ${pct(FQ.sus.before)} to ${pct(FQ.sus.after)} stiffness lost.` : 'No pod was dropped, so its response to a push is unknown.';
  chapter('moving', 'Is it still moving?', 'Still moving?', 38, [
    S(0, 9, { layers: { pods: 1 }, dim: .1, cards: ['freq'], shot: { kind: 'focus', target: A.pods, az: Math.atan2(A.pods[0], A.pods[2]) || .5, el: .3, dist: 26, drift: .012 } }),
    S(9, 26, { layers: { pods: 1, arrows: .6 }, dim: .15, cards: ['freq', 'tau'], shot: { kind: 'wide', az: dAz, el: .42, dist: 40, drift: .012, target: ctr }, shockAt: 11 }),
    S(26, 38, { layers: { pods: 1, order: .5 }, dim: .3, cards: ['tau', 'fail'], shot: { kind: 'wide', az: dAz + .25, el: .38, dist: 38, drift: .012, target: ctr } }),
  ], [
    [0, `Vibration pods are dropped onto ${C.pods.list.length} standing walls; each listens for its wall’s own frequency.`],
    [5, 'A 10 % drop in frequency means about 19 % of the stiffness is gone.'],
    [11, 'An aftershock.'],
    [14, 'Quick repeat scans measure the extra tilt, then watch it creep back.'],
    [19, `It settles with a recovery time of ${A1.tau.toFixed(1)} minutes. If that grows after each aftershock, the block is nearing its limit.`],
    [23, 'Aftershocks fade over time (Omori’s law); Act 8 uses that to time re-entry.'],
    [26, 'How close is it to failure? Our four phase-transition quantities, measured on this block.'],
    [30.5, `${fOrder} ${fSpread} ${fPush}`],
    [34.5, 'Shake it again with the Aftershock button and watch the recovery time.'],
  ], { podsFly: 0, podsFlyLen: 11, podShow: 1.5, shock: 11, shockBtn: 16, fail0: 26 });
  chapter('trust', 'How much to trust it', 'Trust', 28, [
    S(0, 8, { layers: { confidence: 1 }, dim: .6, cards: ['conf'], shot: { kind: 'wide', az: .4, el: .45, dist: 40, drift: .014, target: ctr } }),
    S(8, 18, { layers: { confidence: 1, refly: 1 }, dim: .6, cards: ['conf'], shot: { kind: 'focus', target: A.refly, az: Math.atan2(A.refly[0], A.refly[2] + 0.001) || .7, el: .55, dist: 30, drift: .012 } }),
    S(18, 28, { layers: { truth: 1, truthRooms: .6, voids: 1 }, dim: .55, cards: ['conf', 'score'], shot: { kind: 'wide', az: dAz, el: .55, dist: 40, drift: .012, target: ctr } }),
  ], [
    [0, 'Every surface gets a confidence: seen often, from close, clear of smoke, well aligned.'],
    [4, (C.confidence.unseen || 0) < 0.0005 ? 'Every bit of surface the scans should reach was seen at least once.' : `${pct1(C.confidence.unseen)} of the surface was never seen at all; it stays at zero.`],
    [8, C.confidence.region ? `A short re-fly goes back to the weakest spots a drone can reach, from 2 to 3 m and several angles: there, confidence rises from ${pct(C.confidence.region.before)} to ${pct(C.confidence.region.after)}.` : 'No weak spot was within reach of a drone, so nothing was re-flown.'],
    ...(C.confidence.unreachableN ? [[13, `${C.confidence.unreachableN} weak spots, about ${Math.round(C.confidence.unreachableArea)} m² of surface, can’t be reached from the air: those are for a human to check.`]] : []),
    [18, 'Now the honest part: the same numbers against the known truth of this simulated collapse.'],
    [23, sc.falseSafe === 0 ? (sc.draftedSafe ? `False-safe rooms: none. No room drafted safe was truly damaged.` : 'False-safe rooms: none. No room was drafted safe, and none should have been.') : `False-safe rooms: ${sc.falseSafe}. That is a miss, shown here as it is.`],
  ], { refly0: 8, refly1: 18, after: 13 });
  // flatten to film seconds
  const chapters = [], segs = [], cap = [], B = {}; let t = 0;
  for (const ch of CH) {
    chapters.push({ id: ch.id, title: ch.title, label: ch.label, p0: t, p1: t + ch.len });
    for (const sg of ch.segs) { const o = { ...sg, t0: t + sg.t0, t1: t + sg.t1 }; if (sg.shockAt != null) o.shockAt = t + sg.shockAt; segs.push(o); }
    for (const [tt, text] of ch.caps) cap.push({ t: t + tt, text });
    B[ch.id] = [t, t + ch.len]; for (const [k, v] of Object.entries(ch.beats)) B[k] = t + v;
    t += ch.len;
  }
  B.podsFlyLen = 11;
  const dur = t;
  // ------------------------------------------------------------------ the ground-station clock (film seconds -> clock seconds after touchdown)
  const cm = ck.changeMap, mv = B.moving[0];
  const clockKeys = [[0, 0], [B.offload1, ck.offload], [B.registered, ck.register], [B.firstMap, cm], [B.walls[0], cm + 150], [B.pockets[0], cm + 420], [mv, cm + 840], [B.shock, cm + 900], [B.shock + 13, cm + 900 + 27 * 60], [B.moving[1], cm + 900 + 29 * 60], [dur, cm + 900 + 37 * 60]];
  const clockAt = (p) => { for (let i = 1; i < clockKeys.length; i++) if (p <= clockKeys[i][0]) { const [a, va] = clockKeys[i - 1], [b, vb] = clockKeys[i]; return va + (vb - va) * Math.max(0, (p - a) / (b - a)); } return clockKeys[clockKeys.length - 1][1]; };
  const clockNote = (p) => p < B.offload1 ? ['offloading 8 drones', false] : p < B.registered ? ['registering the scans', false] : p < B.firstMap ? ['mapping what changed', false] : [`first change map at ${mmss(cm)} (target under 10 min)`, cm >= 600];
  // registration animation: film seconds -> iteration (fractional), -1 = raw scan, 0 = starting guess
  const regAt = (p) => p < B.regRaw ? -1 : p < B.regGuess ? -1 + (p - B.regRaw) / (B.regGuess - B.regRaw) : p < B.regDone ? Math.min(1, (p - B.regGuess) / (B.regDone - B.regGuess)) * (C.reg.iters.length - 1) : C.reg.iters.length - 1;
  // the passes play twice: for the fire and again for the cold patch
  const passAt = (p) => (p < B.fire0 ? 0 : p < B.fire1 ? (p - B.fire0) / 2 : p < B.cold0 ? (p < B.cold0 - .5 ? 2 : 0) : p < B.cold1 ? (p - B.cold0) / 1.75 : 2);
  return { chapters, dur, segs, captions: cap, clockAt, clockNote, regAt, passAt, anchors: A, roomLevel: lvl, shockAt: B.shock, afterAt: B.after, beats: B, failure: FQ, events: [{ p: B.shock, color: 'var(--danger)' }, { p: B.firstMap, color: 'var(--teal)' }] };
}
