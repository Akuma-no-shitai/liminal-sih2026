// How close is it to failure? The deck's four phase-transition quantities, from what this run measured:
//   order parameter phi_wall  how much order remains: the mean nematic order S of the wall patches that were seen
//   correlation length xi     how far damage spreads: the size of connected damaged patches; a power law in their sizes
//                             would mean damage cascading rather than staying local
//   susceptibility            how strongly it responds to a push: the stiffness the pods' f0 drop says is gone, before
//                             and after the aftershock
//   relaxation time tau       how slowly it recovers: the tilt's recovery time after each aftershock; growing = nearing
//                             the threshold
// For the whole block, and for one room (its own walls, the pod on them, the moving part it sits in).
const mean = (a) => (a.length ? a.reduce((s, x) => s + x, 0) / a.length : NaN);
// a power-law check on the cluster sizes: the rank-size line in log-log against the same in semi-log (an exponential)
function powerLaw(sizes) {
  const n = sizes.length; if (n < 6) return { verdict: 'few', n };
  const fit = (xs, ys) => { const mx = mean(xs), my = mean(ys); let sxy = 0, sxx = 0, syy = 0; for (let i = 0; i < xs.length; i++) { sxy += (xs[i] - mx) * (ys[i] - my); sxx += (xs[i] - mx) ** 2; syy += (ys[i] - my) ** 2; } return { slope: sxy / (sxx || 1), r2: sxx && syy ? (sxy * sxy) / (sxx * syy) : 0 }; };
  const ly = sizes.map((_, i) => Math.log(i + 1)), pl = fit(sizes.map(Math.log), ly), ex = fit(sizes, ly);
  return { verdict: pl.r2 > 0.9 && pl.r2 > ex.r2 + 0.02 ? 'power' : 'local', n, r2: pl.r2, r2exp: ex.r2, slope: pl.slope };
}
export function failureOf(C, k = 1) {
  const cond = C.condition, ok = cond.patches.filter((p) => p.st === 'ok');
  const phi = { value: ok.length ? mean(ok.map((p) => p.S)) : NaN, n: ok.length, damaged: cond.clusters.damagedShare, low: ok.length ? Math.min(...ok.map((p) => p.S)) : NaN };
  const sizes = cond.clusters.sizes, xi = { value: cond.clusters.xi, n: sizes.length, biggest: sizes[0] || 0, ...powerLaw(sizes) };
  const pre = C.pods.reads, A = C.aftershocks.slice(0, Math.max(1, k)), post = A[A.length - 1] ? A[A.length - 1].reads : null;
  const loss = (rs) => rs.map((r) => Math.max(0, r.stiffLoss)).filter(Number.isFinite);
  const sus = { n: pre.length, before: mean(loss(pre)), after: post ? mean(loss(post)) : NaN, maxBefore: Math.max(0, ...loss(pre)), maxAfter: post ? Math.max(0, ...loss(post)) : NaN };
  sus.push = sus.after - sus.before;
  const taus = A.map((a) => ({ tau: a.tau, lo: a.tauLo, hi: a.tauHi, slowing: a.slowing }));
  const tau = { list: taus, value: taus.length ? taus[taus.length - 1].tau : NaN, growing: taus.some((t) => t.slowing), n: taus.length };
  return { phi, xi, sus, tau };
}
// the same for one room: its walls' order, the damage cluster touching them, a pod on one of them, and the relaxation
// time if the room sits in the part that moved. null fields do not apply here.
export function roomFailure(C, id, k = 1) {
  const room = C.model.rooms[id], walls = new Set(room.walls), cond = C.condition;
  const mine = cond.patches.filter((p) => walls.has(p.wall)), ok = mine.filter((p) => p.st === 'ok');
  const phi = ok.length ? { value: mean(ok.map((p) => p.S)), low: Math.min(...ok.map((p) => p.S)), n: ok.length } : null;
  const area = new Map(); for (const p of cond.patches) if (p.cluster >= 0) area.set(p.cluster, (area.get(p.cluster) || 0) + p.w * p.h);
  let big = 0; for (const p of mine) if (p.cluster >= 0) big = Math.max(big, area.get(p.cluster) || 0);
  const xi = big > 0 ? { value: Math.sqrt(big), area: big } : null;
  const pi = C.pods.list.findIndex((pd) => walls.has(pd.wall)), A = C.aftershocks[Math.max(1, k) - 1];
  const sus = pi >= 0 ? { pod: pi + 1, before: Math.max(0, C.pods.reads[pi].stiffLoss), after: A ? Math.max(0, A.reads[pi].stiffLoss) : NaN } : null;
  const f = C.storeys[room.storey], moved = f && !f.ident && (f.tilt || 0) > 0.3;
  const tau = moved && A ? { value: A.tau, growing: C.aftershocks.slice(0, Math.max(1, k)).some((a) => a.slowing) } : null;
  const n = [phi, xi, sus, tau].filter(Boolean).length;
  return n >= 2 || sus || tau ? { phi, xi, sus, tau } : null;
}
