// The director (adapted from Act 4): a small shot library and an automatic camera with critically damped moves;
// grabbing the view (drag, wheel, pinch) hands it to the user until they press "Director".
//  shots: wide (establishing orbit) | top (plan view) | focus (dolly to a point) | cutaway (focus with the floors above a
//  level hidden). A shot's `level` is the highest storey left standing in view (null: everything).
import * as THREE from 'three';

export function createDirector(camera, dom, { phone = false, onTake = () => {}, onCut = () => {} } = {}) {
  const pos = new THREE.Vector3(30, 22, 30), tgt = new THREE.Vector3(0, 4, 0), vPos = new THREE.Vector3(), vTgt = new THREE.Vector3();
  const wantPos = new THREE.Vector3(), wantTgt = new THREE.Vector3();
  let shot = { kind: 'wide' }, shotT = 0, center = new THREE.Vector3(0, 4, 0), radius = 16, user = false, omega = 1.2, snap = true, cutKey = '__';
  const uS = { az: 0, el: .5, dist: 40, tgt: new THREE.Vector3() };
  let fov = phone ? 50 : 38, viewOffset = 0, viewOffsetY = 0;
  const tmpA = new THREE.Vector3(), tmpB = new THREE.Vector3();
  function setScene(c, r) { center.copy(c); radius = r; snap = true; }
  const sph = (target, az, el, dist, out) => out.set(target.x + Math.cos(el) * Math.sin(az) * dist, target.y + Math.sin(el) * dist, target.z + Math.cos(el) * Math.cos(az) * dist);
  function setShot(s, { cut = false } = {}) {
    if (!s) return; if (shot === s && !cut) return;
    shot = s; shotT = 0; if (cut) snap = true;
    omega = s.omega ?? 1.1;
    const lvl = s.kind === 'cutaway' ? (s.level ?? 0) : (s.level ?? null);
    const key = String(lvl); if (key !== cutKey) { cutKey = key; onCut(lvl); }
  }
  function target() {
    const s = shot, t = shotT, drift = (s.drift ?? .01) * t;
    const tg = s.target ? tmpA.set(s.target[0], s.target[1], s.target[2]) : tmpA.copy(center);
    wantTgt.copy(tg);
    switch (s.kind) {
      case 'top': sph(tg, (s.az ?? 0) + drift * .3, s.el ?? 1.38, s.dist ?? radius * 2.4, wantPos); break;
      case 'focus': case 'cutaway': sph(tg, (s.az ?? .7) + drift, s.el ?? .55, s.dist ?? 22, wantPos); break;
      default: sph(tg, (s.az ?? .78) + drift, s.el ?? .5, s.dist ?? radius * 2.6, wantPos);
    }
  }
  function spring(x, v, goal, dt, w) {
    const ax = w * w * (goal.x - x.x) - 2 * w * v.x, ay = w * w * (goal.y - x.y) - 2 * w * v.y, az = w * w * (goal.z - x.z) - 2 * w * v.z;
    v.x += ax * dt; v.y += ay * dt; v.z += az * dt; x.x += v.x * dt; x.y += v.y * dt; x.z += v.z * dt;
  }
  function update(dt, shake = 0) {
    shotT += dt;
    if (!user) {
      target();
      if (snap) { pos.copy(wantPos); tgt.copy(wantTgt); vPos.set(0, 0, 0); vTgt.set(0, 0, 0); snap = false; }
      else { const steps = Math.max(1, Math.ceil(dt / .016)); const h = dt / steps; for (let s = 0; s < steps; s++) { spring(pos, vPos, wantPos, h, omega); spring(tgt, vTgt, wantTgt, h, omega * 1.25); } }
    } else {
      const f60 = Math.min(4, dt * 60); uS.az += uVel.az * f60; uS.el = THREE.MathUtils.clamp(uS.el + uVel.el * f60, .05, 1.52); uVel.az *= Math.pow(.02, dt); uVel.el *= Math.pow(.02, dt);
      tgt.lerp(uS.tgt, 1 - Math.exp(-dt * 10)); sph(tgt, uS.az, uS.el, uS.dist, tmpB); pos.lerp(tmpB, 1 - Math.exp(-dt * 12));
    }
    if (pos.y < 0.6) pos.y = 0.6;
    camera.position.copy(pos);
    if (shake > .001) { const t = performance.now() * .001, k = shake * Math.min(1.2, pos.distanceTo(tgt) * .02); camera.position.x += Math.sin(t * 37.1) * k; camera.position.y += Math.sin(t * 41.7 + 1) * k * .6; camera.position.z += Math.sin(t * 29.3 + 2) * k; }
    camera.lookAt(tgt);
    camera.near = Math.max(.1, Math.min(1, pos.distanceTo(tgt) * .02)); camera.far = 800; camera.fov = fov;
    applyOffset();
  }
  let fullW = 1, fullH = 1;
  function applyOffset() { if (viewOffset || viewOffsetY) camera.setViewOffset(fullW, fullH, viewOffset, viewOffsetY, fullW, fullH); else camera.clearViewOffset(); camera.updateProjectionMatrix(); }
  function setFrame(w, h, offsetX, offsetY = 0) { fullW = w; fullH = h; viewOffset = offsetX; viewOffsetY = offsetY; camera.aspect = w / h; applyOffset(); }
  // ------------------------------------------------------------------ user takeover
  const uVel = { az: 0, el: 0 };
  const take = () => {
    if (user) return; user = true;
    const d = tmpA.copy(pos).sub(tgt); uS.dist = d.length(); uS.el = Math.asin(THREE.MathUtils.clamp(d.y / Math.max(1e-6, uS.dist), -1, 1)); uS.az = Math.atan2(d.x, d.z); uS.tgt.copy(tgt);
    onTake(true);
  };
  const ptrs = new Map(); let lastPinch = 0, lastMid = null, btn = 0, moved = 0;
  const onDown = (e) => { if (e.button === 1) return; ptrs.set(e.pointerId, { x: e.clientX, y: e.clientY }); btn = e.button; dom.setPointerCapture && dom.setPointerCapture(e.pointerId); lastPinch = 0; lastMid = null; moved = 0; };
  const onMove = (e) => {
    const p = ptrs.get(e.pointerId); if (!p) return; const dx = e.clientX - p.x, dy = e.clientY - p.y; p.x = e.clientX; p.y = e.clientY; moved += Math.abs(dx) + Math.abs(dy);
    if (moved < 5) return;
    take();
    if (ptrs.size === 1 && btn === 0 && !e.shiftKey) { uVel.az = -dx * .005; uVel.el = dy * .004; }
    else if (ptrs.size === 1) pan(dx, dy);
    else if (ptrs.size === 2) {
      const [a, b] = [...ptrs.values()]; const d = Math.hypot(a.x - b.x, a.y - b.y), mid = { x: (a.x + b.x) / 2, y: (a.y + b.y) / 2 };
      if (lastPinch) uS.dist = THREE.MathUtils.clamp(uS.dist * lastPinch / d, 3, radius * 8);
      if (lastMid) pan(mid.x - lastMid.x, mid.y - lastMid.y);
      lastPinch = d; lastMid = mid;
    }
  };
  const pan = (dx, dy) => { const k = uS.dist * .0016; const right = tmpA.set(Math.cos(uS.az), 0, -Math.sin(uS.az)), fwd = tmpB.set(Math.sin(uS.az), 0, Math.cos(uS.az)); uS.tgt.addScaledVector(right, -dx * k).addScaledVector(fwd, -dy * k); };
  const onUp = (e) => { ptrs.delete(e.pointerId); lastPinch = 0; lastMid = null; };
  const onWheel = (e) => { e.preventDefault(); take(); uS.dist = THREE.MathUtils.clamp(uS.dist * Math.exp(e.deltaY * .0012), 3, radius * 8); };
  const onCtx = (e) => e.preventDefault();
  dom.addEventListener('pointerdown', onDown); dom.addEventListener('pointermove', onMove); dom.addEventListener('pointerup', onUp); dom.addEventListener('pointercancel', onUp);
  dom.addEventListener('wheel', onWheel, { passive: false }); dom.addEventListener('contextmenu', onCtx);
  return {
    setScene, setShot, update, setFrame,
    get shot() { return shot; }, get user() { return user; }, get radius() { return radius; }, get moved() { return moved; },
    giveBack() { if (!user) return; user = false; vPos.set(0, 0, 0); vTgt.set(0, 0, 0); omega = 1.0; onTake(false); },
    take, snapNow() { snap = true; }, pos, tgt,
    dispose() { dom.removeEventListener('pointerdown', onDown); dom.removeEventListener('pointermove', onMove); dom.removeEventListener('pointerup', onUp); dom.removeEventListener('pointercancel', onUp); dom.removeEventListener('wheel', onWheel); dom.removeEventListener('contextmenu', onCtx); },
  };
}
