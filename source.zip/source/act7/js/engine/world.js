// The clay diorama: the building as it stands after the collapse (the simulated world, not what was measured), its
// site, the neighbours, and the responders' things: the van, the anchor robot with its mast, the ground-station table
// with its laptop, the landing pad and the drones. Instanced boxes per material; a floor cutaway hides every storey
// above a level. Every material can be dimmed so overlays read on top of it.
import * as THREE from 'three';
import { propGeometry, droneGeometry, makeUgv, makeTetherDrone, makeStation, clay } from './models.js';
import { createLines } from './lines.js';
import { getTheme } from '../theme.js';

let DIMC = new THREE.Color('#8A85AC');   // the colour the clay dims toward under overlays (set per theme)
export function dimPatch(mat, U) {
  mat.onBeforeCompile = (sh) => {
    sh.uniforms.a7Dim = U.dim;
    sh.fragmentShader = sh.fragmentShader.replace('#include <common>', '#include <common>\nuniform float a7Dim;')
      .replace('#include <dithering_fragment>', `#include <dithering_fragment>
        { float l = dot(gl_FragColor.rgb, vec3(.3, .55, .15)); gl_FragColor.rgb = mix(gl_FragColor.rgb, mix(vec3(l) * .8, vec3(${DIMC.r.toFixed(3)}, ${DIMC.g.toFixed(3)}, ${DIMC.b.toFixed(3)}), .6), a7Dim * .9); }`);
  };
  const key = 'a7dim' + DIMC.getHexString(); mat.customProgramCacheKey = () => key;
  return mat;
}

export function buildWorld(C, props, { phone = false, theme = null } = {}) {
  // (the original look multiplies each part's colour by itself: the material colour times the per-instance colour; the
  // other themes set squared: false so their clay is exactly the colour they specify)
  const T = theme || getTheme('dusk'), K = T.clay, COL = K.col; DIMC = new THREE.Color(K.dim);
  const group = new THREE.Group(); group.name = 'world';
  const U = { dim: { value: 0 } };
  const mats = [], geos = [];
  const mkMat = (c, o = {}) => { const m = dimPatch(new THREE.MeshStandardMaterial({ color: new THREE.Color(c), roughness: o.r ?? .92, metalness: 0, vertexColors: false, ...o.extra }), U); if (o.clip) { m.clippingPlanes = [o.clip]; m.clipShadows = true; } mats.push(m); return m; };
  // the props (van, robot, rescuers, trees, drones) keep their own colours in the original look; another theme pulls
  // them part of the way toward its clay so nothing reads as a sticker
  const PT = K.prop ? new THREE.Color(K.prop.color) : null, pm = K.prop ? K.prop.mix : 0;
  const tintProp = (obj, skip) => { if (!PT) return obj; obj.traverse((o) => { if (!o.isMesh || o === skip || !o.material || o.material.isShaderMaterial) return; const m = o.material.clone(); if (m.color) m.color.lerp(PT, pm); o.material = m; mats.push(m); }); return obj; };
  const tintGeo = (geo) => { if (!PT || !geo || !geo.attributes.color) return; const a = geo.attributes.color; for (let i = 0; i < a.count; i++) { a.setXYZ(i, a.getX(i) + (PT.r - a.getX(i)) * pm, a.getY(i) + (PT.g - a.getY(i)) * pm, a.getZ(i) + (PT.b - a.getZ(i)) * pm); } a.needsUpdate = true; };
  // the before / after swipe: today's building keeps the side of the divider the clip plane faces, the survey the other;
  // with the swipe off both planes keep everything (the survey is then hidden)
  const clipAfter = new THREE.Plane(new THREE.Vector3(0, 1, 0), 1e5), clipBefore = new THREE.Plane(new THREE.Vector3(0, 1, 0), 1e5);
  const box = new THREE.BoxGeometry(1, 1, 1); geos.push(box);
  // ------------------------------------------------------------------ the building (post-event parts)
  const parts = C.post.parts.filter((p) => p.kind !== 'site');
  const byMat = new Map();
  for (const p of parts) { const m = p.debris ? (p.mat === 'debrisSlab' ? 'debrisSlab' : 'debris') : p.mat; if (!byMat.has(m)) byMat.set(m, []); byMat.get(m).push(p); }
  const inst = [];
  const M4 = new THREE.Matrix4(), Q = new THREE.Quaternion(), P = new THREE.Vector3(), S = new THREE.Vector3(), col = new THREE.Color();
  let h = 1;
  const jit = () => { h = (h * 16807) % 2147483647; return h / 2147483647; };
  for (const [m, list] of byMat) {
    const mesh = new THREE.InstancedMesh(box, mkMat(K.squared === false ? '#FFFFFF' : (COL[m] || '#DDD'), { clip: clipAfter }), list.length);
    mesh.castShadow = true; mesh.receiveShadow = true; mesh.frustumCulled = false;
    const storeys = new Int8Array(list.length), mats4 = [];
    list.forEach((p, i) => {
      P.set(p.box.c[0], p.box.c[1], p.box.c[2]); Q.set(p.box.q[0], p.box.q[1], p.box.q[2], p.box.q[3]); S.set(p.box.h[0] * 2, p.box.h[1] * 2, p.box.h[2] * 2);
      M4.compose(P, Q, S); mesh.setMatrixAt(i, M4); mats4.push(M4.clone());
      const base = new THREE.Color(COL[m] || '#DDD'); const v = (jit() - .5) * (p.debris ? .16 : p.tile ? .1 : .04); col.copy(base).offsetHSL(0, 0, v); mesh.setColorAt(i, col);
      storeys[i] = p.debris ? -1 : p.storey;
    });
    mesh.instanceMatrix.needsUpdate = true; if (mesh.instanceColor) mesh.instanceColor.needsUpdate = true;
    group.add(mesh); inst.push({ mesh, storeys, mats4, mat: m });
  }
  // window frames (thin, light) in the openings that are still there
  const frames = [];
  const gone = new Set(C.tests.map((s, i) => (s === 'gone' ? i : -1)).filter((i) => i >= 0));
  for (const o of C.model.openings) {
    if (o.kind !== 'window' && o.kind !== 'balcony') continue;
    const u = C.model.walls[o.unit]; if (u.parts.some((id) => gone.has(id))) continue;
    const T = C.post.motions[Math.max(0, Math.min(4, o.storey))]; const t = 0.06, d = 0.07;
    const bars = o.axis === 'x'
      ? [[o.off, o.y0 + t / 2, (o.o0 + o.o1) / 2, d, t, o.o1 - o.o0], [o.off, o.y1 - t / 2, (o.o0 + o.o1) / 2, d, t, o.o1 - o.o0], [o.off, (o.y0 + o.y1) / 2, o.o0 + t / 2, d, o.y1 - o.y0, t], [o.off, (o.y0 + o.y1) / 2, o.o1 - t / 2, d, o.y1 - o.y0, t], [o.off, (o.y0 + o.y1) / 2, (o.o0 + o.o1) / 2, d * .8, o.y1 - o.y0, t * .7]]
      : [[(o.o0 + o.o1) / 2, o.y0 + t / 2, o.off, o.o1 - o.o0, t, d], [(o.o0 + o.o1) / 2, o.y1 - t / 2, o.off, o.o1 - o.o0, t, d], [o.o0 + t / 2, (o.y0 + o.y1) / 2, o.off, t, o.y1 - o.y0, d], [o.o1 - t / 2, (o.y0 + o.y1) / 2, o.off, t, o.y1 - o.y0, d], [(o.o0 + o.o1) / 2, (o.y0 + o.y1) / 2, o.off, t * .7, o.y1 - o.y0, d * .8]];
    for (const b of bars) frames.push({ T, b, storey: o.storey, kind: o.kind });
  }
  if (frames.length) {
    const mesh = new THREE.InstancedMesh(box, mkMat(K.frame, { clip: clipAfter }), frames.length); mesh.castShadow = false; mesh.frustumCulled = false; const storeys = new Int8Array(frames.length), mats4 = [];
    const TM = new THREE.Matrix4();
    frames.forEach((f, i) => { const R = f.T.R, tt = f.T.t; TM.set(R[0], R[1], R[2], tt[0], R[3], R[4], R[5], tt[1], R[6], R[7], R[8], tt[2], 0, 0, 0, 1); M4.compose(P.set(f.b[0], f.b[1], f.b[2]), Q.set(0, 0, 0, 1), S.set(f.b[3], f.b[4], f.b[5])); M4.premultiply(TM); mesh.setMatrixAt(i, M4); mats4.push(M4.clone()); storeys[i] = f.storey; });
    mesh.instanceMatrix.needsUpdate = true; group.add(mesh); inst.push({ mesh, storeys, mats4, mat: 'frame' });
  }
  // the survey (the building before the disaster), for the before / after swipe: the same parts unmoved, no debris
  const before = new THREE.Group(); before.visible = false; group.add(before); const binst = [];
  { const bm = new Map(); for (const p of C.model.parts) { if (p.kind === 'site') continue; if (!bm.has(p.mat)) bm.set(p.mat, []); bm.get(p.mat).push(p); }
    for (const [m, list] of bm) {
      const mesh = new THREE.InstancedMesh(box, mkMat(K.squared === false ? '#FFFFFF' : (COL[m] || '#DDD'), { clip: clipBefore }), list.length); mesh.castShadow = true; mesh.receiveShadow = true; mesh.frustumCulled = false;
      const storeys = new Int8Array(list.length), mats4 = [];
      list.forEach((p, i) => { P.set(p.box.c[0], p.box.c[1], p.box.c[2]); Q.set(p.box.q[0], p.box.q[1], p.box.q[2], p.box.q[3]); S.set(p.box.h[0] * 2, p.box.h[1] * 2, p.box.h[2] * 2); M4.compose(P, Q, S); mesh.setMatrixAt(i, M4); mats4.push(M4.clone()); col.set(COL[m] || '#DDD').offsetHSL(0, 0, (jit() - .5) * .04); mesh.setColorAt(i, col); storeys[i] = p.storey; });
      mesh.instanceMatrix.needsUpdate = true; if (mesh.instanceColor) mesh.instanceColor.needsUpdate = true; before.add(mesh); binst.push({ mesh, storeys, mats4 });
    }
    const bf = []; for (const o of C.model.openings) { if (o.kind !== 'window' && o.kind !== 'balcony') continue; const t = 0.06, d = 0.07;
      const bars = o.axis === 'x' ? [[o.off, o.y0 + t / 2, (o.o0 + o.o1) / 2, d, t, o.o1 - o.o0], [o.off, o.y1 - t / 2, (o.o0 + o.o1) / 2, d, t, o.o1 - o.o0], [o.off, (o.y0 + o.y1) / 2, o.o0 + t / 2, d, o.y1 - o.y0, t], [o.off, (o.y0 + o.y1) / 2, o.o1 - t / 2, d, o.y1 - o.y0, t]]
        : [[(o.o0 + o.o1) / 2, o.y0 + t / 2, o.off, o.o1 - o.o0, t, d], [(o.o0 + o.o1) / 2, o.y1 - t / 2, o.off, o.o1 - o.o0, t, d], [o.o0 + t / 2, (o.y0 + o.y1) / 2, o.off, t, o.y1 - o.y0, d], [o.o1 - t / 2, (o.y0 + o.y1) / 2, o.off, t, o.y1 - o.y0, d]];
      for (const b of bars) bf.push({ b, storey: o.storey }); }
    if (bf.length) { const mesh = new THREE.InstancedMesh(box, mkMat(K.frame, { clip: clipBefore }), bf.length); mesh.frustumCulled = false; const storeys = new Int8Array(bf.length), mats4 = [];
      bf.forEach((f, i) => { M4.compose(P.set(f.b[0], f.b[1], f.b[2]), Q.set(0, 0, 0, 1), S.set(f.b[3], f.b[4], f.b[5])); mesh.setMatrixAt(i, M4); mats4.push(M4.clone()); storeys[i] = f.storey; });
      mesh.instanceMatrix.needsUpdate = true; before.add(mesh); binst.push({ mesh, storeys, mats4 }); } }
  // cracks (the real ones, drawn on both faces)
  const cracks = createLines(4000, { width: 1.6, additive: false, opacity: .9, clip: true }); cracks.mesh.renderOrder = 3;
  cracks.begin();
  const crackStorey = [];
  for (const c of C.post.cracks) {
    const u = C.model.walls[c.unit]; const T = C.post.motions[Math.max(0, Math.min(4, u.storey))]; const R = T.R; const n0 = u.axis === 'x' ? [1, 0, 0] : [0, 0, 1]; const n = [R[0] * n0[0] + R[1] * n0[1] + R[2] * n0[2], R[3] * n0[0] + R[4] * n0[1] + R[5] * n0[2], R[6] * n0[0] + R[7] * n0[1] + R[8] * n0[2]];
    for (const sg of [-1, 1]) { const off = sg * (u.t / 2 + 0.012); for (let k = 1; k < c.pts.length; k++) { const a = c.pts[k - 1], b = c.pts[k]; cracks.seg(a[0] + n[0] * off, a[1] + n[1] * off, a[2] + n[2] * off, b[0] + n[0] * off, b[1] + n[1] * off, b[2] + n[2] * off, ...K.crack, .95); crackStorey.push(u.storey); } }
  }
  cracks.end(); group.add(cracks.mesh);
  // ------------------------------------------------------------------ the site
  const { L, D } = C.model.dims, site = C.model.site;
  const ground = new THREE.Mesh(new THREE.PlaneGeometry(260, 260).rotateX(-Math.PI / 2), mkMat(K.ground)); ground.receiveShadow = true; ground.position.y = -0.002; group.add(ground); geos.push(ground.geometry);
  const yard = new THREE.Mesh(new THREE.PlaneGeometry(L + 5.6, D + 6.4).rotateX(-Math.PI / 2), mkMat(K.yard)); yard.position.set(0, 0.003, 0); yard.receiveShadow = true; group.add(yard); geos.push(yard.geometry);
  const street = new THREE.Mesh(new THREE.PlaneGeometry(260, site.street.z1 - site.street.z0).rotateX(-Math.PI / 2), mkMat(K.street)); street.position.set(0, 0.004, (site.street.z0 + site.street.z1) / 2); street.receiveShadow = true; group.add(street); geos.push(street.geometry);
  const pave = new THREE.Mesh(new THREE.PlaneGeometry(260, 2.0).rotateX(-Math.PI / 2), mkMat(K.pave)); pave.position.set(0, 0.006, D / 2 + 3.2 + 1.1); pave.receiveShadow = true; group.add(pave); geos.push(pave.geometry);
  // lane markings
  const marks = []; for (let x = -60; x < 60; x += 4) marks.push(x);
  const mk = new THREE.InstancedMesh(box, mkMat(K.marks), marks.length); marks.forEach((x, i) => { M4.compose(P.set(x, 0.01, (site.street.z0 + site.street.z1) / 2), Q.set(0, 0, 0, 1), S.set(2, 0.01, 0.12)); mk.setMatrixAt(i, M4); }); mk.receiveShadow = true; group.add(mk);
  // site parts (boundary walls, kerb, neighbours, yard boxes)
  const siteParts = C.model.parts.filter((p) => p.kind === 'site'); const fades = [];
  const winTex = (() => { if (typeof document === 'undefined') return null; const cv = document.createElement('canvas'); cv.width = 64; cv.height = 64; const x = cv.getContext('2d'); x.fillStyle = K.winBase; x.fillRect(0, 0, 64, 64); x.fillStyle = K.winGlass; for (let r = 0; r < 2; r++) for (let c = 0; c < 2; c++) x.fillRect(8 + c * 32, 10 + r * 32, 18, 14); const t = new THREE.CanvasTexture(cv); t.wrapS = t.wrapT = THREE.RepeatWrapping; t.colorSpace = THREE.SRGBColorSpace; return t; })();
  for (const p of siteParts) {
    const isN = p.mat === 'neighbour';
    const g = new THREE.BoxGeometry(p.box.h[0] * 2, p.box.h[1] * 2, p.box.h[2] * 2); geos.push(g);
    let mat;
    if (isN && winTex) { const t = winTex.clone(); t.needsUpdate = true; t.repeat.set(Math.max(1, Math.round(p.box.h[0] * 2 / 3.2)), Math.max(1, Math.round(p.box.h[1] * 2 / 3))); mat = mkMat('#FFFFFF', { extra: { map: t } }); }
    else mat = mkMat(COL[p.mat] || COL.site);
    const m = new THREE.Mesh(g, mat); m.position.set(...p.box.c); m.castShadow = true; m.receiveShadow = true; group.add(m);
    if (isN) fades.push({ m, mat, bb: p.aabb || [p.box.c[0] - p.box.h[0], p.box.c[1] - p.box.h[1], p.box.c[2] - p.box.h[2], p.box.c[0] + p.box.h[0], p.box.c[1] + p.box.h[1], p.box.c[2] + p.box.h[2]], k: 1 });
  }
  // trees on the far side of the street and in the yard corners
  const tree = props && props.getObjectByName ? props.getObjectByName('tree_broad') : null;
  const trees = [[-16, site.street.z1 + 1.5], [-6, site.street.z1 + 2.2], [7, site.street.z1 + 1.6], [17, site.street.z1 + 2.4]];
  for (const [x, z] of trees) { let t; if (tree) { t = tintProp(tree.clone()); t.scale.setScalar(1.1); } else { t = new THREE.Group(); const tr = new THREE.Mesh(new THREE.CylinderGeometry(.12, .16, 2.2, 8), mkMat(K.trunk)); tr.position.y = 1.1; const cr = new THREE.Mesh(new THREE.SphereGeometry(1.4, 14, 10), mkMat(K.crown)); cr.position.y = 3.0; t.add(tr, cr); } t.position.set(x, 0, z); t.traverse((o) => { if (o.isMesh) { o.castShadow = true; o.receiveShadow = true; } }); group.add(t); }
  // ------------------------------------------------------------------ the responders
  const pickProp = (name) => (props && props.getObjectByName ? props.getObjectByName(name) : null);
  const van = (() => { const p = pickProp('van'); if (p) { const c = tintProp(p.clone()); return c; } const g = new THREE.Group(); const b = new THREE.Mesh(new THREE.BoxGeometry(5, 2, 2), mkMat(K.van)); b.position.y = 1.3; g.add(b); const s = new THREE.Mesh(new THREE.BoxGeometry(5.02, .3, 2.02), mkMat(K.vanStripe)); s.position.y = 1.2; g.add(s); return g; })();
  van.position.set(site.van.x, 0, site.van.z); van.rotation.y = Math.PI / 2 * 0; van.traverse((o) => { if (o.isMesh) { o.castShadow = true; o.receiveShadow = true; } }); group.add(van);
  const ugv = makeUgv(props, K.beacon); tintProp(ugv, ugv.userData.beacon); ugv.position.set(site.anchor.x, 0, site.anchor.z); ugv.rotation.y = -Math.PI / 2; group.add(ugv);
  // a mast on the anchor robot
  const mast = new THREE.Mesh(new THREE.CylinderGeometry(.04, .05, 2.2, 8), mkMat(K.mast)); mast.position.set(site.anchor.x + 0.42, 1.85, site.anchor.z); mast.castShadow = true; group.add(mast);
  const mastHead = new THREE.Mesh(new THREE.SphereGeometry(.13, 12, 8), new THREE.MeshBasicMaterial({ color: new THREE.Color(K.mastHead).multiplyScalar(T.dark ? 1.6 : 1.0) })); mastHead.position.set(site.anchor.x + 0.42, 3.0, site.anchor.z); group.add(mastHead); mats.push(mastHead.material); geos.push(mastHead.geometry);
  // the anchor's tethered drone: overwatch above the site, powered and linked through its cable from the station
  // (each prop merged into one vertex-coloured mesh: two draw calls instead of fourteen, plus their shadows)
  const merged = (name, make, attachName, dflt) => {
    const p = pickProp0(name); if (!p) return tintProp(make(props));
    const geo = propGeometry(p); if (!geo) return tintProp(make(props)); tintGeo(geo); geos.push(geo);
    const m = clay('#ffffff', { vc: true, r: .7 }); dimPatch(m, U); mats.push(m);
    const g = new THREE.Group(), mesh = new THREE.Mesh(geo, m); mesh.castShadow = true; g.add(mesh);
    const a = p.getObjectByName(attachName); g.userData.attach = g.userData.out = a ? a.getWorldPosition(new THREE.Vector3()).sub(p.getWorldPosition(new THREE.Vector3())) : dflt; return g;
  };
  const pickProp0 = (name) => (props && props.getObjectByName ? props.getObjectByName(name) : null);
  const station = merged('tether_station', makeStation, 'cable_out', new THREE.Vector3(0, .8, 0)); station.position.set(site.anchor.x - 1.25, 0, site.anchor.z + .35); station.scale.setScalar(1.1); group.add(station);
  const tdrone = merged('tether_drone', makeTetherDrone, 'tether_attach', new THREE.Vector3(0, -.3, 0)); tdrone.scale.setScalar(1.25); tdrone.position.set(site.anchor.x - 0.6, 7.6, site.anchor.z - 0.9); group.add(tdrone);
  const cable = createLines(40, { width: 1.5, additive: false }); group.add(cable.mesh);
  const tether = (time) => {
    tdrone.position.y = 7.6 + Math.sin(time * 1.3) * .1; tdrone.rotation.y = Math.sin(time * .2) * .3;
    const out = station.userData.out || new THREE.Vector3(0, .8, 0), att = tdrone.userData.attach || new THREE.Vector3(0, -.3, 0);
    const ax = station.position.x + out.x * station.scale.x, ay = out.y * station.scale.y, az = station.position.z + out.z * station.scale.z;
    const bx = tdrone.position.x, by = tdrone.position.y + att.y * tdrone.scale.y, bz = tdrone.position.z;
    const chord = Math.hypot(bx - ax, by - ay, bz - az), sag = Math.sqrt(3 * chord * chord * 0.06 / 8) * .5;
    cable.begin(); let lx = ax, ly = ay, lz = az; const NS = 30;
    for (let k = 1; k <= NS; k++) { const u = k / NS, x = ax + (bx - ax) * u, z = az + (bz - az) * u, y = ay + (by - ay) * u - sag * 4 * u * (1 - u) * (1 + .03 * Math.sin(time * 1.1 + u * 6)); cable.seg(lx, ly, lz, x, y, z, ...K.cable, .95); lx = x; ly = y; lz = z; }
    cable.end();
  };
  tether(0);
  // the ground-station table: top, legs, laptop
  const table = new THREE.Group(); table.position.set(site.table.x, 0, site.table.z);
  const top = new THREE.Mesh(new THREE.BoxGeometry(1.8, .04, .8), mkMat(K.table)); top.position.y = .74; table.add(top);
  for (const [lx, lz] of [[-.8, -.32], [.8, -.32], [-.8, .32], [.8, .32]]) { const leg = new THREE.Mesh(new THREE.CylinderGeometry(.02, .02, .72, 6), mkMat(K.legs)); leg.position.set(lx, .36, lz); table.add(leg); }
  const lapBase = new THREE.Mesh(new THREE.BoxGeometry(.42, .02, .3), mkMat(K.laptop)); lapBase.position.set(-.2, .77, .05); table.add(lapBase);
  const screenMat = new THREE.MeshBasicMaterial({ color: new THREE.Color(K.screen) }); mats.push(screenMat);
  const lapLid = new THREE.Mesh(new THREE.BoxGeometry(.42, .28, .015), mkMat(K.laptop)); lapLid.position.set(-.2, .92, -.1); lapLid.rotation.x = -.22; table.add(lapLid);
  const screen = new THREE.Mesh(new THREE.PlaneGeometry(.38, .24), screenMat); screen.position.set(-.2, .92, -.091); screen.rotation.x = -.22; table.add(screen); geos.push(screen.geometry);
  const crate = new THREE.Mesh(new THREE.BoxGeometry(.6, .4, .4), mkMat(K.crate)); crate.position.set(.45, .2, .55); table.add(crate);
  table.traverse((o) => { if (o.isMesh) { o.castShadow = true; o.receiveShadow = true; } }); group.add(table);
  // rescuers
  const resc = pickProp('rescuer');
  for (const [x, z, ry] of [[site.table.x + 0.9, site.table.z + 0.9, 2.6], [site.table.x - 1.1, site.table.z + 0.8, 3.6], [site.van.x + 3.2, site.van.z - 0.4, 1.4]]) {
    let r; if (resc) r = tintProp(resc.clone()); else { r = new THREE.Group(); const b = new THREE.Mesh(new THREE.CapsuleGeometry(.22, 1.0, 4, 8), mkMat(K.rescuer)); b.position.y = .85; r.add(b); const hd = new THREE.Mesh(new THREE.SphereGeometry(.16, 10, 8), mkMat(K.rescuerHead)); hd.position.y = 1.65; r.add(hd); }
    r.position.set(x, 0, z); r.rotation.y = ry; r.traverse((o) => { if (o.isMesh) { o.castShadow = true; } }); group.add(r);
  }
  // landing pad
  const pad = new THREE.Mesh(new THREE.CylinderGeometry(1.25, 1.25, .04, 40), mkMat(K.pad)); pad.position.set(site.pad.x, .02, site.pad.z); pad.receiveShadow = true; group.add(pad);
  const ring = new THREE.Mesh(new THREE.RingGeometry(1.0, 1.08, 48).rotateX(-Math.PI / 2), new THREE.MeshBasicMaterial({ color: new THREE.Color(K.ring) })); ring.position.set(site.pad.x, .05, site.pad.z); group.add(ring); mats.push(ring.material); geos.push(ring.geometry);
  // drones (instanced): eight that land on the pad; the film moves them
  let dGeo = null; const dp = pickProp('swarm_drone'); if (dp) dGeo = propGeometry(dp); if (!dGeo) dGeo = droneGeometry(); tintGeo(dGeo); geos.push(dGeo);
  const dMat = clay('#ffffff', { vc: true, r: .6 }); dimPatch(dMat, U); mats.push(dMat);
  const drones = new THREE.InstancedMesh(dGeo, dMat, 10); drones.castShadow = true; drones.frustumCulled = false; group.add(drones);
  const dScale = dp ? 1.7 : 2.6;
  const padSlots = []; for (let i = 0; i < 8; i++) { const a = i / 8 * Math.PI * 2; padSlots.push([site.pad.x + Math.cos(a) * .7, .06, site.pad.z + Math.sin(a) * .7]); }
  const setDrone = (i, x, y, z, yaw = 0, show = true) => { M4.compose(P.set(x, y, z), Q.setFromAxisAngle(new THREE.Vector3(0, 1, 0), yaw), S.setScalar(show ? dScale : 0)); drones.setMatrixAt(i, M4); };
  for (let i = 0; i < 10; i++) setDrone(i, 0, -10, 0, 0, false); drones.instanceMatrix.needsUpdate = true;
  // ------------------------------------------------------------------ cutaway and dim
  let level = null;
  const Z = new THREE.Matrix4().makeScale(0, 0, 0);
  function cutaway(lv) {
    if (lv === level) return; level = lv;
    for (const it of [...inst, ...binst]) { for (let i = 0; i < it.storeys.length; i++) { const s = it.storeys[i]; const show = lv == null || s <= lv; it.mesh.setMatrixAt(i, show ? it.mats4[i] : Z); } it.mesh.instanceMatrix.needsUpdate = true; }
    // cracks: rebuild alpha by storey
    const a = cracks; // cheap: hide all cracks above the level by re-running begin/end
    a.begin(); let k = 0;
    for (const c of C.post.cracks) { const u = C.model.walls[c.unit]; const show = lv == null || u.storey <= lv; const T = C.post.motions[Math.max(0, Math.min(4, u.storey))]; const R = T.R; const n0 = u.axis === 'x' ? [1, 0, 0] : [0, 0, 1]; const n = [R[0] * n0[0] + R[1] * n0[1] + R[2] * n0[2], R[3] * n0[0] + R[4] * n0[1] + R[5] * n0[2], R[6] * n0[0] + R[7] * n0[1] + R[8] * n0[2]];
      if (!show) continue; for (const sg of [-1, 1]) { const off = sg * (u.t / 2 + 0.012); for (let q = 1; q < c.pts.length; q++) { const p0 = c.pts[q - 1], p1 = c.pts[q]; a.seg(p0[0] + n[0] * off, p0[1] + n[1] * off, p0[2] + n[2] * off, p1[0] + n[0] * off, p1[1] + n[1] * off, p1[2] + n[2] * off, ...K.crack, .95); k++; } } }
    a.end();
  }
  // bounds and camera hints
  const bounds = new THREE.Box3(new THREE.Vector3(-L / 2 - 5, 0, -D / 2 - 5), new THREE.Vector3(L / 2 + 5, 14, site.street.z1));
  const ts = T.sky, sky = { ...ts, sun: { ...ts.sun, dir: new THREE.Vector3(...ts.sun.dir) }, hemi: { ...ts.hemi } };
  return {
    group, U, inst, drones, setDrone, padSlots, dScale, screenMat, mastHead, table, van, ugv, cracks, cable, tdrone, station, bounds, sky,
    // the tethered drone stays up all the time; the film shows it in the touchdown and in shots that keep their distance
    tick(time, cam, always) { const d = cam ? cam.position.distanceTo(tdrone.position) : 99; const on = always || d > 20; tdrone.visible = on; cable.mesh.visible = on; if (on) tether(time); },
    // the swipe: x in [0, 1] across the view (null = off); the survey shows left of the divider, today right of it
    setSwipe(cam, x) {
      if (x == null) { before.visible = false; clipAfter.set(new THREE.Vector3(0, 1, 0), 1e5); clipBefore.set(new THREE.Vector3(0, 1, 0), 1e5); cracks.U.clip.value.set(0, 0, 0, 1); return; }
      before.visible = true; const ndc = x * 2 - 1;
      const a = new THREE.Vector3(ndc, -1, .5).unproject(cam).sub(cam.position), b = new THREE.Vector3(ndc, 1, .5).unproject(cam).sub(cam.position);
      const n = new THREE.Vector3().crossVectors(b, a).normalize();                 // points to the right of the divider
      const r = new THREE.Vector3(1, 0, 0).applyQuaternion(cam.quaternion); if (n.dot(r) < 0) n.negate();
      clipAfter.setFromNormalAndCoplanarPoint(n, cam.position); clipBefore.setFromNormalAndCoplanarPoint(n.clone().negate(), cam.position);
      cracks.U.clip.value.set(clipAfter.normal.x, clipAfter.normal.y, clipAfter.normal.z, clipAfter.constant);
    },
    anchors: { pad: [site.pad.x, 0, site.pad.z], table: [site.table.x, 0.95, site.table.z], anchor: [site.anchor.x, 0, site.anchor.z], mast: [site.anchor.x + 0.42, 3.0, site.anchor.z], van: [site.van.x, 0, site.van.z] },
    cutaway, get level() { return level; },
    // a neighbouring block between the camera and what it looks at turns see-through (it stays in the scans)
    fadeNeighbours(cam, tgt, dt) {
      for (const f of fades) {
        const b = f.bb; const o = [cam.x, cam.y, cam.z];
        const seg = (ty) => { let t0 = 0, t1 = 1; const d = [tgt.x - cam.x, ty - cam.y, tgt.z - cam.z];
          for (let i = 0; i < 3; i++) { const lo = b[i] - .6, hi = b[i + 3] + .6; if (Math.abs(d[i]) < 1e-9) { if (o[i] < lo || o[i] > hi) return false; continue; } let a1 = (lo - o[i]) / d[i], a2 = (hi - o[i]) / d[i]; if (a1 > a2) { const t = a1; a1 = a2; a2 = t; } t0 = Math.max(t0, a1); t1 = Math.min(t1, a2); if (t0 > t1) return false; } return true; };
        // the line of sight to the target, or to the foot of the building under it
        const hit = seg(tgt.y) || seg(Math.max(.5, tgt.y - 4));
        const goal = hit ? .16 : 1; f.k += (goal - f.k) * (1 - Math.exp(-(dt || .1) * 4)); if (Math.abs(f.k - goal) < .01) f.k = goal;
        const tr = f.k < .99; f.mat.transparent = tr; f.mat.opacity = f.k; f.mat.depthWrite = !tr; f.m.castShadow = !tr; f.m.renderOrder = tr ? 3 : 0;
      }
    },
    setDim(d) { U.dim.value = d; },
    dispose() { for (const g of geos) g.dispose(); for (const m of mats) { if (m.map) m.map.dispose(); m.dispose(); } for (const it of inst) it.mesh.dispose(); for (const it of binst) it.mesh.dispose(); cracks.dispose(); cable.dispose(); drones.dispose(); if (winTex) winTex.dispose(); },
  };
}
