// Greedy meshing of voxel label grids: the faces between a labelled voxel and anything else, merged into the largest
// rectangles per slice (Lysenko's greedy algorithm), one indexed geometry per label. A change map of a few hundred
// thousand voxels becomes a few tens of thousands of quads.
import * as THREE from 'three';

// grid: { x0, y0, z0, nx, ny, nz, vox }, lab: Uint8Array (idx = i + nx*(k + nz*j)), labels: array of label values
// opts.bbox: [i0, j0, k0, i1, j1, k1] to limit the work. Returns Map(label -> BufferGeometry)
export function greedyMesh(grid, lab, labels, opts = {}) {
  const { nx, ny, nz, vox, x0, y0, z0 } = grid; const SX = 1, SY = nx * nz, SZ = nx;
  const want = new Uint8Array(256); for (const l of labels) want[l] = 1;
  let bb = opts.bbox;
  if (!bb) { let i0 = 1e9, j0 = 1e9, k0 = 1e9, i1 = -1, j1 = -1, k1 = -1;
    for (let j = 0; j < ny; j++) for (let k = 0; k < nz; k++) { const base = nx * (k + nz * j); for (let i = 0; i < nx; i++) if (want[lab[base + i]]) { if (i < i0) i0 = i; if (i > i1) i1 = i; if (j < j0) j0 = j; if (j > j1) j1 = j; if (k < k0) k0 = k; if (k > k1) k1 = k; } }
    if (i1 < 0) return new Map(); bb = [i0, j0, k0, i1, j1, k1]; }
  const lo = [bb[0], bb[1], bb[2]], hi = [bb[3], bb[4], bb[5]], N = [nx, ny, nz], S = [SX, SY, SZ];
  const out = new Map(); for (const l of labels) out.set(l, { p: [], n: [], idx: [], v: 0 });
  const get = (x, y, z) => (x < 0 || y < 0 || z < 0 || x >= nx || y >= ny || z >= nz ? 0 : lab[x * SX + y * SY + z * SZ]);
  const x = [0, 0, 0], q = [0, 0, 0];
  for (let d = 0; d < 3; d++) {
    const u = (d + 1) % 3, v = (d + 2) % 3; q[0] = q[1] = q[2] = 0; q[d] = 1;
    const du = hi[u] - lo[u] + 1, dv = hi[v] - lo[v] + 1; const mask = new Int16Array(du * dv);
    for (x[d] = lo[d] - 1; x[d] <= hi[d]; x[d]++) {
      let n = 0;
      for (x[v] = lo[v]; x[v] <= hi[v]; x[v]++) for (x[u] = lo[u]; x[u] <= hi[u]; x[u]++, n++) {
        const a = get(x[0], x[1], x[2]), b = get(x[0] + q[0], x[1] + q[1], x[2] + q[2]);
        mask[n] = a === b ? 0 : want[a] ? a : want[b] ? -b : 0;
        if (mask[n] === 0 && a !== b && want[a] && want[b]) mask[n] = a;
      }
      // a voxel of one wanted label next to another wanted label: emit the second face too
      n = 0;
      for (let j = 0; j < dv; j++) for (let i = 0; i < du;) {
        const c = mask[n]; if (!c) { i++; n++; continue; }
        let w = 1; while (i + w < du && mask[n + w] === c) w++;
        let h = 1, done = false; while (j + h < dv) { for (let k = 0; k < w; k++) if (mask[n + k + h * du] !== c) { done = true; break; } if (done) break; h++; }
        // quad at slice x[d]+1, from (i, j) size (w, h) in (u, v)
        const P = [0, 0, 0]; P[d] = x[d] + 1; P[u] = lo[u] + i; P[v] = lo[v] + j;
        const Du = [0, 0, 0], Dv = [0, 0, 0]; Du[u] = w; Dv[v] = h;
        const L = out.get(Math.abs(c)); const sgn = c > 0 ? 1 : -1; const nrm = [0, 0, 0]; nrm[d] = sgn;
        const corners = [[P[0], P[1], P[2]], [P[0] + Du[0], P[1] + Du[1], P[2] + Du[2]], [P[0] + Du[0] + Dv[0], P[1] + Du[1] + Dv[1], P[2] + Du[2] + Dv[2]], [P[0] + Dv[0], P[1] + Dv[1], P[2] + Dv[2]]];
        for (const cc of corners) { L.p.push(x0 + cc[0] * vox, y0 + cc[1] * vox, z0 + cc[2] * vox); L.n.push(nrm[0], nrm[1], nrm[2]); }
        const b0 = L.v; L.v += 4;
        if (sgn > 0) L.idx.push(b0, b0 + 1, b0 + 2, b0, b0 + 2, b0 + 3); else L.idx.push(b0, b0 + 2, b0 + 1, b0, b0 + 3, b0 + 2);
        for (let l = 0; l < h; l++) for (let k = 0; k < w; k++) mask[n + k + l * du] = 0;
        i += w; n += w;
      }
      // second pass for faces between two wanted labels (the other side)
      n = 0;
      for (x[v] = lo[v]; x[v] <= hi[v]; x[v]++) for (x[u] = lo[u]; x[u] <= hi[u]; x[u]++, n++) {
        const a = get(x[0], x[1], x[2]), b = get(x[0] + q[0], x[1] + q[1], x[2] + q[2]);
        mask[n] = a !== b && want[a] && want[b] ? -b : 0;
      }
      n = 0;
      for (let j = 0; j < dv; j++) for (let i = 0; i < du;) {
        const c = mask[n]; if (!c) { i++; n++; continue; }
        let w = 1; while (i + w < du && mask[n + w] === c) w++;
        let h = 1, done = false; while (j + h < dv) { for (let k = 0; k < w; k++) if (mask[n + k + h * du] !== c) { done = true; break; } if (done) break; h++; }
        const P = [0, 0, 0]; P[d] = x[d] + 1; P[u] = lo[u] + i; P[v] = lo[v] + j; const Du = [0, 0, 0], Dv = [0, 0, 0]; Du[u] = w; Dv[v] = h;
        const L = out.get(-c); const nrm = [0, 0, 0]; nrm[d] = -1;
        for (const cc of [[P[0], P[1], P[2]], [P[0] + Du[0], P[1] + Du[1], P[2] + Du[2]], [P[0] + Du[0] + Dv[0], P[1] + Du[1] + Dv[1], P[2] + Du[2] + Dv[2]], [P[0] + Dv[0], P[1] + Dv[1], P[2] + Dv[2]]]) { L.p.push(x0 + cc[0] * vox, y0 + cc[1] * vox, z0 + cc[2] * vox); L.n.push(nrm[0], nrm[1], nrm[2]); }
        const b0 = L.v; L.v += 4; L.idx.push(b0, b0 + 2, b0 + 1, b0, b0 + 3, b0 + 2);
        for (let l = 0; l < h; l++) for (let k = 0; k < w; k++) mask[n + k + l * du] = 0;
        i += w; n += w;
      }
    }
  }
  const res = new Map();
  for (const [l, L] of out) {
    if (!L.v) continue; const g = new THREE.BufferGeometry();
    g.setAttribute('position', new THREE.BufferAttribute(new Float32Array(L.p), 3));
    g.setAttribute('normal', new THREE.BufferAttribute(new Float32Array(L.n), 3));
    g.setIndex(new THREE.BufferAttribute(L.v > 65535 ? new Uint32Array(L.idx) : new Uint16Array(L.idx), 1));
    g.computeBoundingSphere(); res.set(l, g);
  }
  return res;
}
// a mask from a list of cells (for pockets, voids)
export function cellsToGrid(grid, cellLists, labels) { const lab = new Uint8Array(grid.nx * grid.ny * grid.nz); cellLists.forEach((cells, i) => { const v = labels[i]; for (const c of cells) lab[c] = v; }); return lab; }
