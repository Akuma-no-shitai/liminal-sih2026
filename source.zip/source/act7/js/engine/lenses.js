// Lenses: which layers are shown over the clay world. In the World lens the film decides (each moment of the script
// brings its own overlays, softly); any other lens pins its layers until the viewer goes back to World. Every layer has
// a weight that eases toward its goal, so switching never pops.
export const LENSES = [
  { id: 'world', name: 'World', key: '1', tip: 'The building after the collapse, with whatever the film is measuring now' },
  { id: 'scans', name: 'Scans', key: '2', tip: 'The baseline cloud (teal) and the post-event cloud (rose)', layers: { base: 1, post: 1 }, dim: .55 },
  { id: 'change', name: 'Change', key: '3', tip: 'Newly occupied (rose), newly empty (lavender), unchanged (clay)', layers: { change: 1, ghost: .6 }, dim: .7 },
  { id: 'debris', name: 'Debris', key: '4', tip: 'Debris seen (rose) and the unseen space under it (pale)', layers: { debris: 1 }, dim: .5 },
  { id: 'condition', name: 'Condition', key: '5', tip: 'Tilt, sag, crack marks and each room’s draft status', layers: { rooms: 1, arrows: 1, cracks: 1 }, dim: .35 },
  { id: 'order', name: 'Order', key: '6', tip: 'The φ_wall damage field: aligned walls teal, scattered ones warm', layers: { order: 1 }, dim: .45 },
  { id: 'pockets', name: 'Pockets', key: '7', tip: 'Spaces a person could be in that no drone could enter (β₂)', layers: { pockets: 1 }, dim: .55 },
  { id: 'routes', name: 'Routes', key: '8', tip: 'The access graph: clearance, routes cut, new bottlenecks, routes from the street door', layers: { routes: 1 }, dim: .5 },
  { id: 'thermal', name: 'Thermal', key: '9', tip: 'Three thermal passes over everything the swarm saw', layers: { thermal: .45, heat: 1 }, dim: .6 },
  { id: 'confidence', name: 'Confidence', key: '0', tip: 'How far to trust each surface: seen often, close, clear of smoke', layers: { confidence: 1, refly: 1 }, dim: .75 },
  { id: 'truth', name: 'Truth', key: 't', tip: 'The real damage of the simulated collapse, for the honest comparison', layers: { truth: 1, truthRooms: 1, voids: 1 }, dim: .55 },
];
export const LAYERS = ['base', 'post', 'change', 'ghost', 'debris', 'rooms', 'arrows', 'cracks', 'order', 'pockets', 'routes', 'thermal', 'heat', 'behaviour', 'pods', 'confidence', 'refly', 'truth', 'truthRooms', 'voids', 'packets'];
export function createLenses() {
  let cur = 'world';
  const W = {}; for (const l of LAYERS) W[l] = 0;
  const S = { dim: 0 };
  return {
    W, S,
    get current() { return cur; },
    set(id) { if (LENSES.some((l) => l.id === id)) cur = id; },
    // film: the script's layer weights for this moment ({ layer: weight, dim })
    update(dt, film = {}) {
      const L = LENSES.find((l) => l.id === cur); const k = 1 - Math.exp(-dt * 5);
      for (const name of LAYERS) {
        let goal = cur === 'world' ? (film[name] || 0) : (L.layers[name] || 0);
        if (name === 'packets' || name === 'pods' || name === 'behaviour') goal = Math.max(goal, cur === 'world' ? 0 : 0) || goal;
        W[name] += (goal - W[name]) * k; if (Math.abs(W[name] - goal) < .003) W[name] = goal;
      }
      const dg = cur === 'world' ? (film.dim || 0) : L.dim; S.dim += (dg - S.dim) * k; if (Math.abs(S.dim - dg) < .003) S.dim = dg;
    },
  };
}
