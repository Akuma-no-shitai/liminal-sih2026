// Overlay layers built from the case (what the pipeline measured), each a THREE object with a weight the lenses ease.
// Built lazily the first time they are needed, so the film starts quickly. One clipping plane (the floor cutaway) is
// shared by every overlay: the ceiling of the highest storey left in view, as the storey fit moved it.
import * as THREE from 'three';
import { greedyMesh } from './voxmesh.js';
import { createLines as createLines0, createGlows as createGlows0 } from './lines.js';
import { getTheme } from '../theme.js';
import { behaviourLevel } from '../film/script.js';

const C3 = (h) => new THREE.Color(h);
// the overlay palette comes from the theme (set by createLayers): teal = the swarm, rose = newly filled, lav = newly
// empty, heat = caution, danger = no entry, haze = never seen, apr = the middle of the ramps
let TH = getTheme('dusk'), PAL, STATUS_COL;
function setPal(T) {
  TH = T; const d = T.data;
  PAL = { teal: C3(d.swarm), rose: C3(d.added), apr: C3(d.mid), heat: C3(d.caution), danger: C3(d.noentry), lav: C3(d.empty), haze: C3(d.unseen), paper: C3(d.paper), safe: C3(d.safe), hot: C3(d.hot), cold: C3(d.cold) };
  STATUS_COL = { safe: PAL.safe, caution: PAL.heat, noentry: PAL.danger, unseen: PAL.haze };
}
setPal(TH);
// glows and additive lines: on a light theme additive light washes out, so they blend normally (premultiplied)
const createGlows = (cap, o = {}) => createGlows0(cap, TH.data.additive || o.additive === false ? o : { ...o, additive: false, premul: true });
const createLines = (cap, o = {}) => createLines0(cap, { ...(TH.data.additive || !o.additive ? o : { ...o, additive: false, premul: true }), packetColor: TH.data.linePacket });
const v3 = (a) => `vec3(${a.map((x) => (+x).toFixed(4)).join(', ')})`;
const lin = (c) => [c.r, c.g, c.b];

// ------------------------------------------------------------------ point clouds
function cloudMaterial(color, size, clip, extra = {}) {
  return new THREE.ShaderMaterial({
    transparent: true, depthWrite: false, clipping: true, clippingPlanes: [clip], fog: false,
    uniforms: { col: { value: color.clone() }, alpha: { value: 0 }, size: { value: size }, px: { value: 1 }, hh: { value: 800 }, pass: { value: 0 }, mode: { value: extra.mode || 0 }, glow: { value: 0 } },
    vertexShader: `attribute vec3 temp; attribute float cval; uniform float size, px, hh, pass, mode; varying float vT; varying float vC;
      #include <clipping_planes_pars_vertex>
      void main(){ vec4 mvPosition = modelViewMatrix * vec4(position, 1.); gl_Position = projectionMatrix * mvPosition;
        #include <clipping_planes_vertex>
        float s = size * projectionMatrix[1][1] * hh * .5 / max(.1, -mvPosition.z); gl_PointSize = clamp(s, 1.4 * px, 7. * px);
        if (mode > .5 && mode < 1.5) { float a = pass; vT = a < 1. ? mix(temp.x, temp.y, a) : mix(temp.y, temp.z, a - 1.); } else vT = 0.;
        vC = cval; }`,
    fragmentShader: `uniform vec3 col; uniform float alpha, mode, glow; varying float vT; varying float vC;
      #include <clipping_planes_pars_fragment>
      vec3 heatmap(float t){ // degrees C (+10, /255 in the attribute): cool blue-grey, warm apricot, hot heat, very hot paper
        float c = t * 255. - 10.; vec3 cold = ${v3(TH.data.heatmap.cold)}, a = ${v3(TH.data.heatmap.amb)}, w = ${v3(TH.data.heatmap.warm)}, h = ${v3(TH.data.heatmap.hot)}, v = ${v3(TH.data.heatmap.vhot)};
        if (c < 12.) return cold; if (c < 16.) return mix(cold, a, (c - 12.) / 4.);
        if (c < 30.) return a; if (c < 70.) return mix(a, w, (c - 30.) / 40.); if (c < 150.) return mix(w, h, (c - 70.) / 80.); return mix(h, v, clamp((c - 150.) / 120., 0., 1.)); }
      vec3 confmap(float t){ vec3 lo = ${v3(TH.data.conf[0])}, mid = ${v3(TH.data.conf[1])}, hi = ${v3(TH.data.conf[2])}; return t < .5 ? mix(lo, mid, t * 2.) : mix(mid, hi, (t - .5) * 2.); }
      void main(){
        #include <clipping_planes_fragment>
        vec2 q = gl_PointCoord - .5; float d = length(q) * 2.; if (d > 1.) discard;
        vec3 c = mode > .5 && mode < 1.5 ? heatmap(vT) : mode > 1.5 ? confmap(vC) : col;
        if (mode > .5) c = pow(c, vec3(2.2));   // the palettes above are written in sRGB; the frame is linear until the output pass
        float k = 1.; if (mode > .5 && mode < 1.5) { float tc = vT * 255. - 10.; k = tc < 12. ? 1. : tc < 30. ? .4 : 1.; }
        float a = alpha * k * (1. - smoothstep(.65, 1., d)); gl_FragColor = vec4(c * (1. + glow), a); }`,
  });
}
export function makeCloud(pts, n, color, size, clip, opts = {}) {
  // at most 350k points on screen (every k-th point; the pipeline used all of them)
  const MAXP = 350000, st = n > MAXP ? Math.ceil(n / MAXP) : 1;
  if (st > 1) { const m = Math.floor(n / st), q = new Float32Array(m * 3); for (let i = 0; i < m; i++) { q[i * 3] = pts[i * st * 3]; q[i * 3 + 1] = pts[i * st * 3 + 1]; q[i * 3 + 2] = pts[i * st * 3 + 2]; }
    const tp = opts.temps ? opts.temps.map((a) => { const b = new Uint8Array(m); for (let i = 0; i < m; i++) b[i] = a[i * st]; return b; }) : null;
    const cv = opts.conf ? (() => { const b = new Uint8Array(m); for (let i = 0; i < m; i++) b[i] = opts.conf[i * st]; return b; })() : null;
    const p = makeCloud(q, m, color, size, clip, { ...opts, temps: tp, conf: cv }); p.userData.stride = st; return p; }
  const g = new THREE.BufferGeometry(); g.setAttribute('position', new THREE.BufferAttribute(pts.subarray(0, n * 3), 3));
  if (opts.temps) { const t = new Uint8Array(n * 3); for (let i = 0; i < n; i++) { t[i * 3] = opts.temps[0][i]; t[i * 3 + 1] = opts.temps[1][i]; t[i * 3 + 2] = opts.temps[2][i]; } g.setAttribute('temp', new THREE.BufferAttribute(t, 3, true)); }
  else g.setAttribute('temp', new THREE.BufferAttribute(new Uint8Array(3), 3, true));
  if (opts.conf) g.setAttribute('cval', new THREE.BufferAttribute(opts.conf, 1, true)); else g.setAttribute('cval', new THREE.BufferAttribute(new Uint8Array(1), 1, true));
  const m = cloudMaterial(color, size, clip, opts); const p = new THREE.Points(g, m); p.frustumCulled = false; p.renderOrder = 4; p.matrixAutoUpdate = false;
  return p;
}

// ------------------------------------------------------------------ voxel layers
function voxMaterial(color, clip, U, { opacity = 1, emissive = 0, side = THREE.FrontSide, xray = false } = {}) {
  const m = new THREE.MeshStandardMaterial({ color, roughness: .85, metalness: 0, transparent: opacity < 1 || xray, opacity, depthWrite: opacity >= 1 && !xray, depthTest: !xray, emissive: color, emissiveIntensity: emissive, side, clippingPlanes: [clip] });
  m.onBeforeCompile = (sh) => {
    sh.uniforms.uSweep = U.sweep; sh.uniforms.uSweepAxis = U.axis; sh.uniforms.uFade = U.fade;
    sh.vertexShader = sh.vertexShader.replace('#include <common>', '#include <common>\nvarying vec3 vW7;').replace('#include <worldpos_vertex>', '#include <worldpos_vertex>\nvW7 = (modelMatrix * vec4(transformed, 1.)).xyz;');
    sh.fragmentShader = sh.fragmentShader.replace('#include <common>', '#include <common>\nvarying vec3 vW7; uniform float uSweep, uSweepAxis, uFade;')
      .replace('#include <clipping_planes_fragment>', '#include <clipping_planes_fragment>\n float sw7 = uSweepAxis < .5 ? vW7.x : vW7.y; if (sw7 > uSweep) discard;')
      .replace('#include <dithering_fragment>', '#include <dithering_fragment>\n gl_FragColor.a *= uFade; float edge7 = smoothstep(uSweep - .6, uSweep, sw7); gl_FragColor.rgb += ' + v3(TH.data.sweep) + ' * edge7 * .35;');
  };
  m.customProgramCacheKey = () => 'a7vox' + (opacity < 1 ? 't' : 'o') + (xray ? 'x' : '') + TH.id;
  return m;
}
export function makeVoxLayer(grid, lab, spec, clip, opts = {}) {
  // spec: [{ label, color, opacity, emissive }]
  const U = { sweep: { value: 1e4 }, axis: { value: 0 }, fade: { value: 1 } };
  const geos = greedyMesh(grid, lab, spec.map((s) => s.label), opts);
  const group = new THREE.Group(); const mats = [], meshes = {};
  for (const s of spec) {
    const g = geos.get(s.label); if (!g) continue;
    const m = voxMaterial(s.color, clip, U, s); mats.push(m);
    const mesh = new THREE.Mesh(g, m); mesh.castShadow = false; mesh.receiveShadow = !!s.receive; mesh.renderOrder = s.xray ? 9 : s.opacity < 1 ? 6 : 2; mesh.name = 'vox' + s.label; group.add(mesh); meshes[s.label] = mesh;
  }
  let tris = 0; for (const g of geos.values()) tris += g.index.count / 3;
  return { group, U, meshes, tris, setOpacity(w) { for (const m of mats) { const base = m.userData.base ?? (m.userData.base = m.opacity); m.opacity = base * w; m.transparent = true; m.depthWrite = w > .98 && base >= 1; m.visible = w > .01; } group.visible = w > .01; },
    dispose() { for (const g of geos.values()) g.dispose(); for (const m of mats) m.dispose(); } };
}

// ------------------------------------------------------------------ flat quads (room tiles, phi patches) with vertex colours
function quadMesh(quads, clip, { opacity = .85, hatch = false, depthTest = true } = {}) {
  // quads: [{ p: [4][3], c: THREE.Color, a, hatch }]
  const n = quads.length, pos = new Float32Array(n * 12), col = new Float32Array(n * 16), idx = new Uint32Array(n * 6);
  quads.forEach((q, i) => { for (let k = 0; k < 4; k++) { pos.set(q.p[k], i * 12 + k * 3); col.set([q.c.r, q.c.g, q.c.b, (q.a ?? 1) * (q.hatch ? -1 : 1)], i * 16 + k * 4); } idx.set([i * 4, i * 4 + 1, i * 4 + 2, i * 4, i * 4 + 2, i * 4 + 3], i * 6); });
  const g = new THREE.BufferGeometry(); g.setAttribute('position', new THREE.BufferAttribute(pos, 3)); g.setAttribute('qc', new THREE.BufferAttribute(col, 4)); g.setIndex(new THREE.BufferAttribute(idx, 1));
  const m = new THREE.ShaderMaterial({ transparent: true, depthWrite: false, depthTest, side: THREE.DoubleSide, clipping: true, clippingPlanes: [clip], uniforms: { alpha: { value: 0 }, time: { value: 0 } },
    vertexShader: `attribute vec4 qc; varying vec4 vC; varying vec3 vW;
      #include <clipping_planes_pars_vertex>
      void main(){ vC = qc; vec4 w = modelMatrix * vec4(position, 1.); vW = w.xyz; vec4 mvPosition = viewMatrix * w; gl_Position = projectionMatrix * mvPosition;
      #include <clipping_planes_vertex>
      }`,
    fragmentShader: `uniform float alpha, time; varying vec4 vC; varying vec3 vW;
      #include <clipping_planes_pars_fragment>
      void main(){
        #include <clipping_planes_fragment>
        float a = abs(vC.a) * alpha; if (vC.a < 0.) { float s = step(.5, fract((vW.x + vW.z) * 2.2)); a *= .35 + .65 * s; }
        gl_FragColor = vec4(vC.rgb, a); }` });
  const mesh = new THREE.Mesh(g, m); mesh.renderOrder = 7; mesh.frustumCulled = false; return mesh;
}
export const m4 = (T, out = new THREE.Matrix4()) => { const R = T.R, t = T.t; return out.set(R[0], R[1], R[2], t[0], R[3], R[4], R[5], t[1], R[6], R[7], R[8], t[2], 0, 0, 0, 1); };
const tApply = (T, x, y, z) => { const R = T.R; return [R[0] * x + R[1] * y + R[2] * z + T.t[0], R[3] * x + R[4] * y + R[5] * z + T.t[1], R[6] * x + R[7] * y + R[8] * z + T.t[2]]; };
export function roomQuads(C, statusOf, lift = 0.07, inset = 0.12) {
  return C.model.rooms.map((room) => {
    const T = C.storeys[room.storey].T, st = statusOf(room.id);
    const y = room.y0 + lift, p = [[room.x0 + inset, y, room.z0 + inset], [room.x1 - inset, y, room.z0 + inset], [room.x1 - inset, y, room.z1 - inset], [room.x0 + inset, y, room.z1 - inset]].map((q) => tApply(T, ...q));
    return { p, c: STATUS_COL[st] || PAL.haze, a: st === 'unseen' ? .8 : (TH.data.tileA ?? .62), hatch: st === 'unseen', room: room.id };
  });
}
// wall order S on the theme's ramp: stops [S, colour] from the most ordered down, linear in between
export function phiColor(S) {
  const st = TH.data.phi; if (S >= st[0][0]) return C3(st[0][1]);
  for (let i = 1; i < st.length; i++) if (S >= st[i][0]) return C3(st[i - 1][1]).lerp(C3(st[i][1]), (st[i - 1][0] - S) / (st[i - 1][0] - st[i][0]));
  return C3(st[st.length - 1][1]);
}
export function phiQuads(C) {
  const out = [];
  for (const p of C.condition.patches) {
    let c, a = .85; if (p.st === 'missing') c = PAL.danger; else if (p.st === 'unseen') { c = PAL.haze; a = .35; } else c = phiColor(p.S);
    const w = p.w / 2 - 0.04, h = p.h / 2 - 0.04, t = (C.model.walls[p.wall].t / 2) + 0.03;
    for (const sg of [-1, 1]) { const q = []; for (const [da, dv] of [[-w, -h], [w, -h], [w, h], [-w, h]]) q.push([0, 1, 2].map((i) => p.centre[i] + p.a[i] * da + p.y[i] * dv + p.n[i] * t * sg)); out.push({ p: q, c, a, hatch: p.st === 'unseen' }); }
  }
  return out;
}

// ------------------------------------------------------------------ all layers
export function createLayers(scene, C, world, opts = {}) {
  setPal(opts.theme || getTheme('dusk'));
  const root = new THREE.Group(); root.name = 'layers'; scene.add(root);
  const clip = new THREE.Plane(new THREE.Vector3(0, -1, 0), 1000);
  const L = {}; const disposers = [];
  const g = C.g;
  // clouds
  const get = {
    base() { const p = makeCloud(C.scans.base.pts, C.scans.base.n, C3(TH.data.base), 0.04, clip); p.matrix.identity(); root.add(p); disposers.push(() => { p.geometry.dispose(); p.material.dispose(); }); return p; },
    post() { const p = makeCloud(C.scans.post.raw, C.scans.post.n, C3(TH.data.post), 0.04, clip, { temps: C.thermal.temps, mode: 0 }); root.add(p); disposers.push(() => { p.geometry.dispose(); p.material.dispose(); }); return p; },
    // the post-event cloud coloured by temperature (the same points, registered), pass 1-3 blended by a uniform
    thermal() { const src = ensure('post'); const m = cloudMaterial(PAL.paper, 0.05, clip, { mode: 1 }); m.uniforms.mode.value = 1; const p = new THREE.Points(src.geometry, m); p.frustumCulled = false; p.renderOrder = 4; p.matrixAutoUpdate = false; p.matrix.copy(m4(C.reg.T)); p.matrixWorldNeedsUpdate = true; root.add(p); disposers.push(() => m.dispose()); return p; },
    // heat: soft temperature-coloured patches with a halo on the surfaces that are hot (or cold) in some pass, built from
    // those returns only; each patch fades in with its pass, so the fire and the wet patch visibly grow from pass 1 to 3
    heat() {
      const T = C.thermal.temps, P = C.scans.post.pts, n = C.scans.post.n, amb = (C.thermal.amb ?? 21) + 10, sel = [];
      for (let i = 0; i < n; i++) { let on = false; for (let k = 0; k < 3; k++) { const t = T[k][i]; if (t > amb + 22 || t < amb - 3) { on = true; break; } } if (on) sel.push(i); }
      const m = sel.length, pos = new Float32Array(m * 3), tt = new Uint8Array(m * 3);
      sel.forEach((i, q) => { pos[q * 3] = P[i * 3]; pos[q * 3 + 1] = P[i * 3 + 1]; pos[q * 3 + 2] = P[i * 3 + 2]; tt[q * 3] = T[0][i]; tt[q * 3 + 1] = T[1][i]; tt[q * 3 + 2] = T[2][i]; });
      const geo = new THREE.BufferGeometry(); geo.setAttribute('position', new THREE.BufferAttribute(pos, 3)); geo.setAttribute('temp', new THREE.BufferAttribute(tt, 3, true));
      const mat = new THREE.ShaderMaterial({ transparent: true, depthWrite: false, clipping: true, clippingPlanes: [clip], fog: false,
        uniforms: { alpha: { value: 0 }, pass: { value: 2 }, hh: { value: 800 }, px: { value: 1 }, amb: { value: amb / 255 } },
        vertexShader: `attribute vec3 temp; uniform float pass, hh, px, amb; varying float vT; varying float vA;
          #include <clipping_planes_pars_vertex>
          void main(){ float a = pass; float t = a < 1. ? mix(temp.x, temp.y, a) : mix(temp.y, temp.z, a - 1.); vT = t * 255. - 10.;
            float d = t - amb; vA = d > 0. ? smoothstep(12. / 255., 40. / 255., d) : smoothstep(2. / 255., 5. / 255., -d);
            vec4 mvPosition = modelViewMatrix * vec4(position, 1.); mvPosition.xyz += normalize(-mvPosition.xyz) * .22;   // just off the surface, toward the eye
            gl_Position = projectionMatrix * mvPosition;
            #include <clipping_planes_vertex>
            float s = .42 * projectionMatrix[1][1] * hh * .5 / max(.1, -mvPosition.z); gl_PointSize = vA > .01 ? clamp(s, 3. * px, 90. * px) : 0.; }`,
        fragmentShader: `uniform float alpha; varying float vT; varying float vA;
          #include <clipping_planes_pars_fragment>
          void main(){
            #include <clipping_planes_fragment>
            vec2 q = gl_PointCoord - .5; float r = length(q) * 2.; if (r > 1.) discard;
            vec3 c; if (vT < 18.) c = ${v3(TH.data.heatLayer.cold)}; else if (vT < 70.) c = mix(${v3(TH.data.heatLayer.w0)}, ${v3(TH.data.heatLayer.w1)}, (vT - 18.) / 52.); else c = mix(${v3(TH.data.heatLayer.w1)}, ${v3(TH.data.heatLayer.w2)}, clamp((vT - 70.) / 150., 0., 1.));
            float core = exp(-r * r * 6.), halo = exp(-r * r * 1.6) * .45; float a = (core * .85 + halo) * vA * alpha;
            gl_FragColor = vec4(pow(c, vec3(2.2)) * (1. + core * .6), a); }` });
      const pts = new THREE.Points(geo, mat); pts.frustumCulled = false; pts.renderOrder = 9; root.add(pts); disposers.push(() => { geo.dispose(); mat.dispose(); });
      return pts;
    },
    change() { const v = makeVoxLayer(g, C.change.labels, [{ label: 2, color: PAL.rose, opacity: 1, emissive: .12 }, { label: 3, color: C3(TH.data.debris), opacity: 1, emissive: .1 }, { label: 4, color: C3(TH.data.fill), opacity: .45 }, { label: 5, color: PAL.lav, opacity: .55, emissive: .15 }], clip); root.add(v.group); disposers.push(() => v.dispose()); return v; },
    debris() { const v = makeVoxLayer(g, C.change.labels, [{ label: 3, color: C3(TH.data.debris), opacity: 1, emissive: .1 }, { label: 4, color: C3(TH.data.fill), opacity: .5 }], clip); root.add(v.group); disposers.push(() => v.dispose()); return v; },
    truth() { const v = makeVoxLayer(g, C.truth.altered, [{ label: 2, color: PAL.rose, opacity: .9, emissive: .12 }, { label: 1, color: PAL.lav, opacity: .3, emissive: .15 }], clip); root.add(v.group); disposers.push(() => v.dispose()); return v; },
    pockets() {
      const lab = new Uint8Array(g.N); for (const p of C.pockets.list) for (const c of p.cells) lab[c] = p.kind === 'gap' ? 1 : 2;
      const v = makeVoxLayer(g, lab, [{ label: 1, color: PAL.lav, opacity: .8, emissive: .5, xray: true }, { label: 2, color: C3(TH.data.emptyLight), opacity: .6, emissive: .4, xray: true }], clip); root.add(v.group); disposers.push(() => v.dispose());
      // the leaning pieces behind the inferred pockets
      const lines = createLines(800, { width: 1.6, additive: true, nearFade: [0.5, 2] }); lines.begin();
      for (const p of C.pockets.list) { if (!p.piece) continue; const pts = p.piece.pts; const lav = lin(PAL.lav); for (let i = 1; i < pts.length; i += 1) { const a = pts[i - 1], b = pts[i]; if (Math.hypot(a[0] - b[0], a[2] - b[2]) > 1.6) continue; lines.seg(a[0], a[1], a[2], b[0], b[1], b[2], ...lav, .5); } }
      lines.end(); v.group.add(lines.mesh); disposers.push(() => lines.dispose()); return v;
    },
    voids() { const lab = new Uint8Array(g.N); for (const v of C.truth.voids) for (const c of v.cells) lab[c] = 1; const v = makeVoxLayer(g, lab, [{ label: 1, color: C3(TH.data.voidTruth), opacity: .45, emissive: .35, xray: true }], clip); root.add(v.group); disposers.push(() => v.dispose()); return v; },
    rooms() { const m = quadMesh(roomQuads(C, (id) => (opts.statusOf ? opts.statusOf(id) : C.rooms[id].status)), clip); root.add(m); disposers.push(() => { m.geometry.dispose(); m.material.dispose(); }); return m; },
    truthRooms() { const m = quadMesh(roomQuads(C, (id) => C.truth.rooms[id].status, 0.1, 0.25), clip); root.add(m); disposers.push(() => { m.geometry.dispose(); m.material.dispose(); }); return m; },
    order() { const m = quadMesh(phiQuads(C), clip); root.add(m); disposers.push(() => { m.geometry.dispose(); m.material.dispose(); }); return m; },
    arrows() {
      const lines = createLines(1200, { width: 2.4, additive: false, nearFade: [0.5, 2] }); lines.begin();
      for (const w of C.condition.walls) {
        if (!w.ok || w.tilt == null || !w.lean) continue; const F = w.frame; const t = w.tilt; const c = t >= 1.6 ? PAL.danger : t >= .35 ? PAL.heat : PAL.safe; if (t < .2) continue;
        const L2 = Math.min(2.2, 0.35 + t * 0.16); const o = F.c; const top = [o[0] + F.y[0] * F.h * .3, o[1] + F.y[1] * F.h * .3, o[2] + F.y[2] * F.h * .3]; const out = (F.c[0] * F.n[0] + F.c[2] * F.n[2]) > 0 ? 1 : -1; const off = [F.n[0] * out * .35, 0, F.n[2] * out * .35];
        const a = [top[0] + off[0], top[1], top[2] + off[2]], b = [a[0] + w.lean[0] * L2, a[1], a[2] + w.lean[2] * L2]; const cl = lin(c);
        lines.seg(...a, ...b, ...cl, .95); const s = .18; const px = -w.lean[2], pz = w.lean[0];
        lines.seg(...b, b[0] - w.lean[0] * s + px * s * .6, b[1], b[2] - w.lean[2] * s + pz * s * .6, ...cl, .95); lines.seg(...b, b[0] - w.lean[0] * s - px * s * .6, b[1], b[2] - w.lean[2] * s - pz * s * .6, ...cl, .95);
      }
      lines.end(); root.add(lines.mesh); disposers.push(() => lines.dispose()); return lines;
    },
    cracks() { const lines = createLines(Math.max(64, C.condition.marks.length * 2 + 8), { width: 2.6, additive: false }); lines.begin(); const h = lin(PAL.heat); for (const mk of C.condition.marks) lines.seg(...mk.a, ...mk.b, ...h, mk.fp ? .7 : 1); lines.end(); lines.mesh.renderOrder = 8; root.add(lines.mesh); disposers.push(() => lines.dispose()); return lines; },
    routes() {
      const grp = new THREE.Group(); const all = [];
      for (const fl of C.routes) {
      const lines = createLines(4000, { width: 2.2, additive: false, dash: 0 }), cut = createLines(1000, { width: 2.6, additive: false, dash: .5 }), rt = createLines(1500, { width: 3.2, additive: true, packets: true }), glow = createGlows(32, { minPx: 9 });
      lines.begin(); cut.begin(); rt.begin(); glow.begin();
        const hz = lin(PAL.haze);
        for (const e of fl.base.edges) for (let i = 1; i < e.pts.length; i++) lines.seg(...e.pts[i - 1], ...e.pts[i], ...hz, .25);
        for (const e of fl.post.edges) { const w = 2 * e.clear; const c = lin(w >= 1.2 ? PAL.safe : w >= .8 ? PAL.heat : PAL.danger); for (let i = 1; i < e.pts.length; i++) lines.seg(...e.pts[i - 1], ...e.pts[i], ...c, .9); }
        const dg = lin(PAL.danger); for (const e of fl.cut) for (let i = 1; i < e.pts.length; i++) { const a = e.pts[i - 1], b = e.pts[i]; const L2 = Math.hypot(b[0] - a[0], b[2] - a[2]); cut.seg(a[0], a[1] + .05, a[2], b[0], b[1] + .05, b[2], ...dg, .95, .95, 0, L2); }
        let u = 0; const tl = lin(PAL.teal);
        for (const r of fl.routes) { if (!r.reachable || !r.pts) continue; u = 0; for (let i = 1; i < r.pts.length; i++) { const a = r.pts[i - 1], b = r.pts[i], L2 = Math.hypot(b[0] - a[0], b[2] - a[2]); rt.seg(a[0], a[1] + .12, a[2], b[0], b[1] + .12, b[2], ...tl, .7, .7, u, u + L2, 1); u += L2; } }
        for (const nk of fl.necks) glow.add(nk.p[0], nk.p[1], nk.p[2], ...lin(PAL.danger), 1, .5);
      lines.end(); cut.end(); rt.end(); glow.end();
      const sg = new THREE.Group(); sg.userData.storey = fl.storey; sg.add(lines.mesh, cut.mesh, rt.mesh, glow.mesh); grp.add(sg); all.push(lines, cut, rt, glow);
      }
      root.add(grp); disposers.push(() => { for (const x of all) x.dispose(); });
      return grp;
    },
    behaviour() {
      // the replayed flight log on the floor in view: tracks coloured by phi_swarm where a drone had neighbours (teal
      // aligned, lavender heading apart), faint elsewhere; where phi_swarm fell under 0.5 (lavender), where the speed
      // forecast missed most (rose), and the stalls at gaps (danger)
      const F = C.flight, W = C.swarm, n = W.n, nD = W.nD, pos = W.pos, md = W.mode, PI = W.phiI;
      const lv = behaviourLevel(W), y0 = lv * 3 - .4, y1 = lv * 3 + 3.1, inB = (y) => y >= y0 && y <= y1;
      const lines = createLines(n * nD + 8, { width: 2.2, additive: false }), glow = createGlows(F.stalls.length + W.cells.length + W.drops.length * 2 + W.forecast.misses.length * 2 + 16, { minPx: 9 });
      lines.begin(); glow.begin(); const c = new THREE.Color();
      for (let k = 0; k < nD; k++) for (let t = 1; t < n; t++) {
        const o = t * nD + k, o0 = (t - 1) * nD + k; if (!md[o] || !md[o0] || (md[o] === 2 && md[o0] === 2)) continue;   // flying at either end (into or out of a stop)
        const ax = pos[o0 * 3], ay = pos[o0 * 3 + 1], az = pos[o0 * 3 + 2], bx = pos[o * 3], by = pos[o * 3 + 1], bz = pos[o * 3 + 2];
        if (!inB(ay) || !inB(by) || Math.hypot(bx - ax, by - ay, bz - az) > 2.5) continue;
        const ph = Number.isFinite(PI[o]) ? PI[o] : PI[o0];
        if (Number.isFinite(ph)) { c.copy(PAL.lav).lerp(PAL.teal, Math.min(1, Math.max(0, (ph - .3) / .6))); lines.seg(ax, ay + .05, az, bx, by + .05, bz, c.r, c.g, c.b, .95); }
        else lines.seg(ax, ay, az, bx, by, bz, .86, .84, .93, .28);
      }
      // phi_swarm over space: 1.5 m cells where nearby drones were measured, teal aligned, lavender heading apart
      for (const cl of W.cells) if (inB(cl.p[1])) { c.copy(PAL.lav).lerp(PAL.teal, Math.min(1, Math.max(0, (cl.phi - .3) / .6))); glow.add(cl.p[0], cl.p[1], cl.p[2], c.r, c.g, c.b, .5, .7); }
      for (const s2 of F.stalls) if (inB(s2.p[1])) glow.add(s2.p[0], s2.p[1], s2.p[2], ...lin(PAL.danger), .8, .55);
      for (const d of W.drops) if (d.p[1] <= y1) { glow.add(d.p[0], d.p[1], d.p[2], ...lin(PAL.lav), 1, 1.2); glow.add(d.p[0], d.p[1], d.p[2], 1, 1, 1, .7, .3); }
      for (const m of W.forecast.misses) if (m.p[1] <= y1) { glow.add(m.p[0], m.p[1], m.p[2], ...lin(PAL.rose), 1, 1.4); glow.add(m.p[0], m.p[1], m.p[2], 1, 1, 1, .8, .32); }
      lines.end(); glow.end(); const grp = new THREE.Group(); grp.add(lines.mesh, glow.mesh); root.add(grp); disposers.push(() => { lines.dispose(); glow.dispose(); }); grp.userData = { lines, glow }; return grp;
    },
    confidence() {
      const S = C.confidence.surf, n = S.length, pts = new Float32Array(n * 3), cv = new Uint8Array(n); const q = [0, 0, 0];
      const SY = g.nx * g.nz, solid = (c) => C.Shat[c] || C.debrisGrid[c];
      for (let k = 0; k < n; k++) { const c = S[k]; const i = c % g.nx, r = (c - i) / g.nx, kk = r % g.nz, j = (r - kk) / g.nz;
        // the open side: toward the neighbours that are not solid
        let nx = (solid(c - 1) ? 0 : -1) + (solid(c + 1) ? 0 : 1), ny = (solid(c - SY) ? 0 : -1) + (solid(c + SY) ? 0 : 1), nz = (solid(c - g.nx) ? 0 : -1) + (solid(c + g.nx) ? 0 : 1); const L = Math.hypot(nx, ny, nz) || 1;
        pts[k * 3] = g.x0 + (i + .5) * g.vox + nx / L * .1; pts[k * 3 + 1] = g.y0 + (j + .5) * g.vox + ny / L * .1; pts[k * 3 + 2] = g.z0 + (kk + .5) * g.vox + nz / L * .1; cv[k] = C.confidence.before[k]; }
      const p = makeCloud(pts, n, PAL.teal, 0.15, clip, { conf: cv, mode: 2 }); p.material.uniforms.mode.value = 2; p.matrix.identity(); root.add(p); disposers.push(() => { p.geometry.dispose(); p.material.dispose(); });
      p.userData.setAfter = (a) => { const arr = p.geometry.attributes.cval.array, st = p.userData.stride || 1; const A = C.confidence.after, B = C.confidence.before; for (let k = 0; k < arr.length; k++) arr[k] = a ? A[k * st] : B[k * st]; p.geometry.attributes.cval.needsUpdate = true; };
      return p;
    },
    refly() {
      const rp = C.scans.refly.poses, un = C.confidence.unreachable || [], tg = C.confidence.targets || [];
      const lines = createLines(rp.length * 2 + 8, { width: 2.4, additive: true, packets: true }), glow = createGlows(rp.length + tg.length + un.length + 8, { minPx: 8 }); lines.begin(); glow.begin();
      const start = world.anchors.pad; let prev = [start[0], 2.5, start[2]]; let u = 0; const tl = lin(PAL.teal);
      for (const q of rp) { const L2 = Math.hypot(q.p[0] - prev[0], q.p[1] - prev[1], q.p[2] - prev[2]); lines.seg(...prev, ...q.p, ...tl, .6, .6, u, u + L2, 1); u += L2; prev = q.p; glow.add(q.p[0], q.p[1], q.p[2], ...tl, 1, .25); }
      // the targets (teal-white) and the weak spots no drone can reach (warm): those are for a human to check
      for (const t of tg) glow.add(t.c[0], t.c[1], t.c[2], .8, 1, .96, .9, .45);
      for (const q of un) glow.add(q.c[0], q.c[1], q.c[2], ...lin(PAL.heat), .85, .4);
      lines.end(); glow.end();
      const pts = C.scans.refly.pts; const cl = pts.length ? makeCloud(pts, pts.length / 3, C3(TH.data.refly), 0.05, clip) : null; if (cl) cl.matrix.identity();
      const grp = new THREE.Group(); grp.add(lines.mesh, glow.mesh); if (cl) grp.add(cl); root.add(grp); grp.userData = { cloud: cl, lines, glow };
      disposers.push(() => { lines.dispose(); glow.dispose(); if (cl) { cl.geometry.dispose(); cl.material.dispose(); } }); return grp;
    },
    ghost() {
      const lines = createLines(C.model.parts.length * 4 + 16, { width: 1.0, additive: true, nearFade: [1, 4] }); lines.begin(); const c = lin(PAL.lav);
      for (const p of C.model.parts) { if (p.kind === 'site' || p.kind === 'plinth' || p.kind === 'beam' || p.kind === 'stair') continue; const b = p.aabb; const y1 = b[4], y0 = b[1];
        lines.seg(b[0], y1, b[2], b[3], y1, b[2], ...c, .35); lines.seg(b[3], y1, b[2], b[3], y1, b[5], ...c, .35); lines.seg(b[3], y1, b[5], b[0], y1, b[5], ...c, .35); lines.seg(b[0], y1, b[5], b[0], y1, b[2], ...c, .35); }
      lines.end(); root.add(lines.mesh); disposers.push(() => lines.dispose()); return lines;
    },
    packets() { const glow = createGlows(160, { minPx: 5 }); root.add(glow.mesh); disposers.push(() => glow.dispose()); return glow; },
    pods() {
      const grp = new THREE.Group(); const body = new THREE.CylinderGeometry(.09, .09, .1, 16).rotateX(Math.PI / 2), ringG = new THREE.TorusGeometry(.13, .012, 6, 28);
      const mB = new THREE.MeshStandardMaterial({ color: C3(TH.data.podBody), roughness: .6 }), mR = new THREE.MeshBasicMaterial({ color: C3(TH.data.podRing) });
      for (const pd of C.pods.list) { const m = new THREE.Mesh(body, mB), r = new THREE.Mesh(ringG, mR); m.position.set(...pd.pos); r.position.set(...pd.pos); const look = new THREE.Vector3(pd.pos[0] + pd.normal[0], pd.pos[1] + pd.normal[1], pd.pos[2] + pd.normal[2]); m.lookAt(look); r.lookAt(look); m.castShadow = true; m.userData.pod = pd.id; r.userData.pod = pd.id; grp.add(m, r); }
      root.add(grp); disposers.push(() => { body.dispose(); ringG.dispose(); mB.dispose(); mR.dispose(); }); return grp;
    },
  };
  const ensure = (name) => { if (!L[name]) { try { L[name] = get[name](); } catch (e) { console.warn('[act7] layer', name, e); L[name] = null; } } return L[name]; };
  const setW = (name, w) => { try { setW1(name, w); } catch (e) { if (!setW.warned) { setW.warned = true; console.warn('[act7] layer weight', name, e); } } };
  const setW1 = (name, w) => {
    if (w <= .005 && !L[name]) return; const o = ensure(name); if (!o) return;
    if (o.isPoints) { o.visible = w > .005; o.material.uniforms.alpha.value = w * (o.userData.alphaMul ?? 1); return; }
    if (o.setOpacity) { o.setOpacity(w); return; }
    if (o.isMesh && o.material && o.material.uniforms && o.material.uniforms.alpha) { o.visible = w > .005; o.material.uniforms.alpha.value = w; return; }
    if (o.mesh && o.U) { o.mesh.visible = w > .005; if (o.U.op) o.U.op.value = w; return; }
    if (o.isGroup || o.isObject3D) { o.visible = w > .005; o.traverse((x) => { if (x.material && x.material.uniforms) { if (x.material.uniforms.op) x.material.uniforms.op.value = w; if (x.material.uniforms.alpha) x.material.uniforms.alpha.value = w; } else if (x.material && 'opacity' in x.material && x !== o) { x.material.transparent = true; x.material.opacity = w; } }); }
  };
  return {
    root, L, clip, ensure, setW,
    get: (n) => L[n],
    // rebuild a flat layer (the room tiles after the statuses change)
    reset(name) { const o = L[name]; if (!o) return; root.remove(o); if (o.geometry) o.geometry.dispose(); if (o.material) o.material.dispose(); delete L[name]; },
    // the cutaway: a horizontal plane through the ceiling of storey `level` (moved with its storey fit), or none
    setCut(level) {
      if (level == null) { clip.set(new THREE.Vector3(0, -1, 0), 1000); return; }
      const T = C.storeys[Math.min(4, level + 1)].T, R = T.R; const n = [R[1], R[4], R[7]]; const y = (level + 1) * 3 + 0.02; const p = tApply(T, 0, y, 0);
      const nv = new THREE.Vector3(-n[0], -n[1], -n[2]).normalize(); clip.setFromNormalAndCoplanarPoint(nv, new THREE.Vector3(p[0], p[1], p[2]));
    },
    dispose() { for (const d of disposers) { try { d(); } catch (e) { /* ignore */ } } scene.remove(root); },
  };
}
