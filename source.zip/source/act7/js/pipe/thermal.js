// Thermal over time: three repeat passes of the thermal camera over every surface the swarm saw. A gas-line fire in
// one flat grows between passes; a burst water tank leaves a cold patch that spreads. The pipeline measures the hot
// area (over 60 C) and the cold area (3 C under the surroundings) in each pass, and whether they are growing.
// (The temperatures themselves come from a simple heat model of the scene: the camera is simulated, the measuring
// is not.)
import { tApply, tInvert, rngFor } from '../building/geom.js';
import { NS } from '../building/building.js';

export const PASSES = [{ min: -24, label: 'Pass 1, during the search' }, { min: 3, label: 'Pass 2, after landing' }, { min: 19, label: 'Pass 3, 16 minutes later' }];
export function thermal(ctx) {
  const { model, post, pts, n, g, seed, T0 } = ctx;   // pts: registered hits (flat), n points
  const r = rngFor(seed, 'thermal');
  const fire = post.fire, tank = post.tank, room = model.rooms[fire.room];
  const Tf = post.motions[room.storey], Tfi = tInvert(Tf);
  const temps = PASSES.map(() => new Uint8Array(n));
  const q = [0, 0, 0];
  const amb = 21;
  for (let i = 0; i < n; i++) {
    const x = pts[i * 3], y = pts[i * 3 + 1], z = pts[i * 3 + 2];
    tApply(Tfi, x, y, z, q);
    const inRoom = q[0] > room.x0 - 0.35 && q[0] < room.x1 + 0.35 && q[2] > room.z0 - 0.35 && q[2] < room.z1 + 0.35 && q[1] > room.y0 - 0.3 && q[1] < room.y1 + 0.4;
    // the plume: the outside face of the kitchen's external wall, above the window
    const out = Math.abs(q[2] - (room.z0 < 0 ? room.z0 - 0.25 : room.z1 + 0.25)) < 0.45 && q[0] > room.x0 - 0.4 && q[0] < room.x1 + 0.4 && q[1] > room.y0 + 1.6 && q[1] < room.y1 + 3.5;
    const dx = x - fire.pos[0], dy = (y - fire.pos[1]) * 0.6, dz = z - fire.pos[2], d = Math.hypot(dx, dy, dz);
    // the burst tank: water spreads over the roof and soaks the top floor's ceiling under it
    const wet = tank && y > tank.pos[1] - 0.75 && y < tank.pos[1] + 1.4, dh = wet ? Math.hypot(x - tank.pos[0], z - tank.pos[2]) : 0;
    for (let k = 0; k < PASSES.length; k++) {
      let t = amb + (y > 6 ? 0.8 : 0) + r.gauss() * 0.7;
      if (inRoom || out) t += fire.peak[k] * Math.exp(-((d / (fire.radius[k] * (out ? 1.6 : 1))) ** 2));
      if (wet) t += tank.dT[k] * Math.exp(-((dh / tank.radius[k]) ** 2));
      temps[k][i] = Math.max(0, Math.min(255, Math.round(t + 10)));
    }
  }
  // measure: hot and cold area per pass (distinct voxels touched x voxel face area)
  const area = g.vox * g.vox;
  const passes = PASSES.map((P, k) => {
    const hot = new Set(), cold = new Set(); let maxT = -99, hx = 0, hy = 0, hz = 0, hn = 0, cx = 0, cy = 0, cz = 0, cn = 0;
    for (let i = 0; i < n; i++) {
      const t = temps[k][i] - 10; if (t > maxT) maxT = t;
      if (t > 60) { const c = g.cell(pts[i * 3], pts[i * 3 + 1], pts[i * 3 + 2]); if (c >= 0) hot.add(c); hx += pts[i * 3]; hy += pts[i * 3 + 1]; hz += pts[i * 3 + 2]; hn++; }
      else if (t < amb - 3) { const c = g.cell(pts[i * 3], pts[i * 3 + 1], pts[i * 3 + 2]); if (c >= 0) cold.add(c); cx += pts[i * 3]; cy += pts[i * 3 + 1]; cz += pts[i * 3 + 2]; cn++; }
    }
    return { ...P, hotArea: hot.size * area, coldArea: cold.size * area, maxT, hotCentre: hn ? [hx / hn, hy / hn, hz / hn] : null, coldCentre: cn ? [cx / cn, cy / cn, cz / cn] : null };
  });
  const g1 = passes[0].hotArea, g3 = passes[2].hotArea, c1 = passes[0].coldArea, c3 = passes[2].coldArea;
  return { passes, temps, amb, fireRoom: fire.room, spreading: g3 > g1 * 1.3 && g3 > 0.5, coldSpreading: c3 > c1 * 1.2 && c3 > 0.3 };
}
