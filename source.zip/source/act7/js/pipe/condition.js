// How the walls stand. All from the registered post-event cloud and the storey fits:
//  - plane fits (RANSAC, then least squares) per wall: tilt out of plumb, compared with the same wall in the baseline
//  - floors and ceilings per room: tilt, and sag (how far the middle sits below a plane through the edges)
//  - crack marks from a simulated RGB crack detector (recall ~0.8 within 4 m of a camera pass)
//  - the phi_wall damage field: per ~1 m wall patch, local normals (PCA on neighbours) give the nematic order
//    parameter S = largest eigenvalue of Q = <(3 n n^T - I) / 2> (a normal and its flip count the same). S ~ 1 is an
//    intact, aligned wall; low S is scattered, damaged. Damaged patches are clustered on the patch graph.
//  - a draft status per room from simple conservative rules; space never seen is never safe.
import { tApply, tInvert, eigSym3, fitPlane, DEG, rngFor, qToMat, quantile } from '../building/geom.js';
import { NS, floorTop, ceilingOf } from '../building/building.js';
import { clearLine } from './raycast.js';
import { O_UNK, O_FREE, O_OCC } from './occupancy.js';

export const DRAFT = { tiltNoEntry: 1.6, tiltCaution: 0.35, sagNoEntry: 0.04, sagCaution: 0.012, crushNoEntry: 0.05, crushCaution: 0.004,
  debrisNoEntry: 0.18, debrisCaution: 0.02, goneNoEntry: 0.08, phiDamaged: 0.95, phiNoEntry: 0.35, phiCaution: 0.96, seenMin: 0.35, seenWell: 0.7 };

const unitFrame = (u, T) => {
  const R = T.R, n0 = u.axis === 'x' ? [1, 0, 0] : [0, 0, 1], a0 = u.axis === 'x' ? [0, 0, 1] : [1, 0, 0];
  const rot = (v) => [R[0] * v[0] + R[1] * v[1] + R[2] * v[2], R[3] * v[0] + R[4] * v[1] + R[5] * v[2], R[6] * v[0] + R[7] * v[1] + R[8] * v[2]];
  const am = (u.a0 + u.a1) / 2, ym = (u.y0 + u.y1) / 2, c0 = u.axis === 'x' ? [u.off, ym, am] : [am, ym, u.off];
  return { c: tApply(T, ...c0), n: rot(n0), a: rot(a0), y: rot([0, 1, 0]), len: u.a1 - u.a0, h: u.y1 - u.y0 };
};
// points of a wall unit from a cloud: within 0.25 m of its mid plane, away from its ends, floor and beam
function wallPoints(F, hash, P, buf, opts = {}) {
  const ex = F.len / 2 + 0.1, ey = F.h / 2 + 0.1, et = 0.3;
  let x0 = 1e9, y0 = 1e9, z0 = 1e9, x1 = -1e9, y1 = -1e9, z1 = -1e9;
  for (const sa of [-1, 1]) for (const sy of [-1, 1]) for (const sn of [-1, 1]) { const p = [0, 1, 2].map((i) => F.c[i] + F.a[i] * sa * ex + F.y[i] * sy * ey + F.n[i] * sn * et); x0 = Math.min(x0, p[0]); y0 = Math.min(y0, p[1]); z0 = Math.min(z0, p[2]); x1 = Math.max(x1, p[0]); y1 = Math.max(y1, p[1]); z1 = Math.max(z1, p[2]); }
  hash.inBox(x0, y0, z0, x1, y1, z1, buf);
  const out = [], loc = [];
  const amax = F.len / 2 - (opts.endPad ?? 0.15), ylo = -F.h / 2 + (opts.floorPad ?? 0.2), yhi = F.h / 2 - (opts.topPad ?? 0.45);
  for (const i of buf) {
    const dx = P[i * 3] - F.c[0], dy = P[i * 3 + 1] - F.c[1], dz = P[i * 3 + 2] - F.c[2];
    const dn = dx * F.n[0] + dy * F.n[1] + dz * F.n[2]; if (Math.abs(dn) > 0.25) continue;
    const da = dx * F.a[0] + dy * F.a[1] + dz * F.a[2]; if (Math.abs(da) > amax) continue;
    const dv = dx * F.y[0] + dy * F.y[1] + dz * F.y[2]; if (dv < ylo || dv > yhi) continue;
    out.push(i); loc.push(da, dv, dn);
  }
  return { idx: out, loc };
}
function ransacPlane(P, idx, r, thr = 0.025, iters = 60, near = null) {
  if (idx.length < 20) return null;
  let best = null, bestN = 0;
  for (let it = 0; it < iters; it++) {
    const a = idx[Math.floor(r() * idx.length)], b = idx[Math.floor(r() * idx.length)], c = idx[Math.floor(r() * idx.length)];
    const ux = P[b * 3] - P[a * 3], uy = P[b * 3 + 1] - P[a * 3 + 1], uz = P[b * 3 + 2] - P[a * 3 + 2], vx = P[c * 3] - P[a * 3], vy = P[c * 3 + 1] - P[a * 3 + 1], vz = P[c * 3 + 2] - P[a * 3 + 2];
    let nx = uy * vz - uz * vy, ny = uz * vx - ux * vz, nz = ux * vy - uy * vx; const L = Math.hypot(nx, ny, nz); if (L < 1e-6) continue; nx /= L; ny /= L; nz /= L;
    if (near && Math.abs(nx * near[0] + ny * near[1] + nz * near[2]) < 0.9) continue;   // only planes within ~25 degrees of the expected wall
    const d = nx * P[a * 3] + ny * P[a * 3 + 1] + nz * P[a * 3 + 2]; let n = 0;
    for (let k = 0; k < idx.length; k += idx.length > 1200 ? 3 : 1) { const i = idx[k]; if (Math.abs(nx * P[i * 3] + ny * P[i * 3 + 1] + nz * P[i * 3 + 2] - d) < thr) n++; }
    if (n > bestN) { bestN = n; best = [nx, ny, nz, d]; }
  }
  if (!best) return null;
  const inl = []; for (const i of idx) if (Math.abs(best[0] * P[i * 3] + best[1] * P[i * 3 + 1] + best[2] * P[i * 3 + 2] - best[3]) < thr) inl.push(i);
  if (inl.length < 20) return null;
  const f = fitPlane(P, inl); if (!f) return null; f.inliers = inl; return f;
}
// one wall in one cloud: plane, tilt out of plumb, which way its top leans
function fitWall(F, hash, P, buf, r) {
  const g = wallPoints(F, hash, P, buf); const f = ransacPlane(P, g.idx, r, 0.025, 80, F.n);
  if (!f) return { n: g.idx.length, ok: false };
  let span0 = 1e9, span1 = -1e9; for (const i of f.inliers) { const da = (P[i * 3] - F.c[0]) * F.a[0] + (P[i * 3 + 1] - F.c[1]) * F.a[1] + (P[i * 3 + 2] - F.c[2]) * F.a[2]; span0 = Math.min(span0, da); span1 = Math.max(span1, da); }
  if (f.inliers.length < 30 || span1 - span0 < Math.min(0.8, F.len * 0.4) || Math.abs(f.n[0] * F.n[0] + f.n[1] * F.n[1] + f.n[2] * F.n[2]) < 0.9) return { n: g.idx.length, ok: false };
  let nf = f.n; if (nf[0] * F.n[0] + nf[1] * F.n[1] + nf[2] * F.n[2] < 0) nf = nf.map((v) => -v);
  const tilt = Math.asin(Math.min(1, Math.abs(nf[1]))) / DEG;
  const hl = Math.hypot(nf[0], nf[2]) || 1, sg = nf[1] > 0 ? -1 : 1;
  // uncertainty of the tilt: residual over (spread in height x sqrt(n))
  let mv = 0, vv = 0; for (const i of f.inliers) { const dv = (P[i * 3] - F.c[0]) * F.y[0] + (P[i * 3 + 1] - F.c[1]) * F.y[1] + (P[i * 3 + 2] - F.c[2]) * F.y[2]; mv += dv; vv += dv * dv; } mv /= f.inliers.length; const sv = Math.sqrt(Math.max(1e-6, vv / f.inliers.length - mv * mv));
  const sigma = Math.max(0.015, f.rms) / (sv * Math.sqrt(f.inliers.length)) / DEG;
  return { ok: true, n: g.idx.length, inl: f.inliers.length, rms: f.rms, normal: nf, tilt, sigma, lean: [sg * nf[0] / hl, 0, sg * nf[2] / hl], pts: g };
}

// floor (or ceiling) of a room: plane tilt and sag from 0.4 m cells
function fitSurface(room, T, hash, P, buf, ceiling, Org) {
  const Ti = tInvert(T), yl = ceiling ? room.y1 : room.y0, pad = 0.3;
  const cs = 0.4, nx = Math.max(1, Math.floor((room.x1 - room.x0 - 2 * pad) / cs)), nz = Math.max(1, Math.floor((room.z1 - room.z0 - 2 * pad) / cs));
  if (nx < 2 || nz < 2) return null;
  let x0 = 1e9, y0 = 1e9, z0 = 1e9, x1 = -1e9, y1 = -1e9, z1 = -1e9;
  for (const lx of [room.x0, room.x1]) for (const lz of [room.z0, room.z1]) for (const ly of [yl - 0.2, yl + 0.2]) { const p = tApply(T, lx, ly, lz); x0 = Math.min(x0, p[0]); y0 = Math.min(y0, p[1]); z0 = Math.min(z0, p[2]); x1 = Math.max(x1, p[0]); y1 = Math.max(y1, p[1]); z1 = Math.max(z1, p[2]); }
  hash.inBox(x0, y0, z0, x1, y1, z1, buf);
  const cells = Array.from({ length: nx * nz }, () => []); const q = [0, 0, 0];
  for (const i of buf) {
    // seen from the right side: a floor from above, a ceiling from below (the slab's other face is 15 cm away)
    if (Org && ((Org[i * 3 + 1] - P[i * 3 + 1]) > 0) === ceiling) continue;
    tApply(Ti, P[i * 3], P[i * 3 + 1], P[i * 3 + 2], q); const dh = q[1] - yl; if (Math.abs(dh) > 0.16) continue;
    const a = Math.floor((q[0] - room.x0 - pad) / cs), b = Math.floor((q[2] - room.z0 - pad) / cs); if (a < 0 || b < 0 || a >= nx || b >= nz) continue;
    cells[b * nx + a].push(dh);
  }
  const H = new Float64Array(nx * nz).fill(NaN); let good = 0, high = 0;
  cells.forEach((c, k) => { if (c.length < 3) return; const v = quantile(c, ceiling ? 0.75 : 0.25); H[k] = v; good++; if (!ceiling && v > 0.06) high++; });
  if (good < Math.max(5, nx * nz * 0.3)) return { measured: false, cover: good / (nx * nz) };
  // plane through the edge cells, then the deficit in the middle
  const fit = (sel) => { let s = [0, 0, 0, 0, 0, 0, 0, 0, 0], b = [0, 0, 0], n = 0; for (let k = 0; k < nx * nz; k++) { if (!(H[k] === H[k]) || !sel(k)) continue; const x = (k % nx) * cs, z = Math.floor(k / nx) * cs; const r = [1, x, z]; for (let i = 0; i < 3; i++) { b[i] += r[i] * H[k]; for (let j = 0; j < 3; j++) s[i * 3 + j] += r[i] * r[j]; } n++; } if (n < 3) return null; for (let i = 0; i < 3; i++) s[i * 4] += 1e-6; const M = s; const det = (m) => m[0] * (m[4] * m[8] - m[5] * m[7]) - m[1] * (m[3] * m[8] - m[5] * m[6]) + m[2] * (m[3] * m[7] - m[4] * m[6]); const D0 = det(M); if (Math.abs(D0) < 1e-12) return null; const sol = [0, 1, 2].map((c) => { const m = M.slice(); for (let i = 0; i < 3; i++) m[i * 3 + c] = b[i]; return det(m) / D0; }); return sol; };
  const edge = (k) => { const a = k % nx, b = Math.floor(k / nx); return a === 0 || b === 0 || a === nx - 1 || b === nz - 1; };
  const pe = fit(edge) || fit(() => true); if (!pe) return { measured: false, cover: good / (nx * nz) };
  const all = fit(() => true);
  const def = []; for (let k = 0; k < nx * nz; k++) { if (!(H[k] === H[k]) || edge(k)) continue; const x = (k % nx) * cs, z = Math.floor(k / nx) * cs; def.push(pe[0] + pe[1] * x + pe[2] * z - H[k]); }
  def.sort((a, b) => b - a);
  const sag = def.length ? Math.max(0, def.length > 2 ? def[1] : def[0]) : 0;
  // tilt in the world: the local plane's slope combined with the storey's rotation
  const R = T.R, gx = all ? all[1] : 0, gz = all ? all[2] : 0; const nl = [-gx, 1, -gz]; const L = Math.hypot(...nl);
  const nw = [(R[0] * nl[0] + R[1] * nl[1] + R[2] * nl[2]) / L, (R[3] * nl[0] + R[4] * nl[1] + R[5] * nl[2]) / L, (R[6] * nl[0] + R[7] * nl[1] + R[8] * nl[2]) / L];
  return { measured: true, cover: good / (nx * nz), sag, tilt: Math.acos(Math.min(1, Math.abs(nw[1]))) / DEG, debrisCells: high / good };
}

export function* condition(ctx) {
  const { model, fits, tests, g, S, CH, postPts, postHash, postOrg, basePts, baseHash, post, scene, poses, seed } = ctx;
  const r = rngFor(seed, 'condition'); const buf = [];
  // ------------------------------------------------------------------ walls
  const walls = [];
  for (const u of model.walls) {
    const s = Math.max(0, Math.min(NS, u.storey)), Fp = unitFrame(u, fits[s].T), Fb = unitFrame(u, { R: [1, 0, 0, 0, 1, 0, 0, 0, 1], t: [0, 0, 0] });
    const gone = u.parts.filter((id) => tests[id].state === 'gone').length / Math.max(1, u.parts.length);
    const wb = fitWall(Fb, baseHash, basePts, buf, r), wp = gone > 0.7 ? { ok: false, n: 0 } : fitWall(Fp, postHash, postPts, buf, r);
    walls.push({ id: u.id, storey: u.storey, frame: Fp, gone, ok: wp.ok, tilt: wp.ok ? wp.tilt : null, sigma: wp.ok ? wp.sigma : null, baseTilt: wb.ok ? wb.tilt : null, lean: wp.lean || null, inl: wp.inl || 0, rms: wp.rms || 0, pts: wp.pts || null, rooms: u.rooms, truthTilt: post.walls[u.id].tilt });
    if (walls.length % 30 === 0) yield { p: 0.3 * walls.length / model.walls.length };
  }
  // ------------------------------------------------------------------ floors and ceilings
  const surf = model.rooms.map((room) => {
    const s = room.storey; const fl = fitSurface(room, fits[s].T, postHash, postPts, buf, false, postOrg), ce = fitSurface(room, fits[Math.min(NS, s + 1)].T, postHash, postPts, buf, true, postOrg);
    return { floor: fl, ceiling: ce };
  });
  yield { p: 0.45 };
  // ------------------------------------------------------------------ cracks: the simulated RGB detector
  const marks = []; let segAll = 0, segNear = 0, segHit = 0;
  for (const cr of post.cracks) {
    const u = model.walls[cr.unit]; const Tt = post.motions[Math.max(0, Math.min(NS, u.storey))]; const R = Tt.R;
    const n0 = u.axis === 'x' ? [1, 0, 0] : [0, 0, 1], nw = [R[0] * n0[0] + R[1] * n0[1] + R[2] * n0[2], R[3] * n0[0] + R[4] * n0[1] + R[5] * n0[2], R[6] * n0[0] + R[7] * n0[1] + R[8] * n0[2]];
    for (let k = 1; k < cr.pts.length; k++) {
      const a = cr.pts[k - 1], b = cr.pts[k], m = [(a[0] + b[0]) / 2, (a[1] + b[1]) / 2, (a[2] + b[2]) / 2], len = Math.hypot(b[0] - a[0], b[1] - a[1], b[2] - a[2]);
      segAll++; let near = false;
      for (const sg of [-1, 1]) {
        const f = [m[0] + nw[0] * sg * (u.t / 2 + 0.03), m[1], m[2] + nw[2] * sg * (u.t / 2 + 0.03)];
        for (const q of poses) { const d = Math.hypot(q.p[0] - f[0], q.p[1] - f[1], q.p[2] - f[2]); if (d > 4) continue; if ((q.p[0] - f[0]) * nw[0] * sg + (q.p[2] - f[2]) * nw[2] * sg < 0.05) continue; if (clearLine(scene, q.p, f, 0.04)) { near = true; break; } }
        if (near) break;
      }
      if (!near) continue; segNear++;
      if (r() < 0.8) { segHit++; marks.push({ a: a.map((v) => v + r.gauss() * 0.02), b: b.map((v) => v + r.gauss() * 0.02), unit: cr.unit, len, fp: false }); }
    }
  }
  // a couple of false marks on seen walls (stains, cable runs): conservative, they only ever add caution
  const nFalse = r() < 0.5 ? 1 : r() < 0.6 ? 2 : 0;
  for (let k = 0; k < nFalse; k++) { const w = walls.filter((x) => x.ok)[Math.floor(r() * walls.filter((x) => x.ok).length)]; if (!w) break; const F = w.frame, a = [0, 1, 2].map((i) => F.c[i] + F.a[i] * (r() - .5) * F.len * .6 + F.y[i] * (r() - .3) * F.h * .5 + F.n[i] * (u_t(model, w.id) / 2 + 0.01)); const b = a.map((v, i) => v + F.y[i] * 0.4 + F.a[i] * 0.25); marks.push({ a, b, unit: w.id, len: 0.47, fp: true }); }
  const crackLen = new Float64Array(model.walls.length); for (const mk of marks) crackLen[mk.unit] += mk.len;
  yield { p: 0.55 };
  // ------------------------------------------------------------------ phi_wall: nematic order per ~1 m patch
  const patches = []; const nb = [];
  for (const w of walls) {
    const u = model.walls[w.id], F = w.frame; const na = Math.max(1, Math.round(F.len / 1.0)), nv = Math.max(1, Math.round(F.h / 1.0));
    const pa = F.len / na, pv = F.h / nv;
    const ops = u.openings.map((id) => model.openings[id]);
    const got = wallPoints(F, postHash, postPts, buf, { endPad: 0.25, floorPad: 0.2, topPad: 0.45 });
    const nearOpening = (da, dv) => { const la = u.a0 + F.len / 2 + da, lv = u.y0 + F.h / 2 + dv; for (const o of ops) if (la > o.o0 - 0.12 && la < o.o1 + 0.12 && lv > o.y0 - 0.12 && lv < o.y1 + 0.12) return true; return false; };
    const buckets = Array.from({ length: na * nv }, () => []);
    for (let k = 0; k < got.idx.length; k++) { const da = got.loc[k * 3], dv = got.loc[k * 3 + 1]; if (nearOpening(da, dv)) continue; const ia = Math.floor((da + F.len / 2) / pa), iv = Math.floor((dv + F.h / 2) / pv); if (ia < 0 || iv < 0 || ia >= na || iv >= nv) continue; buckets[iv * na + ia].push(got.idx[k]); }
    for (let iv = 0; iv < nv; iv++) for (let ia = 0; ia < na; ia++) {
      const la0 = u.a0 + ia * pa, la1 = la0 + pa, lv0 = u.y0 + iv * pv, lv1 = lv0 + pv;
      let opArea = 0; for (const o of ops) { const ox = Math.max(0, Math.min(la1, o.o1 + 0.12) - Math.max(la0, o.o0 - 0.12)), oy = Math.max(0, Math.min(lv1, o.y1 + 0.12) - Math.max(lv0, o.y0 - 0.12)); opArea += ox * oy; }
      if (opArea > 0.35 * pa * pv) continue;
      const centre = [0, 1, 2].map((i) => F.c[i] + F.a[i] * (-F.len / 2 + (ia + .5) * pa) + F.y[i] * (-F.h / 2 + (iv + .5) * pv));
      const pIdx = buckets[iv * na + ia];
      let st = 'ok', Sv = null, nUsed = 0;
      if (w.gone > 0.5) st = 'missing';
      else if (pIdx.length < 12) st = 'unseen';
      else {
        let q00 = 0, q01 = 0, q02 = 0, q11 = 0, q12 = 0, q22 = 0;
        const use = pIdx.length > 36 ? Array.from({ length: 36 }, () => pIdx[Math.floor(r() * pIdx.length)]) : pIdx;
        const band = u.t / 2 + 0.07;
        for (const i of use) {
          postHash.within(postPts[i * 3], postPts[i * 3 + 1], postPts[i * 3 + 2], 0.15, nb);
          // neighbours inside the wall's own band only (not the floor, a column side or a crossing wall)
          let sx = 0, sy = 0, sz = 0, m = 0; const keep = [];
          const dni = (postPts[i * 3] - F.c[0]) * F.n[0] + (postPts[i * 3 + 1] - F.c[1]) * F.n[1] + (postPts[i * 3 + 2] - F.c[2]) * F.n[2];
          for (const j of nb) { const dn = (postPts[j * 3] - F.c[0]) * F.n[0] + (postPts[j * 3 + 1] - F.c[1]) * F.n[1] + (postPts[j * 3 + 2] - F.c[2]) * F.n[2]; if (Math.abs(dn) > band || (dn > 0) !== (dni > 0)) continue; keep.push(j); sx += postPts[j * 3]; sy += postPts[j * 3 + 1]; sz += postPts[j * 3 + 2]; m++; }
          if (m < 6) continue; sx /= m; sy /= m; sz /= m;
          let a00 = 0, a01 = 0, a02 = 0, a11 = 0, a12 = 0, a22 = 0; for (const j of keep) { const dx = postPts[j * 3] - sx, dy = postPts[j * 3 + 1] - sy, dz = postPts[j * 3 + 2] - sz; a00 += dx * dx; a01 += dx * dy; a02 += dx * dz; a11 += dy * dy; a12 += dy * dz; a22 += dz * dz; }
          const e = eigSym3(a00, a01, a02, a11, a12, a22); if (e.vals[2] > 0.2 * e.vals[1]) continue;   // a corner or an edge, not a surface
          const n = e.vecs[2];
          q00 += 1.5 * n[0] * n[0] - 0.5; q01 += 1.5 * n[0] * n[1]; q02 += 1.5 * n[0] * n[2]; q11 += 1.5 * n[1] * n[1] - 0.5; q12 += 1.5 * n[1] * n[2]; q22 += 1.5 * n[2] * n[2] - 0.5; nUsed++;
        }
        if (nUsed < 8) st = 'unseen'; else Sv = eigSym3(q00 / nUsed, q01 / nUsed, q02 / nUsed, q11 / nUsed, q12 / nUsed, q22 / nUsed).vals[0];
      }
      patches.push({ id: patches.length, wall: w.id, ia, iv, na, nv, centre, S: Sv, st, w: pa, h: pv, n: F.n, a: F.a, y: F.y, truthDmg: post.walls[w.id].damage, truthGone: post.walls[w.id].gone });
    }
  }
  yield { p: 0.8 };
  // damaged patches and their clusters on the patch graph (same wall: edge neighbours; across walls: centres < 1.25 m)
  const dmg = patches.map((p) => p.st === 'missing' || (p.st === 'ok' && p.S < DRAFT.phiDamaged));
  const par = patches.map((p, i) => i); const find = (i) => { while (par[i] !== i) { par[i] = par[par[i]]; i = par[i]; } return i; };
  const byWall = new Map(); patches.forEach((p) => { if (!byWall.has(p.wall)) byWall.set(p.wall, []); byWall.get(p.wall).push(p); });
  const dI = patches.filter((p, i) => dmg[i]);
  for (let a = 0; a < dI.length; a++) for (let b = a + 1; b < dI.length; b++) {
    const p = dI[a], q = dI[b];
    const adj = p.wall === q.wall ? Math.abs(p.ia - q.ia) + Math.abs(p.iv - q.iv) === 1 : Math.hypot(p.centre[0] - q.centre[0], p.centre[1] - q.centre[1], p.centre[2] - q.centre[2]) < 1.25;
    if (adj) { const ra = find(p.id), rb = find(q.id); if (ra !== rb) par[ra] = rb; }
  }
  const csz = new Map(); for (const p of dI) { const k = find(p.id); csz.set(k, (csz.get(k) || 0) + p.w * p.h); }
  const sizes = [...csz.values()].sort((a, b) => b - a);
  let s1 = 0, s2 = 0; for (const v of sizes) { s1 += v; s2 += v * v; }
  const xi = s1 ? Math.sqrt(s2 / s1) : 0;
  // a power-law check: slope of the rank-size line in log-log (only meaningful with a handful of clusters)
  let slope = null; if (sizes.length >= 5) { let sx = 0, sy = 0, sxx = 0, sxy = 0; sizes.forEach((v, i) => { const x = Math.log(v), y = Math.log(i + 1); sx += x; sy += y; sxx += x * x; sxy += x * y; }); const n = sizes.length; slope = (n * sxy - sx * sy) / Math.max(1e-9, n * sxx - sx * sx); }
  for (const p of patches) p.cluster = dmg[p.id] ? find(p.id) : -1;
  return { walls, surf, marks, crackLen, patches, clusters: { sizes, xi, slope, damagedShare: dI.length / Math.max(1, patches.length) }, crackStats: { segAll, segNear, segHit } };
}
const u_t = (model, id) => model.walls[id].t;

// ------------------------------------------------------------------ draft room statuses
// samples of a room's moved interior against the observations and the predicted solid
export function roomObs(model, room, fits, g, S, CH) {
  const s = room.storey, T = fits[s].T, Tc = fits[Math.min(NS, s + 1)].T, cs = 0.3;
  const nx = Math.max(1, Math.round((room.x1 - room.x0 - 0.1) / cs)), nz = Math.max(1, Math.round((room.z1 - room.z0 - 0.1) / cs)), H = room.y1 - room.y0, ny = Math.max(2, Math.round(H / 0.3));
  let tot = 0, seen = 0, struct = 0; const cov = new Uint8Array(nx * nz);
  for (let a = 0; a < nx; a++) for (let b = 0; b < nz; b++) {
    const lx = room.x0 + 0.05 + (a + .5) * (room.x1 - room.x0 - 0.1) / nx, lz = room.z0 + 0.05 + (b + .5) * (room.z1 - room.z0 - 0.1) / nz;
    for (let k = 0; k < ny; k++) {
      const ly = room.y0 + 0.05 + (k + .5) * (H - 0.1) / ny; const p = tApply(ly > room.y0 + H * .6 ? Tc : T, lx, ly, lz); const c = g.cell(p[0], p[1], p[2]); if (c < 0) continue;
      tot++; if (CH.Shat[c]) { struct++; continue; }
      if (S[c] !== O_UNK || CH.debris[c]) seen++;
      if ((CH.debris[c] || CH.fill[c] === 1) && ly < room.y0 + 1.5) cov[b * nx + a] = 1;
    }
  }
  let cv = 0; for (const v of cov) cv += v;
  const open = Math.max(1, tot - struct);
  return { seen: seen / open, crush: tot ? struct / tot : 0, debrisShare: cv / cov.length, samples: tot };
}
const fmtDeg = (v) => `${v.toFixed(1)}°`;
export function draftRooms(model, fits, g, S, CH, cond, tests, extra = {}) {
  const D = DRAFT, out = [];
  const phiBy = new Map(); for (const p of cond.patches) { if (!phiBy.has(p.wall)) phiBy.set(p.wall, []); phiBy.get(p.wall).push(p); }
  for (const room of model.rooms) {
    const s = room.storey, o = roomObs(model, room, fits, g, S, CH);
    const st = Math.max(fits[s].tilt || 0, fits[Math.min(NS, s + 1)].tilt || 0);
    let wt = 0, gone = 0, cracks = 0, crackWalls = 0, phiMin = 1, dmgN = 0, pN = 0;
    for (const wid of room.walls) {
      const w = cond.walls[wid]; gone = Math.max(gone, w.gone);
      // a single wall counts when it leans clearly more than its storey (by more than three times its own uncertainty)
      if (w.ok && w.tilt != null) { const sT = fits[model.walls[wid].storey]?.tilt || 0; if (w.tilt - sT > 3 * w.sigma + 0.1) wt = Math.max(wt, w.tilt); }
      if (cond.crackLen[wid] > 0) { cracks += cond.crackLen[wid]; crackWalls++; }
      for (const p of phiBy.get(wid) || []) { pN++; if (p.st === 'ok') { phiMin = Math.min(phiMin, p.S); if (p.S < D.phiDamaged) dmgN++; } else if (p.st === 'missing') dmgN++; }
    }
    const sf = cond.surf[room.id]; const fl = sf.floor, ce = sf.ceiling;
    const sag = Math.max(fl && fl.measured ? fl.sag : 0, ce && ce.measured ? ce.sag : 0), sagKnown = (fl && fl.measured) || (ce && ce.measured);
    // floors and ceilings: only a clear departure from the storey's own tilt counts (they are noisier than the storey fit)
    const ftilt0 = Math.max(fl && fl.measured ? fl.tilt : 0, ce && ce.measured ? ce.tilt : 0), ftilt = ftilt0 - st > 0.6 ? ftilt0 : 0;
    const tilt = Math.max(st, wt, ftilt);
    const dmgShare = pN ? dmgN / pN : 0;
    const m = { tilt, sag, sagKnown: !!sagKnown, crush: o.crush, debrisShare: o.debrisShare, gone, cracks, crackWalls, phiMin, dmgShare, seen: o.seen };
    let status = 'safe'; const why = [];
    if (o.seen < D.seenMin && o.crush < 0.5) { status = 'unseen'; why.push('Never seen: no drone or ray got far enough in. Space never seen is never safe.'); }
    else {
      if (tilt >= D.tiltNoEntry) why.push(`Leans ${fmtDeg(tilt)}, over the ${fmtDeg(D.tiltNoEntry)} draft limit`);
      if (sag >= D.sagNoEntry) why.push(`A slab sags ${Math.round(sag * 100)} cm`);
      if (o.crush >= D.crushNoEntry) why.push(`Crushed: ${Math.round(o.crush * 100)} % of its space is taken by structure that moved in`);
      if (o.debrisShare >= D.debrisNoEntry) why.push(`Debris covers ${Math.round(o.debrisShare * 100)} % of the floor`);
      if (gone >= D.goneNoEntry) why.push('Part of a wall has fallen');
      if (dmgShare >= D.phiNoEntry) why.push(`Wall order is low on ${Math.round(dmgShare * 100)} % of its walls (φ_wall)`);
      if (why.length) status = 'noentry';
      else {
        if (tilt >= D.tiltCaution) why.push(`Leans ${fmtDeg(tilt)}`);
        if (sag >= D.sagCaution) why.push(`A slab sags ${(sag * 100).toFixed(1)} cm`);
        if (!sagKnown && o.seen < 0.85) why.push('The floor could not be measured');
        if (o.crush >= D.crushCaution) why.push('Something moved into the room');
        if (o.debrisShare >= D.debrisCaution) why.push(`Some debris on the floor (${Math.round(o.debrisShare * 100)} %)`);
        if (crackWalls) why.push(`Cracks seen on ${crackWalls} wall${crackWalls > 1 ? 's' : ''}`);
        if (dmgN >= 2 || (dmgN && phiMin < 0.9)) why.push(`Wall order is low in places (φ_wall ${phiMin.toFixed(2)})`);
        if (o.seen < D.seenWell) why.push(`Only ${Math.round(o.seen * 100)} % of it was seen`);
        if (why.length) status = 'caution';
        else why.push('Level, plumb, no cracks or debris seen, seen well');
      }
    }
    out.push({ id: room.id, status, why, ...m });
  }
  // a room next to one whose structure failed (a wall fell or space was crushed) is at least caution
  const failed = new Set(out.filter((x) => x.status === 'noentry' && (x.crush >= DRAFT.crushNoEntry || x.gone >= DRAFT.goneNoEntry)).map((x) => x.id));
  for (const x of out) {
    if (x.status !== 'safe') continue; const room = model.rooms[x.id];
    const nbr = room.walls.some((wid) => model.walls[wid].rooms.some((rid) => rid !== room.id && failed.has(rid)));
    if (nbr) { x.status = 'caution'; x.why = ['Next to a room where the structure failed']; }
  }
  return out;
}
