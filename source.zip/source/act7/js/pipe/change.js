// What changed, voxel by voxel. Model-based change detection on the registered scans:
//  1. storey fits: each storey of the baseline (its slice of the baseline cloud) is fitted rigidly to the post-event
//     cloud. Drops and tilts about the building's edges and floor lines are tried as starting points, each refined by
//     ICP; the best-supported fit wins. That is how a block that dropped 2 m and tilted 12 degrees is found.
//  2. part tests: every baseline part, moved with its storey, is checked against the scans: hits on its faces
//     (support) or rays that passed through where it should be (contradiction). Contradicted parts are gone.
//  3. the predicted post-event solid = surviving parts at their fitted poses; observed hits it does not explain are new
//     material (debris); the unseen space under observed debris, down to its support, is the inferred debris fill.
//  Labels: 0 nothing, 1 unchanged, 2 newly occupied (moved structure), 3 newly occupied (debris seen), 4 debris fill
//  (inferred), 5 newly empty (collapsed or moved away).
import { slabPieces, onPiece } from './pieces.js';
const SLAB_STOP = true;   // (an A/B on pancake seeds 1-6: debris error 22 % -> 5 %, IoU unchanged; see README)
import { tApply, tCompose, tAxisPivot, tiltOf, boxT, DEG, qToMat, T_ID, rngFor } from '../building/geom.js';
import { rasterBox, dilate, components, boxVoxels } from '../building/voxel.js';
import { NS, SH, ST } from '../building/building.js';
import { L_STRUCT, L_STATIC } from '../building/truth.js';
import { hashGrid, voxelDown, makeTarget, normalAt, icp } from './register.js';
import { O_UNK, O_FREE, O_OCC } from './occupancy.js';

const ENV = (typeof process !== 'undefined' && process.env) || {};
const FILL_R = +(ENV.A7_FILL_R ?? 0), FILL_N = +(ENV.A7_FILL_N ?? 1);
export const C_NONE = 0, C_SAME = 1, C_MOVED = 2, C_DEBRIS = 3, C_FILL = 4, C_GONE = 5;
const PERF = () => (typeof performance !== 'undefined' ? performance.now() : Date.now());

// the baseline points of each storey (upright baseline frame: horizontal slices inside the footprint)
export function storeyPoints(model, base) {
  const { L, D } = model.dims, groups = [[], [], [], [], []];
  for (let i = 0; i < base.n; i++) {
    if (!base.hit[i]) continue; const x = base.pts[i * 3], y = base.pts[i * 3 + 1], z = base.pts[i * 3 + 2];
    if (Math.abs(x) > L / 2 + 0.05 || Math.abs(z) > D / 2 + (z > 0 ? 1.35 : 0.05) || y < 0.12) continue;
    // a storey's ceiling and beams are the underside of the slab above, which moves with the storey above
    const s = Math.min(NS, Math.floor((y - 0.05 + 0.4) / SH)); groups[s].push(i);
  }
  return groups;
}

// ------------------------------------------------------------------ 1. storey fits
// share of points that land on a target surface: nearest target point within reach and, along its normal, within
// a tolerance that grows with the reach (independent of how densely the target was sampled)
const _p = [0, 0, 0], _n = [0, 0, 0];
function scoreP(target, src, T, n, d, srcN) {
  const reach = Math.max(0.22, d), tol = Math.min(0.06, Math.max(0.035, d * 0.4)); let k = 0; const R = T.R;
  for (let i = 0; i < n; i++) {
    tApply(T, src[i * 3], src[i * 3 + 1], src[i * 3 + 2], _p); const j = target.hash.nearest(_p[0], _p[1], _p[2], reach); if (j < 0) continue;
    normalAt(target, j, _n);
    if (srcN) { const a = srcN[i * 3], b = srcN[i * 3 + 1], c = srcN[i * 3 + 2]; if ((R[0] * a + R[1] * b + R[2] * c) * _n[0] + (R[3] * a + R[4] * b + R[5] * c) * _n[1] + (R[6] * a + R[7] * b + R[8] * c) * _n[2] < 0.5) continue; }
    const r = Math.abs((_p[0] - target.P[j * 3]) * _n[0] + (_p[1] - target.P[j * 3 + 1]) * _n[1] + (_p[2] - target.P[j * 3 + 2]) * _n[2]);
    if (r < tol) k++;
  }
  return k / n;
}
function plausible(T, x, y, z, L, D) {
  const mv = tApply(T, x, y, z), tilt = tiltOf(T.R);
  return mv[1] - y <= Math.hypot(L, D) / 2 * Math.sin(tilt) + 0.15;
}
export function* storeyFits(model, base, target, seed, baseTarget) {
  const r = rngFor(seed, 'storeys'); const { L, D } = model.dims;
  const groups = storeyPoints(model, base);
  const fits = new Array(NS + 1);
  const hyps = [];
  // tilts about each footprint edge, at the ground and at the first floor line
  const edges = [[[1, 0, 0], [0, 0, -D / 2]], [[1, 0, 0], [0, 0, D / 2]], [[0, 0, 1], [-L / 2, 0, 0]], [[0, 0, 1], [L / 2, 0, 0]]];
  for (const [ax, p] of edges) for (const y of [0, SH]) for (const a of [2.5, 4.5, 7, 10, 13]) for (const sg of [-1, 1]) hyps.push(tAxisPivot(ax, sg * a * DEG, [p[0], y, p[2]]));
  const pt = [0, 0, 0];
  // top storey first: it is seen best from outside; lower storeys may reuse what the ones above found
  for (let s = NS; s >= 0; s--) {
    const idx = groups[s]; if (idx.length < 30) { fits[s] = { storey: s, T: T_ID(), score: 0, n: idx.length, tilt: 0, drop: 0, shift: 0, rmse: NaN, ident: true }; continue; }
    const seen = new Set(), pick = [];
    for (const i of idx) { const k = Math.floor(base.pts[i * 3] / 0.3) * 1e6 + Math.floor(base.pts[i * 3 + 2] / 0.3) * 1e3 + Math.floor(base.pts[i * 3 + 1] / 0.3); if (seen.has(k)) continue; seen.add(k); pick.push(i); }
    for (let i = pick.length - 1; i > 0; i--) { const j = Math.floor(r() * (i + 1)); const t = pick[i]; pick[i] = pick[j]; pick[j] = t; }
    const ns = Math.min(pick.length, 700), src = new Float32Array(ns * 3);
    for (let k = 0; k < ns; k++) { const i = pick[k]; src[k * 3] = base.pts[i * 3]; src[k * 3 + 1] = base.pts[i * 3 + 1]; src[k * 3 + 2] = base.pts[i * 3 + 2]; }
    // oriented normals of the source points, from the baseline cloud
    const srcN = new Float32Array(ns * 3), nb = [0, 0, 0];
    for (let k = 0; k < ns; k++) { const j = baseTarget.hash.nearest(src[k * 3], src[k * 3 + 1], src[k * 3 + 2], 0.3); if (j < 0) continue; normalAt(baseTarget, j, nb); srcN[k * 3] = nb[0]; srcN[k * 3 + 1] = nb[1]; srcN[k * 3 + 2] = nb[2]; }
    const quick = Math.min(ns, 160);
    const score = (T, n, d) => scoreP(target, src, T, n, d, srcN);
    const idS = score(T_ID(), ns, 0.08);
    const above = []; for (let q = s + 1; q <= NS; q++) if (fits[q] && fits[q].score > 0.3) above.push(fits[q].T);
    let best = null;
    // the solution of the storey above, if it already fits well, is refined first
    // kinematics: a collapse lifts a storey's centre only by tipping it over a footprint edge, so a rise larger than
    // that tipping allows (half the footprint diagonal times the sine of the tilt, plus 0.15 m) is the repeat
    // pattern of floors and walls fitting one storey up, not a motion
    let gx = 0, gy = 0, gz = 0; for (let i = 0; i < ns; i++) { gx += src[i * 3]; gy += src[i * 3 + 1]; gz += src[i * 3 + 2]; } gx /= ns; gy /= ns; gz /= ns;
    const tryRefine = function* (T0) { const res = yield* icp(target, src, T0, { iters: 12, keep: 0.6, d0: 0.3, d1: 0.06, srcN }); if (!plausible(res.T, gx, gy, gz, L, D)) return; const sc = score(res.T, ns, 0.08); if (!best || sc > best.score) best = { T: res.T, score: sc, rmse: res.iters[res.iters.length - 1].rmse }; };
    if (idS > 0.62) best = { T: T_ID(), score: idS, rmse: NaN };
    for (const T0 of above) if (!best || best.score < 0.62) { if (score(T0, quick, 0.25) > 0.45) yield* tryRefine(T0); }
    // continuity: what the storey above found is kept unless an alternative is clearly better (floors and walls repeat
    // every storey, so a whole-storey shift can fit almost as well)
    const fromAbove = best && !(idS > 0.62) ? best : null;
    if (!best || best.score < 0.62) {
      const cands = [T_ID(), ...hyps];
      const ranked = cands.map((T) => ({ T, s: score(T, quick, 0.3) })).sort((a, b) => b.s - a.s).slice(0, 3);
      for (const c of ranked) { yield* tryRefine(c.T); if (best && best.score > 0.7) break; }
      if (!best) best = { T: T_ID(), score: idS, rmse: NaN };
      if (fromAbove && fromAbove.score >= best.score - 0.1) best = fromAbove;
    }
    // model selection: a motion too small to be told from noise is no motion
    let cx = 0, cy = 0, cz = 0; for (let i = 0; i < ns; i++) { cx += src[i * 3]; cy += src[i * 3 + 1]; cz += src[i * 3 + 2]; } cx /= ns; cy /= ns; cz /= ns;
    const mv = tApply(best.T, cx, cy, cz), tilt = tiltOf(best.T.R) / DEG, rot = Math.acos(Math.max(-1, Math.min(1, (best.T.R[0] + best.T.R[4] + best.T.R[8] - 1) / 2))) / DEG, disp = Math.hypot(mv[0] - cx, mv[1] - cy, mv[2] - cz);
    let ident = false;
    if ((rot < 0.35 && disp < 0.05) || idS >= 0.8 * best.score) { best = { T: T_ID(), score: Math.max(idS, best.score), rmse: best.rmse }; ident = true; }
    fits[s] = { storey: s, T: best.T, score: best.score, rmse: best.rmse, n: idx.length, ident, idScore: idS, src, srcN, c: [cx, cy, cz] };
    yield { p: (NS + 1 - s) / (NS + 2) };
  }
  // consistency: a storey may be explained better by a neighbour's motion (one block moving as a whole); then a
  // final fine refinement of every moved storey
  for (let s = 0; s <= NS; s++) {
    const f = fits[s]; if (!f.src) continue; const src = f.src, ns = src.length / 3, srcN = f.srcN;
    const score = (T, d) => scoreP(target, src, T, ns, d, srcN);
    f.score = score(f.T, 0.08);
    for (let q = 0; q <= NS; q++) { if (q === s || fits[q].ident || !fits[q].src) continue; const sc = score(fits[q].T, 0.08); const need = f.ident ? 0.15 : Math.abs(q - s) === 1 ? -0.015 : 0.01; if (sc > f.score + need && plausible(fits[q].T, f.c[0], f.c[1], f.c[2], L, D)) { f.T = fits[q].T; f.score = sc; f.ident = false; } }
    if (!f.ident) { const res = yield* icp(target, src, f.T, { iters: 16, keep: 0.65, d0: 0.12, d1: 0.05, srcN }); const sc = score(res.T, 0.08); if (sc >= f.score - 0.005 && plausible(res.T, f.c[0], f.c[1], f.c[2], L, D)) { f.T = res.T; f.score = sc; } }
  }
  for (const f of fits) {
    const c = f.c || [0, 0, 0], mv = tApply(f.T, c[0], c[1], c[2]);
    f.tilt = f.ident ? 0 : tiltOf(f.T.R) / DEG; f.drop = c[1] - mv[1]; f.shift = Math.hypot(mv[0] - c[0], mv[2] - c[2]); delete f.src; delete f.srcN;
  }
  yield { p: 1 };
  return fits;
}

// ------------------------------------------------------------------ 2. part tests
// samples on a box's two (or four) largest faces, with outward normals
function faceSamples(box, step = 0.25) {
  const m = qToMat(box.q), h = box.h, out = [];
  const ax = [[m[0], m[3], m[6]], [m[1], m[4], m[7]], [m[2], m[5], m[8]]];
  const order = [0, 1, 2].sort((a, b) => h[a] - h[b]);            // thinnest first
  const faces = h[order[1]] > 2.5 * h[order[0]] ? [order[0]] : [order[0], order[1]];
  for (const f of faces) {
    const u = (f + 1) % 3, v = (f + 2) % 3, nu = Math.max(1, Math.round(2 * h[u] / step)), nv = Math.max(1, Math.round(2 * h[v] / step));
    for (const sg of [-1, 1]) for (let a = 0; a < nu; a++) for (let b = 0; b < nv; b++) {
      const lu = -h[u] + (a + .5) * 2 * h[u] / nu, lv = -h[v] + (b + .5) * 2 * h[v] / nv;
      const p = [0, 1, 2].map((i) => box.c[i] + ax[f][i] * sg * h[f] + ax[u][i] * lu + ax[v][i] * lv);
      out.push({ p, n: ax[f].map((x) => x * sg) });
    }
  }
  return out;
}
export function partTests(model, fits, g, S, postHash, postPts) {
  const res = [];
  for (const p of model.parts) {
    if (p.kind === 'site') { res.push({ id: p.id, state: 'static', sup: 0, con: 0, vis: 0, n: 0 }); continue; }
    const s = Math.max(0, Math.min(NS, p.storey === 0 && p.kind === 'beam' ? 1 : p.storey));
    const T = fits[s].T, box = boxT(T, p.box);
    const smp = faceSamples(box, p.kind === 'slab' ? 0.35 : 0.25);
    let sup = 0, con = 0, vis = 0;
    for (const q of smp) {
      const c = g.cell(q.p[0] + q.n[0] * 0.06, q.p[1] + q.n[1] * 0.06, q.p[2] + q.n[2] * 0.06); if (c < 0) continue;
      // the face would be visible if the space just in front of it was seen free
      const front = S[c] === O_FREE; const ci = g.cell(q.p[0] - q.n[0] * 0.07, q.p[1] - q.n[1] * 0.07, q.p[2] - q.n[2] * 0.07);
      const inside = ci >= 0 ? S[ci] : O_UNK;
      const j = postHash.nearest(q.p[0], q.p[1], q.p[2], 0.07);
      if (j >= 0) { sup++; vis++; } else if (front) { vis++; if (inside === O_FREE) con++; }
    }
    const n = smp.length;
    let state = 'unseen';
    if (vis >= 0.15 * n) state = con >= 0.4 * vis && sup < 0.3 * vis && sup < 0.25 * n ? 'gone' : sup > 0 ? 'present' : 'unseen';
    res.push({ id: p.id, storey: s, state, sup: n ? sup / n : 0, con: n ? con / n : 0, vis: n ? vis / n : 0, n });
  }
  return res;
}

// ------------------------------------------------------------------ 3. predicted solid, debris, labels
export function* changeMap(model, truthStatic, g, S, fits, tests, Bmodel, opts = {}) {
  // the baseline model (as surveyed) and the predicted post-event structure
  const Shat = new Uint8Array(g.N);
  const order = [0, 1, 2, 3, 4];
  for (const s of order) for (const p of model.parts) {
    const t = tests[p.id]; if (t.state === 'static' || t.state === 'gone' || t.storey !== s) continue;
    rasterBox(g, boxT(fits[s].T, p.box), Shat, 1, { ymin: 0 });
  }
  yield { p: 0.35 };
  // debris: hits that the predicted structure (grown by one voxel) and the static site do not explain
  const near = dilate(g, Shat, 1, 1, 1, 0);
  // the site as surveyed (boundary walls, neighbours, the ground layer), grown by a voxel for registration noise
  const st0 = new Uint8Array(g.N); for (let c = 0; c < g.N; c++) st0[c] = truthStatic[c] === L_STATIC ? 1 : 0;
  const stat = dilate(g, st0, 1, 1, 1, 0);
  let deb = new Uint8Array(g.N); let nd = 0;
  for (let c = 2 * g.nx * g.nz; c < g.N; c++) if (S[c] === O_OCC && !near[c] && !stat[c]) { deb[c] = 1; nd++; }
  // drop specks (fewer than 4 voxels together)
  const { labels } = components(g, deb.slice(), { minKeep: 4 });
  for (let c = 0; c < g.N; c++) if (deb[c] && !labels[c]) { deb[c] = 0; nd--; }
  // a flat panel filling a surveyed door opening (moved with its storey) is a closed, jammed door: not debris
  const doors = new Uint8Array(g.N);
  for (const o of model.openings) {
    if (o.kind === 'window') continue; const t = 0.18, s2 = Math.max(0, Math.min(NS, o.storey));
    const box = o.axis === 'x' ? { c: [o.off, (o.y0 + o.y1) / 2, (o.o0 + o.o1) / 2], h: [t, (o.y1 - o.y0) / 2, (o.o1 - o.o0) / 2], q: [0, 0, 0, 1] } : { c: [(o.o0 + o.o1) / 2, (o.y0 + o.y1) / 2, o.off], h: [(o.o1 - o.o0) / 2, (o.y1 - o.y0) / 2, t], q: [0, 0, 0, 1] };
    rasterBox(g, boxT(fits[s2].T, box), doors, 1);
  }
  let nDoor = 0; for (let c = 0; c < g.N; c++) if (deb[c] && doors[c]) { deb[c] = 0; doors[c] = 2; nd--; nDoor++; }
  // close the debris surface: unseen voxels next to debris hits (never ones seen free) belong to the same surface
  const SY0 = g.nx * g.nz, add = [];
  for (let c = 2 * SY0; c < g.N - SY0; c++) {
    if (deb[c] || S[c] === O_FREE || near[c] || stat[c] || doors[c]) continue;
    const k = deb[c - 1] + deb[c + 1] + deb[c - g.nx] + deb[c + g.nx] + deb[c - SY0] + deb[c + SY0]; if (k >= 2) add.push(c);
  }
  for (const c of add) deb[c] = 1; nd += add.length;
  // slab pieces lying among the debris (shared with the pockets): the fill stops under them
  const pieces = opts.pts && SLAB_STOP ? slabPieces(g, deb, opts.pts, opts.nh, rngFor(opts.seed || 1, 'pieces')) : [];
  yield { p: 0.6 };
  // fill: below the debris surface, the unseen voxels down to whatever supports it. The surface of each column is the
  // highest debris voxel within 0.3 m around it (returns are sparse; the pile's top is continuous)
  const fill = new Uint8Array(g.N); const SY = g.nx * g.nz; let nf = 0;
  const top = new Int16Array(SY).fill(-1);
  for (let c = SY; c < g.N; c++) if (deb[c]) { const col = c % SY, j = (c - col) / SY; if (j > top[col]) top[col] = j; }
  const topS = new Int16Array(SY).fill(-1);
  for (let k = 0; k < g.nz; k++) for (let i = 0; i < g.nx; i++) {
    let m = -1, cnt = 0; for (let dk = -FILL_R; dk <= FILL_R; dk++) for (let di = -FILL_R; di <= FILL_R; di++) { const kk = k + dk, ii = i + di; if (kk < 0 || ii < 0 || kk >= g.nz || ii >= g.nx) continue; const t = top[ii + g.nx * kk]; if (t >= 0) { cnt++; if (t > m) m = t; } }
    if (cnt >= FILL_N) topS[i + g.nx * k] = m;
  }
  const pc3 = [0, 0, 0];
  for (let col = 0; col < SY; col++) {
    const t = topS[col]; if (t < 0) continue;
    // a column whose top is the face of a slab piece: fill only the slab's own thickness under that face
    let yStop = -1e9;
    if (pieces.length) { g.centre(col + t * SY, pc3); for (const pc of pieces) if (onPiece(pc, pc3[0], pc3[1], pc3[2], 0.12)) { const ny = Math.max(0.3, Math.abs(pc.n[1])); const yp = (pc.d - pc.n[0] * pc3[0] - pc.n[2] * pc3[2]) / pc.n[1]; yStop = yp - 0.15 / ny - g.vox * 0.5; break; } }
    for (let j = t; j >= 1; j--) { const d = col + j * SY; if (Shat[d] || st0[d] || (S[d] === O_OCC && !deb[d])) break; if (g.y0 + (j + .5) * g.vox < yStop) break; if (deb[d] || S[d] === O_FREE) continue; if (!fill[d]) { fill[d] = 1; nf++; } }
  }
  // the upper bound (high): from the observed debris surface straight down to the floor that is still there,
  // through anything that is not standing structure (the inside of a pile is never seen)
  let nh = 0;
  for (let c = SY; c < g.N; c++) {
    if (!deb[c]) continue;
    for (let d = c - SY; d >= SY; d -= SY) { if (deb[d] || fill[d] === 1) continue; if (fill[d] === 2) break; if (Shat[d] || st0[d] || S[d] === O_OCC) break; fill[d] = 2; nh++; }
  }
  yield { p: 0.8 };
  // labels
  const lab = new Uint8Array(g.N); let nSame = 0, nMoved = 0, nGone = 0;
  for (let c = 0; c < g.N; c++) {
    const b = Bmodel[c] === L_STRUCT;
    if (Shat[c]) { if (b) { lab[c] = C_SAME; nSame++; } else { lab[c] = C_MOVED; nMoved++; } }
    else if (doors[c] === 2) lab[c] = b ? C_SAME : C_MOVED;
    else if (deb[c]) lab[c] = b ? C_SAME : C_DEBRIS;
    else if (fill[c] === 1) lab[c] = b ? C_SAME : C_FILL;
    else if (b) { lab[c] = C_GONE; nGone++; }
  }
  return { labels: lab, Shat, debris: deb, fill, pieces, counts: { same: nSame, moved: nMoved, gone: nGone, debris: nd, fill: nf, high: nh, door: nDoor } };
}
