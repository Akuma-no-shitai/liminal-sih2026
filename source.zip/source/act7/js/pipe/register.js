// Registration: bring the post-event cloud into the baseline's frame. Trimmed point-to-plane ICP on subsamples, with
// a voxel-hash nearest neighbour and normals from PCA on the baseline's neighbours. The starting guess is the anchor
// unit's pose; each iteration keeps only the best-fitting 70 % of matches, so whatever moved (the building, debris,
// the responders' van) is left out and the fit rests on what did not move. Every iteration is recorded for the film.
import { rngFor, tApply, tCompose, tInvert, rotAngle, orthonormalize, eigSym3, solveN, DEG } from '../building/geom.js';

// a dense hash grid over points (flat xyz): CSR lists per cell over the points' bounding box
export function hashGrid(P, n, cell) {
  let x0 = 1e9, y0 = 1e9, z0 = 1e9, x1 = -1e9, y1 = -1e9, z1 = -1e9;
  for (let i = 0; i < n; i++) { const x = P[i * 3], y = P[i * 3 + 1], z = P[i * 3 + 2]; if (x < x0) x0 = x; if (x > x1) x1 = x; if (y < y0) y0 = y; if (y > y1) y1 = y; if (z < z0) z0 = z; if (z > z1) z1 = z; }
  if (!n) { x0 = y0 = z0 = 0; x1 = y1 = z1 = 1; }
  // keep the table a sane size: coarsen if the cloud spans a very large box
  let c = cell; while (((x1 - x0) / c + 1) * ((y1 - y0) / c + 1) * ((z1 - z0) / c + 1) > 6e6) c *= 1.25;
  const nx = Math.floor((x1 - x0) / c) + 1, ny = Math.floor((y1 - y0) / c) + 1, nz = Math.floor((z1 - z0) / c) + 1, NC = nx * ny * nz;
  const start = new Int32Array(NC + 1), cid = new Int32Array(n);
  for (let i = 0; i < n; i++) { const k = (Math.floor((P[i * 3] - x0) / c) * nz + Math.floor((P[i * 3 + 2] - z0) / c)) * ny + Math.floor((P[i * 3 + 1] - y0) / c); cid[i] = k; start[k + 1]++; }
  for (let k = 0; k < NC; k++) start[k + 1] += start[k];
  const items = new Int32Array(n), fill = start.slice(0, NC); for (let i = 0; i < n; i++) items[fill[cid[i]]++] = i;
  const H = {
    cell: c, nx, ny, nz, x0, y0, z0, start, items,
    // nearest point within dmax, or -1
    nearest(x, y, z, dmax) {
      const ci = Math.floor((x - x0) / c), cj = Math.floor((y - y0) / c), ck = Math.floor((z - z0) / c), R = Math.ceil(dmax / c);
      let best = -1, bd = dmax * dmax;
      const a0 = Math.max(0, ci - R), a1 = Math.min(nx - 1, ci + R), b0 = Math.max(0, cj - R), b1 = Math.min(ny - 1, cj + R), k0 = Math.max(0, ck - R), k1 = Math.min(nz - 1, ck + R);
      for (let a = a0; a <= a1; a++) for (let kk = k0; kk <= k1; kk++) { const base = (a * nz + kk) * ny;
        for (let b = b0; b <= b1; b++) { const cc = base + b; for (let q = start[cc], e = start[cc + 1]; q < e; q++) { const i = items[q]; const dx = P[i * 3] - x, dy = P[i * 3 + 1] - y, dz = P[i * 3 + 2] - z, d = dx * dx + dy * dy + dz * dz; if (d < bd) { bd = d; best = i; } } } }
      return best;
    },
    // all points inside an axis-aligned box
    inBox(bx0, by0, bz0, bx1, by1, bz1, out) {
      out.length = 0;
      const a0 = Math.max(0, Math.floor((bx0 - x0) / c)), a1 = Math.min(nx - 1, Math.floor((bx1 - x0) / c)), b0 = Math.max(0, Math.floor((by0 - y0) / c)), b1 = Math.min(ny - 1, Math.floor((by1 - y0) / c)), k0 = Math.max(0, Math.floor((bz0 - z0) / c)), k1 = Math.min(nz - 1, Math.floor((bz1 - z0) / c));
      for (let a = a0; a <= a1; a++) for (let kk = k0; kk <= k1; kk++) { const base = (a * nz + kk) * ny;
        for (let b = b0; b <= b1; b++) { const cc = base + b; for (let q = start[cc], e = start[cc + 1]; q < e; q++) { const i = items[q]; const px = P[i * 3], py = P[i * 3 + 1], pz = P[i * 3 + 2]; if (px >= bx0 && px <= bx1 && py >= by0 && py <= by1 && pz >= bz0 && pz <= bz1) out.push(i); } } }
      return out;
    },
    // all points within r of (x, y, z)
    within(x, y, z, r, out) {
      out.length = 0; const ci = Math.floor((x - x0) / c), cj = Math.floor((y - y0) / c), ck = Math.floor((z - z0) / c), R = Math.ceil(r / c), r2 = r * r;
      const a0 = Math.max(0, ci - R), a1 = Math.min(nx - 1, ci + R), b0 = Math.max(0, cj - R), b1 = Math.min(ny - 1, cj + R), k0 = Math.max(0, ck - R), k1 = Math.min(nz - 1, ck + R);
      for (let a = a0; a <= a1; a++) for (let kk = k0; kk <= k1; kk++) { const base = (a * nz + kk) * ny;
        for (let b = b0; b <= b1; b++) { const cc = base + b; for (let q = start[cc], e = start[cc + 1]; q < e; q++) { const i = items[q]; const dx = P[i * 3] - x, dy = P[i * 3 + 1] - y, dz = P[i * 3 + 2] - z; if (dx * dx + dy * dy + dz * dz <= r2) out.push(i); } } }
      return out;
    },
  };
  return H;
}
// keep one point per cell (the first): a uniform subsample
export function voxelDown(P, hit, n, cell, maxN = Infinity, r = null) {
  const seen = new Set(), idx = [];
  for (let i = 0; i < n; i++) { if (hit && !hit[i]) continue; const k = (Math.floor(P[i * 3] / cell) + 4096) * 67108864 + (Math.floor(P[i * 3 + 2] / cell) + 4096) * 8192 + (Math.floor(P[i * 3 + 1] / cell) + 4096); if (seen.has(k)) continue; seen.add(k); idx.push(i); }
  if (idx.length > maxN && r) { for (let i = idx.length - 1; i > 0; i--) { const j = Math.floor(r() * (i + 1)); const t = idx[i]; idx[i] = idx[j]; idx[j] = t; } idx.length = maxN; }
  return idx;
}
// PCA normal of the neighbourhood of point i (lazily cached)
export function normalAt(T, i, out) {
  if (T.nOK[i]) { out[0] = T.N[i * 3]; out[1] = T.N[i * 3 + 1]; out[2] = T.N[i * 3 + 2]; return T.nQ[i]; }
  const P = T.P, nb = T.hash.within(P[i * 3], P[i * 3 + 1], P[i * 3 + 2], T.rad, T._buf);
  let q = 0;
  if (nb.length >= 5) {
    let sx = 0, sy = 0, sz = 0; for (const j of nb) { sx += P[j * 3]; sy += P[j * 3 + 1]; sz += P[j * 3 + 2]; } const m = nb.length; sx /= m; sy /= m; sz /= m;
    let a00 = 0, a01 = 0, a02 = 0, a11 = 0, a12 = 0, a22 = 0;
    for (const j of nb) { const dx = P[j * 3] - sx, dy = P[j * 3 + 1] - sy, dz = P[j * 3 + 2] - sz; a00 += dx * dx; a01 += dx * dy; a02 += dx * dz; a11 += dy * dy; a12 += dy * dz; a22 += dz * dz; }
    const e = eigSym3(a00, a01, a02, a11, a12, a22), v = e.vecs[2];
    out[0] = v[0]; out[1] = v[1]; out[2] = v[2]; q = e.vals[1] > 1e-9 ? 1 - e.vals[2] / e.vals[1] : 0;     // planarity
  } else { out[0] = 0; out[1] = 1; out[2] = 0; }
  // orient toward the sensor that saw the point (a floor faces up, the ceiling under it faces down)
  if (T.O && (out[0] * (T.O[i * 3] - P[i * 3]) + out[1] * (T.O[i * 3 + 1] - P[i * 3 + 1]) + out[2] * (T.O[i * 3 + 2] - P[i * 3 + 2])) < 0) { out[0] = -out[0]; out[1] = -out[1]; out[2] = -out[2]; }
  T.N[i * 3] = out[0]; T.N[i * 3 + 1] = out[1]; T.N[i * 3 + 2] = out[2]; T.nQ[i] = q; T.nOK[i] = 1;
  return q;
}
// a target cloud: points (a subset idx of P), a hash, and lazily computed normals. orig(i) gives the sensor position
// that saw point i (normals are then oriented toward it)
export function makeTarget(P, idx, cell = 0.3, rad = 0.3, orig = null) {
  const n = idx.length, Q = new Float32Array(n * 3), O = orig ? new Float32Array(n * 3) : null;
  idx.forEach((i, k) => { Q[k * 3] = P[i * 3]; Q[k * 3 + 1] = P[i * 3 + 1]; Q[k * 3 + 2] = P[i * 3 + 2]; if (O) { const o = orig(i); O[k * 3] = o[0]; O[k * 3 + 1] = o[1]; O[k * 3 + 2] = o[2]; } });
  return { P: Q, O, n, hash: hashGrid(Q, n, cell), N: new Float32Array(n * 3), nQ: new Float32Array(n), nOK: new Uint8Array(n), rad, _buf: [] };
}

// trimmed point-to-plane ICP. src: flat xyz (raw post points, sampled); T0: starting guess.
export function* icp(target, src, T0, { iters = 30, keep = 0.7, d0 = 0.6, d1 = 0.1, srcN = null, minDot = 0.5 } = {}) {
  const ns = src.length / 3, R = [];
  let T = { R: T0.R.slice(), t: T0.t.slice() };
  const res = new Float64Array(ns), match = new Int32Array(ns), pt = [0, 0, 0], nrm = [0, 0, 0];
  for (let it = 0; it < iters; it++) {
    const dmax = Math.max(d1, d0 * Math.pow(0.82, it));
    let m = 0;
    for (let i = 0; i < ns; i++) {
      tApply(T, src[i * 3], src[i * 3 + 1], src[i * 3 + 2], pt);
      const j = target.hash.nearest(pt[0], pt[1], pt[2], dmax); match[i] = j; if (j < 0) { res[i] = Infinity; continue; }
      normalAt(target, j, nrm);
      if (srcN) { const R = T.R, a = srcN[i * 3], b = srcN[i * 3 + 1], c = srcN[i * 3 + 2]; if ((R[0] * a + R[1] * b + R[2] * c) * nrm[0] + (R[3] * a + R[4] * b + R[5] * c) * nrm[1] + (R[6] * a + R[7] * b + R[8] * c) * nrm[2] < minDot) { res[i] = Infinity; match[i] = -1; continue; } }
      res[i] = Math.abs((pt[0] - target.P[j * 3]) * nrm[0] + (pt[1] - target.P[j * 3 + 1]) * nrm[1] + (pt[2] - target.P[j * 3 + 2]) * nrm[2]); m++;
    }
    // trim: the best `keep` share of all source points (unmatched ones count as the worst)
    const sorted = Float64Array.from(res).sort(); const cut = sorted[Math.max(0, Math.min(ns - 1, Math.floor(ns * keep) - 1))];
    const thr = Math.min(cut, dmax);
    const A = new Float64Array(36), b = new Float64Array(6); let used = 0, se = 0;
    for (let i = 0; i < ns; i++) {
      if (!(res[i] <= thr)) continue; const j = match[i];
      tApply(T, src[i * 3], src[i * 3 + 1], src[i * 3 + 2], pt); normalAt(target, j, nrm);
      const r = (pt[0] - target.P[j * 3]) * nrm[0] + (pt[1] - target.P[j * 3 + 1]) * nrm[1] + (pt[2] - target.P[j * 3 + 2]) * nrm[2];
      const a = [pt[1] * nrm[2] - pt[2] * nrm[1], pt[2] * nrm[0] - pt[0] * nrm[2], pt[0] * nrm[1] - pt[1] * nrm[0], nrm[0], nrm[1], nrm[2]];
      for (let p = 0; p < 6; p++) { b[p] -= a[p] * r; for (let q = 0; q < 6; q++) A[p * 6 + q] += a[p] * a[q]; }
      used++; se += r * r;
    }
    const rmse = used ? Math.sqrt(se / used) : NaN;
    R.push({ T: { R: T.R.slice(), t: T.t.slice() }, rmse, used: used / ns, matched: m / ns, dmax });
    if (used < 12) break;
    for (let p = 0; p < 6; p++) A[p * 6 + p] += 1e-6;
    const x = solveN(Array.from(A), Array.from(b), 6); if (!x) break;
    const [wx, wy, wz, tx, ty, tz] = x;
    const dR = orthonormalize([1, -wz, wy, wz, 1, -wx, -wy, wx, 1]);
    T = tCompose({ R: dR, t: [tx, ty, tz] }, T); T.R = orthonormalize(T.R);
    const step = Math.hypot(tx, ty, tz), rot = Math.hypot(wx, wy, wz);
    yield { p: (it + 1) / iters };
    if (it > 6 && step < 2e-4 && rot < 2e-5) break;
  }
  // final residuals for the record
  let used = 0, se = 0; const inl = new Uint8Array(ns);
  for (let i = 0; i < ns; i++) {
    tApply(T, src[i * 3], src[i * 3 + 1], src[i * 3 + 2], pt); const j = target.hash.nearest(pt[0], pt[1], pt[2], d1 * 1.5); if (j < 0) continue;
    normalAt(target, j, nrm); const r = Math.abs((pt[0] - target.P[j * 3]) * nrm[0] + (pt[1] - target.P[j * 3 + 1]) * nrm[1] + (pt[2] - target.P[j * 3 + 2]) * nrm[2]);
    if (r < 0.06) { inl[i] = 1; used++; se += r * r; res[i] = r; } else res[i] = Infinity;
  }
  R.push({ T: { R: T.R.slice(), t: T.t.slice() }, rmse: used ? Math.sqrt(se / used) : NaN, used: used / ns, final: true });
  return { T, iters: R, inliers: inl, residuals: res };
}

// the whole registration step: subsample, starting guess, ICP, misfit map
export function* registerScans(base, post, Tanchor, seed, site = null) {
  const r = rngFor(seed, 'register');
  // register on what did not move: the site around the building (ground, boundary walls, neighbours, yard objects).
  // The building itself is what is being assessed, so its points (inside its outline + 1.5 m) are left out.
  const off = (x, z) => !site || Math.abs(x - site.cx) > site.hx + 1.5 || Math.abs(z - site.cz) > site.hz + 1.5;
  const tIdx = voxelDown(base.pts, base.hit, base.n, 0.14).filter((i) => off(base.pts[i * 3], base.pts[i * 3 + 2]));
  const target = makeTarget(base.pts, tIdx, 0.3, 0.28, (i) => base.poses[base.pose[i]].p);
  yield { p: 0.1 };
  // the post-event points are judged in the anchor's starting frame (good to ~0.2 m)
  const ga = [0, 0, 0];
  const sAll = voxelDown(post.pts, post.hit, post.n, 0.25).filter((i) => { tApply(Tanchor, post.pts[i * 3], post.pts[i * 3 + 1], post.pts[i * 3 + 2], ga); return off(ga[0], ga[2]); });
  for (let i = sAll.length - 1; i > 0; i--) { const j = Math.floor(r() * (i + 1)); const t = sAll[i]; sAll[i] = sAll[j]; sAll[j] = t; }
  const sIdx = sAll.slice(0, 3500);
  const src = new Float32Array(sIdx.length * 3); sIdx.forEach((i, k) => { src[k * 3] = post.pts[i * 3]; src[k * 3 + 1] = post.pts[i * 3 + 1]; src[k * 3 + 2] = post.pts[i * 3 + 2]; });
  const res = yield* icp(target, src, Tanchor, { d0: 0.3, iters: 28 });
  // misfit map: RMS point-to-plane residual of the final inliers in 2 m cells over the site (x, z)
  const pt = [0, 0, 0], cells = new Map();
  for (let i = 0; i < sIdx.length; i++) { if (!res.inliers[i]) continue; tApply(res.T, src[i * 3], src[i * 3 + 1], src[i * 3 + 2], pt); const k = Math.floor(pt[0] / 2) + ',' + Math.floor(pt[2] / 2); const c = cells.get(k) || [0, 0]; c[0] += res.residuals[i] ** 2; c[1]++; cells.set(k, c); }
  const misfit = {}; for (const [k, c] of cells) misfit[k] = Math.sqrt(c[0] / c[1]);
  // the source points as used in the film's animation (a fixed subsample, raw coordinates)
  return { ...res, nSrc: sIdx.length, nTarget: tIdx.length, misfit, src, start: Tanchor, target };
}
export function transformErr(Test, Tdrift) {
  // the estimate composed with the true drift should be the identity
  const E = tCompose(Test, Tdrift); return { cm: Math.hypot(...E.t) * 100, deg: rotAngle(E.R) / DEG };
}
