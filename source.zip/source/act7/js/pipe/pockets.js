// Where someone could be: pockets (beta_2, enclosed voids), two kinds, each with a volume and a confidence.
//  (a) seen through a gap: free space the scans saw, behind an opening narrower than a drone. Observed free space is
//      shrunk by the drone's half size, flooded from where the drones actually flew, and grown back; what stays out of
//      reach is a candidate. Kept if it holds 0.3 m3 or more, with a core where a curled person fits.
//  (b) sheltered under a slab (inferred, lower confidence): planar debris pieces found by RANSAC on the debris, and
//      displaced slabs, that lean with one edge near the floor, forming a wedge; the unseen wedge volume counts.
import { erode, dilate, flood, components } from '../building/voxel.js';
import { tApply, boxT, qToMat, rngFor, DEG, fitPlane } from '../building/geom.js';
import { NS } from '../building/building.js';
import { O_UNK, O_FREE, O_OCC } from './occupancy.js';
import { slabPieces } from './pieces.js';
import { DRONE_CLEAR } from '../building/truth.js';

export function* pockets(ctx) {
  const { model, g, S, CH, fits, tests, poseCells, seed } = ctx;
  const r = rngFor(seed, 'pockets');
  // (a)
  const free = new Uint8Array(g.N); for (let c = 0; c < g.N; c++) free[c] = S[c] === O_FREE ? 1 : 0;
  // where a drone can pass: seen free, plus unseen voxels touching seen-free space (gaps between rays), never a voxel
  // that returned light
  // (tried: everything not known or inferred to be solid as passable; it closed real passages in the crushed ground
  // floor of a soft storey and made more false pockets, so the drones' own seen space is what counts)
  const pass = dilate(g, free, 1, 1, 1, 0); for (let c = 0; c < g.N; c++) if (pass[c] && S[c] === O_OCC) pass[c] = 0;
  // where a drone's centre fits
  // Default: the spec's test, observed passable space shrunk by one voxel (a returned voxel already sits about half a
  // voxel proud of the real surface, so this is close to a 0.35 m drone against the real surfaces). PT=point measures the
  // drone's clearance to the returns themselves (0.175 m) instead: it was tried, scores worse against the corrected truth
  // (README, Measured), and is kept for the comparison.
  let er; const PTV = !(typeof process !== 'undefined' && process.env && process.env.PT === 'point');
  if (PTV) er = erode(g, pass, 1, 1, 1, 1);
  else {
    const DR = DRONE_CLEAR; const blocked = new Uint8Array(g.N), R2 = DR * DR, { nx, nz, vox, x0, y0, z0 } = g, SYp = nx * nz;
    for (let i = 0; i < ctx.nh; i++) {
      const x = ctx.pts[i * 3], y = ctx.pts[i * 3 + 1], z = ctx.pts[i * 3 + 2];
      const ci = Math.floor((x - x0) / vox), cj = Math.floor((y - y0) / vox), ck = Math.floor((z - z0) / vox);
      for (let dj = -2; dj <= 2; dj++) { const j = cj + dj, cy = y0 + (j + .5) * vox - y; if (j < 1 || j >= g.ny - 1 || cy * cy > R2) continue;
        for (let dk = -2; dk <= 2; dk++) { const k = ck + dk, cz = z0 + (k + .5) * vox - z; if (k < 1 || k >= nz - 1 || cy * cy + cz * cz > R2) continue;
          for (let di = -2; di <= 2; di++) { const ii = ci + di, cx = x0 + (ii + .5) * vox - x; if (ii < 1 || ii >= nx - 1 || cx * cx + cy * cy + cz * cz > R2) continue; blocked[ii + nx * k + SYp * j] = 1; } } }
    }
    er = new Uint8Array(g.N); for (let c = 0; c < g.N; c++) er[c] = pass[c] && !blocked[c] ? 1 : 0;
    // and not hard against the unknown either: a centre needs its six neighbours passable
    const e2 = new Uint8Array(g.N); for (let c = SYp; c < g.N - SYp; c++) if (er[c] && pass[c + 1] && pass[c - 1] && pass[c + nx] && pass[c - nx] && pass[c + SYp] && pass[c - SYp]) e2[c] = 1; er = e2;
  }
  const seeds = poseCells.filter((c) => c >= 0);
  // a drone was physically at every pose: the flood starts from every drone-passable voxel within the drone's own size
  // (0.36 m) of it. (A pose one voxel from a wall loses its own voxel when the free space is shrunk by the drone size;
  // seeding only that voxel lost about 5 % of the poses and everything reachable only through them.)
  const more = []; { const SYs = g.nx * g.nz, R = 3; for (const c of seeds) for (let dj = -R; dj <= R; dj++) for (let dk = -R; dk <= R; dk++) for (let di = -R; di <= R; di++) { if (di * di + dj * dj + dk * dk > R * R) continue; const q = c + di + g.nx * dk + SYs * dj; if (q >= 0 && q < g.N && er[q]) more.push(q); } }
  const reach = flood(g, er, more);
  yield { p: 0.3 };
  // the space the drones' bodies swept: everything within their half-width of a centre they reached (two voxels)
  const body = PTV ? dilate(g, reach, 1, 1, 1, 0) : dilate(g, reach, 2, 2, 2, 0);
  const cand = new Uint8Array(g.N); for (let c = 0; c < g.N; c++) cand[c] = free[c] && !body[c] ? 1 : 0;
  const minN = Math.round(0.3 / g.V3);
  const { comps } = components(g, cand, { minKeep: minN, keepCells: true });
  const core = erode(g, cand, 1, 1, 1, 0);
  yield { p: 0.55 };
  const out = [], unseenSpace = [];
  // what encloses each pocket: the share of the voxels just outside it that are drone-reachable free space (the
  // opening), structure the scans hit, or space nobody saw. Recorded with the pocket (it shows on the card); it is not
  // used to accept or reject (see README: it did not separate real pockets from false ones).
  const mark = new Uint8Array(g.N), SYb = g.nx * g.nz, nb = [1, -1, g.nx, -g.nx, SYb, -SYb];
  for (const cp of comps) {
    let nc = 0; for (const c of cp.cells) if (core[c]) nc++;
    if (nc * g.V3 < 0.02) continue;
    // ignore anything outside the building's outline (open ground the ring did not fly over)
    const cen = [g.x0 + (cp.ci + .5) * g.vox, g.y0 + (cp.cj + .5) * g.vox, g.z0 + (cp.ck + .5) * g.vox];
    if (Math.abs(cen[0]) > model.dims.L / 2 + 2.5 || Math.abs(cen[2]) > model.dims.D / 2 + 3) continue;
    for (const c of cp.cells) mark[c] = 1;
    let nSolid = 0, nUnk = 0, nOpen = 0;
    for (const c of cp.cells) for (const d of nb) { const q = c + d; if (q < 0 || q >= g.N || mark[q]) continue; if (S[q] === O_OCC) nSolid++; else if (S[q] === O_UNK) nUnk++; else nOpen++; }
    for (const c of cp.cells) mark[c] = 0;
    const nB = Math.max(1, nSolid + nUnk + nOpen), enc = { solid: nSolid / nB, unknown: nUnk / nB, open: nOpen / nB };
    const vol = cp.n * g.V3;
    out.push({ id: out.length, kind: 'gap', vol, core: nc * g.V3, centre: cen, cells: cp.cells, conf: Math.min(0.92, 0.55 + 0.35 * Math.min(1, vol / 2)), bb: cp.bb, enc });
  }
  // (b): planes from the debris voxels (RANSAC, several rounds) and displaced slabs
  const pieces = [];
  for (const pc of (CH.pieces || slabPieces(g, CH.debris, ctx.pts, ctx.nh, r))) pieces.push({ ...pc });
  // a displaced floor slab leaning down onto the storey below (the lowest moved storey's own floor)
  const lowMoved = fits.findIndex((f, s) => s > 0 && !f.ident && f.tilt >= 6);
  if (lowMoved > 0) {
    const pts = []; let n = null;
    for (const p of model.parts) {
      if (p.kind !== 'slab' || p.level !== lowMoved || tests[p.id].state === 'gone') continue;
      const b = boxT(fits[lowMoved].T, p.box), m = qToMat(b.q); n = [m[1], m[4], m[7]];
      for (const sa of [-1, -0.5, 0, 0.5, 1]) for (const sc of [-1, -0.5, 0, 0.5, 1]) pts.push([0, 1, 2].map((i) => b.c[i] + m[i * 3] * sa * b.h[0] + m[i * 3 + 2] * sc * b.h[2] - n[i] * b.h[1]));
    }
    if (n && pts.length) pieces.push({ from: 'slab', n, pts, count: pts.length, under: true });
  }
  yield { p: 0.75 };
  const SY = g.nx * g.nz;
  for (const pc of pieces) {
    // the wedge: under the piece, down to whatever is below, within its footprint; only unseen voxels count
    let x0 = 1e9, x1 = -1e9, z0 = 1e9, z1 = -1e9, ylo = 1e9; for (const q of pc.pts) { x0 = Math.min(x0, q[0]); x1 = Math.max(x1, q[0]); z0 = Math.min(z0, q[2]); z1 = Math.max(z1, q[2]); ylo = Math.min(ylo, q[1]); }
    const [nx, ny, nz] = pc.n, d = nx * pc.pts[0][0] + ny * pc.pts[0][1] + nz * pc.pts[0][2];
    if (ylo > 1.4 + (pc.from === 'slab' ? 0 : 3.5)) continue;          // one edge must come down near a floor
    // per column under the piece: the unseen run down to whatever is below. A lean-to void is low (a person crawls or
    // kneels in it), so only columns between 0.4 and 2.0 m count; the largest connected part is the pocket
    const wm = new Uint8Array(g.N); let nW = 0, nSeen = 0;
    for (let x = x0 + 0.06; x < x1; x += g.vox) for (let z = z0 + 0.06; z < z1; z += g.vox) {
      const yTop = (d - nx * x - nz * z) / ny - (pc.from === 'slab' ? 0.02 : g.vox);
      let c = g.cell(x, yTop, z); if (c < 0) continue; let gap = 0; const run = [];
      for (let k = 0; k < 30 && c >= SY; k++, c -= SY) { if (S[c] === O_OCC || CH.Shat[c] || CH.debris[c]) break; if (S[c] === O_UNK && !CH.fill[c]) run.push(c); gap += g.vox; }
      if (gap < 0.4 || gap > 2.0) continue; for (const q of run) if (!wm[q]) { wm[q] = 1; nW++; }
      // evidence that there is space under the piece at all: voxels in this column the scans saw empty
      for (let k = 0, c2 = g.cell(x, yTop, z); k < 30 && c2 >= SY; k++, c2 -= SY) { if (S[c2] === O_OCC || CH.Shat[c2]) break; if (S[c2] === O_FREE) nSeen++; }
    }
    // a wedge nobody looked into is unseen space, not a pocket: some of it must have been seen empty (0.1 m3 or more)
    if (nSeen * g.V3 < 0.1) { unseenSpace.push({ vol: nW * g.V3, centre: [(x0 + x1) / 2, ylo, (z0 + z1) / 2], under: pc.from }); continue; }
    if (nW * g.V3 < 0.3) continue;
    const { comps: wc } = components(g, wm, { minKeep: Math.round(0.3 / g.V3), keepCells: true });
    if (!wc.length) continue; wc.sort((a, b) => b.n - a.n);
    const cells = wc[0].cells; let maxGap = 0; { const colTop = new Map(), colBot = new Map(); for (const c of cells) { const col = c % SY, j = (c - col) / SY; colTop.set(col, Math.max(colTop.get(col) ?? -1, j)); colBot.set(col, Math.min(colBot.get(col) ?? 1e9, j)); } for (const [col, j1] of colTop) maxGap = Math.max(maxGap, (j1 - colBot.get(col) + 1) * g.vox); }
    const vol = cells.length * g.V3;
    if (vol < 0.3 || maxGap < 0.35) continue;
    // already a seen-through-a-gap pocket here? then that one stands
    const cen = [0, 0, 0]; const t = [0, 0, 0]; for (const c of cells) { g.centre(c, t); cen[0] += t[0]; cen[1] += t[1]; cen[2] += t[2]; } cen[0] /= cells.length; cen[1] /= cells.length; cen[2] /= cells.length;
    if (out.some((o) => Math.hypot(o.centre[0] - cen[0], o.centre[1] - cen[1], o.centre[2] - cen[2]) < 1.0)) continue;
    out.push({ id: out.length, kind: 'slab', vol, core: 0, centre: cen, cells: Int32Array.from(cells), conf: Math.min(0.48, 0.28 + 0.1 * Math.min(2, vol)), piece: { n: pc.n, from: pc.from, pts: pc.pts.length > 40 ? pc.pts.filter((q, i) => i % Math.ceil(pc.pts.length / 40) === 0) : pc.pts, gap: maxGap } });
  }
  // room each pocket is in (nearest room centre, moved with its storey)
  for (const o of out) {
    let best = -1, bd = 1e9; for (const room of model.rooms) { const c = tApply(fits[room.storey].T, (room.x0 + room.x1) / 2, (room.y0 + room.y1) / 2, (room.z0 + room.z1) / 2); const dd = Math.hypot(c[0] - o.centre[0], (c[1] - o.centre[1]) * 1.5, c[2] - o.centre[2]); if (dd < bd) { bd = dd; best = room.id; } }
    o.room = bd < 6 ? best : -1;
  }
  out.sort((a, b) => b.conf * b.vol - a.conf * a.vol); out.forEach((o, i) => { o.id = i; });
  return { list: out, reach, pieces: pieces.length, unseenSpace };
}
