// How far to trust it: a confidence value for every exposed surface voxel of the measured building (its standing
// structure and the debris), from how often it was seen, from how far (LiDAR range), whether smoke was in the way, and
// the registration's leftover misfit there. Surfaces the scans should have seen but never did count as zero. A short
// re-fly sortie goes to the weakest areas a drone can reach; the confidence is recomputed with the new rays.
import { O_UNK, O_FREE, O_OCC } from './occupancy.js';

export function surfaceVoxels(g, CH) {
  const solid = (c) => CH.Shat[c] || CH.debris[c];
  const { nx, nz } = g, SY = nx * nz, out = [];
  for (let c = SY; c < g.N - SY; c++) {
    if (!solid(c)) continue; const i = c % nx; if (i === 0 || i === nx - 1) continue;
    if (!solid(c - 1) || !solid(c + 1) || !solid(c - nx) || !solid(c + nx) || !solid(c - SY) || !solid(c + SY)) out.push(c);
  }
  return Int32Array.from(out);
}
export function confidenceOf(g, O, surf, smoke, misfit, area) {
  const conf = new Uint8Array(surf.length), cap = new Uint8Array(surf.length); const { nx, nz } = g, SY = nx * nz; const p = [0, 0, 0];
  let sum = 0, n = 0; const hist = new Array(10).fill(0);
  for (let k = 0; k < surf.length; k++) {
    const c = surf[k]; g.centre(c, p);
    // returns in the voxel and its 26 neighbours: about how many samples describe this bit of surface
    let h = 0; for (let dj = -SY; dj <= SY; dj += SY) for (let dk = -nx; dk <= nx; dk += nx) for (let di = -1; di <= 1; di++) h += O.hits[c + dj + dk + di];
    const seen = 1 - Math.exp(-h / 3);
    const rm = O.rmin[c] < 255 ? O.rmin[c] * 0.05 : 9; const rangeF = Math.max(0.35, Math.min(1, 1 - (rm - 5) / 9));
    let sm = 0; for (const s of smoke) { const d = Math.hypot(p[0] - s.c[0], p[1] - s.c[1], p[2] - s.c[2]); if (d < s.r) sm = Math.max(sm, 1 - d / s.r * 0.5); }
    const mk = Math.floor(p[0] / 2) + ',' + Math.floor(p[2] / 2), mf = misfit[mk] ?? 0.02; const misF = Math.exp(-((mf / 0.045) ** 2));
    const v = seen * rangeF * (1 - 0.55 * sm) * misF;
    conf[k] = Math.round(v * 255);
    // the most a closer, longer look could reach here (smoke and the registration misfit do not go away)
    cap[k] = Math.round((1 - 0.55 * sm) * misF * 255);
    if (p[0] > area.x0 && p[0] < area.x1 && p[2] > area.z0 && p[2] < area.z1) { sum += v; n++; hist[Math.min(9, Math.floor(v * 10))]++; }
  }
  return { conf, cap, mean: n ? sum / n : 0, hist, n };
}
// The re-fly, planned target by target. Weak surface (confidence 35 % or less) is clustered per metre; for each cluster
// the planner looks for viewpoints 2-3 m away that a drone demonstrably reached (the observed reach of the search), on
// the open side of the surface, with a line of sight through space seen empty; it keeps up to
// three of them at least 35 degrees apart, and each scans a 35-degree cone aimed at the cluster. A cluster with no such
// viewpoint cannot be reached from the air: it is listed for a human to check.
export function reflyPlan(g, S, CH, surf, conf, reach, { maxTargets = 10, perTarget = 3, cap = null } = {}) {
  const cell = 1.0, bins = new Map(); const p = [0, 0, 0]; let limitedN = 0;
  const solid = (c) => CH.Shat[c] || CH.debris[c] || S[c] === O_OCC;
  const { nx, nz } = g, SY = nx * nz;
  for (let k = 0; k < surf.length; k++) {
    if (conf[k] > 90) continue; const c = surf[k]; g.centre(c, p);
    // weak because of smoke or the registration misfit, not for lack of looking: a re-fly cannot help there
    if (cap && cap[k] < conf[k] + 90) { limitedN++; continue; }
    const key = Math.floor(p[0] / cell) + ',' + Math.floor(p[1] / cell) + ',' + Math.floor(p[2] / cell);
    let b = bins.get(key); if (!b) { b = { n: 0, x: 0, y: 0, z: 0, nx: 0, ny: 0, nz: 0, idx: [] }; bins.set(key, b); }
    b.n++; b.x += p[0]; b.y += p[1]; b.z += p[2]; b.idx.push(k);
    // the open side of this bit of surface
    b.nx += (solid(c - 1) ? 0 : -1) + (solid(c + 1) ? 0 : 1); b.ny += (solid(c - SY) ? 0 : -1) + (solid(c + SY) ? 0 : 1); b.nz += (solid(c - nx) ? 0 : -1) + (solid(c + nx) ? 0 : 1);
  }
  const clusters = [...bins.values()].filter((b) => b.n >= 20).map((b) => { const L = Math.hypot(b.nx, b.ny, b.nz) || 1; return { n: b.n, c: [b.x / b.n, b.y / b.n, b.z / b.n], nrm: [b.nx / L, b.ny / L, b.nz / L], idx: b.idx }; }).sort((a, b) => b.n - a.n);
  // a line of sight the planner can trust: through space the scans saw empty, except the last half metre at the surface
  const clear = (a, b) => { const d = Math.hypot(b[0] - a[0], b[1] - a[1], b[2] - a[2]); for (let t = 0.15; t < d - 0.3; t += g.vox * 0.8) { const c = g.cell(a[0] + (b[0] - a[0]) * t / d, a[1] + (b[1] - a[1]) * t / d, a[2] + (b[2] - a[2]) * t / d); if (c < 0 || solid(c) || (t < d - 0.5 && S[c] !== O_FREE)) return false; } return true; };
  const views = (cl) => {
    const out = [];
    for (let a = 0; a < 64; a++) {
      const th = a * 2.399963, ph = Math.acos(1 - 2 * (a + .5) / 64), dir = [Math.sin(ph) * Math.cos(th), Math.cos(ph), Math.sin(ph) * Math.sin(th)];
      const face = dir[0] * cl.nrm[0] + dir[1] * cl.nrm[1] + dir[2] * cl.nrm[2]; if (face < 0.3) continue;
      for (const d of [2.0, 2.5, 3.0]) {
        const q = [cl.c[0] + dir[0] * d, cl.c[1] + dir[1] * d, cl.c[2] + dir[2] * d]; const c = g.cell(q[0], q[1], q[2]);
        if (c < 0 || !reach[c] || !clear(q, cl.c)) continue;
        out.push({ p: q, dir, d, score: face - (d - 2) * 0.2 }); break;
      }
    }
    out.sort((a, b) => b.score - a.score);
    const pick = []; for (const v of out) { if (pick.length >= perTarget) break; if (pick.every((w) => w.dir[0] * v.dir[0] + w.dir[1] * v.dir[1] + w.dir[2] * v.dir[2] < Math.cos(35 * Math.PI / 180))) pick.push(v); }
    return pick;
  };
  const poses = [], targets = [], unreachable = [];
  for (const cl of clusters) {
    const vs = views(cl);
    if (!vs.length) { unreachable.push({ c: cl.c, n: cl.n, area: cl.n * g.vox * g.vox }); continue; }
    if (targets.length >= maxTargets) continue;
    // not twice the same place
    if (targets.some((t) => Math.hypot(t.c[0] - cl.c[0], t.c[1] - cl.c[1], t.c[2] - cl.c[2]) < 1.5)) continue;
    const ti = targets.length; targets.push({ c: cl.c, n: cl.n, idx: cl.idx, views: vs.length });
    for (const v of vs) { const aim = [cl.c[0] - v.p[0], cl.c[1] - v.p[1], cl.c[2] - v.p[2]]; const L = Math.hypot(...aim); poses.push({ p: v.p, target: cl.c, aim: aim.map((x) => x / L), cone: 0.61, n: cl.n, kind: 'refly', ti }); }
  }
  return { poses, targets, unreachable, limitedArea: limitedN * g.vox * g.vox };
}
