// Ray casting against oriented boxes (the simulated world) through a uniform-grid accelerator, plus the ground plane.
// Used only by the scan simulator: the pipeline never looks at the world, only at what the scanner returned.
import { qToMat, boxAABB } from '../building/geom.js';

export function buildScene(boxes, { cell = 0.5, bounds, ground = true } = {}) {
  const n = boxes.length, B = new Float64Array(n * 15), AB = new Float64Array(n * 6);
  let x0 = 1e9, y0 = 1e9, z0 = 1e9, x1 = -1e9, y1 = -1e9, z1 = -1e9;
  for (let i = 0; i < n; i++) {
    const b = boxes[i], m = qToMat(b.q), o = i * 15;
    B[o] = b.c[0]; B[o + 1] = b.c[1]; B[o + 2] = b.c[2]; B[o + 3] = b.h[0]; B[o + 4] = b.h[1]; B[o + 5] = b.h[2];
    for (let k = 0; k < 9; k++) B[o + 6 + k] = m[k];
    const bb = boxAABB(b); for (let k = 0; k < 6; k++) AB[i * 6 + k] = bb[k];
    x0 = Math.min(x0, bb[0]); y0 = Math.min(y0, bb[1]); z0 = Math.min(z0, bb[2]); x1 = Math.max(x1, bb[3]); y1 = Math.max(y1, bb[4]); z1 = Math.max(z1, bb[5]);
  }
  if (bounds) { x0 = bounds[0]; y0 = bounds[1]; z0 = bounds[2]; x1 = bounds[3]; y1 = bounds[4]; z1 = bounds[5]; }
  x0 -= 0.01; y0 -= 0.01; z0 -= 0.01;
  const nx = Math.max(1, Math.ceil((x1 - x0) / cell) + 1), ny = Math.max(1, Math.ceil((y1 - y0) / cell) + 1), nz = Math.max(1, Math.ceil((z1 - z0) / cell) + 1);
  const NC = nx * ny * nz, count = new Int32Array(NC + 1);
  const range = (i) => { const o = i * 6; return [Math.max(0, Math.floor((AB[o] - x0) / cell)), Math.max(0, Math.floor((AB[o + 1] - y0) / cell)), Math.max(0, Math.floor((AB[o + 2] - z0) / cell)), Math.min(nx - 1, Math.floor((AB[o + 3] - x0) / cell)), Math.min(ny - 1, Math.floor((AB[o + 4] - y0) / cell)), Math.min(nz - 1, Math.floor((AB[o + 5] - z0) / cell))]; };
  for (let i = 0; i < n; i++) { const r = range(i); for (let k = r[2]; k <= r[5]; k++) for (let j = r[1]; j <= r[4]; j++) for (let a = r[0]; a <= r[3]; a++) count[a + nx * (j + ny * k) + 1]++; }
  for (let c = 0; c < NC; c++) count[c + 1] += count[c];
  const items = new Int32Array(count[NC]), fill = count.slice(0, NC);
  for (let i = 0; i < n; i++) { const r = range(i); for (let k = r[2]; k <= r[5]; k++) for (let j = r[1]; j <= r[4]; j++) for (let a = r[0]; a <= r[3]; a++) items[fill[a + nx * (j + ny * k)]++] = i; }
  return { B, n, x0, y0, z0, nx, ny, nz, cell, start: count, items, stamp: new Int32Array(n), ray: 0, ground };
}

// distance along the ray to the box, or Infinity (slab test in the box's own frame)
function hitBox(B, o, ox, oy, oz, dx, dy, dz) {
  const px = ox - B[o], py = oy - B[o + 1], pz = oz - B[o + 2];
  let tn = -Infinity, tf = Infinity;
  for (let a = 0; a < 3; a++) {
    const ux = B[o + 6 + a], uy = B[o + 9 + a], uz = B[o + 12 + a];          // column a of R (local axis a)
    const e = ux * px + uy * py + uz * pz, f = ux * dx + uy * dy + uz * dz, h = B[o + 3 + a];
    if (Math.abs(f) < 1e-12) { if (e > h || e < -h) return Infinity; continue; }
    let t1 = (-h - e) / f, t2 = (h - e) / f; if (t1 > t2) { const t = t1; t1 = t2; t2 = t; }
    if (t1 > tn) tn = t1; if (t2 < tf) tf = t2; if (tn > tf) return Infinity;
  }
  if (tf < 1e-6) return Infinity;
  return tn > 1e-6 ? tn : Infinity;   // a ray that starts inside a box ignores it
}

// cast one ray (d normalised). out.t = distance, out.id = box index (-2 ground, -1 nothing)
export function castRay(S, ox, oy, oz, dx, dy, dz, tmax, out) {
  let best = tmax, id = -1;
  if (S.ground && dy < -1e-9) { const tg = -oy / dy; if (tg > 0 && tg < best) { best = tg; id = -2; } }
  const { x0, y0, z0, nx, ny, nz, cell, start, items, stamp, B } = S;
  const ray = ++S.ray; if (ray > 2e9) { S.ray = 1; stamp.fill(0); }
  // clip to the grid box
  let t0 = 0, t1 = best;
  const lo = [x0, y0, z0], hi = [x0 + nx * cell, y0 + ny * cell, z0 + nz * cell], O = [ox, oy, oz], Dd = [dx, dy, dz];
  for (let a = 0; a < 3; a++) {
    if (Math.abs(Dd[a]) < 1e-12) { if (O[a] < lo[a] || O[a] > hi[a]) { out.t = best; out.id = id; return id !== -1; } continue; }
    let ta = (lo[a] - O[a]) / Dd[a], tb = (hi[a] - O[a]) / Dd[a]; if (ta > tb) { const t = ta; ta = tb; tb = t; }
    if (ta > t0) t0 = ta; if (tb < t1) t1 = tb;
  }
  if (t0 > t1) { out.t = best; out.id = id; return id !== -1; }
  const sx = ox + dx * (t0 + 1e-7), sy = oy + dy * (t0 + 1e-7), sz = oz + dz * (t0 + 1e-7);
  let i = Math.min(nx - 1, Math.max(0, Math.floor((sx - x0) / cell))), j = Math.min(ny - 1, Math.max(0, Math.floor((sy - y0) / cell))), k = Math.min(nz - 1, Math.max(0, Math.floor((sz - z0) / cell)));
  const stX = dx > 0 ? 1 : -1, stY = dy > 0 ? 1 : -1, stZ = dz > 0 ? 1 : -1;
  const tdX = Math.abs(dx) > 1e-12 ? cell / Math.abs(dx) : Infinity, tdY = Math.abs(dy) > 1e-12 ? cell / Math.abs(dy) : Infinity, tdZ = Math.abs(dz) > 1e-12 ? cell / Math.abs(dz) : Infinity;
  let tmX = Math.abs(dx) > 1e-12 ? ((x0 + (i + (dx > 0 ? 1 : 0)) * cell) - ox) / dx : Infinity;
  let tmY = Math.abs(dy) > 1e-12 ? ((y0 + (j + (dy > 0 ? 1 : 0)) * cell) - oy) / dy : Infinity;
  let tmZ = Math.abs(dz) > 1e-12 ? ((z0 + (k + (dz > 0 ? 1 : 0)) * cell) - oz) / dz : Infinity;
  for (;;) {
    const c = i + nx * (j + ny * k);
    for (let q = start[c], e = start[c + 1]; q < e; q++) {
      const b = items[q]; if (stamp[b] === ray) continue; stamp[b] = ray;
      const t = hitBox(B, b * 15, ox, oy, oz, dx, dy, dz); if (t < best) { best = t; id = b; }
    }
    const tExit = Math.min(tmX, tmY, tmZ);
    if (best <= tExit || tExit > t1) break;
    if (tmX <= tmY && tmX <= tmZ) { i += stX; if (i < 0 || i >= nx) break; tmX += tdX; }
    else if (tmY <= tmZ) { j += stY; if (j < 0 || j >= ny) break; tmY += tdY; }
    else { k += stZ; if (k < 0 || k >= nz) break; tmZ += tdZ; }
  }
  out.t = best; out.id = id; return id !== -1;
}
// is the straight segment a -> b free of boxes (line of sight)?
export function clearLine(S, a, b, pad = 0.05) {
  const dx = b[0] - a[0], dy = b[1] - a[1], dz = b[2] - a[2], L = Math.hypot(dx, dy, dz); if (L < 1e-6) return true;
  const o = { t: 0, id: -1 }; castRay(S, a[0], a[1], a[2], dx / L, dy / L, dz / L, L - pad, o); return o.id === -1;
}
