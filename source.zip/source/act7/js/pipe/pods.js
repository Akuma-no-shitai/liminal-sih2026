// Is it still moving? Drones drop vibration pods (ADXL355 accelerometer + ESP32-C6, from a drop tube) on a few
// standing walls. Each pod listens to ambient vibration; the pipeline finds the wall's natural frequency f0 as the
// peak of the spectrum (parabolic interpolation on the log spectrum). f0 goes with the square root of stiffness over
// mass, so a 10 % drop in f0 means about 19 % of the stiffness is gone. After an aftershock, quick repeat scans
// measure the extra tilt and how it creeps back; an exponential fit gives the relaxation time tau. If tau grows from
// one aftershock to the next, the structure is nearing its threshold (critical slowing down).
import { rngFor, DEG, fitPlane } from '../building/geom.js';
import { NS } from '../building/building.js';

const F0 = 0.5, F1 = 40, DF = 0.05, NB = Math.round((F1 - F0) / DF);
export const SPEC = { f0: F0, f1: F1, df: DF, n: NB };
// the intact natural frequency the baseline model gives for a wall panel of this size (a simple plate rule)
export const refFreq = (u) => 9.5 * Math.pow(3.2 / Math.max(1.6, u.a1 - u.a0), 0.7) * (u.ext ? 1 : 0.9);

const lor = (f, f0, z) => { const x = f / f0; return 1 / ((1 - x * x) ** 2 + (2 * z * x) ** 2); };
// a synthetic ambient spectrum (Welch average of 8 segments): the building's sway, the wall's own mode and its second
// mode, a pink noise floor
export function spectrum(fWall, fBuild, r) {
  const P = new Float32Array(NB);
  for (let b = 0; b < NB; b++) {
    const f = F0 + (b + .5) * DF;
    let v = 0.9 * lor(f, fBuild, 0.05) + 0.55 * lor(f, fWall, 0.03) + 0.06 * lor(f, fWall * 2.75, 0.04) + 0.035 / Math.pow(f, 0.6);
    let gsum = 0; for (let k = 0; k < 8; k++) gsum += -Math.log(Math.max(1e-9, r())); v *= gsum / 8;
    P[b] = v;
  }
  return P;
}
export function peakPick(P, lo = 4, hi = 30, avoid = null) {
  const L = new Float32Array(P.length); for (let b = 0; b < P.length; b++) L[b] = Math.log(P[b]);
  const S = new Float32Array(P.length); for (let b = 1; b < P.length - 1; b++) S[b] = (L[b - 1] + L[b] + L[b + 1]) / 3;
  let best = -1, bv = -1e9;
  for (let b = 2; b < P.length - 2; b++) { const f = F0 + (b + .5) * DF; if (f < lo || f > hi) continue; if (avoid && Math.abs(f - avoid) < avoid * 0.18) continue; if (S[b] > bv) { bv = S[b]; best = b; } }
  if (best < 0) return { f: NaN, bin: -1 };
  const a = S[best - 1], c = S[best + 1], m = S[best]; const den = a - 2 * m + c; const off = Math.abs(den) > 1e-9 ? 0.5 * (a - c) / den : 0;
  return { f: F0 + (best + .5 + Math.max(-1, Math.min(1, off))) * DF, bin: best };
}

// pick 3-5 walls: standing, external (a drop tube reaches them from outside), seen well; the most suspect first, one
// that looks intact for reference, spread over floors and sides
export function choosePods(model, cond, tests, seed) {
  const r = rngFor(seed, 'pods');
  const cands = cond.walls.filter((w) => { const u = model.walls[w.id]; return w.ok && u.ext && u.storey <= 2 && w.gone < 0.05 && (u.a1 - u.a0) > 1.5; });
  const sus = (w) => { const ps = cond.patches.filter((p) => p.wall === w.id && p.st === 'ok'); const phi = ps.length ? Math.min(...ps.map((p) => p.S)) : 1; return (1 - phi) * 3 + (cond.crackLen[w.id] > 0 ? 0.4 : 0) + (w.tilt || 0) * 0.02 + r() * 0.05; };
  const scored = cands.map((w) => ({ w, s: sus(w) })).sort((a, b) => b.s - a.s);
  const chosen = [];
  const far = (w) => chosen.every((c) => { const u1 = model.walls[c.w.id], u2 = model.walls[w.id]; return u1.storey !== u2.storey || u1.axis !== u2.axis || Math.abs(u1.off - u2.off) > 1; });
  for (const c of scored) { if (chosen.length >= 3) break; if (far(c.w)) chosen.push(c); }
  const ref = scored.slice().reverse().find((c) => !chosen.includes(c) && far(c.w)); if (ref) chosen.push({ ...ref, ref: true });
  if (scored.length > chosen.length && chosen.length < 5 && r() < 0.5) { const extra = scored.find((c) => !chosen.includes(c) && far(c.w)); if (extra) chosen.push(extra); }
  return chosen.map((c, i) => {
    const w = c.w, u = model.walls[w.id], F = w.frame;
    const out = (F.c[0] * F.n[0] + F.c[2] * F.n[2]) > 0 ? 1 : -1;
    const pos = [0, 1, 2].map((k) => F.c[k] + F.y[k] * (-F.h / 2 + 1.35) + F.n[k] * out * (u.t / 2 + 0.05));
    return { id: i, wall: w.id, storey: u.storey, pos, normal: F.n.map((v) => v * out), ref: !!c.ref, fRef: refFreq(u) };
  });
}

// read the pods: truth stiffness ratio per pod wall from the simulated damage; the pipeline only sees the spectra
export function podTruth(model, post, pods, seed) {
  const r = rngFor(seed, 'podtruth');
  return pods.map((p) => {
    const w = post.walls[p.wall]; const k = Math.max(0.3, Math.min(1, 1 - 0.55 * w.damage - (w.crackLen > 0 ? 0.07 : 0) - (w.tilt > 1 ? 0.05 : 0) - 0.02 * r()));
    return { k, fIntact: p.fRef * (1 + 0.03 * r.gauss()) };
  });
}
export function readPods(pods, truth, buildK, seed, salt) {
  const r = rngFor(seed, 'podread', salt);
  const fB = 2.6 * Math.sqrt(buildK);
  return pods.map((p, i) => {
    const fTrue = truth[i].fIntact * Math.sqrt(truth[i].k);
    const P = spectrum(fTrue, fB, r); const pk = peakPick(P, 4, 30, fB);
    return { pod: i, spectrum: P, f0: pk.f, bin: pk.bin, fTrue, drop: 1 - pk.f / p.fRef, stiffLoss: 1 - (pk.f / p.fRef) ** 2, trueLoss: 1 - truth[i].k };
  });
}

// ------------------------------------------------------------------ aftershocks and the relaxation time
// a quick repeat scan of one wall: points on its (tilted) plane with scanner noise, plane fit, tilt
function quickTilt(tiltDeg, dir, r) {
  // six walls of the part that moves, ~1200 returns each at 3-6 m (sigma 1.5 cm): their mean tilt
  let sum = 0; const N = 1200, t = tiltDeg * DEG;
  for (let w = 0; w < 6; w++) {
    const P = new Float32Array(N * 3), idx = [];
    for (let i = 0; i < N; i++) { const a = (r() - .5) * 3.6, v = r() * 2.8; const n = r.gauss() * 0.015; P[i * 3] = a; P[i * 3 + 1] = v * Math.cos(t); P[i * 3 + 2] = v * Math.sin(t) * dir + n; idx.push(i); }
    const f = fitPlane(P, idx); sum += Math.asin(Math.min(1, Math.abs(f.n[1]))) / DEG;
  }
  return sum / 6;
}
export function fitTau(ts, ys) {
  let best = null;
  for (let k = 0; k < 260; k++) {
    const tau = 0.2 * Math.pow(400, k / 259);
    let s1 = 0, se = 0, see = 0, sy = 0, sye = 0; const n = ts.length;
    for (let i = 0; i < n; i++) { const e = Math.exp(-ts[i] / tau); s1++; se += e; see += e * e; sy += ys[i]; sye += ys[i] * e; }
    const det = s1 * see - se * se; if (Math.abs(det) < 1e-12) continue;
    const a = (sy * see - se * sye) / det, b = (s1 * sye - se * sy) / det;
    let sse = 0; for (let i = 0; i < n; i++) sse += (ys[i] - a - b * Math.exp(-ts[i] / tau)) ** 2;
    if (!best || sse < best.sse) best = { tau, a, b, sse };
  }
  // a rough interval: taus whose misfit is within 50 % of the best
  let lo = best.tau, hi = best.tau;
  for (let k = 0; k < 260; k++) { const tau = 0.2 * Math.pow(400, k / 259); let s1 = 0, se = 0, see = 0, sy = 0, sye = 0; for (let i = 0; i < ts.length; i++) { const e = Math.exp(-ts[i] / tau); s1++; se += e; see += e * e; sy += ys[i]; sye += ys[i] * e; } const det = s1 * see - se * se; if (Math.abs(det) < 1e-12) continue; const a = (sy * see - se * sye) / det, b = (s1 * sye - se * sy) / det; let sse = 0; for (let i = 0; i < ts.length; i++) sse += (ys[i] - a - b * Math.exp(-ts[i] / tau)) ** 2; if (sse < best.sse * 1.5 + 1e-8) { lo = Math.min(lo, tau); hi = Math.max(hi, tau); } }
  return { ...best, lo, hi };
}
export const SCAN_T = [0.3, 0.6, 1, 1.5, 2, 3, 4, 5.5, 7, 9, 12, 16, 21, 27];
// aftershock number k (1, 2, ...): computed on demand, deterministic from the seed. state carries the truth forward.
export function aftershock(C, k) {
  const r = rngFor(C.seed, 'aftershock', k);
  const prev = k === 1 ? C.pods.state0 : C.aftershocks[k - 2].state;
  const moved = C.storeys.some((f) => f.tilt > 1);
  const dmgMean = C.pods.truth.reduce((s, t) => s + (1 - t.k), 0) / Math.max(1, C.pods.truth.length);
  const kAfter = prev.k.map((kk, i) => Math.max(0.2, kk * (1 - (0.05 + 0.16 * (1 - C.pods.truth[i].k) + 0.03 * (k - 1) + 0.03 * r()))));
  const buildK = prev.buildK * (1 - 0.04 - 0.02 * r());
  const jump = (moved ? 0.12 + 0.16 * r() : 0.07 + 0.07 * r()) * (1 + 0.5 * (k - 1));
  const tau = (3 + 3 * C.pods.tau0) * (1 + 0.6 * (k - 1)) * (1 + dmgMean), perm = 0.45 + 0.1 * r();
  const base = prev.tilt, dir = 1;
  const scans = SCAN_T.map((t) => ({ t, tilt: quickTilt(base + jump * (perm + (1 - perm) * Math.exp(-t / tau)), dir, r) }));
  const before = quickTilt(base, dir, r);
  const fit = fitTau(scans.map((q) => q.t), scans.map((q) => q.tilt));
  const truth = kAfter.map((kk, i) => ({ k: kk, fIntact: C.pods.truth[i].fIntact }));
  const reads = readPods(C.pods.list, truth, buildK, C.seed, 'after' + k);
  const prevTau = k === 1 ? null : C.aftershocks[k - 2].tau;
  return {
    k, jumpTrue: jump, tauTrue: tau, before, scans, tau: fit.tau, tauLo: fit.lo, tauHi: fit.hi, fitA: fit.a, fitB: fit.b, measuredJump: scans[0].tilt - before,
    reads, slowing: prevTau != null && fit.lo > prevTau,
    state: { k: kAfter, buildK, tilt: base + jump * perm },
  };
}
