// Simulated scans: a servo-tilted 2-D LiDAR (RPLidar A1M8 class: ~12 m range, sigma ~1.5 cm) carried by the drones.
//   baseline flight (Before phase): every room, an exterior ring at three heights and a pass over the roof
//   post-event flight (the search that just ended): only where a drone fits, the exterior ring where it is clear, and
//   the spots where drones stalled at gaps too narrow to enter. Its log gives speeds, stalls and splits.
// Output clouds keep every ray's end point (hit or max range) for ray carving; misses inside smoke are dropped.
import { buildScene, castRay } from './raycast.js';
import { rngFor, aabox, tApply } from '../building/geom.js';
import { floorTop, NS } from '../building/building.js';
import { L_FREE } from '../building/truth.js';
import { dilate, components } from '../building/voxel.js';

export const LIDAR = { range: 12, sigma: 0.015, sigmaSmoke: 0.03, drop: 0.01, smokeK: 0.32 };
const PERF = () => (typeof performance !== 'undefined' ? performance.now() : Date.now());

// equipment the responders brought (in the post-event world only): van, anchor robot with mast, table, landing pad
export function equipmentBoxes(model) {
  const S = model.site, out = [];
  const a = S.anchor, t = S.table, v = S.van, p = S.pad;
  out.push(aabox(v.x - 2.6, 0.3, v.z - 1.0, v.x + 2.6, 2.3, v.z + 1.0));                  // van body
  out.push(aabox(a.x - 0.75, 0.15, a.z - 0.5, a.x + 0.75, 0.75, a.z + 0.5));             // anchor robot
  out.push(aabox(a.x + 0.35, 0.75, a.z - 0.06, a.x + 0.47, 2.9, a.z + 0.06));            // its mast
  out.push(aabox(t.x - 0.9, 0.72, t.z - 0.4, t.x + 0.9, 0.76, t.z + 0.4));               // table top
  out.push(aabox(p.x - 1.2, 0, p.z - 1.2, p.x + 1.2, 0.04, p.z + 1.2));                  // landing pad
  return out;
}
export function makeScene(model, parts, { post = false } = {}) {
  const boxes = parts.map((p) => p.box);
  if (post) for (const b of equipmentBoxes(model)) boxes.push(b);
  return buildScene(boxes, { cell: 0.5 });
}

// ------------------------------------------------------------------ flight poses
function ringPoses(model, gap, heights, step) {
  const { L, D } = model.dims, out = [];
  const x0 = -L / 2 - gap, x1 = L / 2 + gap, z0 = -D / 2 - gap, z1 = D / 2 + gap;
  for (const y of heights) {
    const per = 2 * (x1 - x0) + 2 * (z1 - z0), n = Math.max(8, Math.round(per / step));
    for (let i = 0; i < n; i++) {
      let s = (i + (y * 0.37) % 1) / n * per, x, z;
      if (s < x1 - x0) { x = x0 + s; z = z1; } else if ((s -= x1 - x0) < z1 - z0) { x = x1; z = z1 - s; } else if ((s -= z1 - z0) < x1 - x0) { x = x1 - s; z = z0; } else { s -= x1 - x0; x = x0; z = z0 + s; }
      out.push({ p: [x, y, z], kind: 'ring' });
    }
  }
  return out;
}
export function basePoses(model) {
  const out = [];
  for (const room of model.rooms) {
    const w = room.x1 - room.x0, d = room.z1 - room.z0, nx = Math.max(1, Math.round(w / 2.3)), nz = Math.max(1, Math.round(d / 2.3));
    for (let a = 0; a < nx; a++) for (let b = 0; b < nz; b++) out.push({ p: [room.x0 + (a + .5) * w / nx, room.y0 + 1.35, room.z0 + (b + .5) * d / nz], kind: 'room', room: room.id });
    if (room.flat === 'core') out.push({ p: [0, room.y0 + 2.2, room.z0 + 0.75], kind: 'room', room: room.id });
  }
  out.push(...ringPoses(model, 2.0, [1.8, 5.8, 9.8], 2.6));
  out.push(...ringPoses(model, -1.2, [14.6], 3.5).map((q) => ({ ...q, kind: 'roof' })));
  return out;
}
// post-event poses: where a drone's centre fits (truth.reach.centre), inside the building (something overhead) on a
// lattice, the exterior ring where it is clear, and stalls at the mouths of spaces a drone could see but not enter
export function postPoses(model, truth, r) {
  const { g, P } = truth, reach = truth.reachFly || truth.reach, C = reach.centre, out = [];
  const feasibleNear = (x, y, z, rad = 0.7) => {
    const c0 = g.cell(x, y, z); if (c0 >= 0 && C[c0]) return [x, y, z];
    for (let d = 0.2; d <= rad + 1e-6; d += 0.2) for (let a = 0; a < 14; a++) {
      const th = a * 2.399, ph = Math.acos(1 - 2 * (a + .5) / 14); const px = x + d * Math.sin(ph) * Math.cos(th), py = y + d * Math.cos(ph), pz = z + d * Math.sin(ph) * Math.sin(th);
      const c = g.cell(px, py, pz); if (c >= 0 && C[c]) return [px, py, pz];
    }
    return null;
  };
  const overhead = (x, y, z) => { for (let h = 0.3; h < 3.4; h += 0.1) { const c = g.cell(x, y + h, z); if (c < 0) return false; const v = P[c]; if (v !== L_FREE && v !== 3) return true; } return false; };
  const A = truth.area;
  for (let y = 1.5; y < A.y1 - 0.6; y += 1.5) for (let x = A.x0 + 1.0; x < A.x1 - 0.6; x += 2.4) for (let z = A.z0 + 1.0; z < A.z1 - 0.6; z += 2.4) {
    const jx = x + (r() - .5) * 0.6, jz = z + (r() - .5) * 0.6;
    // inside the original outline the swarm searched everywhere it fitted (also where floors fell away); outside it,
    // only under something (the exterior is covered by the ring)
    const inside = Math.abs(jx) < model.dims.L / 2 - 0.3 && Math.abs(jz) < model.dims.D / 2 - 0.3 && y < NS * 3 + 0.5;
    if (!inside && !overhead(jx, y, jz)) continue;
    const p = feasibleNear(jx, y, jz, 0.6); if (!p || (!inside && !overhead(p[0], p[1], p[2]))) continue;
    if (out.some((q) => Math.abs(q.p[1] - p[1]) < 1.6 && Math.hypot(q.p[0] - p[0], q.p[2] - p[2]) < 1.7)) continue;
    out.push({ p, kind: 'room' });
  }
  // frontier-style completion: every reachable spot in the search area (the outline, and under overhangs and spilled
  // floors around it) gets a pose within ~1.6 m, farthest first: the swarm kept pushing into reachable unexplored space,
  // crawl spaces included, until the search was certified
  const FR = 'wide';   // (an A/B against the old outline-only pass: debris error 16-22 % -> 5-8 %; see README)
  {
    const cand = []; const tmp = [0, 0, 0]; const { L, D } = model.dims; const wide = FR === 'wide';
    for (let j = 1; j < g.ny - 1; j += 3) for (let k = 1; k < g.nz - 1; k += 3) for (let i = 1; i < g.nx - 1; i += 3) {
      const c = i + g.nx * (k + g.nz * j); if (!C[c]) continue; g.centre(c, tmp);
      if (tmp[1] > NS * 3 + 0.3) continue;
      const inOutline = Math.abs(tmp[0]) < L / 2 - 0.2 && Math.abs(tmp[2]) < D / 2 - 0.2;
      if (!inOutline && !(wide && Math.abs(tmp[0]) < L / 2 + 2.5 && Math.abs(tmp[2]) < D / 2 + 3 && overhead(tmp[0], tmp[1], tmp[2]))) continue;
      cand.push(tmp[0], tmp[1], tmp[2]);
    }
    // (Math.sqrt of the sum of squares in the inner loop rather than Math.hypot: the same float32 distances, 3x faster)
    const nc = cand.length / 3, cf = Float64Array.from(cand), dist = new Float32Array(nc).fill(1e9);
    const upd = (p) => { const px = p[0], py = p[1], pz = p[2]; for (let q = 0, o = 0; q < nc; q++, o += 3) { const dx = cf[o] - px, dy = (cf[o + 1] - py) * 1.6, dz = cf[o + 2] - pz; const d = Math.sqrt(dx * dx + dy * dy + dz * dz); if (d < dist[q]) dist[q] = d; } };
    for (const q of out) upd(q.p);
    const FCAP = +((typeof process !== 'undefined' && process.env && process.env.FCAP) || 140), FSP = +((typeof process !== 'undefined' && process.env && process.env.FSP) || 1.6);
    for (let add = 0; add < (FR === 'wide' ? FCAP : 60); add++) {
      let b = -1, bd = FR === 'wide' ? FSP : 2.0; for (let q = 0; q < nc; q++) if (dist[q] > bd) { bd = dist[q]; b = q; }
      if (b < 0) break; const p = [cand[b * 3], cand[b * 3 + 1], cand[b * 3 + 2]]; out.push({ p, kind: 'room', fill: true }); upd(p);
    }
  }
  for (const q of ringPoses(model, 2.0, [1.8, 5.8, 9.8], 2.6)) { const p = feasibleNear(q.p[0], q.p[1], q.p[2], 1.4); if (p) out.push({ p, kind: 'ring' }); }
  for (const q of ringPoses(model, -1.2, [14.6], 3.5)) { const p = feasibleNear(q.p[0], q.p[1], q.p[2], 1.0); if (p) out.push({ p, kind: 'roof' }); }
  // stalls: free space next to where a drone's body reached, that the drone could not enter
  const front = dilate(g, reach.body, 2, 2, 2, 0);
  const cand = new Uint8Array(g.N); for (let c = 0; c < g.N; c++) cand[c] = front[c] && !reach.body[c] && P[c] === L_FREE ? 1 : 0;
  const { comps } = components(g, cand, { minKeep: 40, keepCells: true });
  comps.sort((a, b) => b.n - a.n);
  const stalls = [];
  for (const cp of comps) {
    if (stalls.length >= 36) break;
    const cen = [g.x0 + (cp.ci + .5) * g.vox, g.y0 + (cp.cj + .5) * g.vox, g.z0 + (cp.ck + .5) * g.vox];
    // the reachable centre voxel nearest to the component
    let best = null, bd = 1e9; const tmp = [0, 0, 0];
    for (let q = 0; q < cp.cells.length; q += Math.max(1, Math.floor(cp.cells.length / 40))) {
      g.centre(cp.cells[q], tmp);
      for (let a = 0; a < 26; a++) { const th = a * 2.399, ph = Math.acos(1 - 2 * (a + .5) / 26); for (let d = 0.2; d < 0.9; d += 0.2) { const px = tmp[0] + d * Math.sin(ph) * Math.cos(th), py = tmp[1] + d * Math.cos(ph), pz = tmp[2] + d * Math.sin(ph) * Math.sin(th); const c = g.cell(px, py, pz); if (c >= 0 && C[c]) { const dd = Math.hypot(px - cen[0], py - cen[1], pz - cen[2]); if (dd < bd) { bd = dd; best = [px, py, pz]; } break; } } }
    }
    if (best && !out.some((q) => q.kind === 'stall' && Math.hypot(q.p[0] - best[0], q.p[1] - best[1], q.p[2] - best[2]) < 1.2)) { out.push({ p: best, kind: 'stall', gap: cen, vol: cp.n * g.V3 }); stalls.push(out.length - 1); }
  }
  return { poses: out, stalls };
}

// ------------------------------------------------------------------ scanning
// a stratified sphere of directions, rotated randomly per pose; elevation limited to what the tilting LiDAR covers
function directions(n, r) {
  const dirs = new Float32Array(n * 3); const rot = r() * Math.PI * 2, off = r(); let k = 0;
  for (let i = 0; i < n * 1.08 && k < n; i++) {
    const y = 1 - 2 * ((i + off) % (n * 1.08)) / (n * 1.08); if (Math.abs(y) > 0.985) continue;
    const rr = Math.sqrt(1 - y * y), th = i * 2.399963 + rot; dirs[k * 3] = rr * Math.cos(th); dirs[k * 3 + 1] = y; dirs[k * 3 + 2] = rr * Math.sin(th); k++;
  }
  return dirs.subarray(0, k * 3);
}
// aimed: a stratified cap of directions (half-angle h) around a unit vector, for a re-fly pose pointed at its target
function coneDirections(n, aim, h, r) {
  const dirs = new Float32Array(n * 3), c0 = Math.cos(h), rot = r() * Math.PI * 2;
  // a basis around the aim
  const a = aim, t = Math.abs(a[1]) < 0.9 ? [0, 1, 0] : [1, 0, 0];
  let u = [a[1] * t[2] - a[2] * t[1], a[2] * t[0] - a[0] * t[2], a[0] * t[1] - a[1] * t[0]]; const ul = Math.hypot(...u); u = u.map((x) => x / ul);
  const v = [a[1] * u[2] - a[2] * u[1], a[2] * u[0] - a[0] * u[2], a[0] * u[1] - a[1] * u[0]];
  for (let i = 0; i < n; i++) {
    const ct = 1 - (1 - c0) * (i + .5) / n, st = Math.sqrt(1 - ct * ct), ph = i * 2.399963 + rot;
    const x = st * Math.cos(ph), y = st * Math.sin(ph);
    dirs[i * 3] = a[0] * ct + u[0] * x + v[0] * y; dirs[i * 3 + 1] = a[1] * ct + u[1] * x + v[1] * y; dirs[i * 3 + 2] = a[2] * ct + u[2] * x + v[2] * y;
  }
  return dirs;
}
function smokeLen(sm, ox, oy, oz, dx, dy, dz, t) {
  if (!sm) return 0; let L = 0;
  for (const s of sm) { const px = ox - s.c[0], py = oy - s.c[1], pz = oz - s.c[2]; const b = px * dx + py * dy + pz * dz, cc = px * px + py * py + pz * pz - s.r * s.r, disc = b * b - cc; if (disc <= 0) continue; const q = Math.sqrt(disc); const t0 = Math.max(0, -b - q), t1 = Math.min(t, -b + q); if (t1 > t0) L += (t1 - t0) * s.k; }
  return L;
}
// generator: yields progress. opts: { rays(pose) -> count, smoke: [{ c, r, k }], seed, salt }
export function* scan(scene, poses, opts = {}) {
  const r = rngFor(opts.seed || 1, 'scan', opts.salt || '');
  const counts = poses.map((q) => opts.rays ? opts.rays(q) : 1500); let tot = 0; for (const c of counts) tot += c;
  const pts = new Float32Array(tot * 3), hit = new Uint8Array(tot), pose = new Uint16Array(tot), part = new Int32Array(tot), rng = new Float32Array(tot);
  let n = 0; const o = { t: 0, id: -1 }; let t0 = PERF();
  for (let pi = 0; pi < poses.length; pi++) {
    const P0 = poses[pi].p, dirs = poses[pi].aim ? coneDirections(counts[pi], poses[pi].aim, poses[pi].cone || 0.61, r) : directions(counts[pi], r);
    for (let k = 0; k < dirs.length; k += 3) {
      const dx = dirs[k], dy = dirs[k + 1], dz = dirs[k + 2];
      castRay(scene, P0[0], P0[1], P0[2], dx, dy, dz, LIDAR.range, o);
      if (o.id === -1) { // no return: the ray is free to its full range
        const t = LIDAR.range; pts[n * 3] = P0[0] + dx * t; pts[n * 3 + 1] = P0[1] + dy * t; pts[n * 3 + 2] = P0[2] + dz * t; hit[n] = 0; pose[n] = pi; part[n] = -1; rng[n] = t; n++; continue;
      }
      const sl = smokeLen(opts.smoke, P0[0], P0[1], P0[2], dx, dy, dz, o.t);
      let pDrop = LIDAR.drop + (o.t > 10 ? (o.t - 10) * 0.2 : 0);
      if (sl > 0) pDrop = 1 - (1 - pDrop) * Math.exp(-LIDAR.smokeK * sl);
      if (r() < pDrop) continue;
      const t = Math.max(0.1, o.t + r.gauss() * (sl > 0.2 ? LIDAR.sigmaSmoke : LIDAR.sigma));
      pts[n * 3] = P0[0] + dx * t; pts[n * 3 + 1] = P0[1] + dy * t; pts[n * 3 + 2] = P0[2] + dz * t; hit[n] = 1; pose[n] = pi; part[n] = o.id; rng[n] = t; n++;
    }
    if (PERF() - t0 > 30) { t0 = PERF(); yield { p: pi / poses.length }; }
  }
  return { pts: pts.subarray(0, n * 3), hit: hit.subarray(0, n), pose: pose.subarray(0, n), part: part.subarray(0, n), range: rng.subarray(0, n), n, poses };
}
export function countHits(S) { let h = 0; for (let i = 0; i < S.n; i++) h += S.hit[i]; return h; }

// ------------------------------------------------------------------ the post-event flight log (behaviour as data)
// Poses are shared among the drones by region, each drone's route ordered nearest-first from the gate. Speed follows
// the clearance around each spot (tight spaces are flown slowly); stalls are logged where a drone could see a space
// but not fit into it, splits where the flock divided.
export function flightLog(model, truth, poses, stallIdx, seed, nDrones = 8) {
  const r = rngFor(seed, 'flight'); const { g, P } = truth;
  const clear = poses.map((q) => {
    let m = 1.5; const [x, y, z] = q.p;
    for (let a = 0; a < 26; a++) { const th = a * 2.399, ph = Math.acos(1 - 2 * (a + .5) / 26), dx = Math.sin(ph) * Math.cos(th), dy = Math.cos(ph), dz = Math.sin(ph) * Math.sin(th);
      for (let d = 0.1; d < m; d += 0.1) { const c = g.cell(x + dx * d, y + dy * d, z + dz * d); if (c < 0) break; const v = P[c]; if (v !== L_FREE) { m = d; break; } } }
    return m;
  });
  // k-means on the poses (deterministic start)
  const K = Math.min(nDrones, poses.length), cen = []; for (let k = 0; k < K; k++) cen.push(poses[Math.floor((k + .5) * poses.length / K)].p.slice());
  const asg = new Int32Array(poses.length);
  for (let it = 0; it < 12; it++) {
    poses.forEach((q, i) => { let b = 0, bd = 1e18; for (let k = 0; k < K; k++) { const d = (q.p[0] - cen[k][0]) ** 2 + 2 * (q.p[1] - cen[k][1]) ** 2 + (q.p[2] - cen[k][2]) ** 2; if (d < bd) { bd = d; b = k; } } asg[i] = b; });
    for (let k = 0; k < K; k++) { let sx = 0, sy = 0, sz = 0, n = 0; poses.forEach((q, i) => { if (asg[i] === k) { sx += q.p[0]; sy += q.p[1]; sz += q.p[2]; n++; } }); if (n) cen[k] = [sx / n, sy / n, sz / n]; }
  }
  const gate = [model.site.gate.x, 1.6, model.site.gate.z - 0.6];
  const drones = [];
  for (let k = 0; k < K; k++) {
    const mine = []; poses.forEach((q, i) => { if (asg[i] === k) mine.push(i); });
    const route = []; let cur = gate; const left = new Set(mine);
    while (left.size) { let b = -1, bd = 1e18; for (const i of left) { const q = poses[i].p; const d = (q[0] - cur[0]) ** 2 + 3 * (q[1] - cur[1]) ** 2 + (q[2] - cur[2]) ** 2; if (d < bd) { bd = d; b = i; } } route.push(b); left.delete(b); cur = poses[b].p; }
    drones.push({ id: k, route });
  }
  const speed = (c) => Math.max(0.2, Math.min(1.3, 0.25 + (c - 0.3) * 1.05));
  const legs = [];
  for (const d of drones) { let prev = null; for (const i of d.route) { if (prev != null) { const c = Math.min(clear[prev], clear[i]); legs.push({ a: prev, b: i, drone: d.id, clear: c, speed: speed(c) }); } prev = i; } }
  const stalls = stallIdx.map((i) => ({ pose: i, p: poses[i].p, gap: poses[i].gap, vol: poses[i].vol, drone: asg[i] }));
  // splits: where each drone's route peels off from the shared approach (its first stop)
  const splits = drones.filter((d) => d.route.length).map((d) => ({ drone: d.id, at: poses[d.route[0]].p }));
  let tSum = 0; for (const l of legs) { const a = poses[l.a].p, b = poses[l.b].p; tSum += Math.hypot(a[0] - b[0], a[1] - b[1], a[2] - b[2]) / l.speed + 6; }
  return { drones, legs, stalls, splits, clear, minutes: tSum / 60 / Math.max(1, K) };
}
