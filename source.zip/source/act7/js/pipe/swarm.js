// Swarm behaviour as data. The post-event flight log, replayed in time: eight drones leave the gate together and fly
// their share of the search (the routes of flightLog), steering toward the next stop with Vicsek alignment (each drone
// turns part of the way toward its neighbours' mean heading, with a little heading noise), slowing where the space is
// tight and hovering to scan at each stop. From the log:
//   phi_swarm: heading alignment of nearby drones (|mean of unit headings| over a drone and its neighbours within 4 m),
//     over time and over space; where it falls under 0.5 the drones were heading apart (two random headings give 0.64);
//   a small Koopman forecast: Hankel DMD on the swarm's mean speed (a 5 s average), refitted every 3 s on the last 60 s, 5 s ahead,
//     behind a rank gate (skipped when the window has no low-rank structure); scored against simply assuming the
//     speed stays as it is. Where it missed most is where the building surprised the swarm.
import { rngFor } from '../building/geom.js';
import { L_FREE } from '../building/truth.js';

const DT = 0.5, LOG = 1, R_NB = 4, W_ALIGN = 0.3, NOISE = 0.12, DWELL = 6, DWELL_STALL = 12;
const DIRS = []; for (const v of [[1, 0, 0], [-1, 0, 0], [0, 1, 0], [0, -1, 0], [0, 0, 1], [0, 0, -1], [1, 1, 0], [1, -1, 0], [-1, 1, 0], [-1, -1, 0], [1, 0, 1], [1, 0, -1], [-1, 0, 1], [-1, 0, -1], [0, 1, 1], [0, 1, -1], [0, -1, 1], [0, -1, -1]]) { const l = Math.hypot(...v); DIRS.push(v[0] / l, v[1] / l, v[2] / l); }
const speedOf = (c) => Math.max(0.2, Math.min(1.3, 0.25 + (c - 0.3) * 1.05));

// symmetric eigen-decomposition (cyclic Jacobi), small n; returns values (descending) and column vectors
function jacobi(A, n) {
  const a = Float64Array.from(A), v = new Float64Array(n * n); for (let i = 0; i < n; i++) v[i * n + i] = 1;
  for (let sweep = 0; sweep < 30; sweep++) {
    let off = 0, dia = 0; for (let p = 0; p < n; p++) { dia += a[p * n + p] * a[p * n + p]; for (let q = p + 1; q < n; q++) off += a[p * n + q] * a[p * n + q]; }
    if (off <= 1e-14 * dia + 1e-30) break;
    for (let p = 0; p < n; p++) for (let q = p + 1; q < n; q++) {
      const apq = a[p * n + q]; if (Math.abs(apq) < 1e-15) continue;
      const th = (a[q * n + q] - a[p * n + p]) / (2 * apq), t = Math.sign(th || 1) / (Math.abs(th) + Math.sqrt(th * th + 1)), c = 1 / Math.sqrt(t * t + 1), s = t * c;
      for (let k = 0; k < n; k++) { const akp = a[k * n + p], akq = a[k * n + q]; a[k * n + p] = c * akp - s * akq; a[k * n + q] = s * akp + c * akq; }
      for (let k = 0; k < n; k++) { const apk = a[p * n + k], aqk = a[q * n + k]; a[p * n + k] = c * apk - s * aqk; a[q * n + k] = s * apk + c * aqk; }
      for (let k = 0; k < n; k++) { const vkp = v[k * n + p], vkq = v[k * n + q]; v[k * n + p] = c * vkp - s * vkq; v[k * n + q] = s * vkp + c * vkq; }
    }
  }
  const ord = [...Array(n).keys()].sort((x, y) => a[y * n + y] - a[x * n + x]);
  return { vals: ord.map((i) => a[i * n + i]), vecs: ord.map((i) => Array.from({ length: n }, (_, k) => v[k * n + i])) };
}
// Hankel DMD forecast of a scalar window, h steps past its end; null when the rank gate says no
export function dmdForecast(win, d, h, { energy = 0.95, maxRank = 5 } = {}) {
  const W = win.length, mu = win.reduce((s, x) => s + x, 0) / W, y = win.map((x) => x - mu), m = W - d + 1;
  if (m < d + 2) return null;
  const G = new Float64Array(d * d), YX = new Float64Array(d * d);
  for (let j = 0; j < m - 1; j++) for (let a = 0; a < d; a++) { const xa = y[j + a], ya = y[j + 1 + a]; for (let b = 0; b < d; b++) { G[a * d + b] += xa * y[j + b]; YX[a * d + b] += ya * y[j + b]; } }
  const E = jacobi(G, d), tot = E.vals.reduce((s, x) => s + Math.max(0, x), 0);
  if (tot < 1e-6 * (m - 1)) return { value: mu, rank: 0 };                       // nothing moves: the mean is the forecast
  let r = 0, acc = 0; while (r < d && acc < energy * tot) { acc += Math.max(0, E.vals[r]); r++; }
  if (r > maxRank) return null;
  const U = E.vecs.slice(0, r), At = new Float64Array(r * r);
  for (let i = 0; i < r; i++) for (let k = 0; k < r; k++) { let s = 0; for (let a = 0; a < d; a++) { let t = 0; for (let b = 0; b < d; b++) t += YX[a * d + b] * U[k][b]; s += U[i][a] * t; } At[i * r + k] = s / Math.max(1e-12, E.vals[k]); }
  let st = U.map((u) => { let s = 0; for (let a = 0; a < d; a++) s += u[a] * y[m - 1 + a]; return s; });
  for (let it = 0; it < h; it++) st = Array.from({ length: r }, (_, i) => { let s = 0; for (let k = 0; k < r; k++) s += At[i * r + k] * st[k]; return s; });
  let z = 0; for (let k = 0; k < r; k++) z += U[k][d - 1] * st[k];
  return { value: mu + z, rank: r };
}

export function swarmLog(model, truth, poses, flight, seed) {
  const r = rngFor(seed, 'swarmlog'); const { g, P } = truth, RF = (truth.reachFly || truth.reach).centre;
  // where a drone's centre can be (the replayed search's own test), on a 0.36 m lattice for path finding
  const CS = 3, cx = Math.ceil(g.nx / CS), cy = Math.ceil(g.ny / CS), cz = Math.ceil(g.nz / CS), CN = cx * cy * cz, cv = g.vox * CS;
  const cpassA = new Int8Array(CN).fill(-1);
  const cpass = (c) => { let v = cpassA[c]; if (v >= 0) return v; const i = c % cx, rr = (c - i) / cx, k = rr % cz, j = (rr - k) / cz; v = 0;
    for (let q = 0; q < 8 && !v; q++) { const fi = Math.min(g.nx - 1, i * CS + (q & 1 ? 2 : 0)), fj = Math.min(g.ny - 1, j * CS + (q & 2 ? 2 : 0)), fk = Math.min(g.nz - 1, k * CS + (q & 4 ? 2 : 0)); if (RF[fi + g.nx * (fk + g.nz * fj)]) v = 1; }
    cpassA[c] = v; return v; };
  const ccell = (x, y, z) => { const i = Math.floor((x - g.x0) / cv), j = Math.floor((y - g.y0) / cv), k = Math.floor((z - g.z0) / cv); return i < 0 || j < 0 || k < 0 || i >= cx || j >= cy || k >= cz ? -1 : i + cx * (k + cz * j); };
  const ccen = (c) => { const i = c % cx, rr = (c - i) / cx, k = rr % cz, j = (rr - k) / cz; return [g.x0 + (i + .5) * cv, g.y0 + (j + .5) * cv, g.z0 + (k + .5) * cv]; };
  const fine = (x, y, z) => { const c = g.cell(x, y, z); return c >= 0 && RF[c]; };
  const clearLine = (a, b) => { const L = Math.hypot(b[0] - a[0], b[1] - a[1], b[2] - a[2]), n = Math.max(1, Math.ceil(L / 0.12)); for (let s = 1; s < n; s++) { const t = s / n; if (!fine(a[0] + (b[0] - a[0]) * t, a[1] + (b[1] - a[1]) * t, a[2] + (b[2] - a[2]) * t)) return false; } return true; };
  // clearance around a point (18 rays through the truth: the 6 axes and 12 edge diagonals, up to 1.5 m), cached per lattice cell
  const clr = new Map();
  const clearance = (x, y, z) => {
    const key = ccell(x, y, z); if (key >= 0 && clr.has(key)) return clr.get(key);
    let m = 1.5;
    for (let a = 0; a < DIRS.length; a += 3) { const dx = DIRS[a], dy = DIRS[a + 1], dz = DIRS[a + 2];
      for (let d = 0.12; d < m; d += 0.12) { const c = g.cell(x + dx * d, y + dy * d, z + dz * d); if (c < 0) break; if (P[c] !== L_FREE) { m = d; break; } } }
    if (key >= 0) clr.set(key, m); return m;
  };
  // A* on the lattice (26 neighbours) for legs whose straight line is blocked
  const gS = new Float32Array(CN), from = new Int32Array(CN), stamp = new Int32Array(CN); let stampN = 0;
  const NB = []; for (let dj = -1; dj <= 1; dj++) for (let dk = -1; dk <= 1; dk++) for (let di = -1; di <= 1; di++) if (di || dj || dk) NB.push([di + cx * (dk + cz * dj), Math.hypot(di, dj, dk), di, dj, dk]);
  const AST = { n: 0, exp: 0, fail: 0, early: 0 };
  let hk = new Float32Array(4096), hv = new Int32Array(4096), hn = 0;
  const hpush = (f, c) => { if (hn === hk.length) { const k2 = new Float32Array(hn * 2), v2 = new Int32Array(hn * 2); k2.set(hk); v2.set(hv); hk = k2; hv = v2; } let i = hn++; while (i > 0) { const q = (i - 1) >> 1; if (hk[q] <= f) break; hk[i] = hk[q]; hv[i] = hv[q]; i = q; } hk[i] = f; hv[i] = c; };
  const hpop = () => { const top = hv[0]; const f = hk[--hn], c = hv[hn]; let i = 0; for (;;) { const l = 2 * i + 1; if (l >= hn) break; const m = l + 1 < hn && hk[l + 1] < hk[l] ? l + 1 : l; if (hk[m] >= f) break; hk[i] = hk[m]; hv[i] = hv[m]; i = m; } hk[i] = f; hv[i] = c; return top; };
  const snap = (p) => { const c = ccell(...p); if (c < 0) return -1; if (cpass(c)) return c; const i = c % cx, rr = (c - i) / cx, k = rr % cz, j = (rr - k) / cz; for (const [o, , di, dj, dk] of NB) { const ii = i + di, jj = j + dj, kk = k + dk; if (ii < 0 || jj < 0 || kk < 0 || ii >= cx || jj >= cy || kk >= cz) continue; if (cpass(c + o)) return c + o; } return -1; };
  function astar(a, b) {
    const s = snap(a), t = snap(b); if (s < 0 || t < 0) { AST.early++; return null; }
    stampN++; hn = 0; const tc = ccen(t), ti = t % cx, tr = (t - ti) / cx, tk = tr % cz, tj = (tr - tk) / cz;
    stamp[s] = stampN; gS[s] = 0; from[s] = -1; hpush(0, s); let exp = 0;
    while (hn && exp < 2500) {
      const c = hpop(); exp++; if (c === t) break;
      const i = c % cx, rr = (c - i) / cx, k = rr % cz, j = (rr - k) / cz;
      for (let q8 = 0; q8 < NB.length; q8++) { const nb = NB[q8], ii = i + nb[2], jj = j + nb[3], kk = k + nb[4]; if (ii < 0 || jj < 0 || kk < 0 || ii >= cx || jj >= cy || kk >= cz) continue; const q = c + nb[0]; if (!cpass(q)) continue; const ng = gS[c] + nb[1]; if (stamp[q] === stampN && ng >= gS[q]) continue; stamp[q] = stampN; gS[q] = ng; from[q] = c; hpush(ng + 1.5 * Math.hypot(ii - ti, jj - tj, kk - tk), q); }
    }
    AST.n++; AST.exp += exp; if (stamp[t] !== stampN) { AST.fail++; return null; }
    const path = []; for (let c = t; c >= 0; c = from[c]) path.push(ccen(c)); path.reverse();
    // string-pull (greedy, forward): skip ahead while the straight line stays clear
    const out = [a]; let k0 = 0; const pts = [a, ...path.slice(1, -1), b];
    while (k0 < pts.length - 1) { let k1 = k0 + 1; while (k1 + 1 < pts.length && clearLine(pts[k0], pts[k1 + 1])) k1++; out.push(pts[k1]); k0 = k1; }
    return out;
  }
  // ------------------------------------------------------------------ the replay
  const gate = [model.site.gate.x, 1.6, model.site.gate.z - 0.6], stallSet = new Set(flight.stalls.map((s) => s.pose));
  const D = flight.drones.map((d, i) => ({ id: d.id, stops: d.route.slice(), si: -1, path: null, pi: 0, x: [gate[0] + (i % 3 - 1) * 0.6, gate[1] + Math.floor(i / 3) * 0.4, gate[2]], u: [0, 0, -1], v: 0, dwell: 0, launch: i * 2, done: false, moving: false, stall: false }));
  let legsBlocked = 0, legsTotal = 0;
  const nextLeg = (d) => {
    d.si++; if (d.si >= d.stops.length) { d.done = true; d.path = null; return; }
    const tgt = poses[d.stops[d.si]].p; legsTotal++;
    if (clearLine(d.x, tgt)) d.path = [tgt];
    else { legsBlocked++; const pth = astar(d.x, tgt); d.path = pth ? pth.slice(1) : [tgt]; }
    d.pi = 0;
  };
  const Tmax = 3600, NL = Math.ceil(Tmax / LOG), nD = D.length;
  const lx = new Float32Array(NL * nD * 3), lv = new Float32Array(NL * nD), lu = new Float32Array(NL * nD * 3), lm = new Uint8Array(NL * nD);
  let t = 0, li = 0;
  for (; t < Tmax; t += DT) {
    let alive = 0;
    for (const d of D) {
      d.moving = false; if (d.done || t < d.launch) { d.v = 0; if (!d.done) alive++; continue; } alive++;
      if (d.dwell > 0) { d.dwell -= DT; d.v = 0; if (d.stall) { const a = (r() - .5) * 2.4, ux = d.u[0], uz = d.u[2]; d.u[0] = Math.cos(a) * ux - Math.sin(a) * uz; d.u[1] = 0; d.u[2] = Math.sin(a) * ux + Math.cos(a) * uz; } continue; }
      if (!d.path) nextLeg(d); if (d.done) continue;
      const wp = d.path[d.pi]; let dx = wp[0] - d.x[0], dy = wp[1] - d.x[1], dz = wp[2] - d.x[2]; const dl = Math.hypot(dx, dy, dz);
      const last = d.pi === d.path.length - 1;
      if (dl < (last ? 0.3 : 0.4)) { if (last) { d.path = null; d.stall = stallSet.has(d.stops[d.si]); d.dwell = d.stall ? DWELL_STALL : DWELL; } else d.pi++; continue; }
      dx /= dl; dy /= dl; dz /= dl;
      // Vicsek: part of the way toward the neighbours' mean heading, plus a little heading noise
      let mx = 0, my = 0, mz = 0, nn = 0;
      for (const e of D) { if (e === d || !e.moving && e.v === 0) continue; const q = Math.hypot(e.x[0] - d.x[0], e.x[1] - d.x[1], e.x[2] - d.x[2]); if (q < R_NB) { mx += e.u[0]; my += e.u[1]; mz += e.u[2]; nn++; } }
      let hx = dx, hy = dy, hz = dz;
      if (nn) { const ml = Math.hypot(mx, my, mz) || 1; hx = (1 - W_ALIGN) * dx + W_ALIGN * mx / ml; hy = (1 - W_ALIGN) * dy + W_ALIGN * my / ml; hz = (1 - W_ALIGN) * dz + W_ALIGN * mz / ml; }
      const a = (r() - .5) * 2 * NOISE, ca = Math.cos(a), sa = Math.sin(a); const tx = ca * hx - sa * hz, tz = sa * hx + ca * hz; hx = tx; hz = tz;
      const hl = Math.hypot(hx, hy, hz) || 1; hx /= hl; hy /= hl; hz /= hl;
      const v = speedOf(clearance(d.x[0], d.x[1], d.x[2])), step = Math.min(dl, v * DT);
      let nx = d.x[0] + hx * step, ny = d.x[1] + hy * step, nz = d.x[2] + hz * step;
      if (!fine(nx, ny, nz)) { hx = dx; hy = dy; hz = dz; nx = d.x[0] + dx * step; ny = d.x[1] + dy * step; nz = d.x[2] + dz * step; }
      d.x[0] = nx; d.x[1] = ny; d.x[2] = nz; d.u[0] = hx; d.u[1] = hy; d.u[2] = hz; d.v = v; d.moving = true;
    }
    if (Math.abs(t / LOG - Math.round(t / LOG)) < 1e-6) {
      for (let k = 0; k < nD; k++) { const d = D[k], o = li * nD + k; lx[o * 3] = d.x[0]; lx[o * 3 + 1] = d.x[1]; lx[o * 3 + 2] = d.x[2]; lu[o * 3] = d.u[0]; lu[o * 3 + 1] = d.u[1]; lu[o * 3 + 2] = d.u[2]; lv[o] = d.moving ? d.v : 0; lm[o] = d.done || t < d.launch ? 0 : d.moving ? 1 : d.stall && d.dwell > 0 ? 3 : 2; }
      li++;
    }
    if (!alive && t > 30) break;
  }
  const n = li;
  // ------------------------------------------------------------------ phi_swarm over time and space
  const phiT = new Float32Array(n).fill(NaN), phiI = new Float32Array(n * nD).fill(NaN), samples = [];
  for (let s = 0; s < n; s++) {
    let sum = 0, cnt = 0;
    for (let i = 0; i < nD; i++) {
      const oi = s * nD + i; if (lm[oi] !== 1 && lm[oi] !== 3) continue;
      let ux = lu[oi * 3], uy = lu[oi * 3 + 1], uz = lu[oi * 3 + 2], m = 1;
      for (let j = 0; j < nD; j++) { if (j === i) continue; const oj = s * nD + j; if (lm[oj] !== 1 && lm[oj] !== 3) continue; const q = Math.hypot(lx[oj * 3] - lx[oi * 3], lx[oj * 3 + 1] - lx[oi * 3 + 1], lx[oj * 3 + 2] - lx[oi * 3 + 2]); if (q < R_NB) { ux += lu[oj * 3]; uy += lu[oj * 3 + 1]; uz += lu[oj * 3 + 2]; m++; } }
      if (m < 2) continue;
      const phi = Math.hypot(ux, uy, uz) / m; sum += phi; cnt++; phiI[oi] = phi; samples.push([s, lx[oi * 3], lx[oi * 3 + 1], lx[oi * 3 + 2], phi]);
    }
    if (cnt) phiT[s] = sum / cnt;
  }
  const BIN = 1.5, bins = new Map();
  for (const [s, x, y, z, phi] of samples) { const k = `${Math.floor(x / BIN)},${Math.floor(y / 3)},${Math.floor(z / BIN)}`; let b = bins.get(k); if (!b) { b = { n: 0, phi: 0, x: 0, y: 0, z: 0, t: s }; bins.set(k, b); } b.n++; b.phi += phi; b.x += x; b.y += y; b.z += z; }
  const cells = [...bins.values()].filter((b) => b.n >= 3).map((b) => ({ p: [b.x / b.n, b.y / b.n, b.z / b.n], phi: b.phi / b.n, n: b.n, t: b.t }));
  const drops = []; for (const c of cells.filter((q) => q.phi < 0.5).sort((a, b) => a.phi - b.phi)) { if (drops.length >= 5) break; if (drops.some((q) => Math.hypot(q.p[0] - c.p[0], q.p[1] - c.p[1], q.p[2] - c.p[2]) < 2)) continue; drops.push(c); }
  const allPhi = samples.map((q) => q[4]).sort((a, b) => a - b), med = (a) => (a.length ? a[Math.floor(a.length / 2)] : NaN);
  // ------------------------------------------------------------------ the swarm's mean speed and its forecast
  // the fleet's mean speed (all eight drones, a hovering, landed or not yet launched drone counts as zero)
  const spd = new Float32Array(n); for (let s = 0; s < n; s++) { let sm = 0; for (let k = 0; k < nD; k++) sm += lv[s * nD + k]; spd[s] = sm / nD; }
  // the observable: the swarm's mean speed averaged over the last 5 s (single drones' stops are noise to a swarm forecast)
  const obs = new Float32Array(n); { let acc = 0; for (let s = 0; s < n; s++) { acc += spd[s]; if (s >= 5) acc -= spd[s - 5]; obs[s] = acc / Math.min(5, s + 1); } }
  const FW = 60, FD = 10, FH = 5, FSTEP = 3, fc = new Float32Array(n).fill(NaN), errs = [];
  let made = 0, skipped = 0, seD = 0, seP = 0;
  for (let s = Math.max(FW, 20 + FW); s + FH - 1 < n; s += FSTEP) {
    const win = Array.from(obs.subarray(s - FW, s)); const f = dmdForecast(win, FD, FH);
    if (!f) { skipped++; continue; }
    const at = s - 1 + FH, val = Math.max(0, Math.min(1.4, f.value)); fc[at] = val; made++;
    const e = val - obs[at], ep = obs[s - 1] - obs[at]; seD += e * e; seP += ep * ep; errs.push([at, Math.abs(e)]);
  }
  const rmseD = made ? Math.sqrt(seD / made) : NaN, rmseP = made ? Math.sqrt(seP / made) : NaN, skill = made && rmseP > 1e-9 ? 1 - rmseD / rmseP : NaN;
  // where it missed most: the biggest errors (25 s apart), each placed at the drone whose speed changed most then
  // (a drone in flight or probing a gap; a scheduled stop to scan is not a surprise)
  const eMed = med(errs.map((q) => q[1]).sort((a, b) => a - b)), misses = [];
  for (const [at, e] of errs.slice().sort((a, b) => b[1] - a[1])) {
    if (misses.length >= 4 || e < 2 * eMed || e < 0.05) break; if (misses.some((q) => Math.abs(q.t - at) < 25)) continue;
    let bk = -1, bd = -1; for (let pass = 0; pass < 2 && bk < 0; pass++) for (let k = 0; k < nD; k++) { const o = at * nD + k, o0 = (at - FH) * nD + k; if (!lm[o]) continue; if (!pass && (lm[o] === 2 || lm[o0] === 2)) continue; const dv = Math.abs(lv[o] - lv[o0]); if (dv > bd) { bd = dv; bk = k; } }
    if (bk < 0) continue; const o = at * nD + bk; misses.push({ t: at, err: e, drone: bk, p: [lx[o * 3], lx[o * 3 + 1], lx[o * 3 + 2]], dv: bd });
  }
  return {
    dt: LOG, n, nD, pos: lx.subarray(0, n * nD * 3), speed: lv.subarray(0, n * nD), mode: lm.subarray(0, n * nD),
    phiT, phiI, phiMedian: med(allPhi), phiLow: drops.length ? drops[0].phi : null, phiShareLow: allPhi.length ? allPhi.filter((x) => x < 0.5).length / allPhi.length : 0, phiSamples: allPhi.length, cells, drops,
    spd, obs, forecast: { values: fc, made, skipped, rmse: rmseD, rmsePersist: rmseP, skill, window: FW, delay: FD, ahead: FH, misses },
    legs: { total: legsTotal, routed: legsBlocked, ast: AST }, minutes: n * LOG / 60,
  };
}
