// Occupancy by ray carving (OctoMap-style counts on the voxel grid): every registered ray marks the voxels it passed
// through as seen free and its end voxel as hit. A voxel is occupied when hits outweigh passes, free when it was
// passed and never (or rarely) hit, unknown otherwise. Small unseen holes inside free space (gaps between beams) are
// closed, keeping a one-voxel buffer around every hit so no wall is ever opened up.
import { tApply } from '../building/geom.js';
import { erode, dilate } from '../building/voxel.js';

export const O_UNK = 0, O_FREE = 1, O_OCC = 2;
const PERF = () => (typeof performance !== 'undefined' ? performance.now() : Date.now());

export function makeObs(g) { return { pass: new Uint8Array(g.N), hits: new Uint8Array(g.N), rmin: new Uint8Array(g.N).fill(255), rays: 0 }; }

// carve rays: origins = registered sensor positions per pose, ends = registered end points; hit[i] = 1 for returns
export function* carve(g, O, scanOut, T, opts = {}) {
  const { pts, hit, pose, n, poses } = scanOut;
  const org = poses.map((q) => tApply(T, ...(q.raw || q.p)));
  const { x0, y0, z0, nx, ny, nz, vox } = g, SY = nx * nz;
  const pass = O.pass, hits = O.hits, rmin = O.rmin; const e = [0, 0, 0]; let t0 = PERF();
  for (let i = 0; i < n; i++) {
    const o = org[pose[i]]; tApply(T, pts[i * 3], pts[i * 3 + 1], pts[i * 3 + 2], e);
    let ox = o[0], oy = o[1], oz = o[2]; const dx = e[0] - ox, dy = e[1] - oy, dz = e[2] - oz, L = Math.hypot(dx, dy, dz); if (L < 1e-4) continue;
    const ux = dx / L, uy = dy / L, uz = dz / L;
    // clip the segment to the grid
    let ta = 0, tb = L;
    const cl = (o1, u, lo, hi) => { if (Math.abs(u) < 1e-12) return o1 >= lo && o1 <= hi; let t1 = (lo - o1) / u, t2 = (hi - o1) / u; if (t1 > t2) { const t = t1; t1 = t2; t2 = t; } if (t1 > ta) ta = t1; if (t2 < tb) tb = t2; return ta <= tb; };
    if (!cl(ox, ux, x0, x0 + nx * vox) || !cl(oy, uy, y0, y0 + ny * vox) || !cl(oz, uz, z0, z0 + nz * vox)) continue;
    const endIn = tb >= L - 1e-9;
    const sx = ox + ux * (ta + 1e-6), sy = oy + uy * (ta + 1e-6), sz = oz + uz * (ta + 1e-6);
    let ci = Math.min(nx - 1, Math.max(0, Math.floor((sx - x0) / vox))), cj = Math.min(ny - 1, Math.max(0, Math.floor((sy - y0) / vox))), ck = Math.min(nz - 1, Math.max(0, Math.floor((sz - z0) / vox)));
    const ei = Math.floor((e[0] - x0) / vox), ej = Math.floor((e[1] - y0) / vox), ek = Math.floor((e[2] - z0) / vox);
    const stI = ux > 0 ? 1 : -1, stJ = uy > 0 ? 1 : -1, stK = uz > 0 ? 1 : -1;
    const tdI = Math.abs(ux) > 1e-12 ? vox / Math.abs(ux) : Infinity, tdJ = Math.abs(uy) > 1e-12 ? vox / Math.abs(uy) : Infinity, tdK = Math.abs(uz) > 1e-12 ? vox / Math.abs(uz) : Infinity;
    let tmI = Math.abs(ux) > 1e-12 ? ((x0 + (ci + (ux > 0 ? 1 : 0)) * vox) - ox) / ux : Infinity;
    let tmJ = Math.abs(uy) > 1e-12 ? ((y0 + (cj + (uy > 0 ? 1 : 0)) * vox) - oy) / uy : Infinity;
    let tmK = Math.abs(uz) > 1e-12 ? ((z0 + (ck + (uz > 0 ? 1 : 0)) * vox) - oz) / uz : Infinity;
    const isHit = hit[i] === 1;
    for (let guard = 0; guard < 4000; guard++) {
      const c = ci + nx * ck + SY * cj;
      if (ci === ei && cj === ej && ck === ek) {
        if (isHit) { if (hits[c] < 255) hits[c]++; const rq = Math.min(254, Math.round(L / 0.05)); if (rq < rmin[c]) rmin[c] = rq; }
        else if (pass[c] < 255) pass[c]++;
        break;
      }
      if (pass[c] < 255) pass[c]++;
      if (tmI <= tmJ && tmI <= tmK) { if (tmI > tb) break; ci += stI; if (ci < 0 || ci >= nx) break; tmI += tdI; }
      else if (tmJ <= tmK) { if (tmJ > tb) break; cj += stJ; if (cj < 0 || cj >= ny) break; tmJ += tdJ; }
      else { if (tmK > tb) break; ck += stK; if (ck < 0 || ck >= nz) break; tmK += tdK; }
    }
    if (!endIn) { /* the end lies outside the grid: everything inside was passed */ }
    O.rays++;
    if ((i & 4095) === 0 && PERF() - t0 > 30) { t0 = PERF(); yield { p: i / n }; }
  }
  return O;
}

// classify: 0 unknown, 1 free, 2 occupied
export function classify(g, O, { close = true } = {}) {
  const S = new Uint8Array(g.N); const { pass, hits } = O;
  // a voxel that returned light is a surface even if other rays grazed through its corner
  for (let c = 0; c < g.N; c++) { const h = hits[c], p = pass[c]; if (h && h * 4 >= p) S[c] = O_OCC; else if (p) S[c] = O_FREE; }
  if (close) {
    // close one-voxel holes in free space, away from anything hit
    const free = new Uint8Array(g.N), occ = new Uint8Array(g.N);
    for (let c = 0; c < g.N; c++) { free[c] = S[c] === O_FREE ? 1 : 0; occ[c] = S[c] === O_OCC ? 1 : 0; }
    const occD = dilate(g, occ, 1, 1, 1, 0);
    const cl = erode(g, dilate(g, free, 1, 1, 1, 0), 1, 1, 1, 1);
    let added = 0; for (let c = 0; c < g.N; c++) if (!S[c] && cl[c] && !occD[c]) { S[c] = O_FREE; added++; }
    S.closed = added;
  }
  return S;
}
