// The scorecard: the deck's own metrics, computed against the known ground truth of the simulated collapse.
//   landing to first change map (< 10 min) | debris volume error (< 20 %) | change-map IoU (> 0.7) |
//   false-safe rooms (rooms drafted safe that are truly damaged; < 1 %, the headline) | search certified (>= 95 %)
// plus what the sweep reports: pockets found against true voids, registration error, wall-tilt error.
import { C_SAME, C_MOVED, C_DEBRIS, C_FILL, C_GONE } from './change.js';
import { O_FREE } from './occupancy.js';

export const TARGETS = { minutes: 10, debris: 0.2, iou: 0.7, falseSafe: 0.01, certified: 0.95 };

// the ground-station clock: offloading the drones over local Wi-Fi, then the processing, scaled from the time this
// browser took on the simulated clouds to full-resolution clouds on the ground-station laptop
export function stationClock(drones, compute) {
  const offload = 95 + drones * 14;                     // s: maps, clouds, video, logs (~0.7 GB per drone at ~50 MB/s)
  const scale = 45;                                     // full-resolution clouds are ~45x the points simulated here
  const process = Math.min(300, Math.max(60, (compute.register + compute.carve + compute.change) / 1000 * scale));
  return { offload, register: offload + Math.min(150, Math.max(25, compute.register / 1000 * scale)), changeMap: offload + process, total: offload + process };
}
export function score(C, T) {
  const g = T.g; const L = C.change.labels;
  // the overlap, and the same over the space a sensor saw (observed free or occupied), and the share of what truly changed
  // that lies in space nobody saw (inside walls, slabs and the pile)
  let I = 0, U = 0, A = 0, F = 0, Iv = 0, Uv = 0, Ah = 0; const Sx = C.S, Al = T.altered;
  for (let k = 0; k < g.N; k++) { const a = Al[k] > 0, f = L[k] >= C_MOVED; if (!a && !f) continue; if (a) A++; if (f) F++; if (a && f) I++; U++;
    if (Sx[k] === 0) { if (a) Ah++; } else { if (a && f) Iv++; Uv++; } }
  const iou = U ? I / U : 1;
  const iouSeen = Uv ? Iv / Uv : 1, hiddenShare = A ? Ah / A : 0;
  // search certified: the share of the truly reachable free space (inside the search area) that the scans observed
  // (seen free, or holding a return: a voxel whose corner holds a wall face was seen even though it is not empty)
  const ar = T.area, p = [0, 0, 0]; let nR = 0, nO = 0;
  for (let k = 0; k < g.N; k++) { if (!T.reach.body[k]) continue; g.centre(k, p); if (p[0] < ar.x0 || p[0] > ar.x1 || p[2] < ar.z0 || p[2] > ar.z1 || p[1] > ar.y1) continue; nR++; if (C.S[k] !== 0) nO++; }
  // rooms
  const conf = { safe: { safe: 0, caution: 0, noentry: 0 }, caution: { safe: 0, caution: 0, noentry: 0 }, noentry: { safe: 0, caution: 0, noentry: 0 }, unseen: { safe: 0, caution: 0, noentry: 0 } };
  let falseSafe = 0, draftedSafe = 0, overCautious = 0; const fsRooms = [];
  C.rooms.forEach((d, i) => { const t = T.rooms[i]; conf[d.status][t.status]++; if (d.status === 'safe') { draftedSafe++; if (t.status !== 'safe') { falseSafe++; fsRooms.push(i); } } else if (t.status === 'safe') overCautious++; });
  // pockets against true voids (a void is found if a pocket overlaps it or sits within 0.8 m of it)
  const cellOwner = new Map(); T.voids.forEach((v, vi) => { for (const c of v.cells) cellOwner.set(c, vi); });
  // two tiers, scored separately: pockets seen through a gap (observed) and possible pockets under a slab (inferred)
  const found = new Set(), foundGap = new Set(); let falsePk = 0; const tier = { gap: { n: 0, false: 0 }, slab: { n: 0, false: 0 } };
  for (const pk of C.pockets.list) {
    let hit = -1; for (const c of pk.cells) { const o = cellOwner.get(c); if (o != null) { hit = o; break; } }
    if (hit < 0) for (let vi = 0; vi < T.voids.length; vi++) { const v = T.voids[vi]; if (Math.hypot(v.centre[0] - pk.centre[0], v.centre[1] - pk.centre[1], v.centre[2] - pk.centre[2]) < Math.max(0.8, Math.cbrt(v.vol))) { hit = vi; break; } }
    const t = tier[pk.kind] || tier.gap; t.n++;
    if (hit >= 0) { found.add(hit); if (pk.kind === 'gap') foundGap.add(hit); pk.truth = hit; } else { falsePk++; t.false++; pk.truth = -1; }
  }
  // wall tilt error over walls measured in both
  let te = 0, tn = 0; for (const w of C.condition.walls) if (w.ok && w.tilt != null) { te += Math.abs(w.tilt - w.truthTilt); tn++; }
  const dv = C.debris;
  return {
    minutes: C.clock.changeMap / 60, debrisErr: Math.abs(dv.estimate - T.debrisVolume) / Math.max(0.1, T.debrisVolume), debrisMidErr: Math.abs(dv.mid - T.debrisVolume) / Math.max(0.1, T.debrisVolume),
    debrisTruth: T.debrisVolume, debrisInRange: T.debrisVolume >= dv.low - 1e-6 && T.debrisVolume <= dv.high + 1e-6,
    iou, iouSeen, hiddenShare, precision: F ? I / F : 1, recall: A ? I / A : 1, alteredM3: A * g.V3, flaggedM3: F * g.V3,
    falseSafe, falseSafeRate: falseSafe / C.rooms.length, draftedSafe, overCautious, fsRooms, confusion: conf,
    certified: nR ? nO / nR : 1, reachableM3: nR * g.V3,
    voids: T.voids.length, voidsFound: found.size, voidsFoundGap: foundGap.size, falsePockets: falsePk, pockets: C.pockets.list.length, pocketTiers: tier,
    regCm: C.reg.err.cm, regDeg: C.reg.err.deg, wallTiltErr: tn ? te / tn : 0, wallsMeasured: tn,
    truthStatus: T.rooms.map((t) => t.status),
  };
}
