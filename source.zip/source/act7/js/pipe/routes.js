// The access graph, per floor: free space in the 0.3-2.0 m band above the floor (in the storey's own, fitted frame),
// shrunk by a person's half width (0.3 m), skeletonised (Zhang-Suen) into a path network whose edges carry their
// clearance. The baseline graph against the post-event graph gives the routes that were cut and the new bottlenecks
// (under 0.8 m wide); a shortest path runs from the street door (or the stair landing) to every room still reachable.
// beta_1 counts the independent loops (alternative routes). Act 8 decides entry routes; Act 7 only measures.
import { tApply } from '../building/geom.js';
import { NS, floorTop } from '../building/building.js';
import { L_FREE } from '../building/truth.js';
import { O_FREE, O_OCC } from './occupancy.js';

// squared Euclidean distance transform (Felzenszwalb-Huttenlocher), in cells, of "blocked" (1) pixels
function edt2(block, nx, nz) {
  const INF = 1e12, f = new Float64Array(Math.max(nx, nz)), d = new Float64Array(Math.max(nx, nz)), v = new Int32Array(Math.max(nx, nz)), z = new Float64Array(Math.max(nx, nz) + 1);
  const D = new Float64Array(nx * nz);
  const pass = (n, get, set) => { for (let q = 0; q < n; q++) f[q] = get(q); let k = 0; v[0] = 0; z[0] = -INF; z[1] = INF;
    for (let q = 1; q < n; q++) { let s = ((f[q] + q * q) - (f[v[k]] + v[k] * v[k])) / (2 * q - 2 * v[k]); while (s <= z[k]) { k--; s = ((f[q] + q * q) - (f[v[k]] + v[k] * v[k])) / (2 * q - 2 * v[k]); } k++; v[k] = q; z[k] = s; z[k + 1] = INF; }
    k = 0; for (let q = 0; q < n; q++) { while (z[k + 1] < q) k++; d[q] = (q - v[k]) * (q - v[k]) + f[v[k]]; set(q, d[q]); } };
  for (let b = 0; b < nz; b++) pass(nx, (q) => (block[b * nx + q] ? 0 : INF), (q, val) => { D[b * nx + q] = val; });
  for (let a = 0; a < nx; a++) pass(nz, (q) => D[q * nx + a], (q, val) => { D[q * nx + a] = val; });
  return D;
}
// Zhang-Suen thinning of a binary image (1 = foreground)
function thin(img, nx, nz) {
  const I = img.slice(); let changed = true; const del = [];
  const at = (a, b) => (a < 0 || b < 0 || a >= nx || b >= nz ? 0 : I[b * nx + a]);
  while (changed) {
    changed = false;
    for (let step = 0; step < 2; step++) {
      del.length = 0;
      for (let b = 0; b < nz; b++) for (let a = 0; a < nx; a++) {
        if (!I[b * nx + a]) continue;
        const p2 = at(a, b - 1), p3 = at(a + 1, b - 1), p4 = at(a + 1, b), p5 = at(a + 1, b + 1), p6 = at(a, b + 1), p7 = at(a - 1, b + 1), p8 = at(a - 1, b), p9 = at(a - 1, b - 1);
        const B = p2 + p3 + p4 + p5 + p6 + p7 + p8 + p9; if (B < 2 || B > 6) continue;
        const A = (!p2 && p3) + (!p3 && p4) + (!p4 && p5) + (!p5 && p6) + (!p6 && p7) + (!p7 && p8) + (!p8 && p9) + (!p9 && p2); if (A !== 1) continue;
        if (step === 0 ? (p2 * p4 * p6 || p4 * p6 * p8) : (p2 * p4 * p8 || p2 * p6 * p8)) continue;
        del.push(b * nx + a);
      }
      if (del.length) { changed = true; for (const k of del) I[k] = 0; }
    }
  }
  return I;
}
const N8 = [[1, 0], [1, 1], [0, 1], [-1, 1], [-1, 0], [-1, -1], [0, -1], [1, -1]];
// skeleton pixels -> graph edges (pixel paths between endpoints/junctions) with their minimum clearance
function graphOf(sk, clr, nx, nz) {
  const deg = (k) => { const a = k % nx, b = (k - a) / nx; let n = 0; for (const [da, db] of N8) { const x = a + da, y = b + db; if (x >= 0 && y >= 0 && x < nx && y < nz && sk[y * nx + x]) n++; } return n; };
  const nodes = new Set(); let V = 0;
  for (let k = 0; k < nx * nz; k++) if (sk[k]) { V++; const d = deg(k); if (d !== 2) nodes.add(k); }
  const seenE = new Set(), edges = [];
  const nbrs = (k) => { const a = k % nx, b = (k - a) / nx, o = []; for (const [da, db] of N8) { const x = a + da, y = b + db; if (x >= 0 && y >= 0 && x < nx && y < nz && sk[y * nx + x]) o.push(y * nx + x); } return o; };
  const walk = (start, first) => { const path = [start, first]; let prev = start, cur = first; let guard = 0; while (!nodes.has(cur) && guard++ < 5000) { const nx2 = nbrs(cur).filter((q) => q !== prev && !(path.length > 2 && q === path[path.length - 3])); if (!nx2.length) break; prev = cur; cur = nx2[0]; path.push(cur); if (cur === start) break; } return path; };
  for (const s of nodes) for (const f of nbrs(s)) { const key = s < f ? s + ':' + f : f + ':' + s; if (seenE.has(key)) continue; const p = walk(s, f); const e = p[p.length - 1]; const k2 = p[p.length - 2]; seenE.add(key); seenE.add(e < k2 ? e + ':' + k2 : k2 + ':' + e); let m = 1e9; for (const q of p) m = Math.min(m, clr[q]); edges.push({ path: p, clear: m }); }
  // loops with no node at all (a ring): one edge each
  // components of the skeleton
  const lab = new Int32Array(nx * nz); let C = 0;
  for (let k = 0; k < nx * nz; k++) { if (!sk[k] || lab[k]) continue; C++; const st = [k]; lab[k] = C; while (st.length) { const q = st.pop(); for (const r of nbrs(q)) if (!lab[r]) { lab[r] = C; st.push(r); } } }
  // beta_1 of the pixel graph (8-connected): E - V + C, with E counted over unique pixel adjacencies
  let E = 0; for (let k = 0; k < nx * nz; k++) if (sk[k]) { const a = k % nx, b = (k - a) / nx; for (const [da, db] of [[1, 0], [0, 1], [1, 1], [-1, 1]]) { const x = a + da, y = b + db; if (x >= 0 && y >= 0 && x < nx && y < nz && sk[y * nx + x]) { if (da !== 0 && db !== 0 && (sk[b * nx + x] || sk[y * nx + a])) continue; E++; } } }
  return { edges, beta1: Math.max(0, E - V + C), V, C };
}
function simplify(pts, eps) {
  if (pts.length < 3) return pts; let dmax = 0, idx = 0; const a = pts[0], b = pts[pts.length - 1];
  for (let i = 1; i < pts.length - 1; i++) { const p = pts[i]; const vx = b[0] - a[0], vz = b[2] - a[2], L = Math.hypot(vx, vz) || 1; const d = Math.abs((p[0] - a[0]) * vz - (p[2] - a[2]) * vx) / L; if (d > dmax) { dmax = d; idx = i; } }
  if (dmax > eps) { const l = simplify(pts.slice(0, idx + 1), eps), r = simplify(pts.slice(idx), eps); return l.slice(0, -1).concat(r); }
  return [a, b];
}

export function* routes(ctx) {
  const { model, fits, g, S, B } = ctx;
  const { L, D, zb } = model.dims, cs = 0.12, x0 = -L / 2, z0 = -D / 2, nx = Math.round(L / cs), nz = Math.round(D / cs);
  const out = [];
  for (let s = 0; s < NS; s++) {
    const T = fits[s].T, F = floorTop(s);
    const postFree = new Uint8Array(nx * nz), baseFree = new Uint8Array(nx * nz);
    for (let b = 0; b < nz; b++) for (let a = 0; a < nx; a++) {
      const lx = x0 + (a + .5) * cs, lz = z0 + (b + .5) * cs; let nf = 0, nb = 0, occ = 0, n = 0;
      for (let y = F + 0.3; y <= F + 2.0; y += 0.12) {
        const p = tApply(T, lx, y, lz), c = g.cell(p[0], p[1], p[2]); const c0 = g.cell(lx, y, lz); n++;
        if (c >= 0) { if (S[c] === O_FREE) nf++; else if (S[c] === O_OCC) occ++; }
        if (c0 >= 0 && B[c0] === L_FREE) nb++;
      }
      postFree[b * nx + a] = !occ && nf >= n * 0.4 ? 1 : 0; baseFree[b * nx + a] = nb === n ? 1 : 0;
    }
    const clear = (free) => { const blk = new Uint8Array(nx * nz); for (let k = 0; k < nx * nz; k++) blk[k] = free[k] ? 0 : 1; const d2 = edt2(blk, nx, nz); const c = new Float32Array(nx * nz); for (let k = 0; k < nx * nz; k++) c[k] = Math.sqrt(d2[k]) * cs; return c; };
    const cP = clear(postFree), cB = clear(baseFree);
    const walkP = new Uint8Array(nx * nz), walkB = new Uint8Array(nx * nz); for (let k = 0; k < nx * nz; k++) { walkP[k] = cP[k] >= 0.3 ? 1 : 0; walkB[k] = cB[k] >= 0.3 ? 1 : 0; }
    const skP = thin(walkP, nx, nz), skB = thin(walkB, nx, nz);
    const gP = graphOf(skP, cP, nx, nz), gB = graphOf(skB, cB, nx, nz);
    const W = (k, h = 0.08) => { const a = k % nx, b = (k - a) / nx; return tApply(T, x0 + (a + .5) * cs, F + h, z0 + (b + .5) * cs); };
    const WB = (k, h = 0.08) => { const a = k % nx, b = (k - a) / nx; return [x0 + (a + .5) * cs, F + h, z0 + (b + .5) * cs]; };
    const toEdges = (gr, w) => gr.edges.filter((e) => e.path.length > 2).map((e) => ({ pts: simplify(e.path.map((k) => w(k)), 0.06), clear: e.clear }));
    // routes cut: baseline skeleton where a person no longer fits
    const cutMask = new Uint8Array(nx * nz); for (let k = 0; k < nx * nz; k++) if (skB[k] && !walkP[k]) cutMask[k] = 1;
    const cut = toEdges(graphOf(cutMask, cB, nx, nz), WB).filter((e) => e.pts.length >= 2);
    let cutLen = 0; for (let k = 0; k < nx * nz; k++) if (cutMask[k]) cutLen += cs;
    // new bottlenecks: post skeleton under 0.8 m wide where the baseline was wider
    const necks = []; const used = new Uint8Array(nx * nz);
    for (let k = 0; k < nx * nz; k++) {
      if (!skP[k] || used[k] || cP[k] >= 0.37 || cB[k] < 0.46) continue;
      const st = [k]; used[k] = 1; let sx = 0, sz = 0, n = 0, mn = 1e9, mk = k;
      while (st.length) { const q = st.pop(); const a = q % nx, b = (q - a) / nx; sx += a; sz += b; n++; if (cP[q] < mn) { mn = cP[q]; mk = q; } for (const [da, db] of N8) { const x = a + da, y = b + db; const r = y * nx + x; if (x >= 0 && y >= 0 && x < nx && y < nz && skP[r] && !used[r] && cP[r] < 0.37 && cB[r] >= 0.46) { used[r] = 1; st.push(r); } } }
      if (n >= 3) necks.push({ p: W(mk, 1.0), width: 2 * mn });
    }
    // routes from the entry (street door on the ground floor, the stair landing above) to each room
    const ex = 0, ez = s === 0 ? D / 2 - 0.6 : (zb + D / 2) / 2;
    const nearestWalk = (lx, lz, rad) => { let best = -1, bd = 1e9; const a0 = Math.floor((lx - x0) / cs), b0 = Math.floor((lz - z0) / cs), R = Math.ceil(rad / cs); for (let b = b0 - R; b <= b0 + R; b++) for (let a = a0 - R; a <= a0 + R; a++) { if (a < 0 || b < 0 || a >= nx || b >= nz || !walkP[b * nx + a]) continue; const d = (a - a0) ** 2 + (b - b0) ** 2; if (d < bd) { bd = d; best = b * nx + a; } } return best; };
    const entry = nearestWalk(ex, ez, 1.5);
    const prev = new Int32Array(nx * nz).fill(-1), dist = new Float32Array(nx * nz).fill(Infinity);
    if (entry >= 0) {
      // Dijkstra on walkable cells (tight spots cost a little more)
      const heap = [[0, entry]]; dist[entry] = 0;
      const push = (it) => { heap.push(it); let i = heap.length - 1; while (i > 0) { const p = (i - 1) >> 1; if (heap[p][0] <= heap[i][0]) break; [heap[p], heap[i]] = [heap[i], heap[p]]; i = p; } };
      const pop = () => { const top = heap[0], last = heap.pop(); if (heap.length) { heap[0] = last; let i = 0; for (;;) { const l = 2 * i + 1, r2 = l + 1; let m = i; if (l < heap.length && heap[l][0] < heap[m][0]) m = l; if (r2 < heap.length && heap[r2][0] < heap[m][0]) m = r2; if (m === i) break; [heap[m], heap[i]] = [heap[i], heap[m]]; i = m; } } return top; };
      while (heap.length) { const [dd, k] = pop(); if (dd > dist[k]) continue; const a = k % nx, b = (k - a) / nx; for (const [da, db] of N8) { const x = a + da, y = b + db; if (x < 0 || y < 0 || x >= nx || y >= nz) continue; const q = y * nx + x; if (!walkP[q]) continue; const w = Math.hypot(da, db) * cs * (1 + 0.6 / Math.max(0.3, cP[q])); if (dd + w < dist[q]) { dist[q] = dd + w; prev[q] = k; push([dist[q], q]); } } }
    }
    const rts = [];
    for (const room of model.rooms) {
      if (room.storey !== s) continue;
      const t = nearestWalk((room.x0 + room.x1) / 2, (room.z0 + room.z1) / 2, Math.min(room.x1 - room.x0, room.z1 - room.z0) / 2 - 0.2);
      if (t < 0 || !(dist[t] < Infinity)) { rts.push({ room: room.id, reachable: false }); continue; }
      const path = []; for (let k = t; k >= 0; k = prev[k]) path.push(W(k)); path.reverse();
      rts.push({ room: room.id, reachable: true, pts: simplify(path, 0.12), len: dist[t] });
    }
    out.push({ storey: s, tilt: fits[s].tilt || 0, base: { edges: toEdges(gB, WB), beta1: gB.beta1 }, post: { edges: toEdges(gP, W), beta1: gP.beta1 }, cut, cutLen, necks, routes: rts, entry: entry >= 0 ? W(entry, 0.1) : null, walkShare: walkP.reduce((s2, v) => s2 + v, 0) / Math.max(1, walkB.reduce((s2, v) => s2 + v, 0)) });
    yield { p: (s + 1) / NS };
  }
  return out;
}
