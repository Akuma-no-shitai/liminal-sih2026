// The whole After-phase pipeline as one generator that runs in slices and yields progress ({ p, label }); it returns
// the case the film reads. Deterministic from (mode, seed). Pure JS: no DOM, no three.js, runs in node for the sweep.
//   building -> collapse -> truth grids -> baseline + post-event scans -> registration -> ray carving -> storey fits ->
//   part tests -> change map + debris -> wall condition + phi_wall -> draft statuses -> pockets -> routes -> thermal ->
//   pods + aftershock -> confidence + re-fly -> score
import { buildBuilding } from '../building/building.js';
import { collapse } from '../building/collapse.js';
import { computeTruth } from '../building/truth.js';
import { rngFor, tFromEuler, tInvert, tCompose, tApply, DEG } from '../building/geom.js';
import { makeScene, basePoses, postPoses, scan, flightLog } from './scan.js';
import { swarmLog } from './swarm.js';
import { registerScans, transformErr, makeTarget, voxelDown, hashGrid } from './register.js';
import { makeObs, carve, classify } from './occupancy.js';
import { storeyFits, partTests, changeMap } from './change.js';
import { condition, draftRooms, DRAFT } from './condition.js';
import { pockets } from './pockets.js';
import { routes } from './routes.js';
import { thermal } from './thermal.js';
import { choosePods, podTruth, readPods, aftershock } from './pods.js';
import { surfaceVoxels, confidenceOf, reflyPlan } from './confidence.js';
import { score, stationClock } from './score.js';

const PERF = () => (typeof performance !== 'undefined' ? performance.now() : Date.now());
export const RAYS = (q) => (q.kind === 'room' ? 1500 : q.kind === 'stall' ? 1000 : q.kind === 'roof' ? 1800 : q.kind === 'refly' ? 2500 : 1900);
const STAGES = [
  ['collapse', 'Simulating the collapse', 4], ['truth', 'Simulating the collapse', 6], ['base', 'Loading the baseline survey', 4], ['post', 'Rescanning', 6],
  ['register', 'Registering the scans', 4], ['carve', 'Carving free space', 6], ['storeys', 'Fitting each floor', 5], ['change', 'Mapping what changed', 5],
  ['condition', 'Measuring the walls', 6], ['pockets', 'Looking for pockets', 4], ['routes', 'Tracing routes', 2], ['rest', 'Thermal, pods and confidence', 5], ['score', 'Scoring against the truth', 3],
];
const W = STAGES.reduce((s, x) => s + x[2], 0);

export function* runCase(mode, seed, opts = {}) {
  const tm = {}, C = { mode, seed, version: 1 };
  let done = 0; const st = (k) => STAGES.find((x) => x[0] === k);
  const stage = function* (key, gen) { const [, label, w] = st(key); yield { p: done / W, label }; const t0 = PERF(); if (typeof gen === 'function') gen = gen(); let res;
    if (gen && typeof gen.next === 'function') { for (;;) { const r = gen.next(); if (r.done) { res = r.value; break; } yield { p: (done + w * Math.min(1, r.value.p || 0)) / W, label }; } } else res = gen;
    tm[key] = Math.round(PERF() - t0); done += w; return res; };
  // ------------------------------------------------------------------ world and truth
  let model;
  const post = yield* stage('collapse', () => { model = buildBuilding({ seed }); return collapse(model, mode, seed); });
  const T = yield* stage('truth', () => computeTruth(model, post));
  // ------------------------------------------------------------------ scans
  let sb, sp, bp, pp; const smoke = [{ c: post.fire.pos, r: 3.2, k: 1 }];
  const SB = yield* stage('base', function* () { sb = makeScene(model, model.parts); sp = makeScene(model, post.parts, { post: true }); bp = basePoses(model); return yield* scan(sb, bp, { rays: RAYS, seed, salt: 'base' }); });
  const SP = yield* stage('post', function* () { pp = postPoses(model, T, rngFor(seed, 'poses')); return yield* scan(sp, pp.poses, { rays: RAYS, seed, salt: 'post', smoke }); });
  const flight = flightLog(model, T, pp.poses, pp.stalls, seed);
  const tSw = PERF(); const swarm = swarmLog(model, T, pp.poses, flight, seed); tm.swarm = Math.round(PERF() - tSw);
  // the post-event map drifted (GPS-denied SLAM): a rigid offset of 0.3-0.6 m and 1-3 degrees
  const r = rngFor(seed, 'drift');
  const ang = r() * Math.PI * 2, dist = 0.3 + r() * 0.3, yaw = (1 + r() * 2) * DEG * (r() < .5 ? -1 : 1);
  const Td = tFromEuler((r() - .5) * 0.6 * DEG, yaw, (r() - .5) * 0.6 * DEG, Math.cos(ang) * dist, (r() - .5) * 0.15, Math.sin(ang) * dist);
  const trueEnds = SP.pts.slice();
  for (let i = 0; i < SP.n; i++) { const q = tApply(Td, SP.pts[i * 3], SP.pts[i * 3 + 1], SP.pts[i * 3 + 2]); SP.pts[i * 3] = q[0]; SP.pts[i * 3 + 1] = q[1]; SP.pts[i * 3 + 2] = q[2]; }
  for (const q of SP.poses) q.raw = tApply(Td, ...q.p);
  // the anchor unit localised itself in the baseline map when it parked: a good, not perfect, starting guess
  const err = tFromEuler((r() - .5) * 0.8 * DEG, (r() - .5) * 1.0 * DEG, (r() - .5) * 0.8 * DEG, (r() - .5) * 0.3, (r() - .5) * 0.1, (r() - .5) * 0.3);
  const Tanchor = tCompose(err, tInvert(Td));
  // ------------------------------------------------------------------ registration
  const REG = yield* stage('register', registerScans(SB, SP, Tanchor, seed, { cx: 0, cz: 0, hx: model.dims.L / 2, hz: model.dims.D / 2 + 1.2 }));
  C.reg = { iters: REG.iters.map((it) => ({ T: it.T, rmse: it.rmse, used: it.used })), start: Tanchor, T: REG.T, drift: Td, err: transformErr(REG.T, Td), errStart: transformErr(Tanchor, Td), nSrc: REG.nSrc, misfit: REG.misfit, src: REG.src };
  // registered hits (and the sensor each came from)
  let nh = 0; for (let i = 0; i < SP.n; i++) nh += SP.hit[i];
  const preg = new Float32Array(nh * 3), praw = new Float32Array(nh * 3), porg = new Float32Array(nh * 3), pIdx = new Int32Array(nh);
  { const ro = SP.poses.map((q) => tApply(REG.T, ...q.raw)); let k = 0; const e = [0, 0, 0];
    for (let i = 0; i < SP.n; i++) { if (!SP.hit[i]) continue; tApply(REG.T, SP.pts[i * 3], SP.pts[i * 3 + 1], SP.pts[i * 3 + 2], e); preg[k * 3] = e[0]; preg[k * 3 + 1] = e[1]; preg[k * 3 + 2] = e[2]; praw[k * 3] = SP.pts[i * 3]; praw[k * 3 + 1] = SP.pts[i * 3 + 1]; praw[k * 3 + 2] = SP.pts[i * 3 + 2]; const o = ro[SP.pose[i]]; porg[k * 3] = o[0]; porg[k * 3 + 1] = o[1]; porg[k * 3 + 2] = o[2]; pIdx[k] = i; k++; } }
  // ------------------------------------------------------------------ carving
  const g = T.g, O = makeObs(g);
  const carveGen = function* () { yield* carve(g, O, SP, REG.T); return classify(g, O); };
  const S = yield* stage('carve', carveGen());
  // ------------------------------------------------------------------ storeys, parts, change map
  const tIdx = voxelDown(preg, null, nh, 0.1);
  const target = makeTarget(preg, tIdx, 0.3, 0.3, (i) => [porg[i * 3], porg[i * 3 + 1], porg[i * 3 + 2]]);
  // oriented normals of the whole baseline (the storey fits need the building's own surfaces)
  const bTarget = makeTarget(SB.pts, voxelDown(SB.pts, SB.hit, SB.n, 0.14), 0.3, 0.28, (i) => SB.poses[SB.pose[i]].p);
  const fits = yield* stage('storeys', storeyFits(model, SB, target, seed, bTarget));
  const postHash = hashGrid(preg, nh, 0.2);
  const tests = partTests(model, fits, g, S, postHash, preg);
  const CH = yield* stage('change', changeMap(model, T.B, g, S, fits, tests, T.B, { pts: preg, nh, seed }));
  // the low end counts only what a return proves: each voxel holding a debris return at half its volume (a surface
  // crosses that voxel; the solid side behind it is not counted). Voxels the surface closing added were never hit,
  // so they count toward the estimate only.
  let seen = 0, closed = 0, fu = 0, fh = 0; for (let k = 0; k < g.N; k++) { if (CH.debris[k]) { if (S[k] === 2) seen++; else closed++; } if (CH.fill[k] === 1) fu++; else if (CH.fill[k] === 2) fh++; }
  const V3 = g.V3, lo = seen + closed; const debris = { low: 0.5 * seen * V3, estimate: (lo + fu) * V3, high: (lo + fu + fh) * V3, seen: seen * V3, closed: closed * V3 }; debris.mid = (debris.low + debris.high) / 2; debris.trucks = Math.max(1, Math.round(debris.estimate * 1.3 / 10));
  // ------------------------------------------------------------------ condition, rooms
  // baseline hits (for the baseline wall fits)
  let nb = 0; for (let i = 0; i < SB.n; i++) nb += SB.hit[i];
  const bpts = new Float32Array(nb * 3); { let k = 0; for (let i = 0; i < SB.n; i++) { if (!SB.hit[i]) continue; bpts[k * 3] = SB.pts[i * 3]; bpts[k * 3 + 1] = SB.pts[i * 3 + 1]; bpts[k * 3 + 2] = SB.pts[i * 3 + 2]; k++; } }
  const baseHash = hashGrid(bpts, nb, 0.2);
  const cond = yield* stage('condition', condition({ model, fits, tests, g, S, CH, postPts: preg, postHash, postOrg: porg, basePts: bpts, baseHash, post, scene: sp, poses: SP.poses, seed }));
  const rooms = draftRooms(model, fits, g, S, CH, cond, tests);
  // ------------------------------------------------------------------ pockets, routes
  const poseCells = SP.poses.map((q) => { const p = tApply(REG.T, ...q.raw); return g.cell(p[0], p[1], p[2]); });
  const PK = yield* stage('pockets', pockets({ model, g, S, CH, fits, tests, poseCells, seed, pts: preg, nh }));
  const RT = yield* stage('routes', routes({ model, fits, g, S, B: T.B }));
  // ------------------------------------------------------------------ thermal, pods, confidence + re-fly
  const t0 = PERF();
  const TH = thermal({ model, post, pts: preg, n: nh, g, seed });
  yield { p: (done + 1) / W, label: 'Thermal, pods and confidence' };
  const podList = choosePods(model, cond, tests, seed);
  const truthK = podTruth(model, post, podList, seed);
  const moved = fits.some((f) => f.tilt > 1);
  const buildK0 = moved ? 0.72 : 0.94;
  const reads0 = readPods(podList, truthK, buildK0, seed, 'first');
  C.storeys = fits; C.seed = seed;
  C.pods = { list: podList, truth: truthK, reads: reads0, tau0: rngFor(seed, 'tau0')(), state0: { k: truthK.map((t) => t.k), buildK: buildK0, tilt: Math.max(...fits.map((f) => f.tilt || 0)) } };
  C.aftershocks = []; C.aftershocks.push(aftershock(C, 1));
  // statuses after the scripted aftershock
  const roomsAfter = afterStatuses(model, rooms, C, cond);
  // confidence and the re-fly
  const surf = surfaceVoxels(g, CH);
  const area = { x0: -model.dims.L / 2 - 3, x1: model.dims.L / 2 + 3, z0: -model.dims.D / 2 - 3, z1: model.dims.D / 2 + 4 };
  const conf0 = confidenceOf(g, O, surf, smoke, REG.misfit, area);
  // where a drone can be: the reach the pockets stage flooded (observed free space a drone fits in)
  const RP = reflyPlan(g, S, CH, surf, conf0.conf, PK.reach, { cap: conf0.cap }); delete PK.reach; const rp = RP.poses;
  const RF = rp.length ? (() => { const gen = scan(sp, rp, { rays: RAYS, seed, salt: 'refly', smoke: [{ c: post.fire.pos, r: 2.4, k: 0.5 }] }); let v; for (;;) { const x = gen.next(); if (x.done) { v = x.value; break; } } return v; })() : null;
  let conf1 = conf0, reflyPts = new Float32Array(0);
  if (RF) {
    for (let i = 0; i < RF.n; i++) { const q = tApply(Td, RF.pts[i * 3], RF.pts[i * 3 + 1], RF.pts[i * 3 + 2]); RF.pts[i * 3] = q[0]; RF.pts[i * 3 + 1] = q[1]; RF.pts[i * 3 + 2] = q[2]; }
    for (const q of RF.poses) q.raw = tApply(Td, ...q.p);
    const gen = carve(g, O, RF, REG.T); for (;;) { if (gen.next().done) break; }
    conf1 = confidenceOf(g, O, surf, [{ c: post.fire.pos, r: 2.4, k: 0.5 }], REG.misfit, area);
    let k = 0; for (let i = 0; i < RF.n; i++) k += RF.hit[i]; reflyPts = new Float32Array(k * 3); k = 0; const e = [0, 0, 0];
    for (let i = 0; i < RF.n; i++) { if (!RF.hit[i]) continue; tApply(REG.T, RF.pts[i * 3], RF.pts[i * 3 + 1], RF.pts[i * 3 + 2], e); reflyPts[k * 3] = e[0]; reflyPts[k * 3 + 1] = e[1]; reflyPts[k * 3 + 2] = e[2]; k++; }
  }
  const surfC = new Float32Array(surf.length * 3); { const q = [0, 0, 0]; for (let k = 0; k < surf.length; k++) { g.centre(surf[k], q); surfC[k * 3] = q[0]; surfC[k * 3 + 1] = q[1]; surfC[k * 3 + 2] = q[2]; } }
  const roomConf = model.rooms.map((room) => roomConfidence(g, room, fits, surfC, conf1.conf));
  tm.rest = Math.round(PERF() - t0); done += st('rest')[2];
  // ------------------------------------------------------------------ assemble and score
  Object.assign(C, {
    model, post: { parts: post.parts, cracks: post.cracks, fire: post.fire, tank: post.tank, info: post.info, motions: post.motions, walls: post.walls, jammed: post.jammed, sag: [...post.sag.entries()], debrisVolume: post.debrisVolume },
    g: { x0: g.x0, y0: g.y0, z0: g.z0, nx: g.nx, ny: g.ny, nz: g.nz, vox: g.vox, N: g.N, V3: g.V3 },
    S, change: { labels: CH.labels, counts: CH.counts }, debrisGrid: CH.debris, fillGrid: CH.fill, Shat: CH.Shat,
    debris, tests: tests.map((t) => t.state), condition: cond, rooms, roomsAfter, roomConf, pockets: PK, routes: RT, thermal: TH,
    scans: { base: { pts: bpts, n: nb, poses: bp.map((q) => ({ p: q.p, kind: q.kind })) }, post: { pts: preg, raw: praw, n: nh, poses: SP.poses.map((q) => ({ p: q.p, raw: q.raw, kind: q.kind })), trueEnds: null }, refly: { pts: reflyPts, poses: rp } },
    flight, swarm, smoke,
    confidence: { surf, before: conf0.conf, after: conf1.conf, mean0: conf0.mean, mean1: conf1.mean, hist0: conf0.hist, hist1: conf1.hist, ...confStats(g, surf, conf0.conf, conf1.conf, RP, area) },
    truth: { rooms: T.rooms, voids: T.voids.map((v) => ({ vol: v.vol, centre: v.centre, cells: v.cells, bb: v.bb })), altered: T.altered, removed: T.removed * V3, added: T.added * V3, debrisVolume: T.debrisVolume, reachM3: 0 },
  });
  const compute = { register: tm.register, carve: tm.carve, change: tm.change + tm.storeys };
  C.clock = stationClock(8, compute);
  const SC = yield* stage('score', () => score(C, T));
  C.score = SC; C.timings = tm; tm.total = Object.values(tm).reduce((s, v) => s + v, 0);
  return C;
}
// rooms after the aftershock: a pod that read a large stiffness loss closes the rooms on its wall; slower recovery
// than before (critical slowing down) closes the moved storeys
export function afterStatuses(model, rooms, C, cond, k = 0) {
  const A = C.aftershocks[k]; const out = rooms.map((x) => ({ ...x, why: x.why.slice() }));
  A.reads.forEach((rd, i) => {
    const pod = C.pods.list[i]; const loss = rd.stiffLoss;
    if (loss < 0.3) return;
    for (const rid of model.walls[pod.wall].rooms) { const x = out[rid]; if (x.status === 'noentry' || x.status === 'unseen') continue; x.status = 'noentry'; x.why = [`After the aftershock the pod on its wall reads ${Math.round(loss * 100)} % less stiffness than an intact wall`]; }
  });
  if (A.slowing) for (const x of out) { const s = model.rooms[x.id].storey; if (C.storeys[s].ident || x.status === 'noentry' || x.status === 'unseen') continue; x.status = 'noentry'; x.why = ['Recovers more slowly after each aftershock: nearing its threshold']; }
  return out;
}
// what the whole-building mean hides: the share of surface never seen at all, and the re-fly measured where it went:
// the weak clusters it targeted (before and after, each and together), and the weak clusters it could not reach
function confStats(g, surf, c0, c1, RP, area) {
  const p = [0, 0, 0]; let n = 0, un0 = 0, un1 = 0;
  for (let k = 0; k < surf.length; k++) { g.centre(surf[k], p); if (p[0] < area.x0 || p[0] > area.x1 || p[2] < area.z0 || p[2] > area.z1) continue; n++; if (c0[k] === 0) un0++; if (c1[k] === 0) un1++; }
  let tn = 0, t0 = 0, t1 = 0; const targets = RP.targets.map((t) => { let a = 0, b = 0; for (const k of t.idx) { a += c0[k]; b += c1[k]; } tn += t.idx.length; t0 += a; t1 += b; return { c: t.c, n: t.n, views: t.views, before: a / t.idx.length / 255, after: b / t.idx.length / 255 }; });
  const ua = RP.unreachable.reduce((s, u) => s + u.area, 0);
  return { unseen: n ? un0 / n : 0, unseenAfter: n ? un1 / n : 0, region: tn ? { n: tn, before: t0 / tn / 255, after: t1 / tn / 255 } : null, targets, unreachable: RP.unreachable.slice(0, 40), unreachableN: RP.unreachable.length, unreachableArea: ua, limitedArea: RP.limitedArea };
}
function roomConfidence(g, room, fits, surfC, conf) {
  const s = room.storey, T = fits[s].T, Ti = tInvert(T); let sum = 0, n = 0; const q = [0, 0, 0];
  // surface voxels inside the room's moved box (walls, floor, ceiling within 0.3 m)
  const c0 = tApply(T, (room.x0 + room.x1) / 2, (room.y0 + room.y1) / 2, (room.z0 + room.z1) / 2), R = Math.hypot(room.x1 - room.x0, room.z1 - room.z0, room.y1 - room.y0) / 2 + 0.4;
  const nS = surfC.length / 3; for (let k = 0; k < nS; k += 2) { const px = surfC[k * 3], py = surfC[k * 3 + 1], pz = surfC[k * 3 + 2]; if (Math.abs(px - c0[0]) > R || Math.abs(py - c0[1]) > R || Math.abs(pz - c0[2]) > R) continue; tApply(Ti, px, py, pz, q); if (q[0] < room.x0 - 0.3 || q[0] > room.x1 + 0.3 || q[2] < room.z0 - 0.3 || q[2] > room.z1 + 0.3 || q[1] < room.y0 - 0.3 || q[1] > room.y1 + 0.3) continue; sum += conf[k] / 255; n++; }
  return n ? sum / n : 0;
}
export function runSync(mode, seed, opts) { const gen = runCase(mode, seed, opts); for (;;) { const r = gen.next(); if (r.done) return r.value; } }
