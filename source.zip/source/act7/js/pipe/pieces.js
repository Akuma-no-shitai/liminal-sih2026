// Slab pieces among the debris: tight planes (RANSAC, several rounds) in the returns that landed on debris. A fallen
// slab gives a large tight plane (rms under 1.5 cm, at least 0.9 m across both ways, tilted 8-60 degrees); a rubble
// slope does not. One definition, used twice: the change map stops its inferred fill under such a slab (a slab is
// 0.15 m thick; what is under it is unknown, not assumed to be debris), and the pockets look for lean-to wedges there.
import { fitPlane, DEG } from '../building/geom.js';

export function slabPieces(g, deb, pts, nh, r) {
  const pieces = [];
  // returns that landed in debris voxels (a fallen slab gives a large tight plane; a rubble slope does not)
  const dSel = []; for (let i = 0; i < nh; i++) { const c = g.cell(pts[i * 3], pts[i * 3 + 1], pts[i * 3 + 2]); if (c >= 0 && deb[c]) dSel.push(i); }
  for (let i = dSel.length - 1; i > 0; i--) { const j = Math.floor(r() * (i + 1)); const t = dSel[i]; dSel[i] = dSel[j]; dSel[j] = t; }
  if (dSel.length > 16000) dSel.length = 16000;
  if (dSel.length > 150) {
    const P = new Float32Array(dSel.length * 3); dSel.forEach((i, k) => { P[k * 3] = pts[i * 3]; P[k * 3 + 1] = pts[i * 3 + 1]; P[k * 3 + 2] = pts[i * 3 + 2]; });
    let left = dSel.map((i, k) => k);
    for (let round = 0; round < 6 && left.length > 150; round++) {
      let best = null, bn = 0;
      for (let it = 0; it < 150; it++) {
        const a = left[Math.floor(r() * left.length)], b = left[Math.floor(r() * left.length)], c = left[Math.floor(r() * left.length)];
        const ux = P[b * 3] - P[a * 3], uy = P[b * 3 + 1] - P[a * 3 + 1], uz = P[b * 3 + 2] - P[a * 3 + 2], vx = P[c * 3] - P[a * 3], vy = P[c * 3 + 1] - P[a * 3 + 1], vz = P[c * 3 + 2] - P[a * 3 + 2];
        if (Math.hypot(ux, uy, uz) > 2.5 || Math.hypot(vx, vy, vz) > 2.5) continue;
        let nx = uy * vz - uz * vy, ny = uz * vx - ux * vz, nz = ux * vy - uy * vx; const L = Math.hypot(nx, ny, nz); if (L < 1e-6) continue; nx /= L; ny /= L; nz /= L;
        const tilt = Math.acos(Math.abs(ny)) / DEG; if (tilt < 8 || tilt > 60) continue;
        const d = nx * P[a * 3] + ny * P[a * 3 + 1] + nz * P[a * 3 + 2]; let n = 0;
        for (let q = 0; q < left.length; q += 2) { const k = left[q]; if (Math.abs(nx * P[k * 3] + ny * P[k * 3 + 1] + nz * P[k * 3 + 2] - d) < 0.025) n++; }
        if (n > bn) { bn = n; best = [nx, ny, nz, d]; }
      }
      if (!best || bn * 2 < 120) break;
      const inl = left.filter((k) => Math.abs(best[0] * P[k * 3] + best[1] * P[k * 3 + 1] + best[2] * P[k * 3 + 2] - best[3]) < 0.025);
      const f = fitPlane(P, inl); if (!f) break;
      const set = new Set(inl); left = left.filter((k) => !set.has(k));
      // a real piece: tight (rms under 1.5 cm) and at least 0.9 m across both ways
      const n = f.n, u = Math.abs(n[1]) < 0.9 ? [n[2], 0, -n[0]] : [1, 0, 0]; const ul = Math.hypot(...u); const ua = u.map((x) => x / ul); const va = [n[1] * ua[2] - n[2] * ua[1], n[2] * ua[0] - n[0] * ua[2], n[0] * ua[1] - n[1] * ua[0]];
      let a0 = 1e9, a1 = -1e9, b0 = 1e9, b1 = -1e9; for (const k of inl) { const x = P[k * 3] * ua[0] + P[k * 3 + 1] * ua[1] + P[k * 3 + 2] * ua[2], y = P[k * 3] * va[0] + P[k * 3 + 1] * va[1] + P[k * 3 + 2] * va[2]; a0 = Math.min(a0, x); a1 = Math.max(a1, x); b0 = Math.min(b0, y); b1 = Math.max(b1, y); }
      if (f.rms > 0.015 || a1 - a0 < 0.9 || b1 - b0 < 0.9) continue;
      const sg = n[1] < 0 ? -1 : 1, nn = n.map((v) => v * sg), dd = nn[0] * f.c[0] + nn[1] * f.c[1] + nn[2] * f.c[2];
      pieces.push({ from: 'debris', n: nn, d: dd, ua, va, ext: [a0, a1, b0, b1], pts: inl.filter((k, i) => i % Math.max(1, Math.floor(inl.length / 400)) === 0).map((k) => [P[k * 3], P[k * 3 + 1], P[k * 3 + 2]]), count: inl.length, rms: f.rms });
    }
  }
  return pieces;
}
// is a point on a piece (within tol of its plane, inside its extent)?
export function onPiece(pc, x, y, z, tol = 0.1) {
  const n = pc.n; if (Math.abs(n[0] * x + n[1] * y + n[2] * z - pc.d) > tol) return false;
  const a = x * pc.ua[0] + y * pc.ua[1] + z * pc.ua[2], b = x * pc.va[0] + y * pc.va[1] + z * pc.va[2];
  return a > pc.ext[0] - 0.1 && a < pc.ext[1] + 0.1 && b > pc.ext[2] - 0.1 && b < pc.ext[3] + 0.1;
}
