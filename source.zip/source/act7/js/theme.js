// Act 7's themes: every colour the act uses, in one place. A theme sets the CSS (custom properties on .a7), the sky,
// light and fog, the clay of the diorama, the overlay and status colours, the chart colours and the picker posters.
// Selected with opts.theme ('dusk' is the default and the original look). All of them keep the clay-diorama rendering
// and a restrained, low-chroma palette; only the mood changes.
//   ui    CSS colours. *-rgb are "r,g,b" for tints; *-txt is the colour as text on a panel (AA contrast); *-on is text
//         on a tint of that colour (status chips, labels).
//   data  overlay colours in the 3-D view (hex, or [r, g, b] in sRGB 0-1 for shader constants)
//   clay  the diorama's materials;  sky  sky, fog and lights;  look  exposure, grade, bloom, vignette
const rgbOf = (h) => { const n = parseInt(h.slice(1), 16); return `${(n >> 16) & 255},${(n >> 8) & 255},${n & 255}`; };
export const f3 = (h) => { const n = parseInt(h.slice(1), 16); return [((n >> 16) & 255) / 255, ((n >> 8) & 255) / 255, (n & 255) / 255]; };
export const rgba = (h, a) => `rgba(${rgbOf(h)},${a})`;

// the original look: lavender dusk
const dusk = {
  id: 'dusk', label: 'Dusk', dark: true,
  names: { base: 'teal', post: 'rose', added: 'rose', empty: 'lavender' },
  ui: {
    ink: '#1E2140', paper: '#F3EEF2', fg: '243,238,242', lineRgb: '220,214,236', panel: '30,33,64', panel2: '36,40,77', bar: '24,26,52', card: '32,35,70', well: '20,22,48', halo: '20,22,50', shadow: '10,12,30', shadow2: '12,14,34', pick: '58,61,114', hover: '44,48,90', hover2: '43,47,94',
    view1: '#3a3d72', view2: '#262a55', night: '#2B2F5E', dusk: '#4A4B86', mist: '#DCE4EE', apricot: '#F6D2B1', apricotTxt: '#F6D2B1',
    line: 'rgba(220,214,236,.14)', muted: 'rgba(243,238,242,.8)', faint: 'rgba(243,238,242,.68)', glass: 'rgba(30,33,64,.74)', glass2: 'rgba(36,40,77,.78)', body: 'rgba(243,238,242,.9)',
    teal: '#7FD4CF', tealTxt: '#7FD4CF', tealOn: '#BFF0EC', tealOn2: '#CFF5F2',
    safe: '#7FD4CF', safeTxt: '#7FD4CF', safeOn: '#BFF0EC',
    caution: '#FFC36B', cautionTxt: '#FFC36B', cautionOn: '#FFE2B8',
    heat: '#FFC36B', heatTxt: '#FFC36B', heatOn: '#FFE2B8',
    danger: '#F08A7E', dangerTxt: '#F08A7E', dangerOn: '#FFD0C9', dangerOn2: '#FFD9D3',
    lav: '#B9A6F2', lavTxt: '#B9A6F2', lavOn: '#DCD2FF',
    haze: '#8F8CC4', hazeTxt: '#A9A6DA', hazeOn: '#DCD8F8', hazeOn2: '#D6D3F5',
    rose: '#EFB1B4', roseTxt: '#EFB1B4', roseOn: '#FFD6D8',
    swarm: '#7FD4CF', post: '#EFB1B4', accent2: '#FFC36B', accent2On: '#1E2140', labA: .7,
  },
  data: {
    swarm: '#7FD4CF', base: '#8FF0E8', post: '#FFB3BC', added: '#EFB1B4', debris: '#E9967F', fill: '#F2C8B4', empty: '#B9A6F2', emptyLight: '#CFC2F7', voidTruth: '#DCD2FF',
    safe: '#7FD4CF', caution: '#FFC36B', noentry: '#F08A7E', unseen: '#8F8CC4', hot: '#FFC36B', cold: '#8FB8E8', mid: '#F6D2B1', paper: '#F3EEF2', refly: '#CFF5F2', podBody: '#F6D2B1', podRing: '#7FD4CF',
    phi: [[.975, '#7FD4CF'], [.95, '#F6D2B1'], [.9, '#FFC36B'], [.75, '#F08A7E']],
    conf: [[.56, .55, .77], [.96, .82, .69], [.5, .83, .81]],
    heatmap: { cold: [.38, .66, 1.], amb: [.36, .35, .6], warm: [.98, .72, .52], hot: [1., .6, .3], vhot: [1., .42, .3] },
    heatLayer: { cold: [.30, .62, 1.], w0: [1., .80, .45], w1: [1., .60, .28], w2: [1., .34, .22] },
    sweep: [.6, .9, .88], packet: [.55, .95, .9], linePacket: [.9, 1., .98], additive: true, heatAdditive: true, tileA: .62,
  },
  clay: {
    col: { wallExt: '#ECE2E4', wallInt: '#E4DCE6', column: '#DCD2DE', beam: '#D6CCDA', slab: '#D2C8D8', stair: '#CFC5D6', balcony: '#E6DCE0', parapet: '#E2D8DE',
      plinth: '#B8AEC2', tank: '#9FB4C8', door: '#B9907E', debris: '#B6AABC', debrisSlab: '#C2B6C8', site: '#BEB5C8', neighbour: '#CDC4D4', kerb: '#A39BB2' },
    dim: '#8A85AC', frame: '#F4EEF0', ground: '#9D97B4', yard: '#B1AABF', street: '#77728F', pave: '#A8A1B8', marks: '#E8E2EC', winBase: '#CFC6D6', winGlass: '#8E86A6',
    trunk: '#8C7E8E', crown: '#8FA494', van: '#EFE6EA', vanStripe: '#F08A7E', mast: '#D6CEDC', mastHead: '#7FD4CF', table: '#E9E1E6', legs: '#8C86A8', laptop: '#5E5878', screen: '#9FE6E0',
    crate: '#F6D2B1', rescuer: '#F6D2B1', rescuerHead: '#FFC36B', pad: '#5D587A', ring: '#7FD4CF', beacon: '#FFC36B', prop: null, crack: [.2, .19, .3], cable: [.16, .15, .26],
  },
  sky: { top: '#7D82AC', horizon: '#D8CAD4', fog: '#C2B8CE', fogDensity: 0.0065, glow: .35, sun: { dir: [.55, .62, .42], color: '#FFE4D2', intensity: 1.15 }, hemi: { sky: '#E6E1F2', ground: '#6C668E', intensity: 1.0 } },
  look: { exposure: 1.02, sat: 1.04, bloom: .22, bloomThreshold: .92, vig: '#1E2140', vigAmt: .22, shadowRadius: 3 },
  chart: { conf: ['#8F8CC4', '#F6D2B1', '#7FD4CF'], paper: '#F3EEF2', faint: 'rgba(243,238,242,.45)', grid: 'rgba(220,214,236,.12)', well: 'rgba(220,214,236,.14)', bar: 'rgba(220,214,236,.1)', band: 'rgba(220,214,236,.06)', dash: 'rgba(220,214,236,.25)' },
  poster: { sky: ['#6E73A0', '#C8BACB', '#8D86A6'], ground: '#7C7698', facade: '#EDE3E6', floor: '#C9BFD2', win: '#5E587E', parapet: '#E2D8DE', rubble: ['#B6AABC', '#A99DB4', '#C4B8C9'], crushed: '#CFC4D2', bay: '#8D86A6', slab: '#D2C8D8', mark: 'rgba(240,138,126,.9)', drone: 'rgba(127,212,207,.9)' },
};

// light, neutral daylight under cloud
const overcast = {
  id: 'overcast', label: 'Overcast', dark: false,
  names: { base: 'teal', post: 'indigo', added: 'indigo', empty: 'sand' },
  ui: {
    ink: '#ECEAE5', paper: '#24282C', fg: '36,40,44', lineRgb: '36,40,44', panel: '247,246,243', panel2: '243,242,238', bar: '238,236,231', card: '248,247,244', well: '228,226,220', halo: '244,243,239', shadow: '52,50,44', shadow2: '52,50,44', pick: '250,249,246', hover: '240,238,233', hover2: '238,236,231',
    view1: '#E8E6E1', view2: '#DCDCD8', night: '#3B4046', dusk: '#585D63', mist: '#E4E2DD', apricot: '#B07A3C', apricotTxt: '#8A5E28',
    line: 'rgba(36,40,44,.12)', muted: '#565A5F', faint: '#6A6E73', glass: 'rgba(247,246,243,.86)', glass2: 'rgba(243,242,238,.92)', body: '#3A3E43',
    teal: '#3D7A80', tealTxt: '#33696E', tealOn: '#2B5D62', tealOn2: '#3D7A80',
    safe: '#6F9A7B', safeTxt: '#4A7556', safeOn: '#3C6548',
    caution: '#C49A45', cautionTxt: '#86601C', cautionOn: '#765417',
    heat: '#D2763F', heatTxt: '#A0501F', heatOn: '#8A4419',
    danger: '#B05A4A', dangerTxt: '#9A4434', dangerOn: '#8A3A2C', dangerOn2: '#8A3A2C',
    lav: '#C9A46A', lavTxt: '#87652A', lavOn: '#755722',
    haze: '#8E9196', hazeTxt: '#686C71', hazeOn: '#53575C', hazeOn2: '#53575C',
    rose: '#5B5F8A', roseTxt: '#4E5280', roseOn: '#434774',
    swarm: '#3D7A80', post: '#6C6FA0', accent2: '#C49A45', accent2On: '#24282C',
  },
  data: {
    swarm: '#3D7A80', base: '#3D7A80', post: '#6B6E9E', added: '#656994', debris: '#6E6A93', fill: '#ABA9C6', empty: '#C9A46A', emptyLight: '#D9C29A', voidTruth: '#E3D2AE',
    safe: '#6F9A7B', caution: '#C49A45', noentry: '#B05A4A', unseen: '#9A9DA1', hot: '#D2763F', cold: '#5C86A8', mid: '#B9C4C2', paper: '#F1EEE9', refly: '#5F979C', podBody: '#E8E3DA', podRing: '#3D7A80',
    phi: [[.975, '#3D7A80'], [.94, '#8FAAAA'], [.86, '#C9C6C0']],
    conf: [f3('#CFCCC6'), f3('#93ADAD'), f3('#3D7A80')],
    heatmap: { cold: f3('#5C86A8'), amb: f3('#9C9890'), warm: f3('#E2A576'), hot: f3('#D2763F'), vhot: f3('#B4532D') },
    heatLayer: { cold: f3('#5C86A8'), w0: f3('#E0A574'), w1: f3('#D2763F'), w2: f3('#AD4E2A') },
    sweep: f3('#3D7A80'), packet: f3('#3D7A80'), linePacket: f3('#2F6A70'), additive: false, heatAdditive: false, tileA: .56,
  },
  clay: {
    col: { wallExt: '#E4E0D8', wallInt: '#DDD9D1', column: '#D6D1C8', beam: '#CFCAC1', slab: '#CFCAC1', stair: '#C8C3BA', balcony: '#E0DCD4', parapet: '#DEDAD2',
      plinth: '#A9A39A', tank: '#A2AAAF', door: '#A08B79', debris: '#B6B0A7', debrisSlab: '#C3BDB4', site: '#C6C1B8', neighbour: '#EAE7E1', kerb: '#A9A39A' },
    dim: '#D4D0C9', frame: '#F2EFEA', ground: '#CBC6BD', yard: '#D4CFC6', street: '#ADA8A0', pave: '#C7C2B9', marks: '#EEEBE5', winBase: '#E4E1DB', winGlass: '#A2A6A8',
    trunk: '#8E857B', crown: '#A5AD9E', van: '#EEEBE6', vanStripe: '#B05A4A', mast: '#D9D4CB', mastHead: '#3D7A80', table: '#E8E4DC', legs: '#8E8A84', laptop: '#5C5F63', screen: '#9CC4C5',
    crate: '#D6C3A5', rescuer: '#D6C3A5', rescuerHead: '#C49A45', squared: false, pad: '#8F8B84', ring: '#3D7A80', beacon: '#C49A45', prop: { color: '#DCD7CE', mix: .35 }, crack: [.34, .32, .3], cable: [.3, .3, .31],
  },
  sky: { top: '#DCDCD8', horizon: '#E8E6E1', fog: '#E4E2DD', fogDensity: 0.0052, glow: .12, sun: { dir: [.38, .85, .36], color: '#FFF6EA', intensity: .65 }, hemi: { sky: '#EAEAE6', ground: '#BDB8AF', intensity: 1.45 } },
  look: { exposure: .98, sat: 1.0, bloom: .1, bloomThreshold: .97, vig: '#CFCBC3', vigAmt: .14, shadowRadius: 7 },
  chart: { paper: '#24282C', faint: 'rgba(36,40,44,.62)', grid: 'rgba(36,40,44,.14)', well: 'rgba(36,40,44,.1)', bar: 'rgba(36,40,44,.08)', band: 'rgba(36,40,44,.05)', dash: 'rgba(36,40,44,.28)' },
  poster: { sky: ['#D9D9D5', '#E6E4DF', '#CFCBC3'], ground: '#BDB8AF', facade: '#ECE9E3', floor: '#CFCAC1', win: '#7E8286', parapet: '#DEDAD2', rubble: ['#B6B0A7', '#A9A39A', '#C3BDB4'], crushed: '#D0CBC2', bay: '#A9A39A', slab: '#CFCAC1', mark: 'rgba(176,90,74,.9)', drone: 'rgba(61,122,128,.9)' },
};

// dark, neutral, cinematic: a night work site under sodium light
const graphite = {
  id: 'graphite', label: 'Graphite', dark: true,
  names: { base: 'pale teal', post: 'copper', added: 'copper', empty: 'blue-grey' },
  ui: {
    ink: '#121417', paper: '#E6E2DA', fg: '230,226,218', lineRgb: '230,226,218', panel: '24,26,30', panel2: '30,32,37', bar: '16,18,21', card: '27,29,33', well: '14,16,19', halo: '9,10,12', shadow: '0,0,0', shadow2: '0,0,0', pick: '38,41,46', hover: '40,43,48', hover2: '40,43,48',
    view1: '#2A2D31', view2: '#1B1E22', night: '#1E2125', dusk: '#3A3E44', mist: '#CFCBC3', apricot: '#D9A55B', apricotTxt: '#D9A55B',
    line: 'rgba(230,226,218,.12)', muted: '#B3AFA7', faint: '#9A978F', glass: 'rgba(24,26,30,.84)', glass2: 'rgba(30,32,37,.9)', body: 'rgba(230,226,218,.84)',
    teal: '#D9A55B', tealTxt: '#D9A55B', tealOn: '#F0D4A6', tealOn2: '#E6C088',
    safe: '#86A88F', safeTxt: '#9DBBA5', safeOn: '#CFE0D3',
    caution: '#D9A55B', cautionTxt: '#E0B271', cautionOn: '#F0D4A6',
    heat: '#E39A5B', heatTxt: '#E8A86F', heatOn: '#F5D2B0',
    danger: '#C26B5C', dangerTxt: '#D98777', dangerOn: '#F0C3B9', dangerOn2: '#F0C3B9',
    lav: '#7F97B3', lavTxt: '#9CB0C8', lavOn: '#D0DBE8',
    haze: '#7C7A75', hazeTxt: '#9A978F', hazeOn: '#D2CFC8', hazeOn2: '#D2CFC8',
    rose: '#B8835F', roseTxt: '#C9997A', roseOn: '#EBCFBC',
    swarm: '#8EC3C0', post: '#C79A78', accent2: '#D9A55B', accent2On: '#121417',
  },
  data: {
    swarm: '#8EC3C0', base: '#8EC3C0', post: '#C99B78', added: '#B8835F', debris: '#A8775A', fill: '#8A6A56', empty: '#7F97B3', emptyLight: '#9DB0C6', voidTruth: '#B6C5D6',
    safe: '#86A88F', caution: '#D9A55B', noentry: '#C26B5C', unseen: '#6F6D69', hot: '#E39A5B', cold: '#6E9CC4', mid: '#7E9A99', paper: '#E6E2DA', refly: '#B5DAD7', podBody: '#C9C4BA', podRing: '#8EC3C0',
    phi: [[.975, '#5A817E'], [.94, '#4D605F'], [.86, '#45484D']],
    conf: [f3('#5E6166'), f3('#73908F'), f3('#8EC3C0')],
    heatmap: { cold: f3('#6E9CC4'), amb: f3('#45484D'), warm: f3('#E8B482'), hot: f3('#E39A5B'), vhot: f3('#CC6B3D') },
    heatLayer: { cold: f3('#6E9CC4'), w0: f3('#ECBB86'), w1: f3('#E39A5B'), w2: f3('#C9653A') },
    sweep: f3('#8EC3C0'), packet: f3('#8EC3C0'), linePacket: f3('#CDE6E4'), additive: true, heatAdditive: true, tileA: .4,
  },
  clay: {
    col: { wallExt: '#5F646B', wallInt: '#575C63', column: '#4F535A', beam: '#4A4E54', slab: '#4E5258', stair: '#45494F', balcony: '#565B62', parapet: '#575C63',
      plinth: '#3A3D42', tank: '#4A535D', door: '#5B4F46', debris: '#46494E', debrisSlab: '#4E5258', site: '#44474C', neighbour: '#404348', kerb: '#3A3D42' },
    dim: '#2F3236', frame: '#6B7077', ground: '#2C2F33', yard: '#32353A', street: '#25282B', pave: '#303337', marks: '#4E5155', winBase: '#3F4247', winGlass: '#24272B',
    trunk: '#3A3531', crown: '#3F4641', van: '#5E6166', vanStripe: '#C26B5C', mast: '#5A5E64', mastHead: '#8EC3C0', table: '#55595F', legs: '#3A3D42', laptop: '#2A2C30', screen: '#7FB2AF',
    crate: '#6B5E4E', rescuer: '#7A6A55', rescuerHead: '#D9A55B', squared: false, pad: '#34373B', ring: '#8EC3C0', beacon: '#D9A55B', prop: { color: '#55595F', mix: .6 }, crack: [.14, .14, .15], cable: [.1, .1, .11],
  },
  sky: { top: '#15181C', horizon: '#2A2D31', fog: '#23262A', fogDensity: 0.0075, glow: .3, sun: { dir: [-.45, .38, .6], color: '#E9B06A', intensity: 3.0 }, hemi: { sky: '#7E8C99', ground: '#33363B', intensity: 3.4 } },
  look: { exposure: 1.18, sat: 1.0, bloom: .2, bloomThreshold: .9, vig: '#0A0B0D', vigAmt: .3, shadowRadius: 4 },
  chart: { paper: '#E6E2DA', faint: 'rgba(230,226,218,.55)', grid: 'rgba(230,226,218,.12)', well: 'rgba(230,226,218,.13)', bar: 'rgba(230,226,218,.09)', band: 'rgba(230,226,218,.05)', dash: 'rgba(230,226,218,.25)' },
  poster: { sky: ['#15181C', '#2E3135', '#1F2226'], ground: '#26292D', facade: '#5E636A', floor: '#4A4E54', win: '#2A2D31', parapet: '#575C63', rubble: ['#46494E', '#3E4146', '#53575D'], crushed: '#4A4E54', bay: '#2F3236', slab: '#55595F', mark: 'rgba(194,107,92,.95)', drone: 'rgba(142,195,192,.9)' },
};

// mid-tone, cool blue-grey dawn after the quake
const bluedawn = {
  id: 'bluedawn', label: 'Blue dawn', dark: false,
  names: { base: 'teal', post: 'plum', added: 'plum', empty: 'straw' },
  ui: {
    ink: '#E3E9EE', paper: '#1F2A33', fg: '31,42,51', lineRgb: '31,42,51', panel: '238,242,245', panel2: '232,237,241', bar: '226,232,237', card: '240,243,246', well: '220,227,232', halo: '234,239,243', shadow: '28,42,56', shadow2: '28,42,56', pick: '243,246,248', hover: '228,234,239', hover2: '226,232,237',
    view1: '#C9D3DB', view2: '#9FB0C0', night: '#2C3A46', dusk: '#4E5E6C', mist: '#DDE5EB', apricot: '#B5774A', apricotTxt: '#8E5630',
    line: 'rgba(31,42,51,.14)', muted: '#46525D', faint: '#56636E', glass: 'rgba(238,242,245,.84)', glass2: 'rgba(232,237,241,.92)', body: '#33414C',
    teal: '#2E7D7A', tealTxt: '#256764', tealOn: '#1D5A57', tealOn2: '#2E7D7A',
    safe: '#5F9478', safeTxt: '#43745A', safeOn: '#36654C',
    caution: '#D0A24C', cautionTxt: '#84601C', cautionOn: '#735317',
    heat: '#D9824A', heatTxt: '#9E5325', heatOn: '#88461E',
    danger: '#B85C55', dangerTxt: '#9B443D', dangerOn: '#8A3933', dangerOn2: '#8A3933',
    lav: '#E0C27A', lavTxt: '#866728', lavOn: '#735821',
    haze: '#8B97A1', hazeTxt: '#5E6B76', hazeOn: '#4B5863', hazeOn2: '#4B5863',
    rose: '#8A5A78', roseTxt: '#7A4C69', roseOn: '#6A405B',
    swarm: '#2E7D7A', post: '#9A6A88', accent2: '#D0A24C', accent2On: '#1F2A33',
  },
  data: {
    swarm: '#2E7D7A', base: '#2E7D7A', post: '#986987', added: '#946482', debris: '#855B76', fill: '#B99DB0', empty: '#E0C27A', emptyLight: '#E8D3A0', voidTruth: '#F0E2BE',
    safe: '#5F9478', caution: '#D0A24C', noentry: '#B85C55', unseen: '#8F9AA3', hot: '#D9824A', cold: '#4F7FA6', mid: '#A7BCBF', paper: '#E2E6E9', refly: '#5D9F9C', podBody: '#E3E8EB', podRing: '#2E7D7A',
    phi: [[.975, '#2E7D7A'], [.94, '#86A7AA'], [.86, '#C2CACF']],
    conf: [f3('#C3CBD0'), f3('#86A6A8'), f3('#2E7D7A')],
    heatmap: { cold: f3('#4F7FA6'), amb: f3('#8E99A2'), warm: f3('#E6AE7E'), hot: f3('#D9824A'), vhot: f3('#BB5C33') },
    heatLayer: { cold: f3('#4F7FA6'), w0: f3('#E7B07F'), w1: f3('#D9824A'), w2: f3('#B5552F') },
    sweep: f3('#2E7D7A'), packet: f3('#2E7D7A'), linePacket: f3('#24625F'), additive: false, heatAdditive: false, tileA: .56,
  },
  clay: {
    col: { wallExt: '#D3D8DC', wallInt: '#CCD2D6', column: '#C3C9CE', beam: '#B9C0C6', slab: '#BCC3C9', stair: '#B3BAC0', balcony: '#CFD4D8', parapet: '#CDD2D6',
      plinth: '#8E979F', tank: '#8EA2B2', door: '#9C8A80', debris: '#A3ABB2', debrisSlab: '#B1B8BE', site: '#A6AFB7', neighbour: '#C4CBD1', kerb: '#8E979F' },
    dim: '#BAC2C9', frame: '#E3E7EA', ground: '#A9B3BB', yard: '#B5BEC5', street: '#8C969E', pave: '#AFB8BF', marks: '#DCE2E6', winBase: '#C3CBD1', winGlass: '#7E8993',
    trunk: '#7E7773', crown: '#94A1A1', van: '#E4E8EB', vanStripe: '#B85C55', mast: '#C3C9CE', mastHead: '#2E7D7A', table: '#D6DBDF', legs: '#7E8890', laptop: '#4E5A64', screen: '#8FC0BE',
    crate: '#C9B8A2', rescuer: '#C9B8A2', rescuerHead: '#D0A24C', squared: false, pad: '#7E8890', ring: '#2E7D7A', beacon: '#D0A24C', prop: { color: '#C6CDD3', mix: .35 }, crack: [.24, .28, .32], cable: [.2, .24, .28],
  },
  sky: { top: '#9FB0C0', horizon: '#C9D3DB', fog: '#BCC7D0', fogDensity: 0.006, glow: .5, sun: { dir: [-.62, .34, .5], color: '#F4E9DA', intensity: 1.3 }, hemi: { sky: '#D8E1E8', ground: '#8F9BA6', intensity: 1.2 } },
  look: { exposure: .98, sat: 1.0, bloom: .14, bloomThreshold: .95, vig: '#5A6A78', vigAmt: .14, shadowRadius: 5 },
  chart: { paper: '#1F2A33', faint: 'rgba(31,42,51,.62)', grid: 'rgba(31,42,51,.14)', well: 'rgba(31,42,51,.1)', bar: 'rgba(31,42,51,.08)', band: 'rgba(31,42,51,.05)', dash: 'rgba(31,42,51,.28)' },
  poster: { sky: ['#9FB0C0', '#C9D3DB', '#AEBAC4'], ground: '#97A2AB', facade: '#D9DEE2', floor: '#B9C0C6', win: '#6E7A85', parapet: '#CDD2D6', rubble: ['#A3ABB2', '#8E979F', '#B1B8BE'], crushed: '#BCC3C9', bay: '#8E979F', slab: '#BCC3C9', mark: 'rgba(184,92,85,.9)', drone: 'rgba(46,125,122,.9)' },
};

// What differs from the brief's hexes, and why:
//  - every theme gives each accent a darker (light themes) or lighter (dark themes) text variant, *Txt and *On, so text
//    in that colour passes WCAG AA on the panels; the brief's hex stays the fill colour of chips, tiles and charts
//  - overcast and bluedawn: the change map's "added" is a step lighter than the brief (#656994 for #5B5F8A, #946482 for
//    #8A5A78) and the debris voxels lighter still: at the brief's value the moved slabs read as near-black stripes
//    under the soft key light
//  - graphite: the clay of the walls a step lighter (#5F646B for #5A5F66) so the facades separate from a #2C2F33
//    ground under sodium light; the swarm teal #8EC3C0 is kept for the swarm, but the phi_wall ramp tops out at a
//    darker #5A817E, since #8EC3C0 painted over whole walls glowed on the dark scene; "never seen" is a dark grey
//    #6F6D69 (the brief's muted grey hatch)
//  - graphite's accent (the chapter labels, the playhead's chapter, the clock note) is the sodium #D9A55B, and its
//    "teal" UI role (focus rings, live dots) is the sodium too: the swarm teal stays in the 3-D overlays
//  - lighting is per theme (key, fill, exposure, shadow softness), tuned on the frames in tests/themes; the brief's
//    hemisphere ground colours were lifted a little for bluedawn (#8F9BA6) and graphite (#33363B) so shadowed faces
//    keep some detail
//  - dusk: the original look, except text contrast: muted .72 -> .8, faint .48 -> .68, body .8 -> .9, the card glass
//    .62 -> .74, the haze text #8F8CC4 -> #A9A6DA, and the scene labels' backing .62 -> .7 (all now AA)
// ------------------------------------------------------------------ dusk, at another hour or place
// Five variants made from dusk itself: the same clay-diorama rendering (dusk's clay-colour multiply, no prop tint), the
// same lighting model, gradient sky and glass panels, the same pastel accents and status colours. Only the hue of the
// panels (and the view behind them), of the clay, ground and site, and the sky, fog and light colours change. A colour
// is moved by rotating its hue (and scaling its saturation), keeping its lightness, so every text and panel keeps
// dusk's contrast.
const hsl = (h) => { const [r, g, b] = f3(h), mx = Math.max(r, g, b), mn = Math.min(r, g, b), l = (mx + mn) / 2; if (mx === mn) return [0, 0, l]; const d = mx - mn, s = l > .5 ? d / (2 - mx - mn) : d / (mx + mn);
  const H = mx === r ? (g - b) / d + (g < b ? 6 : 0) : mx === g ? (b - r) / d + 2 : (r - g) / d + 4; return [H * 60, s, l]; };
const hex2 = (H, S, L) => { const k = (n) => (n + H / 30) % 12, a = S * Math.min(L, 1 - L), f = (n) => L - a * Math.max(-1, Math.min(k(n) - 3, 9 - k(n), 1)); return '#' + [f(0), f(8), f(4)].map((v) => Math.round(Math.max(0, Math.min(1, v)) * 255).toString(16).padStart(2, '0')).join('').toUpperCase(); };
const rot = (h, dh, sm = 1, dl = 0) => { const [H, S, L] = hsl(h); return hex2((H + dh + 360) % 360, Math.min(1, S * sm), Math.max(0, Math.min(1, L + dl))); };
const rotRgb = (t, dh, sm, dl) => { const [r, g, b] = t.split(',').map(Number); const h = '#' + [r, g, b].map((v) => v.toString(16).padStart(2, '0')).join(''); return rgbOf(rot(h, dh, sm, dl)); };
const rotRgba = (t, dh, sm) => t.replace(/rgba\(([^)]+)\)/, (m, a) => { const q = a.split(','); return `rgba(${rotRgb(q.slice(0, 3).join(','), dh, sm, 0)},${q[3]})`; });
function variant(id, label, { ui: U, clay: K, sky, look = {}, data = {}, uiOver = {}, poster = {} }) {
  const T = JSON.parse(JSON.stringify(dusk)); T.id = id; T.label = label;
  // the panels: the neutral (ink) colours of the UI
  // (dl darkens the panels a little where the new hue reads lighter than dusk's indigo, to keep dusk's text contrast)
  for (const k of ['fg', 'lineRgb', 'panel', 'panel2', 'bar', 'card', 'well', 'halo', 'shadow', 'shadow2', 'pick', 'hover', 'hover2']) T.ui[k] = rotRgb(dusk.ui[k], U.dh, U.sm ?? 1, ['fg', 'lineRgb'].includes(k) ? 0 : U.dl ?? 0);
  for (const k of ['ink', 'paper', 'view1', 'view2', 'night', 'dusk', 'mist']) T.ui[k] = rot(dusk.ui[k], U.dh, U.sm ?? 1, ['paper', 'mist'].includes(k) ? 0 : U.dl ?? 0);
  for (const k of ['line', 'muted', 'faint', 'glass', 'glass2', 'body']) T.ui[k] = rotRgba(dusk.ui[k], U.dh, U.sm ?? 1);
  T.ui.accent2On = T.ui.ink; T.ui.faint = T.ui.faint.replace(/,\.68\)$/, ',.74)'); Object.assign(T.ui, uiOver);
  // the clay, the ground and the site
  for (const k of Object.keys(dusk.clay.col)) T.clay.col[k] = rot(dusk.clay.col[k], K.dh, K.sm ?? 1, K.dl ?? 0);
  for (const k of ['dim', 'frame', 'ground', 'yard', 'street', 'pave', 'marks', 'winBase', 'winGlass', 'trunk', 'van', 'mast', 'table', 'legs', 'laptop', 'pad'])
    T.clay[k] = rot(dusk.clay[k], K.dh, K.sm ?? 1, (K.dl ?? 0) + (K.dlk?.[k] ?? 0));
  if (K.crown) T.clay.crown = K.crown;
  T.sky = { ...T.sky, ...sky, sun: { ...dusk.sky.sun, ...sky.sun }, hemi: { ...dusk.sky.hemi, ...sky.hemi } };
  T.look = { ...T.look, vig: T.ui.ink, ...look };
  for (const k of ['paper']) T.chart[k] = T.ui.paper;
  for (const k of ['faint', 'grid', 'well', 'bar', 'band', 'dash']) T.chart[k] = rotRgba(dusk.chart[k], U.dh, U.sm ?? 1);
  T.data.paper = T.ui.paper; Object.assign(T.data, data);
  const P = T.poster; P.sky = poster.sky || [sky.top, sky.horizon, sky.fog];
  for (const k of ['ground', 'facade', 'floor', 'win', 'parapet', 'crushed', 'bay', 'slab']) P[k] = rot(dusk.poster[k], K.dh, K.sm ?? 1, K.dl ?? 0);
  P.rubble = dusk.poster.rubble.map((c) => rot(c, K.dh, K.sm ?? 1, K.dl ?? 0));
  return T;
}
// first light: rose to lilac, blush clay, plum-ink glass
const dawnrose = variant('dawnrose', 'Dawn rose', {
  ui: { dh: 62, sm: .8, dl: -.015 }, clay: { dh: 16, sm: 1.3, dl: .025, dlk: { ground: .05, street: .05, yard: .04, pave: .04 } }, look: { exposure: 1.06, vigAmt: .15 },
  sky: { top: '#B7A3CF', horizon: '#E9C7C9', fog: '#DCC2CC', fogDensity: 0.0062, glow: .55, sun: { dir: [-.6, .36, .5], color: '#FFDCD2', intensity: 1.15 }, hemi: { sky: '#F6E6EE', ground: '#9A849E', intensity: 1.02 } },
});
// a sea-green dusk: teal-blue sky, mint-grey clay, deep teal glass; the swarm a lighter, cooler aqua so it stays
// distinct from the sky
const seaglass = variant('seaglass', 'Sea glass', {
  ui: { dh: -45, sm: .9, dl: -.03 }, clay: { dh: -78, sm: .62 },
  sky: { top: '#1F3A44', horizon: '#5E8C8E', fog: '#6E9496', fogDensity: 0.0065, glow: .3, sun: { dir: [.55, .55, .42], color: '#FFE8D8', intensity: 1.2 }, hemi: { sky: '#DDEDEA', ground: '#5C7A7A', intensity: 1.0 } },
  uiOver: { teal: '#9FE3EE', tealTxt: '#9FE3EE', tealOn: '#CDF3F8', tealOn2: '#DAF6FA', swarm: '#9FE3EE' },
  data: { swarm: '#9FE3EE', base: '#B4F0F6', refly: '#DAF6FA', podRing: '#9FE3EE', phi: [[.975, '#9FE3EE'], [.95, '#F6D2B1'], [.9, '#FFC36B'], [.75, '#F08A7E']], conf: [[.56, .55, .77], [.96, .82, .69], [.62, .89, .93]], sweep: [.66, .9, .94], packet: [.62, .93, .96] },
});
// a muted green-grey evening: sage clay, moss-ink glass
const sage = variant('sage', 'Sage', {
  ui: { dh: -90, sm: .55, dl: -.025 }, clay: { dh: -138, sm: .55 },
  sky: { top: '#2E3A36', horizon: '#7C8F84', fog: '#8B9C92', fogDensity: 0.0065, glow: .3, sun: { dir: [.55, .6, .42], color: '#FFEAD6', intensity: 1.15 }, hemi: { sky: '#E6ECE4', ground: '#646F68', intensity: 1.0 } },
});
// a deeper, warmer mauve twilight than dusk: mauve clay, plum glass
const plum = variant('plum', 'Plum', {
  ui: { dh: 52, sm: .95 }, clay: { dh: 22, sm: 1.45, dl: -.03, dlk: { ground: -.07, street: -.06, yard: -.05, pave: -.05 } }, look: { exposure: .97, vigAmt: .3 },
  sky: { top: '#3A2440', horizon: '#8E6C93', fog: '#957598', fogDensity: 0.007, glow: .35, sun: { dir: [.55, .55, .42], color: '#FFD6C2', intensity: 1.1 }, hemi: { sky: '#EED8E6', ground: '#5C4262', intensity: .96 } },
});
// a low golden sun on a lavender sky: sand-lilac clay, deep indigo glass (dusk's panels)
const goldhour = variant('goldhour', 'Golden hour', {
  ui: { dh: 0 }, clay: { dh: 12, sm: 1.1, dl: .025 }, look: { exposure: 1.1, vigAmt: .16, sat: 1.06 },
  sky: { top: '#B9A6D8', horizon: '#E8C9A8', fog: '#E2C8B6', fogDensity: 0.0055, glow: .75, sun: { dir: [.7, .3, .45], color: '#FFDDB2', intensity: 1.3 }, hemi: { sky: '#F0E6F0', ground: '#857590', intensity: 1.0 } },
});
// ------------------------------------------------------------------ graphite, softened
// graphite's dark neutral panels and warm accent, but a softer scene: lighter mid-grey clay so the model keeps its
// detail, a gentler key light with wide soft shadows, more fill, a lifted haze for depth, and muted copper for the
// change map. Each is graphite deep-merged with the values below.
const merge = (a, b) => { const o = Array.isArray(a) ? [...a] : { ...a }; for (const [k, v] of Object.entries(b)) o[k] = v && typeof v === 'object' && !Array.isArray(v) && a[k] && typeof a[k] === 'object' && !Array.isArray(a[k]) ? merge(a[k], v) : v; return o; };
const fromGraphite = (id, label, over) => merge(JSON.parse(JSON.stringify(graphite)), { id, label, ...over });
// the same warm work-light mood as graphite, gentler
const softgraphite = fromGraphite('softgraphite', 'Soft graphite', {
  data: { noentry: '#C27668', post: '#CFA88E', added: '#B99178', debris: '#A58370', fill: '#8E7464', phi: [[.975, '#6E9693'], [.94, '#5E7472'], [.86, '#55595F']] },
  clay: {
    col: { wallExt: '#8A8E94', wallInt: '#82868C', column: '#7B7F85', beam: '#767A80', slab: '#7A7E84', stair: '#71757B', balcony: '#83878D', parapet: '#82868C',
      plinth: '#595D62', tank: '#69737D', door: '#7D6E63', debris: '#6C6F74', debrisSlab: '#767A7F', site: '#595C61', neighbour: '#53565B', kerb: '#4E5156' },
    dim: '#43464B', frame: '#959AA1', ground: '#404348', yard: '#46494E', street: '#393C40', pave: '#43464B', marks: '#55585D', winBase: '#5E6268', winGlass: '#4A4D52',
    trunk: '#4E4742', crown: '#5E6860', van: '#82858A', mast: '#7E8288', table: '#777B81', legs: '#4E5156', laptop: '#383A3E', crate: '#8E7E6A', rescuer: '#9E8B74', pad: '#4A4D52', prop: { color: '#72767C', mix: .5 },
  },
  sky: { top: '#26292E', horizon: '#5C5F64', fog: '#505358', fogDensity: 0.0068, glow: .3, sun: { dir: [-.38, .62, .56], color: '#F2CB98', intensity: 1.6 }, hemi: { sky: '#B3BCC6', ground: '#4A4D52', intensity: 2.2 } },
  look: { exposure: 1.12, sat: .97, bloom: .1, bloomThreshold: .94, vig: '#121417', vigAmt: .18, shadowRadius: 9, grain: .003 },
  poster: { sky: ['#24272C', '#4B4E53', '#3A3D42'], ground: '#404348', facade: '#8A8E94', floor: '#767A80', win: '#4A4D52', parapet: '#82868C', rubble: ['#6C6F74', '#63666B', '#767A7F'], crushed: '#767A80', bay: '#43464B', slab: '#7A7E84' },
});
// cool blue-grey, moonlit: ice accent, warm apricot for what changed
const slate = fromGraphite('slate', 'Slate', {
  names: { base: 'ice blue', post: 'apricot', added: 'apricot', empty: 'steel blue' },
  ui: {
    ink: '#13171C', paper: '#E3E8EE', fg: '227,232,238', lineRgb: '227,232,238', panel: '23,28,35', panel2: '29,35,43', bar: '16,20,25', card: '26,31,39', well: '14,17,22', halo: '9,11,14', pick: '38,45,54', hover: '40,47,57', hover2: '40,47,57',
    view1: '#2A3139', view2: '#1B2027', night: '#1E242B', dusk: '#3A434D', mist: '#CCD5DE', apricot: '#E3B07E', apricotTxt: '#E8BC90',
    line: 'rgba(227,232,238,.12)', muted: '#AEB7C1', faint: '#97A1AC', glass: 'rgba(23,28,35,.82)', glass2: 'rgba(29,35,43,.9)', body: 'rgba(227,232,238,.86)',
    teal: '#9FD0DD', tealTxt: '#A9D6E2', tealOn: '#D6EEF4', tealOn2: '#C3E5EE',
    caution: '#E3B07E', cautionTxt: '#E8BC90', cautionOn: '#F5DCC2',
    lav: '#8FA8C4', lavTxt: '#A8BDD4', lavOn: '#D3DFEC', rose: '#D29C7C', roseTxt: '#DDAE92', roseOn: '#F2D6C6',
    swarm: '#9FD0DD', post: '#D9A887', accent2: '#E3B07E', accent2On: '#13171C',
  },
  data: { swarm: '#9FD0DD', base: '#A9DCE6', post: '#DDAA88', added: '#C99878', debris: '#B08A72', fill: '#927866', empty: '#8FA8C4', emptyLight: '#AFC3D8', voidTruth: '#C6D5E5',
    caution: '#E3B07E', noentry: '#C27668', unseen: '#6A727C', refly: '#C9E9F0', podRing: '#9FD0DD', mid: '#7F9AA6',
    phi: [[.975, '#6F98A6'], [.94, '#5D7480'], [.86, '#545C66']], conf: [f3('#5C646E'), f3('#7393A0'), f3('#9FD0DD')], sweep: f3('#9FD0DD'), packet: f3('#9FD0DD'), linePacket: f3('#D3ECF2') },
  clay: {
    col: { wallExt: '#8F969E', wallInt: '#878E96', column: '#80878F', beam: '#7B828A', slab: '#7F868E', stair: '#767D85', balcony: '#888F97', parapet: '#878E96',
      plinth: '#5A6169', tank: '#6A7886', door: '#7A7069', debris: '#6E747B', debrisSlab: '#787E85', site: '#596068', neighbour: '#525961', kerb: '#4D535B' },
    dim: '#40464E', frame: '#9AA2AB', ground: '#3C4249', yard: '#42484F', street: '#353A41', pave: '#3F454C', marks: '#535A62', winBase: '#5C636B', winGlass: '#484E56',
    trunk: '#4A4643', crown: '#596560', van: '#848B92', vanStripe: '#C97A6A', mast: '#80878F', mastHead: '#9FD0DD', table: '#7A8188', legs: '#4D535B', laptop: '#363B41', screen: '#8FC4D0',
    crate: '#8C7F70', rescuer: '#9A8B78', rescuerHead: '#E3B07E', pad: '#484E56', ring: '#9FD0DD', beacon: '#E3B07E', prop: { color: '#757C84', mix: .5 },
  },
  sky: { top: '#1C2430', horizon: '#586676', fog: '#4D5967', fogDensity: 0.007, glow: .28, sun: { dir: [.32, .74, .46], color: '#DCE6F2', intensity: 1.5 }, hemi: { sky: '#B7C5D4', ground: '#444B54', intensity: 2.2 } },
  look: { exposure: 1.1, sat: .98, bloom: .1, bloomThreshold: .94, vig: '#0E1216', vigAmt: .18, shadowRadius: 9, grain: .003 },
  chart: { conf: ['#6A727C', '#7F9AA6', '#9FD0DD'], paper: '#E3E8EE', faint: 'rgba(227,232,238,.55)', grid: 'rgba(227,232,238,.12)', well: 'rgba(227,232,238,.13)', bar: 'rgba(227,232,238,.09)', band: 'rgba(227,232,238,.05)', dash: 'rgba(227,232,238,.25)' },
  poster: { sky: ['#1A2028', '#4E5965', '#3A434D'], ground: '#3C4249', facade: '#8F969E', floor: '#7B828A', win: '#484E56', parapet: '#878E96', rubble: ['#6E747B', '#656B72', '#787E85'], crushed: '#7B828A', bay: '#40464E', slab: '#7F868E', mark: 'rgba(221,170,136,.95)', drone: 'rgba(159,208,221,.9)' },
});
// an architect's plaster model in a dark studio: pale warm-grey clay, soft light from above, charcoal set
const studio = fromGraphite('studio', 'Studio', {
  data: { noentry: '#C27668', post: '#C99A7C', added: '#B88A6E', debris: '#A27C66', fill: '#8A6E5E', phi: [[.975, '#6F9895'], [.94, '#617774'], [.86, '#5A5D61']] },
  clay: {
    col: { wallExt: '#C9C5BD', wallInt: '#C1BDB5', column: '#BAB6AE', beam: '#B4B0A8', slab: '#B8B4AC', stair: '#AEAAA2', balcony: '#C4C0B8', parapet: '#C1BDB5',
      plinth: '#76736E', tank: '#8A9298', door: '#968679', debris: '#A29E97', debrisSlab: '#ADA9A2', site: '#595B5E', neighbour: '#505255', kerb: '#4A4C4F' },
    dim: '#424447', frame: '#D4D0C9', ground: '#3F4144', yard: '#46484B', street: '#37393C', pave: '#424447', marks: '#525457', winBase: '#5A5C5F', winGlass: '#4A4C4F',
    trunk: '#4C4642', crown: '#5C635C', van: '#9C9994', mast: '#9A9690', table: '#8E8A84', legs: '#4C4E51', laptop: '#38393C', crate: '#958672', rescuer: '#A69580', pad: '#46484B', prop: { color: '#8C8984', mix: .55 },
  },
  sky: { top: '#1A1B1D', horizon: '#444548', fog: '#3B3D40', fogDensity: 0.0072, glow: .2, sun: { dir: [.3, .62, .5], color: '#FFF7EC', intensity: 1.15 }, hemi: { sky: '#DAD8D4', ground: '#3F4144', intensity: 1.5 } },
  look: { exposure: 1.0, sat: .92, bloom: .08, bloomThreshold: .95, vig: '#0C0D0E', vigAmt: .22, shadowRadius: 11, grain: .003 },
  poster: { sky: ['#1A1B1D', '#444548', '#2E2F32'], ground: '#3F4144', facade: '#C9C5BD', floor: '#B4B0A8', win: '#5A5C5F', parapet: '#C1BDB5', rubble: ['#A29E97', '#97938C', '#ADA9A2'], crushed: '#B4B0A8', bay: '#424447', slab: '#B8B4AC' },
});
// a lit work site at night: pale concrete under a warm work light with a cool fill, set against a dark blue-grey site.
// Value plan: the building is the brightest large thing on screen; the site, neighbours and sky sit well below it, so
// the building separates from them; the warm key and cool fill model every wall and slab. Overlays blend normally
// (no additive glow, almost no bloom) in clear, mid-value colours, so they read against pale clay without glowing.
const worklight = fromGraphite('worklight', 'Work light', {
  names: { base: 'teal', post: 'copper', added: 'copper', empty: 'blue' },
  ui: {
    ink: '#14171B', panel: '22,25,30', panel2: '28,31,37', bar: '15,17,21', card: '25,28,33', well: '13,15,18', pick: '37,41,47', hover: '39,43,49', hover2: '39,43,49',
    teal: '#E2A84F', tealTxt: '#E8B868', tealOn: '#F4DDB2', tealOn2: '#ECC98C', apricot: '#E2A84F', apricotTxt: '#E8B868',
    safe: '#5AA88A', safeTxt: '#74C2A3', safeOn: '#CDEEDF',
    caution: '#D9A54E', cautionTxt: '#E6B868', cautionOn: '#F6DDB0',
    heat: '#EE8A3A', heatTxt: '#F29E5C', heatOn: '#FAD2B2',
    danger: '#C9675B', dangerTxt: '#E38677', dangerOn: '#F6C8C1', dangerOn2: '#F6C8C1',
    lav: '#7A93CC', lavTxt: '#9DB2E4', lavOn: '#D4DEF7', rose: '#D9845C', roseTxt: '#E6A07E', roseOn: '#F6D4C3',
    swarm: '#4FB8C6', post: '#D9845C', accent2: '#E2A84F', accent2On: '#14171B',
  },
  data: {
    swarm: '#4FB8C6', base: '#56BCC8', post: '#D3967A', added: '#C08468', debris: '#BD7150', fill: '#D6A285', empty: '#8899C0', emptyLight: '#A9B7D8', voidTruth: '#BCCAEC',
    safe: '#5AA88A', caution: '#D9A54E', noentry: '#C9675B', unseen: '#7D838B', hot: '#EE8A3A', cold: '#4F8FD6', mid: '#9AA8B0', paper: '#ECE9E3', refly: '#8FDDE6', podBody: '#E5DED2', podRing: '#4FB8C6',
    phi: [[.975, '#A8C4C4'], [.95, '#CFCBC0'], [.9, '#D9A54E'], [.75, '#C9675B']],
    conf: [f3('#7D838B'), f3('#C9A46A'), f3('#4FB8C6')],
    heatmap: { cold: f3('#4F8FD6'), amb: f3('#59606A'), warm: f3('#F0B07A'), hot: f3('#EE8A3A'), vhot: f3('#D2563A') },
    heatLayer: { cold: f3('#4F8FD6'), w0: f3('#F2B277'), w1: f3('#EE8A3A'), w2: f3('#D2563A') },
    sweep: f3('#4FB8C6'), packet: f3('#4FB8C6'), linePacket: f3('#2E8E9B'), additive: false, heatAdditive: false, tileA: .56,
  },
  clay: {
    col: { wallExt: '#D9D5CE', wallInt: '#CFCBC4', column: '#C6C2BB', beam: '#BFBBB4', slab: '#C3BFB8', stair: '#B8B4AD', balcony: '#D3CFC8', parapet: '#D0CCC5',
      plinth: '#8B8984', tank: '#8E99A3', door: '#9C8A7C', debris: '#A9A59E', debrisSlab: '#B5B1AA', site: '#30353B', neighbour: '#3E444B', kerb: '#2A2E33' },
    dim: '#5E636A', frame: '#E4E0D9', ground: '#1D2126', yard: '#262A30', street: '#181B1F', pave: '#22262B', marks: '#3E434A', winBase: '#4E545C', winGlass: '#2A2F35',
    trunk: '#4A433E', crown: '#4F5E52', van: '#D5D2CC', vanStripe: '#C9675B', mast: '#BDB9B2', mastHead: '#4FB8C6', table: '#B5B1AA', legs: '#4A4F55', laptop: '#2C3035', screen: '#7FD0D8',
    crate: '#B39572', rescuer: '#C2A27A', rescuerHead: '#E2A238', pad: '#3A3F45', ring: '#4FB8C6', beacon: '#E2A238', prop: { color: '#C4C0B9', mix: .5 }, crack: [.2, .19, .19], cable: [.14, .14, .15],
  },
  sky: { top: '#161B22', horizon: '#3A4350', fog: '#2C343E', fogDensity: 0.0064, glow: .2, sun: { dir: [.42, .7, .48], color: '#FFF0DC', intensity: 1.55 }, hemi: { sky: '#B4C4D6', ground: '#6A6F76', intensity: 1.35 } },
  look: { exposure: 1.0, sat: 1.05, bloom: .05, bloomThreshold: .98, vig: '#0B0D10', vigAmt: .2, shadowRadius: 6, grain: .004 },
  chart: { conf: ['#7D838B', '#C9A46A', '#4FB8C6'] },
  poster: { sky: ['#161B22', '#3A4350', '#272E37'], ground: '#2E3339', facade: '#D9D5CE', floor: '#BFBBB4', win: '#3C434B', parapet: '#D0CCC5', rubble: ['#A9A59E', '#9F9B94', '#B5B1AA'], crushed: '#BFBBB4', bay: '#5A5F66', slab: '#C3BFB8', mark: 'rgba(201,103,91,.95)', drone: 'rgba(79,184,198,.95)' },
});
export const THEMES = { dusk, overcast, graphite, bluedawn, dawnrose, seaglass, sage, plum, goldhour, softgraphite, slate, studio, worklight };
export const THEME_IDS = Object.keys(THEMES);
export const getTheme = (id) => THEMES[id] || THEMES.dusk;

// the CSS custom properties of a theme (set on the .a7 root)
export function cssVars(T) {
  const u = T.ui, v = {};
  const put = (k, x) => { v[`--${k}`] = x; };
  put('ink', u.ink); put('paper', u.paper); put('fg-rgb', u.fg); put('line-rgb', u.lineRgb); put('panel-rgb', u.panel); put('panel2-rgb', u.panel2); put('bar-rgb', u.bar); put('card-rgb', u.card);
  put('well-rgb', u.well); put('halo-rgb', u.halo); put('shadow-rgb', u.shadow); put('shadow2-rgb', u.shadow2); put('pick-rgb', u.pick); put('hover-rgb', u.hover); put('hover2-rgb', u.hover2);
  put('view1', u.view1); put('view2', u.view2); put('night', u.night); put('dusk', u.dusk); put('mist', u.mist); put('apricot', u.apricot); put('apricot-txt', u.apricotTxt);
  put('line', u.line); put('muted', u.muted); put('faint', u.faint); put('glass', u.glass); put('glass2', u.glass2); put('body', u.body);
  for (const c of ['teal', 'safe', 'caution', 'heat', 'danger', 'lav', 'haze', 'rose']) {
    put(c, u[c]); put(`${c}-rgb`, rgbOf(u[c])); put(`${c}-txt`, u[`${c}Txt`]); put(`${c}-on`, u[`${c}On`]); if (u[`${c}On2`]) put(`${c}-on2`, u[`${c}On2`]);
  }
  put('lab-a', u.labA ?? .62); put('swarm', u.swarm); put('swarm-rgb', rgbOf(u.swarm)); put('post', u.post); put('accent2', u.accent2); put('accent2-on', u.accent2On);
  return v;
}
export const cssVarText = (T) => Object.entries(cssVars(T)).map(([k, x]) => `${k}:${x};`).join(' ');
export function applyTheme(el, T) { for (const [k, x] of Object.entries(cssVars(T))) el.style.setProperty(k, x); el.dataset.theme = T.id; }
