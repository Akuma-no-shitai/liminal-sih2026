// LIMINAL Act 7: what's left standing. After the search: the ground station compares the new scans with the survey made
// before the disaster and judges the building. Each run simulates a collapse (one of three failure modes, seeded),
// scans it, runs the whole pipeline in time slices (registration, change map, debris, wall condition, pockets, routes,
// thermal, pods, confidence) and scores it against the known truth; then plays it back as a directed film with
// chapters, captions, lenses, live cards and a director camera the viewer can take over.
//   createAct7(host, opts) -> { play, pause, resume, destroy, mode(id, {seed}), seek, chapter, speed, lens, aftershock(),
//     director(), takeCamera(), showPicker(), state, renderNow(settle), frameStats() }
//   opts: { base: 'assets/', onExit(), onLab(id), onNext(), music, start, seed, quality, onReady(), test, theme }
//     theme: 'worklight' (default) | 'graphite' | 'slate' | 'softgraphite' | 'studio' | 'dusk' | 'dawnrose' | 'seaglass' | 'sage' | 'plum' | 'goldhour' (dusk at another hour) | 'overcast' | 'bluedawn' (see theme.js)
import * as THREE from 'three';
import { GLTFLoader } from 'three/addons/loaders/GLTFLoader.js';
import { MeshoptDecoder } from 'three/addons/libs/meshopt_decoder.module.js';
import { CSS } from './style.js';
import { createScore } from './score.js';
import { createRenderer } from './engine/renderer.js';
import { createDirector } from './engine/director.js';
import { createLenses, LENSES, LAYERS } from './engine/lenses.js';
import { buildWorld } from './engine/world.js';
import { createLayers, m4 } from './engine/layers.js';
import { createDock } from './ui/dock.js';
import { createCaptions } from './ui/captions.js';
import { createCards } from './ui/cards.js';
import { createLabels } from './ui/labels.js';
import { createPicker, createModeMenu, createSimOverlay, MODE_META, MODE_IDS } from './ui/picker.js';
import { createReport } from './ui/report.js';
import { createRoomCard } from './ui/roomcard.js';
import { createClock } from './ui/groundstation.js';
import { buildScript, mmss, behaviourLevel } from './film/script.js';
import { runCase, afterStatuses } from './pipe/run.js';
import { aftershock as nextShock } from './pipe/pods.js';
import { PASSES } from './pipe/thermal.js';
import { getTheme, applyTheme } from './theme.js';

const ICON = {
  note: '<svg viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.4" stroke-linecap="round" stroke-linejoin="round"><path d="M6 12V3.5l7-1.5v8.5"/><circle cx="4.3" cy="12" r="1.7"/><circle cx="11.3" cy="10.5" r="1.7"/></svg>',
  back: '<svg viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"><path d="M10 3 5 8l5 5"/></svg>',
  swipe: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"><path d="M9 7l-5 5 5 5M15 7l5 5-5 5"/></svg>',
  shock: '<svg viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><path d="M1 9h3l1.5-4 2.5 8 2-6 1.5 2H15"/></svg>',
};
const WORD = { safe: 'safe', caution: 'caution', noentry: 'no entry', unseen: 'never seen' };
const LENS_CARDS = { scans: ['reg'], change: ['change'], debris: ['debris'], condition: ['phi'], order: ['phi', 'xi'], pockets: ['pockets'], routes: ['routes'], thermal: ['thermal'], confidence: ['conf'], truth: ['score'] };
const m3 = (v) => (v >= 100 ? `${Math.round(v)} m³` : `${v.toFixed(1)} m³`);
const pct = (v) => `${Math.round(v * 100)} %`;
const ease = (x) => { x = Math.max(0, Math.min(1, x)); return x * x * (3 - 2 * x); };

export async function createAct7(host, opts = {}) {
  const base = opts.base || 'assets/';
  if (!document.getElementById('a7css')) { const st = document.createElement('style'); st.id = 'a7css'; st.textContent = CSS; document.head.appendChild(st); }
  const PH = matchMedia('(max-width: 760px)').matches;
  const TEST = !!opts.test;
  const THEME = getTheme(opts.theme || 'worklight');
  const h = (tag, cls, html) => { const e = document.createElement(tag); if (cls) e.className = cls; if (html != null) e.innerHTML = html; return e; };
  const exitAct = () => { if (opts.onExit) opts.onExit(); else if (history.length > 1) history.back(); };
  const onLab = (id) => { if (opts.onLab) opts.onLab(id); else toast(`Opens the swarm lab: ${id}`); };

  // ------------------------------------------------------------------ DOM
  const root = h('div', 'a7 nomis' + (TEST ? ' test' : '')); root.tabIndex = -1; root.setAttribute('role', 'region'); root.setAttribute('aria-label', 'Act 7: what’s left standing');
  const view = h('div', 'a7view'), canvas = h('canvas'), labelsEl = h('div', 'a7labels');
  // the before / after swipe: drag the handle (mouse or touch); the survey shows left of the divider, today right of it
  const swipeEl = h('div', 'a7swipe', `<i class="ln"></i><span class="lb l"><i style="background:var(--swarm)"></i>Survey, before</span><span class="lb r"><i style="background:var(--post)"></i>Today</span><button class="hd" type="button" aria-label="Drag to compare the survey with the building today" data-hint="Drag to compare">${ICON.swipe}</button>`);
  view.append(canvas, labelsEl, swipeEl);
  const top = h('header', 'a7top', `<div class="a7brand">LIMINAL <i>Act 7, what’s left standing</i></div><div class="a7mis"></div><span class="sp"></span>
    <button class="a7pill a7mus" type="button" data-a="music" aria-pressed="false" title="Music">${ICON.note}<span class="hideS">Music</span></button>
    <button class="a7pill" type="button" data-a="exit">${ICON.back}<span class="hideS">Back to the story</span><span class="showS">Back</span></button>`);
  const chip = h('div', 'a7chipsim', '<i></i>Simulated collapse, scored against known ground truth');
  const clockEl = h('div'), floorsEl = h('div', 'a7floors'), togEl = h('div', 'a7tog');
  const capEl = h('div', 'a7cap'); capEl.setAttribute('aria-live', 'polite');
  const cardsEl = h('div', 'a7cards'), dockEl = h('div', 'a7dock'), roomEl = h('div');
  const pickEl = h('div'), simEl = h('div'), repEl = h('div'), toastEl = h('div', 'a7toast');
  root.append(view, top, chip, clockEl, floorsEl, togEl, capEl, cardsEl, dockEl, roomEl, repEl, simEl, pickEl, toastEl);
  applyTheme(root, THEME);
  host.appendChild(root);
  let toastT = 0; function toast(s) { toastEl.textContent = s; toastEl.classList.add('on'); clearTimeout(toastT); toastT = setTimeout(() => toastEl.classList.remove('on'), 2600); }

  // ------------------------------------------------------------------ engine
  const R = createRenderer(canvas, { phone: PH || opts.quality === 'low', preserve: TEST }); R.renderer.setClearColor(THEME.sky.fog, 1);   // 'low': smaller shadow map, less MSAA
  const onLost = (e) => { e.preventDefault(); toast('The graphics were reset. One moment…'); };
  canvas.addEventListener('webglcontextlost', onLost);
  const { scene, camera, renderer } = R;
  let props = null;
  try { const gl = new GLTFLoader(); gl.setMeshoptDecoder(MeshoptDecoder); props = (await gl.loadAsync(base + 'props.glb')).scene; } catch (e) { props = null; console.warn('[act7] props.glb did not load; using simple shapes', e && e.message); }
  const lenses = createLenses();
  const labels = createLabels(labelsEl);
  const director = createDirector(camera, canvas, { phone: PH, onTake: (u) => dock.setUser(u), onCut: (lv) => { dirLevel = lv; if (userLevel === undefined) applyCut(lv); } });

  // ------------------------------------------------------------------ UI
  const captions = createCaptions(capEl);
  const shockBtn = h('button', 'a7shock', `${ICON.shock}Aftershock`); shockBtn.type = 'button'; shockBtn.hidden = true; capEl.appendChild(shockBtn);
  shockBtn.addEventListener('click', () => doShock());
  const cards = createCards(cardsEl, { onLab, phone: PH, theme: THEME });
  const idleEl = h('div', 'idle', '<h4></h4><p>The cards for each step appear here as the film reaches it.</p>'); cardsEl.appendChild(idleEl);
  const clock = createClock(clockEl);
  const dock = createDock(dockEl, {
    onPlay: () => (playing ? pause() : play()), onSpeed: (s) => setSpeed(s), onSeek: (p) => seek(p), onLens: (l) => setLens(l),
    onDirector: () => { if (director.user) director.giveBack(); else toast('The director has the camera. Drag the view to take over.'); },
    onShock: () => doShock(), onStep: (d) => seek(P + d), onScrub: (on) => { scrubbing = on; },
  });
  const picker = createPicker(pickEl, { onPick: (id) => start(id), onSurprise: () => surprise(), theme: THEME });
  const menu = createModeMenu(top.querySelector('.a7mis'), { onPick: (id) => start(id), onSurprise: () => surprise() });
  const simOv = createSimOverlay(simEl);
  const report = createReport(repEl, { hasNext: !!opts.onNext, onNext: () => opts.onNext && opts.onNext(), onReplay: () => { report.hide(); seek(0); play(); }, onPicker: () => { report.hide(); showPicker(); }, onBack: exitAct });
  const roomCard = createRoomCard(roomEl, { onClose: () => root.classList.remove('roomopen') });
  top.querySelector('[data-a="exit"]').addEventListener('click', exitAct);
  const music = createScore('countdown'), musB = top.querySelector('[data-a="music"]');
  const paintMus = () => { musB.classList.toggle('on', music.on); musB.setAttribute('aria-pressed', String(music.on)); const t = musB.querySelector('span'); if (t) t.textContent = music.on ? 'Music on' : 'Music off'; };
  musB.addEventListener('click', () => { music.on ? music.stop() : music.start(); paintMus(); });
  if (opts.music) { try { music.start(); } catch (e) { /* audio may need a gesture */ } } paintMus();
  // floors: the cutaway control (Auto follows the director)
  floorsEl.innerHTML = '<div class="k">Floors</div>' + [['auto', 'Auto'], ['all', 'All'], ['3', '3rd'], ['2', '2nd'], ['1', '1st'], ['0', 'Gnd']].map(([v, t]) => `<button type="button" data-f="${v}" class="${v === 'auto' ? 'auto' : ''}" title="${v === 'auto' ? 'The director chooses' : v === 'all' ? 'The whole building' : 'Hide every floor above this one'}">${t}</button>`).join('');
  floorsEl.addEventListener('click', (e) => { const b = e.target.closest('[data-f]'); if (!b) return; const v = b.dataset.f; userLevel = v === 'auto' ? undefined : v === 'all' ? null : +v; applyCut(userLevel === undefined ? dirLevel : userLevel); paintFloors(); wantRender = true; });
  const paintFloors = () => floorsEl.querySelectorAll('[data-f]').forEach((b) => { const v = b.dataset.f; const on = v === 'auto' ? userLevel === undefined : userLevel !== undefined && (v === 'all' ? userLevel === null : +v === userLevel); b.classList.toggle('on', on); });
  // lens extras: cloud toggles, thermal passes, before and after the re-fly
  const tog = { base: true, post: true, pass: 2, after: true };
  let swipeUser = false, swipeX = .5, swipeTouched = -2, swipeFrozen = -2, swipeNow = null;
  function paintTog() {
    const L = lenses.current; let html = '';
    if (L === 'world' && C) html = `<span class="k">Compare</span><button type="button" data-t="swipe" class="${swipeUser ? 'on' : ''}" aria-pressed="${swipeUser}">Survey and today</button>`;
    else if (L === 'scans') html = `<span class="k">Show</span><button type="button" data-t="base" class="${tog.base ? 'on' : ''}"><span class="sw" style="background:var(--swarm)"></span>Before</button><button type="button" data-t="post" class="${tog.post ? 'on' : ''}"><span class="sw" style="background:var(--post)"></span>After</button>`;
    else if (L === 'thermal') html = `<span class="k">Thermal</span>${PASSES.map((p, i) => `<button type="button" data-t="pass" data-v="${i}" class="${tog.pass === i ? 'on' : ''}" title="${p.label}">Pass ${i + 1}</button>`).join('')}`;
    else if (L === 'confidence') html = `<span class="k">Re-fly</span><button type="button" data-t="after" data-v="0" class="${!tog.after ? 'on' : ''}">Before</button><button type="button" data-t="after" data-v="1" class="${tog.after ? 'on' : ''}">After</button>`;
    togEl.innerHTML = html; togEl.classList.toggle('on', !!html);
  }
  togEl.addEventListener('click', (e) => { const b = e.target.closest('[data-t]'); if (!b) return; const t = b.dataset.t; if (t === 'base' || t === 'post') tog[t] = !tog[t]; else if (t === 'pass') tog.pass = +b.dataset.v; else if (t === 'after') tog.after = b.dataset.v === '1'; else if (t === 'swipe') { swipeUser = !swipeUser; if (swipeUser) swipeX = .5; } paintTog(); wantRender = true; });

  // ------------------------------------------------------------------ state
  let C = null, script = null, world = null, layers = null, modeId = null, seedUsed = 0;
  let P = 0, playing = false, speed = 1, dur = 1, chapters = [], scrubbing = false, readyFired = false, loading = false, loadId = 0, destroyed = false;
  let userLevel, dirLevel = null, cutLevel = null, liveShocks = 0, liveShockAt = -1e9, statusKey = '', afterOn = null, segIdx = -1, curShot = null;
  const res = new THREE.Vector2(1, 1);
  let lastRender = -1e9, wantRender = false, capHold = 0;
  function setSpeed(s) { speed = s; dock.setSpeed(s); }
  function setLens(id) { lenses.set(id); dock.setLens(lenses.current); paintTog(); wantRender = true; if (roomCard.shown && C) roomCard.show(C, roomCard.room, { after: shockLevel() > 0, truth: lenses.current === 'truth', k: shockLevel() }); }
  setSpeed(1); setLens('world'); paintFloors();
  function applyCut(lv) { cutLevel = lv; if (world) world.cutaway(lv); if (layers) layers.setCut(lv); }
  const chapterAt = (p) => { const i = chapters.findIndex((c) => p >= c.p0 && p < c.p1); return i < 0 ? chapters.length - 1 : i; };
  const segAt = (p) => { if (!script) return -1; for (let i = 0; i < script.segs.length; i++) if (p < script.segs[i].t1) return i; return script.segs.length - 1; };
  // how many aftershocks have happened at this moment of the film (the scripted one, then the viewer's)
  const shockLevel = () => (!C ? 0 : (P >= script.shockAt || liveShocks > 0 ? 1 + liveShocks : 0));
  const roomsNow = () => { const k = shockLevel(); if (!k) return C.rooms; if (k === 1) return C.roomsAfter; return C._after[k] || C.roomsAfter; };
  const statusOf = (id) => roomsNow()[id].status;

  // ------------------------------------------------------------------ the pipeline, in slices
  const cache = new Map();            // `${mode}:${seed}` -> case (two at most)
  const newSeed = () => (TEST ? 7 : ((Math.random() * 1e6) | 0) + 1);
  const nextTask = (ms = 0) => new Promise((r) => setTimeout(r, ms));
  let loadInfo = null;
  async function compute(mode, seed, my) {
    const key = `${mode}:${seed}`; if (cache.has(key)) return { C: cache.get(key), cached: true, work: 0 };
    const gen = runCase(mode, seed); let work = 0, lastP = -1, lastT = performance.now(); const t0 = performance.now(); const budget = TEST ? 400 : 45;
    for (;;) {
      const s0 = performance.now(); let r;
      do { r = gen.next(); if (r.done) break; if (r.value.p > lastP + 1e-4) { lastP = r.value.p; lastT = performance.now(); simOv.progress(.02 + r.value.p * .96, r.value.label); } } while (performance.now() - s0 < budget);
      work += performance.now() - s0;
      if (r.done) { const c = r.value; cache.set(key, c); while (cache.size > 2) cache.delete(cache.keys().next().value); return { C: c, cached: false, work }; }
      if (performance.now() - lastT > 20000) throw new Error('the pipeline stopped making progress');
      if (performance.now() - t0 > 180000) throw new Error('the pipeline took too long');
      await nextTask(0); if (my !== loadId || destroyed) return null;
    }
  }
  function surprise() { const id = MODE_IDS[Math.floor(Math.random() * MODE_IDS.length)]; start(id, { seed: newSeed() }); }
  function showPicker() { pause(); report.hide(); (roomCard.hide(), root.classList.remove('roomopen')); if (loading) { loadId++; loading = false; simOv.hide(); } picker.show(); root.classList.toggle('nomis', true); }
  async function start(id, { seed } = {}) {
    if (!MODE_META[id]) id = MODE_IDS[0];
    const my = ++loadId; picker.hide(); report.hide(); (roomCard.hide(), root.classList.remove('roomopen')); pause(); menu.set(id); modeId = id;
    root.classList.add('nomis'); loading = true; cards.clear(); captions.set(null, '', '');
    const want = seed ?? opts.seed ?? newSeed();
    simOv.show(MODE_META[id], 'Simulating'); simOv.progress(.01, 'Starting');
    await nextTask(TEST ? 0 : 40); if (my !== loadId) return;
    const T0 = performance.now();
    for (let attempt = 0; attempt < 2; attempt++) {
      const s = attempt ? newSeed() + 1 : want;
      try {
        const out = await compute(id, s, my); if (!out || my !== loadId) return;
        simOv.progress(.99, 'Building the scene'); await nextTask(0); if (my !== loadId) return;
        const tb = performance.now(); begin(out.C);
        loadInfo = { mode: id, seed: s, pipeline: Math.round(out.work), cached: out.cached, scene: Math.round(performance.now() - tb), total: Math.round(performance.now() - T0), timings: out.C.timings };
        await nextTask(TEST ? 0 : 200); if (my !== loadId) return;
        simOv.hide(); root.classList.remove('nomis'); loading = false;
        P = 0; segIdx = -1; director.giveBack(); play();
        if (!readyFired) { readyFired = true; if (opts.onReady) opts.onReady(); }
        return;
      } catch (e) {
        console.warn(`[act7] ${id} (seed ${s}) failed:`, e);
        cache.delete(`${id}:${s}`); dropScene();
        if (my !== loadId) return;
      }
    }
    loading = false;
    simOv.fail('This collapse could not be computed here. Another seed usually works.', () => start(id, { seed: newSeed() + 2 }), () => { simOv.hide(); showPicker(); });
  }
  function dropScene() {
    if (layers) { try { layers.dispose(); } catch (e) { /* ignore */ } layers = null; }
    if (world) { scene.remove(world.group); try { world.dispose(); } catch (e) { /* ignore */ } world = null; }
    C = null; script = null; chapters = [];
  }
  function begin(c) {
    dropScene();
    C = c; P = 0; playing = false; seedUsed = c.seed; c.aftershocks.length = 1; c._after = {}; liveShocks = 0; liveShockAt = -1e9; statusKey = ''; afterOn = null; segIdx = -1; curShot = null; userLevel = undefined; paintFloors();
    for (const n of LAYERS) lenses.W[n] = 0; lenses.S.dim = 0;      // nothing carries over from the last collapse
    idleEl.querySelector('h4').textContent = MODE_META[C.mode].title; idleEl.querySelector('p').textContent = MODE_META[C.mode].line + ' The cards for each step appear here as the film reaches it.';
    world = buildWorld(C, props, { phone: PH, theme: THEME }); scene.add(world.group);
    R.setSky(world.sky, world.bounds, THEME.look);
    layers = createLayers(scene, C, world, { statusOf, theme: THEME });
    script = buildScript(C, THEME.names); chapters = script.chapters; dur = script.dur; swipeUser = false; swipeTouched = -2; swipeFrozen = -2; paintTog();
    dock.setTimeline(chapters, dur, script.events); cards.setCase(C);
    director.setScene(new THREE.Vector3(0, 5, 0), 15); director.setShot(script.segs[0].shot, { cut: true });
    applyCut(null); wantRender = true;
    // build the heavier overlays while the first chapter plays (lazily in tests)
    if (!TEST) { const order = ['base', 'post', 'packets', 'ghost', 'change', 'debris', 'arrows', 'cracks', 'order', 'rooms', 'routes', 'pockets', 'thermal', 'heat', 'behaviour', 'pods', 'confidence', 'refly', 'truth', 'truthRooms', 'voids']; const my = loadId, L = layers;
      const step = () => { if (destroyed || my !== loadId || L !== layers || !order.length) return; const n = order.shift(); try { L.ensure(n); L.setW(n, lenses.W[n] || 0); } catch (e) { /* built on demand */ } setTimeout(step, 60); }; setTimeout(step, 400); }
  }
  function play() { if (!C) return; if (P >= dur - .05) { P = 0; segIdx = -1; } report.hide(); playing = true; if (held) { held = false; running = true; last = performance.now(); } }
  function pause() { playing = false; }
  function seek(p) { if (!C) return; P = Math.max(0, Math.min(dur, p)); segIdx = -1; capHold = 0; if (P < dur - .1) report.hide(); wantRender = true; }
  let held = false, heldPlaying = false, heldMusic = false;
  function hold() { if (held) { playing = false; return; } held = true; heldPlaying = playing; playing = false; running = false; heldMusic = music.on; if (music.on) { music.stop(); paintMus(); } }
  function unhold() { running = true; last = performance.now(); if (!held) return; held = false; if (heldPlaying) play(); if (heldMusic) { music.start(); paintMus(); } }
  // the viewer's aftershock (also the A key): computed on the spot from the case, statuses updated
  function doShock() {
    if (!C || loading) return;
    if (P < script.shockAt) { seek(script.shockAt - .5); play(); return; } // the first one is the film's
    const k = C.aftershocks.length + 1; if (k > 6) { toast('Six aftershocks is enough for one building.'); return; }
    try {
      C.aftershocks.push(nextShock(C, k));
      const prev = k === 2 ? C.roomsAfter : C._after[k - 1];
      C._after[k] = afterStatuses(C.model, prev, C, C.condition, k - 1);
      liveShocks = k - 1; liveShockAt = performance.now();
      const A = C.aftershocks[k - 1], B = C.aftershocks[k - 2];
      captions.set(chapterAt(P), chapters[chapterAt(P)].title, `Aftershock ${k}: it recovers in ${A.tau.toFixed(1)} minutes, ${A.slowing ? 'slower than last time. Rooms on the moved floors close.' : `against ${B.tau.toFixed(1)} last time.`}`);
      capHold = performance.now() + 9000; wantRender = true;
      if (lenses.current === 'world' && script.segs[segAt(P)].cards.indexOf('tau') < 0) setLens('world');
    } catch (e) { console.warn('[act7] aftershock failed', e); }
  }

  // ------------------------------------------------------------------ per-frame playback
  const filmW = {}; for (const n of LAYERS) filmW[n] = 0;
  const st = { clock: 0, offload: 0, regIter: 0, reveal: 1, pass: 2, shock: 0, pod: 0, tauT: 27, after: false };
  const M = new THREE.Matrix4(), Ma = new THREE.Matrix4(), Mb = new THREE.Matrix4(), qa = new THREE.Quaternion(), qb = new THREE.Quaternion(), va = new THREE.Vector3(), vb = new THREE.Vector3(), sc1 = new THREE.Vector3(1, 1, 1), sc2 = new THREE.Vector3();
  function regMatrix(f, out) {
    // f: -1 raw scan (identity), 0 the anchor's starting guess, then iterations (fractional)
    const it = C.reg.iters;
    const T = (i) => (i < 0 ? null : i === 0 ? C.reg.start : it[Math.min(it.length - 1, i)].T);
    const i0 = Math.floor(f), k = f - i0; const A = T(i0), B = T(i0 + 1);
    if (A) m4(A, Ma); else Ma.identity(); if (B) m4(B, Mb); else Mb.identity();
    Ma.decompose(va, qa, sc2); Mb.decompose(vb, qb, sc2); va.lerp(vb, ease(k)); qa.slerp(qb, ease(k));
    return out.compose(va, qa, sc1);
  }
  let shake = 0, lastCi = -1;
  function playback(dt) {
    if (!C) return;
    if (playing && !scrubbing) { P += dt * speed; if (P >= dur) { P = dur; playing = false; onEnded(); } }
    const ci = chapterAt(P), ch = chapters[ci], si = segAt(P), sg = script.segs[si];
    if (ci !== lastCi) { if (lastCi >= 0 && roomCard.shown) { roomCard.hide(); root.classList.remove('roomopen'); } lastCi = ci; }
    // film layers for the World lens
    for (const n of LAYERS) filmW[n] = sg.layers[n] || 0; filmW.dim = sg.dim || 0;
    const B = script.beats; if (P < B.touchdown[1] && P > B.packets0) filmW.packets = 1;
    lenses.update(dt, filmW);
    const W = lenses.W;
    // clouds: the registration plays in chapter 2; otherwise the post-event cloud sits where it was registered
    const reg = P >= B.register[0] && P < B.register[1] && lenses.current === 'world' ? script.regAt(P) : C.reg.iters.length - 1; st.regIter = Math.max(0, reg + 1);
    const post = layers.get('post'); if (post) { regMatrix(reg, post.matrix); post.matrixWorldNeedsUpdate = true; }
    const wb = W.base * (lenses.current === 'scans' && !tog.base ? 0 : 1), wp = W.post * (lenses.current === 'scans' && !tog.post ? 0 : 1);
    // statuses after the aftershocks
    const key = String(shockLevel()); if (key !== statusKey) { statusKey = key; layers.reset('rooms'); }
    // apply weights
    for (const n of LAYERS) { const w = n === 'base' ? wb : n === 'post' ? wp : W[n]; layers.setW(n, w); }
    world.setDim(lenses.S.dim);
    // change-map reveal: a sweep along the building
    const cv = layers.get('change'); if (cv) { const L = C.model.dims.L; const k = P >= B.reveal0 && P < B.reveal0 + 6 && lenses.current === 'world' ? (P - B.reveal0) / 5 : 1.2; cv.U.sweep.value = k >= 1.15 ? 1e4 : -L / 2 - 3 + k * (L + 6); st.reveal = k; }
    // thermal pass
    const pass = lenses.current === 'world' && P >= B.pockets[0] && P < B.pockets[1] ? script.passAt(P) : tog.pass; st.pass = Math.round(Math.min(2, pass));
    const th = layers.get('thermal'); if (th) th.material.uniforms.pass.value = pass;
    const ht = layers.get('heat'); if (ht) ht.material.uniforms.pass.value = pass;
    // confidence before / after the re-fly
    const aft = lenses.current === 'confidence' ? tog.after : P >= script.afterAt; st.after = aft;
    const cf = layers.get('confidence'); if (cf && afterOn !== aft) { afterOn = aft; cf.userData.setAfter(aft); }
    // pods (dropped one by one)
    const pods = layers.get('pods'); if (pods) for (const m of pods.children) { const i = m.userData.pod; m.visible = P >= B.podShow + i * 1.8 || lenses.current !== 'world'; }
    // routes: with the floors cut away, only the floor in view
    const rg = layers.get('routes'); if (rg) for (const sg of rg.children) { const on = cutLevel == null || sg.userData.storey === Math.min(3, cutLevel); if (sg.visible !== on) sg.visible = on; }
    // drones, packets
    drones(P);
    const pk = layers.get('packets'); if (pk && W.packets > .01) packets(pk, P, W.packets);
    // captions
    let cap = null; for (const c of script.captions) { if (c.t <= P + .05) cap = c; else break; }
    if (performance.now() > capHold) captions.set(ci, ch.title, cap ? cap.text : '');
    // aftershock button: in the caption once the film's aftershock has played, and in the dock from then on
    const sbHide = !(P >= B.shockBtn && ch.id === 'moving' && C.aftershocks.length < 6); if (shockBtn.hidden !== sbHide) shockBtn.hidden = sbHide; dock.showShock(P >= B.shockBtn);
    // shots
    if (si !== segIdx) { segIdx = si; curShot = sg.shot; director.setShot(curShot, { cut: !!(sg.shot && sg.shot.cut) }); }
    // cards
    cards.show(lenses.current === 'world' ? sg.cards : LENS_CARDS[lenses.current] || []);
    // clock and the card state
    // the swipe: the director sweeps it once in chapter 3; the viewer can drag it, or turn it on from the World lens
    const segSwipe = !!sg.swipe && lenses.current === 'world', swOn = lenses.current === 'world' && (swipeUser || segSwipe);
    if (swOn && segSwipe && !swipeUser && swipeTouched !== si && swipeFrozen !== si) { const u = (P - sg.t0) / (sg.t1 - sg.t0); swipeX = .5 + .22 * Math.sin(u * Math.PI * 2); }
    swipeNow = swOn ? swipeX : null; paintSwipe(swOn, segSwipe && swipeTouched !== si);
    st.behav = P >= B.behav0 && P < B.behav1 && lenses.current === 'world' ? Math.min(1, (P - B.behav0) / (B.behav1 - B.behav0 - 3)) : 1;
    world.tick(clockT, camera, ch.id === 'touchdown' || lenses.current !== 'world');
    const ck = script.clockAt(P); st.clock = ck; st.offload = Math.max(0, Math.min(1, (P - B.offload0) / (B.offload1 - B.offload0)));
    const [note, warn] = script.clockNote(P); clock.set(ck, note, warn);
    st.shock = shockLevel(); st.pod = Math.floor(P / 3.5) % Math.max(1, C.pods.list.length);
    if (liveShocks > 0) st.tauT = Math.min(27, (performance.now() - liveShockAt) / 1000 * 2.4); else st.tauT = P >= script.shockAt ? Math.min(27, (ck - script.clockAt(script.shockAt)) / 60) : 0;
    // the ground shakes: the film's aftershock, then the viewer's
    const age = P - script.shockAt, lage = (performance.now() - liveShockAt) / 1000;
    shake = Math.max(age >= 0 && age < 6 ? Math.exp(-age * .9) * (age < .25 ? age / .25 : 1) * .6 : 0, lage < 6 ? Math.exp(-lage * .9) * .6 : 0);
    if (shake > .01) wantRender = true;
  }
  // drones: they land in chapter 1, one drops the pods in chapter 6, one flies the re-fly in chapter 7
  const dpos = new Float32Array(30);
  function drones(p) {
    const slots = world.padSlots, site = C.model.site; const n = 8;
    for (let i = 0; i < n; i++) {
      const s = slots[i]; const t0 = .6 + i * .55, t1 = t0 + 5.2; let x = s[0], y = s[1], z = s[2], yaw = i * .8;
      if (p < t1) { const k = ease((p - t0) / (t1 - t0)); const sx = -9 + i * 2.6, sy = 15.5 + (i % 3) * 1.4, sz = (i % 2 ? -2.5 : 3.5) + C.model.dims.D * .1; const bob = Math.sin(p * 2 + i) * .15;
        x = sx + (s[0] - sx) * k; z = sz + (s[2] - sz) * k; y = sy + (s[1] - sy) * Math.pow(k, .6) + bob * (1 - k); yaw += (1 - k) * 1.2; }
      dpos[i * 3] = x; dpos[i * 3 + 1] = y; dpos[i * 3 + 2] = z;
      world.setDrone(i, x, y, z, yaw, true);
    }
    // the pod drone (drone 0 takes off again)
    const podList = C.pods.list, B = script.beats, f0 = B.podsFly, f1 = B.podsFly + B.podsFlyLen;
    if (p >= f0 && p < f1 && podList.length) { const path = [[slots[0][0], 2.5, slots[0][2]]]; podList.forEach((pd) => path.push([pd.pos[0] + pd.normal[0] * .9, pd.pos[1] + .5, pd.pos[2] + pd.normal[2] * .9])); path.push([slots[0][0], 2.5, slots[0][2]]);
      const q = flyPath(path, (p - f0) / (f1 - f0)); world.setDrone(0, q[0], Math.max(.06, q[1] - (p > f1 - .6 ? (p - f1 + .6) * 4 : 0)), q[2], p, true); }
    const rf = C.scans.refly.poses;
    if (p >= B.refly0 && p < B.refly1 && rf.length) { const path = [[slots[1][0], 2.5, slots[1][2]], ...rf.map((q) => q.p), [slots[1][0], 2.5, slots[1][2]]]; const q = flyPath(path, (p - B.refly0) / (B.refly1 - B.refly0)); world.setDrone(1, q[0], q[1], q[2], p * .7, true); }
    world.drones.instanceMatrix.needsUpdate = true;
  }
  const fp = [0, 0, 0];
  function flyPath(path, k) { k = Math.max(0, Math.min(.9999, k)); const f = k * (path.length - 1), i = Math.floor(f), t = ease(f - i), a = path[i], b = path[i + 1]; fp[0] = a[0] + (b[0] - a[0]) * t; fp[1] = a[1] + (b[1] - a[1]) * t + Math.sin(t * Math.PI) * .6; fp[2] = a[2] + (b[2] - a[2]) * t; return fp; }
  // data packets from the landed drones to the ground-station laptop
  function packets(g, p, w) {
    const tb = world.anchors.table, slots = world.padSlots; g.begin();
    for (let j = 0; j < 36; j++) { const s = slots[j % 8]; const ph = (p * .45 + j / 36) % 1; const x = s[0] + (tb[0] - .2 - s[0]) * ph, z = s[2] + (tb[2] - s[2]) * ph, y = .3 + (tb[1] - .3) * ph + Math.sin(ph * Math.PI) * 1.1; g.add(x, y, z, ...THEME.data.packet, w * Math.sin(ph * Math.PI), .09); }
    g.end();
  }
  function onEnded() { report.show(C, { rooms: roomsNow(), k: shockLevel() }); }
  // ------------------------------------------------------------------ labels in the scene
  const tA = (T, x, y, z) => { const R2 = T.R; return [R2[0] * x + R2[1] * y + R2[2] * z + T.t[0], R2[3] * x + R2[4] * y + R2[5] * z + T.t[1], R2[6] * x + R2[7] * y + R2[8] * z + T.t[2]]; };
  function sceneLabels() {
    const r = canvas.getBoundingClientRect(); labels.begin(camera, r.width, r.height);
    if (!C || !world) { labels.end(); return; }
    const W = lenses.W, A = script.anchors, world0 = lenses.current === 'world', B = script.beats;
    // the responders' things, while the drones land
    const a0 = world0 && P >= B.packets0 ? Math.max(0, 1 - Math.max(0, P - B.labels1) / 2) : 0;
    const at = world0 && P >= B.tether0 - .5 && P < B.tether1 ? 1 : 0; if (at) { const q = world.tdrone.position; labels.add(q.x, q.y + 1.1, q.z, '<b>Tethered drone</b><small>overwatch above the anchor, powered through its cable</small>', 'apr', at, 6); }
    // the flight log: where phi_swarm fell and where the forecast missed most
    if (W.behaviour > .3) { const SW = C.swarm, y1 = behaviourLevel(SW) * 3 + 3.1; SW.drops.filter((q) => q.p[1] <= y1).slice(0, 1).forEach((q) => labels.add(q.p[0], q.p[1] + .6, q.p[2], `<b>φ_swarm ${q.phi.toFixed(2)}</b><small>the drones split up here</small>`, 'lav', Math.min(1, W.behaviour), 7)); SW.forecast.misses.filter((q) => q.p[1] <= y1).slice(0, 1).forEach((q) => labels.add(q.p[0], q.p[1] + .6, q.p[2], '<b>Forecast missed most</b><small>the swarm’s speed changed here</small>', 'rose', Math.min(1, W.behaviour), 7)); }
    if (a0 > .02) { const m = world.anchors.mast; labels.add(m[0], m[1] + .3, m[2], '<b>Anchor robot</b><small>its mast relays to the station</small>', 'apr', a0, 6); const t = world.anchors.table; labels.add(t[0], t[1] + .6, t[2], '<b>Ground station</b><small>a laptop on a folding table</small>', 'teal', a0, 6); }
    // debris
    const ad = Math.max(W.debris, world0 && P >= B.debris0 && P < B.debris1 ? 1 : 0) * (W.debris > .2 ? 1 : 0);
    if (ad > .05) labels.add(A.debris[0], A.debrisTop + .6, A.debris[2], `<b>Debris about ${m3(C.debris.estimate)}</b><small>range ${C.debris.low.toFixed(1)} to ${C.debris.high.toFixed(1)} m³</small>`, 'heat', ad, 8);
    // tilt
    if (W.arrows > .3 && A.tiltDeg > .3) labels.add(A.tiltTop[0], A.tiltTop[1] + 1.2, A.tiltTop[2], `<b>Leans ${A.tiltDeg.toFixed(1)}°</b><small>${A.leanWho.replace(/^The /, 'the ').replace(/^Everything/, 'everything')}, toward ${A.dirWord}</small>`, A.tiltDeg >= 1.6 ? 'noentry' : 'caution', Math.min(1, W.arrows), 8);
    // rooms of the level in view
    if (W.rooms > .3) {
      const lv = cutLevel != null ? Math.min(3, cutLevel) : (script.segs[segAt(P)].roomLabels ?? null);
      if (lv != null) { const rs = roomsNow(); for (const room of C.model.rooms) { if (room.storey !== lv) continue; const s = rs[room.id].status; const T = C.storeys[room.storey].T; const p = tA(T, (room.x0 + room.x1) / 2, room.y0 + .25, (room.z0 + room.z1) / 2); labels.add(p[0], p[1], p[2], `<b>${room.short}</b><small>${WORD[s]}</small>`, `room ${s}`, Math.min(1, W.rooms * 1.2), 4, 0, room.id); } }
    }
    // pockets and true voids
    if (W.pockets > .3) for (const pk of C.pockets.list.slice(0, 6)) labels.add(pk.centre[0], pk.centre[1] + .5, pk.centre[2], `<b>${pk.kind === 'gap' ? 'Seen through a gap' : 'Sheltered under a slab'}</b><small>${pk.vol.toFixed(1)} m³, confidence ${pct(pk.conf)}</small>`, 'lav', Math.min(1, W.pockets), 8);
    if (W.voids > .3) for (const v of C.truth.voids.slice(0, 6)) { const found = C.pockets.list.some((pk) => pk.truth === C.truth.voids.indexOf(v)); labels.add(v.centre[0], v.centre[1] + .4, v.centre[2], `<b>True void ${v.vol.toFixed(1)} m³</b><small>${found ? 'found' : 'missed'}</small>`, 'lav', Math.min(1, W.voids), 6); }
    // thermal
    const wt = Math.max(W.heat, W.thermal); if (wt > .3) { const ps = C.thermal.passes[st.pass];
      if (ps.hotCentre && ps.hotArea > 0.2) labels.add(ps.hotCentre[0], ps.hotCentre[1] + .8, ps.hotCentre[2], `<b>${C.thermal.spreading && st.pass === 2 ? 'Fire spreading' : 'Hot spot'}</b><small>${PASSES[st.pass].label}: ${ps.hotArea.toFixed(1)} m² hot</small>`, 'heat', Math.min(1, wt), 8);
      if (ps.coldCentre && ps.coldArea > 0.3) labels.add(ps.coldCentre[0], ps.coldCentre[1] + .8, ps.coldCentre[2], `<b>Water from the burst tank</b><small>${PASSES[st.pass].label}: ${ps.coldArea.toFixed(1)} m² cold</small>`, 'teal', Math.min(1, wt), 8); }
    // pods
    if (W.pods > .3) { const k = shockLevel(); const reads = k ? C.aftershocks[k - 1].reads : C.pods.reads; C.pods.list.forEach((pd, i) => { if (lenses.current === 'world' && P < B.podShow + i * 1.8) return; const rd = reads[i]; labels.add(pd.pos[0] + pd.normal[0] * .3, pd.pos[1] + .35, pd.pos[2] + pd.normal[2] * .3, `<b>Pod ${i + 1}</b><small>f₀ ${rd.f0.toFixed(2)} Hz${k ? `, ${Math.round(rd.stiffLoss * 100)} % stiffness lost` : ''}</small>`, k && rd.stiffLoss >= .3 ? 'noentry' : 'teal', Math.min(1, W.pods), 6); }); }
    // re-fly
    if (W.refly > .3) { const R2 = C.confidence; (R2.targets || []).slice(0, 3).forEach((t, i) => labels.add(t.c[0], t.c[1] + .5, t.c[2], i === 0 ? `<b>Re-flown target</b><small>${pct(t.before)} then ${pct(t.after)}</small>` : `<b>${pct(t.before)} then ${pct(t.after)}</b>`, 'teal', Math.min(1, W.refly), 6));
      const u = (R2.unreachable || [])[0]; if (u) labels.add(u.c[0], u.c[1] + .5, u.c[2], '<b>Can’t be reached from the air</b><small>for a human to check</small>', 'caution', Math.min(1, W.refly), 6); }
    labels.end();
  }
  // ------------------------------------------------------------------ the swipe handle
  const swHd = swipeEl.querySelector('.hd'), swLn = swipeEl.querySelector('.ln'), swL = swipeEl.querySelector('.lb.l'), swR = swipeEl.querySelector('.lb.r');
  let swShown = null, swPos = -1, swHint = null;
  function paintSwipe(on, hint) {
    if (on !== swShown) { swShown = on; swipeEl.classList.toggle('on', on); }
    if (hint !== swHint) { swHint = hint; swipeEl.classList.toggle('hint', hint); }
    if (on && Math.abs(swipeX - swPos) > 1e-4) { swPos = swipeX; const l = `${(swipeX * 100).toFixed(2)}%`; swHd.style.left = l; swLn.style.left = l; swL.style.left = l; swR.style.left = l; }
  }
  let swDrag = null;
  const swTo = (cx) => { const r = view.getBoundingClientRect(); swipeX = Math.max(.04, Math.min(.96, (cx - r.left) / Math.max(1, r.width))); swipeTouched = segAt(P); wantRender = true; };
  // the director's sweep holds still as soon as the pointer moves over the view, so the handle can be caught
  view.addEventListener('pointermove', () => { if (swShown && swHint) swipeFrozen = segAt(P); });
  // the handle and a 56 px strip along the line both grab the divider (it may be moving while the director sweeps it)
  for (const el of [swHd, swLn]) {
    el.addEventListener('pointerdown', (e) => { e.preventDefault(); e.stopPropagation(); swDrag = e.pointerId; try { el.setPointerCapture(e.pointerId); } catch (er) { /* ignore */ } swTo(e.clientX); });
    el.addEventListener('pointermove', (e) => { if (swDrag !== e.pointerId) return; e.preventDefault(); swTo(e.clientX); });
    const swEnd = (e) => { if (swDrag === e.pointerId) swDrag = null; };
    el.addEventListener('pointerup', swEnd); el.addEventListener('pointercancel', swEnd);
  }
  swHd.addEventListener('keydown', (e) => { if (e.key === 'ArrowLeft' || e.key === 'ArrowRight') { e.preventDefault(); e.stopPropagation(); swipeX = Math.max(.04, Math.min(.96, swipeX + (e.key === 'ArrowLeft' ? -.05 : .05))); swipeTouched = segAt(P); wantRender = true; } });
  // ------------------------------------------------------------------ rooms: click or tap
  const ray = new THREE.Raycaster(), ndc = new THREE.Vector2();
  function pickRoom(cx, cy) {
    if (!C) return -1; const r = canvas.getBoundingClientRect(); ndc.set((cx - r.left) / r.width * 2 - 1, -(cy - r.top) / r.height * 2 + 1); ray.setFromCamera(ndc, camera);
    const o = ray.ray.origin, d = ray.ray.direction, topLv = cutLevel == null ? 3 : Math.min(3, cutLevel); let best = -1, bt = 1e9;
    for (let s = 0; s <= topLv; s++) {
      const T = C.storeys[s].T, Rm = T.R; const ox = o.x - T.t[0], oy = o.y - T.t[1], oz = o.z - T.t[2];
      const lo = [Rm[0] * ox + Rm[3] * oy + Rm[6] * oz, Rm[1] * ox + Rm[4] * oy + Rm[7] * oz, Rm[2] * ox + Rm[5] * oy + Rm[8] * oz], ld = [Rm[0] * d.x + Rm[3] * d.y + Rm[6] * d.z, Rm[1] * d.x + Rm[4] * d.y + Rm[7] * d.z, Rm[2] * d.x + Rm[5] * d.y + Rm[8] * d.z];
      for (const room of C.model.rooms) { if (room.storey !== s || Math.abs(ld[1]) < 1e-6) continue; const t = (room.y0 + .05 - lo[1]) / ld[1]; if (t <= 0 || t >= bt) continue; const x = lo[0] + ld[0] * t, z = lo[2] + ld[2] * t; if (x >= room.x0 && x <= room.x1 && z >= room.z0 && z <= room.z1) { bt = t; best = room.id; } }
    }
    return best;
  }
  const openRoom = (id) => { if (id < 0 || !C) return; roomCard.show(C, id, { after: shockLevel() > 0, truth: lenses.current === 'truth', k: shockLevel() }); root.classList.add('roomopen'); };
  let downAt = null;
  canvas.addEventListener('pointerdown', (e) => { downAt = { x: e.clientX, y: e.clientY }; });
  canvas.addEventListener('pointerup', (e) => { if (!downAt || Math.hypot(e.clientX - downAt.x, e.clientY - downAt.y) > 6) return; downAt = null; const id = pickRoom(e.clientX, e.clientY); if (id >= 0) openRoom(id); else (roomCard.hide(), root.classList.remove('roomopen')); });
  labelsEl.addEventListener('click', (e) => { const l = e.target.closest('[data-room]'); if (l) openRoom(+l.dataset.room); });

  // ------------------------------------------------------------------ frame loop
  let raf = 0, last = performance.now(), clockT = 0, running = true, frames = 0, fpsT = 0, fps = 0, frameErr = 0;
  const prof = {};
  function frame(now) {
    raf = requestAnimationFrame(frame);
    if (!running || document.hidden) { last = now; return; }
    try { frameBody(now); } catch (e) { resetGL(); if (frameErr++ < 3) console.warn('[act7] frame failed', e); }
  }
  let offNow = 0, cardsHalf = 0, viewW = 1, viewH = 1;
  function frameBody(now) {
    // film time follows wall time at any frame rate; only a long stall (a tab switch, a hiccup) is capped
    const dtRaw = Math.min(TEST ? 1 : .4, (now - last) / 1000), dt = dtRaw; last = now; clockT += dt; frames++;
    if (now - fpsT > 1000) { fps = frames; frames = 0; fpsT = now; }
    const idle = picker.shown || loading || !C;
    if (!TEST && !idle) R.adapt(dtRaw); else if (!TEST) R.resetAdapt();
    const q0 = performance.now();
    if (C && !loading) { try { playback(dt); } catch (e) { if (frameErr++ < 3) console.warn('[act7] playback failed', e); } }
    { const goal = cards.active.length && !PH ? cardsHalf : 0; const n = offNow + (goal - offNow) * (1 - Math.exp(-dt * 1.6)); if (Math.abs(n - offNow) > .05) { offNow = n; director.setFrame(viewW, viewH, offNow, PH ? 0 : 22); } }
    director.update(dt, shake); if (world) world.fadeNeighbours(camera.position, director.tgt, TEST ? 1 : dt);
    prof.play = performance.now() - q0;
    if (!idle && (!TEST || wantRender || (playing && now - lastRender > (opts.testRenderMs ?? 2500)))) { safeDraw(); lastRender = now; wantRender = false; }
    if (C) { dock.update(P, playing, `ground station ${mmss(st.clock)}`); cards.update(st, TEST); }
    prof.frame = performance.now() - q0;
  }
  // per-frame uniforms for lines, glows and clouds (pixel sizes, time)
  function syncUniforms() {
    const dpr = R.dpr, H = R.h;
    const f = (o) => { const m = o.material; if (!m || !m.uniforms) return; const u = m.uniforms; if (u.res) u.res.value.set(R.w, R.h); if (u.time) u.time.value = clockT; if (u.hh) u.hh.value = H * dpr; if (u.px) u.px.value = dpr; };
    if (layers) layers.root.traverse(f); if (world) { f(world.cracks.mesh); f(world.cable.mesh); }
  }
  function draw() { syncUniforms(); if (world) { camera.updateMatrixWorld(); world.setSwipe(camera, swipeNow); } R.render(clockT); sceneLabels(); }
  function resetGL() { renderer.setRenderTarget(null); renderer.setScissorTest(false); renderer.setViewport(0, 0, R.w, R.h); renderer.autoClear = true; }
  function safeDraw() { try { draw(); } catch (e) { resetGL(); if (frameErr++ < 3) console.warn('[act7] frame failed', e); } }
  function resize() {
    const r = view.getBoundingClientRect(); const w = Math.max(16, r.width), hh = Math.max(16, r.height);
    R.setSize(w, hh); res.set(w * R.dpr, hh * R.dpr); viewW = w; viewH = hh;
    cardsHalf = PH ? 0 : Math.min(190, (parseFloat(getComputedStyle(root).getPropertyValue('--cards')) || 336) * .5);
    director.setFrame(w, hh, offNow, PH ? 0 : 22); dock.layout(); wantRender = true;
  }
  const ro = new ResizeObserver(resize); ro.observe(view); resize();
  raf = requestAnimationFrame(frame);
  // keys
  const typing = (t) => t && t.closest && t.closest('input, textarea, select');
  const onKey = (e) => {
    if (typing(e.target) || e.ctrlKey || e.metaKey || e.altKey) return;
    if (e.key === ' ' && C && !picker.shown) { e.preventDefault(); playing ? pause() : play(); }
    else if (e.key === 'ArrowRight' && C) seek(P + 5); else if (e.key === 'ArrowLeft' && C) seek(P - 5);
    else if (/^[0-9]$/.test(e.key) && C) { const L = LENSES.find((l) => l.key === e.key); if (L) setLens(L.id); }
    else if ((e.key === 't' || e.key === 'T') && C) setLens('truth');
    else if (e.key === 'd' || e.key === 'D') director.giveBack();
    else if ((e.key === 'a' || e.key === 'A') && C) doShock();
    else if (e.key === 'Escape') { if (menu.open) menu.close(); else if (roomCard.shown) (roomCard.hide(), root.classList.remove('roomopen')); else exitAct(); }
  };
  addEventListener('keydown', onKey);
  // start
  if (opts.start && MODE_META[opts.start]) start(opts.start, { seed: opts.seed }); else showPicker();
  root.focus({ preventScroll: true });

  const api = {
    root,
    play: () => { held = false; running = true; play(); }, pause: () => hold(), resume: () => unhold(),
    mode: (id, o = {}) => start(id, o), seek, lens: setLens, speed: setSpeed, aftershock: () => doShock(),
    chapter: (i) => { const c = chapters[i]; if (c) seek(c.p0 + .01); },
    director: () => director.giveBack(), takeCamera: () => director.take(), showPicker,
    floors: (lv) => { userLevel = lv === 'auto' ? undefined : lv; applyCut(userLevel === undefined ? dirLevel : userLevel); paintFloors(); wantRender = true; },
    openRoom: (id) => openRoom(id), pickRoom,
    get state() { return { mode: modeId, seed: seedUsed, P, dur, playing, chapter: chapters[chapterAt(P)]?.id, lens: lenses.current, cards: cards.active, caption: captions.text, shot: curShot && curShot.kind, cut: cutLevel, user: director.user, shocks: C ? C.aftershocks.length : 0, fps, dpr: R.dpr, calls: renderer.info.render.calls, tris: renderer.info.render.triangles, load: loadInfo, score: C && { iou: C.score.iou, debrisErr: C.score.debrisErr, falseSafe: C.score.falseSafe, certified: C.score.certified, minutes: C.score.minutes } }; },
    renderNow(settle = 0) {
      if (!C) { R.render(clockT); return api.state; }
      playback(0); offNow = cards.active.length && !PH ? cardsHalf : 0; director.setFrame(viewW, viewH, offNow, PH ? 0 : 22);
      for (let i = 0; i < settle; i++) { lenses.update(.1, filmW); playback(0); director.update(.1, 0); }
      playback(0); director.update(.016, shake); if (world) world.fadeNeighbours(camera.position, director.tgt, 5); draw(); dock.update(P, playing, `ground station ${mmss(st.clock)}`); cards.update(st, true); return api.state;
    },
    frameStats() {
      // draw now and read back in the same task: the drawing buffer is still intact (no preserveDrawingBuffer needed)
      if (C && world) { try { draw(); } catch (e) { /* stats of whatever is on screen */ } }
      const stat = (sx, sy, sw, sh, W, H) => { const c = document.createElement('canvas'); c.width = W; c.height = H; const x = c.getContext('2d', { willReadFrequently: true }); x.drawImage(canvas, sx, sy, sw, sh, 0, 0, W, H); const d = x.getImageData(0, 0, W, H).data, L = new Float32Array(W * H);
        let m = 0; for (let i = 0; i < W * H; i++) { L[i] = (.2126 * d[i * 4] + .7152 * d[i * 4 + 1] + .0722 * d[i * 4 + 2]) / 255; m += L[i]; } m /= W * H; let v = 0, e = 0, n = 0;
        for (let k = 1; k < H - 1; k++) for (let i = 1; i < W - 1; i++) { const q = k * W + i; v += (L[q] - m) ** 2; const g = Math.abs(L[q + 1] - L[q - 1]) + Math.abs(L[q + W] - L[q - W]); if (g > .06) e++; n++; }
        let flat = 0; const bw = W / 12, bh = H / 8; for (let by = 0; by < 8; by++) for (let bx = 0; bx < 12; bx++) { let s1 = 0, s2 = 0, c2 = 0; for (let k = Math.floor(by * bh); k < Math.floor((by + 1) * bh); k++) for (let i = Math.floor(bx * bw); i < Math.floor((bx + 1) * bw); i++) { const l = L[k * W + i]; s1 += l; s2 += l * l; c2++; } const sd = Math.sqrt(Math.max(0, s2 / c2 - (s1 / c2) ** 2)); if (sd < .012) flat++; }
        return { mean: +m.toFixed(3), std: +Math.sqrt(v / n).toFixed(3), edge: +(e / n).toFixed(3), flat: +(flat / 96).toFixed(2) }; };
      const cw = canvas.width, ch = canvas.height; const cam = camera.position;
      return { main: stat(0, 0, cw * (PH ? 1 : .72), ch * .82, 192, 120), cam: [+cam.x.toFixed(1), +cam.y.toFixed(1), +cam.z.toFixed(1)], shot: curShot && curShot.kind, chapter: chapters[chapterAt(P)]?.id };
    },
    // test helper: draw calls and triangles of the 3-D scene alone (no post passes) for the current frame
    sceneStats() { const inf = renderer.info; inf.autoReset = false; inf.reset(); try { syncUniforms(); renderer.setRenderTarget(null); renderer.render(scene, camera); } finally { inf.autoReset = true; } const out = { calls: inf.render.calls, tris: inf.render.triangles, points: inf.render.points }; draw(); return out; },
    get prof() { return prof; }, get caseData() { return C; }, get script() { return script; },
    _dbg: { scene, camera, renderer, R, director, lenses, get layers() { return layers; }, get world() { return world; } },
    destroy() {
      if (destroyed) return; destroyed = true; loadId++;
      canvas.removeEventListener('webglcontextlost', onLost);
      cancelAnimationFrame(raf); running = false; playing = false; ro.disconnect(); removeEventListener('keydown', onKey);
      clearTimeout(toastT);
      try { music.destroy(); } catch (e) { /* ignore */ }
      menu.dispose(); dock.dispose(); director.dispose();
      dropScene(); cache.clear();
      scene.traverse((o) => { if (o.geometry) o.geometry.dispose(); if (o.material) (Array.isArray(o.material) ? o.material : [o.material]).forEach((m) => { for (const k in m) if (m[k] && m[k].isTexture) m[k].dispose(); m.dispose(); }); });
      if (props) props.traverse((o) => { if (o.geometry) o.geometry.dispose(); if (o.material) (Array.isArray(o.material) ? o.material : [o.material]).forEach((m) => { for (const k in m) if (m[k] && m[k].isTexture) m[k].dispose(); m.dispose(); }); });
      R.dispose(); root.remove();
    },
  };
  return api;
}
