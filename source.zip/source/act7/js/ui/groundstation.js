// The ground-station clock chip: time since touchdown, and what the station is doing (or when the first change map came).
import { mmss } from '../film/script.js';
export function createClock(el) {
  el.className = 'a7clock'; el.innerHTML = '<div class="k">Ground station, since touchdown</div><div class="t">00:00</div><div class="s"></div>';
  const t = el.querySelector('.t'), s = el.querySelector('.s'); let lt = '', ls = '', lw = null;
  return {
    set(sec, note, warn = false) { const a = mmss(sec); if (a !== lt) { lt = a; t.textContent = a; } if (note !== ls) { ls = note; s.textContent = note; } if (warn !== lw) { lw = warn; s.classList.toggle('warn', warn); } },
  };
}
