// Concept cards (right column, at most three, newest on top), each with a small live visualisation drawn from the
// case at the current moment of the film, a stat line, one plain sentence and, where Act 5 has one, a lab link.
import { failureOf } from '../film/failure.js';
import { getTheme, rgba } from '../theme.js';
// the chart colours come from the theme (set by createCards)
const FONTS = { mono: '"Geist Mono", ui-monospace, monospace', sans: 'Geist, ui-sans-serif, system-ui, sans-serif' };
let TH = getTheme('dusk'), C;
const css3 = (a) => `rgb(${a.map((x) => Math.round(x * 255)).join(',')})`;
function chartPal(T) {
  const d = T.data, ch = T.chart;
  return { teal: d.swarm, safe: d.safe, rose: d.added, debris: d.debris, heat: d.hot, cold: d.cold, haze: d.unseen, apr: d.mid, lav: d.empty, emptyLight: d.emptyLight, danger: d.noentry,
    paper: ch.paper, faint: ch.faint, grid: ch.grid, well: ch.well, bar: ch.bar, band: ch.band, dash: ch.dash, conf: ch.conf || d.conf.map(css3), phi: d.phi, ...FONTS };
}
C = chartPal(TH);
const phiStep = (S) => { for (const [s0, c] of C.phi) if (S >= s0) return c; return C.phi[C.phi.length - 1][1]; };
export const CARD = {
  station: { name: 'Ground station', tag: 'after landing', line: 'In flight the drones kept one shared coverage map, merged in any order (a CRDT), so lost or repeated packets did no harm. Now the full-resolution scans, video and logs come off.', lab: 'lab-crdt' },
  reg: { name: 'Two scans, one frame', tag: 'trimmed ICP', line: 'Only what did not move is used: the ground, boundary walls, neighbours. Whatever moved is left out.' },
  change: { name: 'Change map', tag: 'voxel by voxel', line: 'Newly occupied (rose), newly empty (lavender), with the inferred debris under the pile. Part of what changed lies where no sensor can see: inside walls, slabs and the pile.' },
  debris: { name: 'Debris', tag: 'a range', line: 'The inside of a pile is never seen, so the volume is a range; the estimate counts the unseen space under what was seen.' },
  phi: { name: 'Wall order φ_wall', tag: 'nematic order', line: 'φ_wall is the alignment of a wall’s surface normals: near 1 when intact, lower as damage scatters them (a normal and its flip count the same). φ_swarm is the same number for drone headings (Vicsek), the one that keeps the swarm at its tipping point.', lab: 'lab-vicsek' },
  xi: { name: 'Correlation length', tag: 'damage clusters', line: 'How far damage spreads: the size of connected damaged patches. A straight line in log-log would mean damage cascading.' },
  pockets: { name: 'Pockets β₂', tag: 'enclosed voids', line: 'Space someone could be in that no drone could enter: seen through a gap, or possible under a leaning slab (inferred, lower confidence).', lab: 'lab-pocket' },
  routes: { name: 'Access graph', tag: 'β₁ loops', line: 'Free space a person fits through, thinned to a path network. Cut routes and new bottlenecks against the survey.', lab: 'lab-topology' },
  thermal: { name: 'Thermal over time', tag: 'three passes', line: 'A hot area that grows between passes is a fire spreading; a cold patch that grows is water getting in.' },
  freq: { name: 'Natural frequency', tag: 'vibration pods', line: 'Each pod, an ADXL355 accelerometer on an ESP32-C6 dropped from a tube, hears its wall’s own frequency f₀. f₀ goes with the square root of stiffness: a 10 % drop means about 19 % of the stiffness is gone.' },
  tau: { name: 'Relaxation time', tag: 'critical slowing down', line: 'After a shake the tilt creeps back. If that takes longer after each aftershock, the structure is nearing its threshold.', lab: 'lab-slowing' },
  swarm: { name: 'Swarm behaviour as data', tag: 'φ_swarm and a forecast', line: 'φ_swarm, the alignment of nearby drones’ headings (Vicsek), over the flight log; a small Koopman forecast of the swarm’s speed, 5 s ahead. Where the forecast was wrong is where the building surprised the swarm.', labs: [['lab-vicsek', 'Alignment in the lab'], ['lab-koopman', 'Forecasts in the lab']] },
  fail: { name: 'How close is it to failure?', tag: 'four quantities', line: 'Near a threshold, order falls, damage spreads farther, a push moves it more and it recovers more slowly.', html: true },
  conf: { name: 'Confidence', tag: 'how far to trust it', line: 'Seen often, from close, clear of smoke, well registered: high. Never seen: zero, and never called safe.' },
  score: { name: 'Scorecard', tag: 'against the truth', line: 'The targets from our proposal, measured on a collapse whose damage is known exactly.' },
};
export function createCards(el, { onLab = () => {}, phone = false, theme = null } = {}) {
  TH = theme || getTheme('dusk'); C = chartPal(TH);
  CARD.change.line = `Newly occupied (${TH.names.added}), newly empty (${TH.names.empty}), with the inferred debris under the pile. Part of what changed lies where no sensor can see: inside walls, slabs and the pile.`;
  const live = new Map(), order = [];
  let Cs = null;
  const cap = () => (phone ? 4 : (el.clientHeight || innerHeight) < 600 || innerHeight < 800 ? 2 : 3);
  function add(id) {
    const def = CARD[id]; if (!def || live.has(id)) return;
    const node = document.createElement('article'); node.className = 'a7card enter'; node.dataset.card = id; node.setAttribute('aria-label', def.name);
    const labs = def.labs || (def.lab ? [[def.lab, 'See it in the lab']] : []);
    node.innerHTML = `<header><i></i><h4>${def.name}</h4><span class="tag">${def.tag}</span></header>${def.html ? '<div class="q4"></div>' : '<canvas></canvas>'}<div class="st"><span class="a"></span><span class="b"></span></div><p>${def.line}</p>${labs.length ? `<div class="labs">${labs.map(([l, t]) => `<button class="lab" type="button" data-lab="${l}">${t}</button>`).join('')}</div>` : ''}`;
    node.querySelectorAll('[data-lab]').forEach((b) => b.addEventListener('click', () => onLab(b.dataset.lab)));
    el.insertBefore(node, el.firstChild);
    const cv = node.querySelector('canvas'); live.set(id, { node, cv, ctx: cv && cv.getContext('2d'), q4: node.querySelector('.q4'), sa: node.querySelector('.st .a'), sb: node.querySelector('.st .b'), w: 0, h: 0 }); order.unshift(id);
    requestAnimationFrame(() => node.classList.remove('enter'));
    if (phone) requestAnimationFrame(() => { if (el.scrollLeft > 0) el.scrollLeft = 0; });   // the newest card is the first one: bring it into view
    while (order.length > cap()) remove(order[order.length - 1]);
  }
  function remove(id, now = false) { const o = live.get(id); if (!o) return; live.delete(id); const i = order.indexOf(id); if (i >= 0) order.splice(i, 1); if (now) { o.node.remove(); return; } o.node.classList.add('leave'); setTimeout(() => o.node.remove(), 460); }
  function show(ids) { const want = ids.slice(-cap()); for (const c of [...live.keys()]) if (!want.includes(c)) remove(c); for (const c of want) if (!live.has(c)) add(c); }
  let last = 0;
  function update(st, force = false) {
    if (!Cs) return; const now = performance.now(); if (!force && now - last < 80) return; last = now;
    for (const [id, o] of live) {
      if (o.q4) { try { const s = DRAW[id](null, 0, 0, Cs, st) || ['', '', '']; if (o.q4.innerHTML !== s[2]) o.q4.innerHTML = s[2]; if (o.sa.innerHTML !== s[0]) o.sa.innerHTML = s[0]; if (o.sb.innerHTML !== s[1]) o.sb.innerHTML = s[1]; } catch (e) { console.warn('[act7] card', id, e); } continue; }
      const r = o.cv.getBoundingClientRect(); const dpr = Math.min(2, window.devicePixelRatio || 1); if (r.width < 4) continue;
      if (Math.abs(r.width - o.w) > .5 || Math.abs(r.height - o.h) > .5) { o.w = r.width; o.h = r.height; o.cv.width = Math.round(r.width * dpr); o.cv.height = Math.round(r.height * dpr); }
      const x = o.ctx; x.setTransform(dpr, 0, 0, dpr, 0, 0); x.clearRect(0, 0, o.w, o.h);
      try { const s = DRAW[id](x, o.w, o.h, Cs, st) || ['', '']; if (o.sa.innerHTML !== s[0]) o.sa.innerHTML = s[0]; if (o.sb.innerHTML !== s[1]) o.sb.innerHTML = s[1]; } catch (e) { console.warn('[act7] card', id, e); }
    }
  }
  return { show, update, setCase(c) { Cs = c; for (const k of [...live.keys()]) remove(k, true); }, clear() { for (const k of [...live.keys()]) remove(k, true); }, get active() { return [...order]; } };
}
// ------------------------------------------------------------------ drawing helpers
const label = (x, s, X, Y, col = C.faint, align = 'left', size = 10.5, font = C.sans) => { x.font = `${size}px ${font}`; x.fillStyle = col; x.textAlign = align; x.textBaseline = 'alphabetic'; x.fillText(s, X, Y); };
const pct = (v) => `${Math.round(v * 100)} %`;
const f1 = (v) => (Math.abs(v) >= 100 ? Math.round(v).toLocaleString('en') : v.toFixed(1));
const mm = (s) => `${String(Math.floor(s / 60)).padStart(2, '0')}:${String(Math.floor(s % 60)).padStart(2, '0')}`;
const DRAW = {
  station(x, w, h, Cs, st) {
    const k = st.offload ?? 1, X0 = 10, W = w - 20; const gb = 8 * 0.7;
    label(x, 'offloaded from 8 drones', X0, 18, C.faint); x.fillStyle = C.well; x.fillRect(X0, 26, W, 10); x.fillStyle = C.teal; x.fillRect(X0, 26, W * k, 10);
    const items = ['maps', 'point clouds', 'video', 'flight logs']; items.forEach((s, i) => { const on = k > (i + .5) / items.length; label(x, (on ? '✓ ' : '· ') + s, X0 + (i % 2) * W / 2, 56 + Math.floor(i / 2) * 16, on ? C.paper : C.faint, 'left', 11); });
    return [`<b>${(gb * k).toFixed(1)}</b> of ${gb.toFixed(1)} GB`, `clock <b>${mm(st.clock ?? 0)}</b>`];
  },
  reg(x, w, h, Cs, st) {
    const it = Cs.reg.iters.filter((q) => !q.final), k = Math.max(0, Math.min(it.length, st.regIter ?? it.length));
    const X0 = 8, Y0 = 8, W = w - 16, H = h - 22; const mx = Math.max(...it.map((q) => q.rmse || 0), 0.02);
    x.strokeStyle = C.grid; x.beginPath(); x.moveTo(X0, Y0 + H); x.lineTo(X0 + W, Y0 + H); x.stroke();
    x.beginPath(); for (let i = 0; i < it.length; i++) { const px = X0 + i / Math.max(1, it.length - 1) * W, py = Y0 + H - (it[i].rmse / mx) * H; i ? x.lineTo(px, py) : x.moveTo(px, py); } x.strokeStyle = rgba(C.teal, .18); x.lineWidth = 1.2; x.stroke();
    x.beginPath(); for (let i = 0; i < k; i++) { const px = X0 + i / Math.max(1, it.length - 1) * W, py = Y0 + H - (it[i].rmse / mx) * H; i ? x.lineTo(px, py) : x.moveTo(px, py); } x.strokeStyle = C.teal; x.lineWidth = 1.8; x.stroke();
    for (let i = 0; i < k; i++) { const px = X0 + i / Math.max(1, it.length - 1) * W; x.fillStyle = rgba(C.rose, .55); const uh = it[i].used * H * .35; x.fillRect(px - 1, Y0 + H - uh, 2, uh); }
    label(x, 'misfit per iteration', X0 + 2, Y0 + 10, C.teal); label(x, 'share used', X0 + W - 2, Y0 + 10, C.rose, 'right');
    const cur = it[Math.max(0, k - 1)] || it[0];
    return [`misfit <b>${(cur.rmse * 100).toFixed(1)} cm</b>`, `points used <b>${pct(cur.used)}</b>`];
  },
  change(x, w, h, Cs, st) {
    const c = Cs.change.counts, V = Cs.g.V3, mov = c.moved * V, gone = c.gone * V, deb = (c.debris + c.fill) * V, tot = Math.max(1, mov + gone + deb);
    const X0 = 10, W = w - 20, dy = (h - 10) / 3; const bar = (i, v, col, t) => { const y = 6 + i * dy + (dy - 9) / 2; x.fillStyle = C.bar; x.fillRect(X0 + 96, y, W - 150, 9); x.fillStyle = col; x.fillRect(X0 + 96, y, (W - 150) * v / tot, 9); label(x, t, X0, y + 8.5, C.faint, 'left', 10.5); label(x, `${f1(v)} m³`, X0 + W, y + 8.5, C.paper, 'right', 10.5, C.mono); };
    bar(0, mov, C.rose, 'moved structure'); bar(1, deb, C.debris, 'debris'); bar(2, gone, C.lav, 'newly empty');
    const show = st.reveal == null || st.reveal >= 1;
    const sc = Cs.score, ok = sc.iou > 0.7;
    return [show ? `IoU <b style="color:var(${ok ? '--safe-txt' : '--danger-txt'})">${sc.iou.toFixed(2)}</b> (over 0.7), on what a sensor saw <b>${sc.iouSeen.toFixed(2)}</b>` : 'computing', show ? `<b>${Math.round(sc.hiddenShare * 100)} %</b> never seen` : ''];
  },
  debris(x, w, h, Cs) {
    const d = Cs.debris, t = Cs.score.debrisTruth, hi = Math.max(d.high, t) * 1.08, X0 = 12, W = w - 24, y = 34;
    const X = (v) => X0 + v / hi * W;
    x.fillStyle = C.bar; x.fillRect(X0, y, W, 12); x.fillStyle = rgba(C.rose, .35); x.fillRect(X(d.low), y, X(d.high) - X(d.low), 12);
    x.fillStyle = C.rose; x.fillRect(X(d.estimate) - 1.5, y - 6, 3, 24); label(x, 'estimate', X(d.estimate), y - 9, C.rose, 'center');
    x.fillStyle = C.lav; x.beginPath(); x.moveTo(X(t), y + 14); x.lineTo(X(t) - 5, y + 23); x.lineTo(X(t) + 5, y + 23); x.closePath(); x.fill(); label(x, 'truth', X(t), y + 35, C.lav, 'center');
    label(x, `${f1(d.low)}`, X(d.low), y + 26, C.faint, 'center', 10, C.mono); label(x, `${f1(d.high)} m³`, X(d.high), y + 26, C.faint, 'center', 10, C.mono);
    const err = Cs.score.debrisErr;
    return [`<b>${f1(d.estimate)} m³</b>, about ${d.trucks} truck${d.trucks === 1 ? '' : 's'}`, `error <b style="color:var(${err < .2 ? '--safe-txt' : '--danger-txt'})">${pct(err)}</b>`];
  },
  phi(x, w, h, Cs) {
    const P = Cs.condition.patches.filter((p) => p.st === 'ok'), miss = Cs.condition.patches.filter((p) => p.st === 'missing').length;
    const bins = new Array(12).fill(0); for (const p of P) { const b = Math.max(0, Math.min(11, Math.floor((p.S - .76) / .02))); bins[b]++; }
    const X0 = 8, W = w - 16, Y0 = 8, H = h - 24, mx = Math.max(...bins, 1);
    bins.forEach((v, i) => { const S = .76 + (i + .5) * .02; x.fillStyle = phiStep(S); const bw = W / bins.length; const bh = Math.sqrt(v / mx) * H; x.fillRect(X0 + i * bw + 1, Y0 + H - bh, bw - 2, bh); });
    label(x, '0.76', X0, h - 4, C.faint, 'left', 10, C.mono); label(x, 'S = 1', X0 + W, h - 4, C.faint, 'right', 10, C.mono);
    const low = P.filter((p) => p.S < .95).length;
    return [`wall patches <b>${P.length + miss}</b>`, `low order <b>${low}</b>, fallen <b>${miss}</b>`];
  },
  xi(x, w, h, Cs) {
    const s = Cs.condition.clusters.sizes, X0 = 26, Y0 = 6, W = w - 36, H = h - 22;
    x.strokeStyle = C.grid; x.strokeRect(X0, Y0, W, H);
    if (!s.length) { label(x, 'no damaged patches', w / 2, h / 2, C.faint, 'center'); return ['no clusters', '']; }
    const lx = (v) => X0 + Math.log10(v) / Math.log10(Math.max(10, s[0] * 1.5)) * W, ly = (r) => Y0 + H - Math.log10(r) / Math.log10(Math.max(10, s.length * 1.5)) * H;
    s.forEach((v, i) => { x.fillStyle = C.heat; x.beginPath(); x.arc(lx(Math.max(1, v)), ly(i + 1), 2.6, 0, 7); x.fill(); });
    label(x, 'size m²', X0 + W, h - 3, C.faint, 'right', 10); label(x, 'rank', 2, Y0 + 9, C.faint, 'left', 10);
    const sl = Cs.condition.clusters.slope;
    return [`ξ <b>${Cs.condition.clusters.xi.toFixed(1)} m</b> (weighted cluster size)`, `${s.length} cluster${s.length === 1 ? '' : 's'}${sl != null ? `, slope ${sl.toFixed(1)}` : ''}`];
  },
  pockets(x, w, h, Cs) {
    const L = Cs.pockets.list.slice(0, 4);
    if (!L.length) { label(x, 'no enclosed space found', w / 2, h / 2, C.faint, 'center'); }
    L.forEach((p, i) => { const y = 14 + i * 19; x.fillStyle = p.kind === 'gap' ? C.lav : rgba(C.emptyLight, .6); x.beginPath(); x.arc(14, y - 4, 5, 0, 7); x.fill(); const room = p.room >= 0 ? Cs.model.rooms[p.room].short : 'outside'; label(x, `${room}, ${p.kind === 'gap' ? 'seen through a gap' : 'possible, under a slab'}`, 26, y, C.paper, 'left', 11); label(x, `${p.vol.toFixed(1)} m³  ${pct(p.conf)}`, w - 8, y, C.faint, 'right', 10.5, C.mono); });
    const sc = Cs.score;
    const t = sc.pocketTiers || { gap: { n: 0, false: 0 }, slab: { n: 0, false: 0 } };
    return [`β₂ <b>${Cs.pockets.list.length}</b> (${t.gap.n} seen, ${t.slab.n} possible), <b>${sc.falsePockets}</b> false`, `found <b>${sc.voidsFound}/${sc.voids}</b>`];
  },
  routes(x, w, h, Cs) {
    const R = Cs.routes; const X0 = 10, W = w - 20;
    R.forEach((f, i) => { const y = 14 + i * 18; const reach = f.routes.filter((q) => q.reachable).length, tot = f.routes.length; label(x, ['ground', 'first', 'second', 'third'][i] + ' floor', X0, y, C.faint, 'left', 10.5); x.fillStyle = C.bar; x.fillRect(X0 + 78, y - 8, W - 150, 8); x.fillStyle = C.teal; x.fillRect(X0 + 78, y - 8, (W - 150) * reach / Math.max(1, tot), 8); label(x, `${reach}/${tot} rooms`, X0 + W, y, C.paper, 'right', 10.5, C.mono); });
    const cut = R.reduce((s, f) => s + f.cutLen, 0), necks = R.reduce((s, f) => s + f.necks.length, 0), b1 = R.reduce((s, f) => s + f.post.beta1, 0), b0 = R.reduce((s, f) => s + f.base.beta1, 0);
    return [`routes cut <b>${cut.toFixed(0)} m</b>, bottlenecks <b>${necks}</b>`, `loops β₁ <b>${b0}</b> then <b>${b1}</b>`];
  },
  thermal(x, w, h, Cs, st) {
    const P = Cs.thermal.passes, mx = Math.max(...P.map((p) => p.hotArea), 1), X0 = 10, W = w - 20, cur = st.pass ?? 2;
    P.forEach((p, i) => { const bx = X0 + i * W / 3 + 6, bw = W / 3 - 12, bh = (h - 30) * p.hotArea / mx; x.fillStyle = i <= cur ? C.heat : rgba(C.heat, .25); x.fillRect(bx, h - 18 - bh, bw * .62, bh); const ch = (h - 30) * Math.min(1, p.coldArea / mx); x.fillStyle = i <= cur ? C.cold : rgba(C.cold, .25); x.fillRect(bx + bw * .66, h - 18 - ch, bw * .34, ch); label(x, `pass ${i + 1}`, bx + bw / 2, h - 5, i === cur ? C.paper : C.faint, 'center', 10.5); });
    const p = P[Math.min(2, cur)];
    const a1 = (v) => (v >= 10 ? v.toFixed(0) : v.toFixed(1));
    return [`hot <b>${a1(p.hotArea)} m²</b>, cold <b>${a1(p.coldArea)} m²</b>`, Cs.thermal.spreading ? '<b style="color:var(--heat-txt)">fire spreading</b>' : 'stable'];
  },
  freq(x, w, h, Cs, st) {
    const k = st.shock ?? 0, A = k > 0 ? Cs.aftershocks[k - 1] : null, reads = A ? A.reads : Cs.pods.reads, i = Math.min(reads.length - 1, st.pod ?? 0), rd = reads[i], before = Cs.pods.reads[i];
    const P = rd.spectrum, X0 = 6, Y0 = 6, W = w - 12, H = h - 20; let mx = -1e9, mn = 1e9; for (const v of P) { const l = Math.log(v); if (l > mx) mx = l; if (l < mn) mn = l; }
    const fx = (f) => X0 + (f - 0.5) / 30 * W;
    const curve = (S, col, lw) => { x.beginPath(); for (let b = 0; b < S.length; b++) { const f = 0.5 + (b + .5) * 0.05; if (f > 30.5) break; const px = fx(f), py = Y0 + H - (Math.log(S[b]) - mn) / (mx - mn) * H; b ? x.lineTo(px, py) : x.moveTo(px, py); } x.strokeStyle = col; x.lineWidth = lw; x.stroke(); };
    if (A) curve(before.spectrum, rgba(C.teal, .35), 1.2); curve(P, A ? C.rose : C.teal, 1.5);
    x.strokeStyle = C.heat; x.setLineDash([3, 3]); x.beginPath(); x.moveTo(fx(rd.f0), Y0); x.lineTo(fx(rd.f0), Y0 + H); x.stroke(); x.setLineDash([]);
    label(x, `f₀ ${rd.f0.toFixed(2)} Hz`, Math.min(fx(rd.f0) + 4, w - 70), Y0 + 10, C.heat); label(x, '0', X0, h - 3, C.faint, 'left', 10, C.mono); label(x, '30 Hz', X0 + W, h - 3, C.faint, 'right', 10, C.mono);
    const drop = A ? 1 - rd.f0 / before.f0 : 1 - rd.f0 / Cs.pods.list[i].fRef;
    return [`pod ${i + 1} <b>${rd.f0.toFixed(2)} Hz</b>`, A ? `f₀ <b>${pct(drop)}</b> down, stiffness <b>${pct(1 - (1 - drop) ** 2)}</b> down` : `vs intact <b>${drop >= 0 ? pct(drop) + ' lower' : pct(-drop) + ' higher'}</b>`];
  },
  tau(x, w, h, Cs, st) {
    const k = Math.max(1, st.shock ?? 1), A = Cs.aftershocks[k - 1]; if (!A) return ['', ''];
    const X0 = 8, Y0 = 8, W = w - 16, H = h - 22, tmax = 28; const ys = A.scans.map((q) => q.tilt); const lo = Math.min(A.before, ...ys) - 0.01, hi = Math.max(...ys) + 0.01;
    const px = (t) => X0 + t / tmax * W, py = (v) => Y0 + H - (v - lo) / (hi - lo) * H;
    const tShow = st.tauT ?? tmax;
    x.strokeStyle = C.dash; x.setLineDash([3, 3]); x.beginPath(); x.moveTo(X0, py(A.before)); x.lineTo(X0 + W, py(A.before)); x.stroke(); x.setLineDash([]);
    x.beginPath(); for (let t = 0.2; t <= Math.min(tShow, tmax); t += 0.25) { const v = A.fitA + A.fitB * Math.exp(-t / A.tau); t === 0.2 ? x.moveTo(px(t), py(v)) : x.lineTo(px(t), py(v)); } x.strokeStyle = C.heat; x.lineWidth = 1.6; x.stroke();
    for (const q of A.scans) if (q.t <= tShow) { x.fillStyle = C.paper; x.beginPath(); x.arc(px(q.t), py(q.tilt), 2.2, 0, 7); x.fill(); }
    label(x, 'tilt after the shake', X0 + 2, Y0 + 10, C.faint); label(x, '27 min', X0 + W, h - 3, C.faint, 'right', 10, C.mono);
    const prev = k > 1 ? Cs.aftershocks[k - 2] : null;
    return [`τ <b>${A.tau.toFixed(1)} min</b> <span style="opacity:.6">(${A.tauLo.toFixed(1)} to ${A.tauHi.toFixed(1)})</span>`, prev ? (A.slowing ? '<b style="color:var(--danger-txt)">slower than last time</b>' : `last time ${prev.tau.toFixed(1)} min`) : `extra tilt <b>${(A.measuredJump).toFixed(2)}°</b>`];
  },
  swarm(x, w, h, Cs, st) {
    // top band: phi_swarm over the flight (dots where nearby drones were measured, lavender under 0.5); bottom band: the
    // swarm's speed (teal) and the forecast made 5 s earlier (dashed heat), rose ticks where it missed most
    const S = Cs.swarm, F = S.forecast, n = S.n, X0 = 8, W = w - 16, top = 6, hb = (h - 22) * .38, gap = 6, b0 = top + hb + gap, hs = h - 16 - b0;
    let vmax = 0.2; for (let t = 0; t < n; t++) vmax = Math.max(vmax, S.obs[t], Number.isFinite(F.values[t]) ? F.values[t] : 0); vmax *= 1.1;
    const px = (t) => X0 + t / Math.max(1, n - 1) * W, pyS = (v) => b0 + hs - Math.min(1, v / vmax) * hs, pyP = (v) => top + hb - v * hb;
    const upto = Math.floor((st.behav ?? 1) * (n - 1));
    x.fillStyle = C.band; x.fillRect(X0, top, W, hb); x.fillRect(X0, b0, W, hs);
    x.strokeStyle = rgba(C.lav, .28); x.setLineDash([2, 3]); x.beginPath(); x.moveTo(X0, pyP(.5)); x.lineTo(X0 + W, pyP(.5)); x.stroke(); x.setLineDash([]);
    for (let t = 0; t <= upto; t++) { const v = S.phiT[t]; if (!Number.isFinite(v)) continue; x.fillStyle = v < .5 ? C.lav : rgba(C.teal, .7); x.fillRect(px(t) - 1, pyP(v) - 1, 2, 2); }
    x.beginPath(); for (let t = 0; t <= upto; t++) { const v = S.obs[t]; t ? x.lineTo(px(t), pyS(v)) : x.moveTo(px(t), pyS(v)); } x.strokeStyle = C.teal; x.lineWidth = 1.3; x.stroke();
    x.beginPath(); let pen = false; for (let t = 0; t <= upto; t++) { const v = F.values[t]; if (!Number.isFinite(v)) { pen = false; continue; } pen ? x.lineTo(px(t), pyS(v)) : x.moveTo(px(t), pyS(v)); pen = true; } x.strokeStyle = rgba(C.heat, .9); x.setLineDash([2, 2]); x.lineWidth = 1.1; x.stroke(); x.setLineDash([]);
    for (const m of F.misses) if (m.t <= upto) { x.fillStyle = C.rose; x.fillRect(px(m.t) - 1, b0, 2, hs); }
    label(x, 'φ_swarm', X0 + 3, top + 10, C.lav, 'left', 10); label(x, 'speed', X0 + 3, b0 + 10, C.teal, 'left', 10); label(x, 'forecast', X0 + 38, b0 + 10, C.heat, 'left', 10);
    label(x, `${Math.round(S.minutes)} min of flight`, X0 + W, h - 3, C.faint, 'right', 10);
    const sk = F.made ? (F.skill >= 0.1 ? `forecast <b>${Math.round(F.skill * 100)} %</b> closer than no change` : 'forecast <b>no better</b> than no change') : 'forecast <b>skipped</b>';
    return [S.phiSamples >= 30 ? `φ_swarm <b>${S.phiMedian.toFixed(2)}</b>${S.drops.length ? `, lowest <b>${S.phiLow.toFixed(2)}</b>` : ''}` : 'φ_swarm <b>too few pairs</b>', sk];
  },
  fail(x, w, h, Cs, st) {
    const k = Math.max(1, st.shock ?? 1), Q = failureOf(Cs, k);
    const sp = Q.xi.verdict === 'power' ? 'a power law: damage cascading' : Q.xi.verdict === 'local' ? 'no power law: damage stays local' : 'too few clusters to see a power law';
    const tl = Q.tau.list, tauV = tl.map((t) => t.tau.toFixed(1)).join(', then ');
    const rows = [
      ['Order parameter φ_wall', Number.isFinite(Q.phi.value) ? Q.phi.value.toFixed(2) : 'not seen', 'how much order remains (1 = all aligned)'],
      ['Correlation length ξ', `${Q.xi.value.toFixed(1)} m`, `how far damage spreads; ${sp}`],
      ['Susceptibility', Q.sus.n ? `${pct(Q.sus.before)}, then ${pct(Q.sus.after)}` : 'no pods', 'how strongly it responds to a push: stiffness lost before and after the aftershock'],
      ['Relaxation time τ', `${tauV} min`, Q.tau.growing ? 'how slowly it recovers: growing, so it is nearing its threshold' : 'how slowly it recovers; if it grows after each shake, it is nearing its threshold'],
    ];
    const html = rows.map(([n, v, l]) => `<div class="r"><span class="n">${n}</span><b>${v}</b><small>${l}</small></div>`).join('');
    return [`after aftershock <b>${k}</b>`, Q.tau.growing ? '<b style="color:var(--danger-txt)">recovery slowing</b>' : tl.length > 1 ? 'recovery <b>not slowing</b>' : 'one shake so far', html];
  },
  conf(x, w, h, Cs, st) {
    const after = !!st.after, a = Cs.confidence.hist0, b = Cs.confidence.hist1, X0 = 8, W = w - 16, Y0 = 8, H = h - 22; const mx = Math.max(...a, ...b, 1);
    for (let i = 0; i < 10; i++) { const bw = W / 10; const t = (i + .5) / 10; const c = t < .5 ? C.conf[0] : t < .75 ? C.conf[1] : C.conf[2]; x.fillStyle = after ? rgba(C.haze, .25) : c; const h0 = Math.sqrt(a[i] / mx) * H; x.fillRect(X0 + i * bw + 1, Y0 + H - h0, bw * (after ? .45 : .9), h0); if (after) { x.fillStyle = c; const h1 = Math.sqrt(b[i] / mx) * H; x.fillRect(X0 + i * bw + bw * .48, Y0 + H - h1, bw * .45, h1); } }
    label(x, '0', X0, h - 3, C.faint, 'left', 10, C.mono); label(x, '100 %', X0 + W, h - 3, C.faint, 'right', 10, C.mono);
    const R = Cs.confidence; const reg = R.region;
    return [after && reg ? `re-flown targets <b>${pct(reg.before)}</b> then <b>${pct(reg.after)}</b>` : `whole building <b>${pct(R.mean0)}</b>`, after ? `<b>${R.unreachableN || 0}</b> spots for a human` : `never seen <b>${pct(R.unseen || 0)}</b>`];
  },
  score(x, w, h, Cs) {
    const s = Cs.score, rows = [['change map', `${(Cs.clock.changeMap / 60).toFixed(1)} min`, s.minutes < 10], ['debris', pct(s.debrisErr), s.debrisErr < .2], ['IoU', s.iou.toFixed(2), s.iou > .7], ['false-safe', `${s.falseSafe}`, s.falseSafe === 0], ['certified', pct(s.certified), s.certified >= .95]];
    rows.forEach((r, i) => { const y = 14 + i * 16; label(x, r[0], 10, y, C.faint, 'left', 11); label(x, r[1], w - 30, y, C.paper, 'right', 11, C.mono); label(x, r[2] ? '✓' : '✗', w - 12, y, r[2] ? C.safe : C.danger, 'right', 12); });
    const n = rows.filter((r) => r[2]).length; return [`<b>${n} of 5</b> targets met`, `false-safe rooms <b>${s.falseSafe}</b>`];
  },
};
