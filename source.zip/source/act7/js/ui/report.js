// The end card, two panels: "Against the truth" (the deck's own metrics and targets, misses shown as misses) and "What
// the commander gets" (the drafts handed over for the call in Act 8), then "Next: Act 8, decide" (only when the host
// gives onNext), "Watch again", "Collapse it differently" and "Back to the story".
import { MODE_META } from './picker.js';
import { failureOf } from '../film/failure.js';
const FLOOR = ['ground floor', 'first floor', 'second floor', 'third floor', 'roof'];
const WORD = { noentry: 'No entry', caution: 'Caution', unseen: 'Never seen', safe: 'Safe' };
const pct = (v) => `${Math.round(v * 100)} %`;
const m3 = (v) => (v >= 100 ? `${Math.round(v)} m³` : `${v.toFixed(1)} m³`);
const mmss = (s) => `${Math.floor(s / 60)}:${String(Math.floor(s % 60)).padStart(2, '0')}`;
// the commander's panel: rooms by status, debris, pockets, routes, pod alerts, spots for a human, the four quantities
function commander(C, rooms, k) {
  // per floor: how many rooms in each draft status; the rooms a person may enter (safe, caution) by name
  const FL = ['Ground floor', 'First floor', 'Second floor', 'Third floor'], nm = (rm) => `${rm.flat && rm.flat !== 'core' ? `flat ${rm.flat} ` : ''}${rm.short.toLowerCase()}`;
  const tot = { noentry: 0, caution: 0, unseen: 0, safe: 0 }; rooms.forEach((r) => tot[r.status]++);
  const roomChips = `<p>${Object.entries(tot).filter(([, v]) => v).map(([k, v]) => `<b>${v}</b> ${WORD[k].toLowerCase()}`).join(', ')}</p>` + FL.map((f, s) => {
    const mine = rooms.map((r, i) => ({ r, rm: C.model.rooms[i] })).filter((q) => q.rm.storey === s); if (!mine.length) return '';
    const cnt = { noentry: 0, caution: 0, unseen: 0, safe: 0 }; mine.forEach((q) => cnt[q.r.status]++);
    const open = mine.filter((q) => q.r.status === 'safe' || q.r.status === 'caution');
    return `<div class="chips"><span>${f}</span>${Object.entries(cnt).filter(([, v]) => v).map(([k, v]) => `<span class="${k}">${WORD[k]} ${v}</span>`).join('')}${open.slice(0, 6).map((q) => `<span class="${q.r.status}">${nm(q.rm)}</span>`).join('')}${open.length > 6 ? `<span>and ${open.length - 6} more</span>` : ''}</div>`; }).join('');
  const d = C.debris, pk = C.pockets.list;
  const pockets = pk.length ? pk.slice(0, 6).map((p) => `<p>${p.room >= 0 ? C.model.rooms[p.room].short : 'Outside the rooms'}: ${p.kind === 'gap' ? 'seen through a gap' : 'possible under a leaning slab'}, ${p.vol.toFixed(1)} m³, confidence <b>${pct(p.conf)}</b></p>`).join('') + (pk.length > 6 ? `<p>and ${pk.length - 6} more</p>` : '') : '<p>No enclosed pocket big enough for a person was found.</p>';
  const R = C.routes, cut = R.reduce((a, f) => a + f.cutLen, 0), necks = R.flatMap((f) => f.necks.map((q) => ({ ...q, storey: f.storey }))), unr = R.reduce((a, f) => a + f.routes.filter((q) => !q.reachable).length, 0);
  const narrow = necks.length ? Math.min(...necks.map((q) => q.width)) : null;
  const routes = `<p>Routes cut: <b>${cut.toFixed(0)} m</b> of the survey’s walkable paths${cut > 0 ? ` (${R.filter((f) => f.cutLen > 0.5).map((f) => FLOOR[f.storey]).join(', ')})` : ''}.</p><p>New bottlenecks under 0.8 m: <b>${necks.length}</b>${narrow != null ? `, the narrowest ${Math.round(narrow * 100)} cm` : ''}. Rooms a person can’t reach from the entry: <b>${unr}</b>.</p>`;
  const A = C.aftershocks[Math.max(1, k) - 1], pods = C.pods.list.map((pd, i) => ({ i, storey: pd.storey, loss: Math.max(0, (A ? A.reads[i] : C.pods.reads[i]).stiffLoss) })).sort((a, b) => b.loss - a.loss);
  const podsHtml = pods.length ? pods.map((p) => `<p>${p.loss >= .3 ? '<b style="color:var(--danger-txt)">Alert</b> ' : ''}Pod ${p.i + 1}, ${FLOOR[p.storey] || 'wall'}: <b>${pct(p.loss)}</b> stiffness lost${A ? ' after the aftershock' : ''}</p>`).join('') : '<p>No pods were dropped.</p>';
  const cf = C.confidence, human = cf.unreachableN ? `<p><b>${cf.unreachableN}</b> weak spots, about <b>${Math.round(cf.unreachableArea)} m²</b> of surface, that no drone can reach: for a human to check.</p>` : '<p>Every weak spot was within reach of a drone.</p>';
  const Q = failureOf(C, k);
  const fq = `<p>Order φ_wall <b>${Number.isFinite(Q.phi.value) ? Q.phi.value.toFixed(2) : 'not seen'}</b>: how much order remains.</p><p>Correlation length ξ <b>${Q.xi.value.toFixed(1)} m</b>: ${Q.xi.verdict === 'power' ? 'damage sizes follow a power law, so it may be cascading' : Q.xi.verdict === 'local' ? 'damage stays local' : 'too few clusters to tell how damage spreads'}.</p><p>Susceptibility <b>${Q.sus.n ? `${pct(Q.sus.before)}, then ${pct(Q.sus.after)}` : 'no pods'}</b>: stiffness lost before and after the aftershock.</p><p>Relaxation time τ <b>${Q.tau.list.map((t) => t.tau.toFixed(1)).join(', then ')} min</b>${Q.tau.growing ? ': growing, nearing its threshold' : ''}.</p>`;
  return `<div class="cmd">
    <section><h5>Rooms by draft status</h5>${roomChips}</section>
    <section><h5>Debris</h5><p>About <b>${m3(d.estimate)}</b>, between ${m3(d.low)} and ${m3(d.high)}: roughly <b>${d.trucks}</b> truck load${d.trucks === 1 ? '' : 's'}.</p></section>
    <section><h5>Where someone could be</h5>${pockets}</section>
    <section><h5>Access</h5>${routes}</section>
    <section><h5>Vibration pods</h5>${podsHtml}</section>
    <section><h5>For a human to check</h5>${human}</section>
    <section><h5>How close is it to failure?</h5>${fq}</section>
  </div>`;
}
export function createReport(el, { onReplay, onNext, onPicker, onBack, hasNext = false } = {}) {
  el.className = 'a7over a7rep hide';
  let shown = false;
  function show(C, { rooms = null, k = 1 } = {}) {
    const s = C.score, m = MODE_META[C.mode], n = C.rooms.length;
    const rows = [
      { n: 'Landing to first change map', sub: 'offload, registration and the change map, on the ground-station laptop', v: mmss(C.clock.changeMap), tg: 'under 10 min', ok: s.minutes < 10 },
      { n: 'Debris volume error', sub: `estimate ${m3(C.debris.estimate)}, true ${m3(s.debrisTruth)}, range ${m3(C.debris.low)} to ${m3(C.debris.high)}`, v: pct(s.debrisErr), tg: 'under 20 %', ok: s.debrisErr < 0.2 },
      { n: 'Change map IoU', sub: `overlap with what truly changed; on the space a sensor saw ${s.iouSeen.toFixed(2)}, and ${Math.round(s.hiddenShare * 100)} % of the change lies where no sensor saw`, v: s.iou.toFixed(2), tg: 'over 0.7', ok: s.iou > 0.7 },
      { n: 'False-safe rooms', sub: s.draftedSafe ? `rooms drafted safe that were truly damaged (${s.draftedSafe} drafted safe)` : 'no room was drafted safe; none of them truly was', v: `${s.falseSafe} of ${n}`, tg: 'under 1 %', ok: s.falseSafeRate < 0.01, hl: true },
      { n: 'Search certified', sub: 'share of the truly reachable space that the scans observed', v: pct(s.certified), tg: '95 % or more', ok: s.certified >= 0.95 },
    ];
    const met = rows.filter((r) => r.ok).length;
    const head = {
      truth: ['Scored against the known truth', met === 5 ? 'All five targets met' : `${met} of 5 targets met`, `${m ? m.title : ''}, building no. ${C.seed}. The collapse was simulated, so the real damage is known exactly; these are the targets from our proposal.`],
      cmd: ['Handed to the incident commander', 'What the commander gets', 'Every line is a draft from this run’s measurements, with how far to trust it. These are drafts: the incident commander makes the call (Act 8).'],
    };
    el.innerHTML = `<div class="card" role="dialog" aria-label="End of Act 7"><p class="k">${head.truth[0]}</p><h2>${head.truth[1]}</h2>
      <p class="pl">${head.truth[2]}</p>
      <div class="tabs" role="tablist"><button type="button" role="tab" data-tab="truth" class="on" aria-selected="true">Against the truth</button><button type="button" role="tab" data-tab="cmd" aria-selected="false">What the commander gets</button></div>
      <div class="pane" data-pane="cmd" hidden>${commander(C, rooms || C.rooms, k)}</div>
      <div class="pane" data-pane="truth">
      <div class="a7score">${rows.map((r) => `<div class="row2${r.hl ? ' hl' : ''}${r.ok ? '' : ' miss'}"><div class="n">${r.n}<small>${r.sub}</small></div><div class="v ${r.ok ? 'ok' : 'bad'}">${r.v}</div><div class="tg">${r.tg} ${r.ok ? '<span class="ok">met</span>' : '<span class="bad">missed</span>'}</div></div>`).join('')}</div>
      <p class="note2">Also measured: pockets ${s.voids ? `${s.voidsFound} of ${s.voids} true voids found` : C.pockets.list.length ? 'no true voids' : 'none claimed, none there'}${C.pockets.list.length ? ` (${s.pocketTiers.gap.n} seen through a gap, ${s.pocketTiers.gap.false} false; ${s.pocketTiers.slab.n} possible under a slab, ${s.pocketTiers.slab.false} false)` : ''};${C.confidence.region ? ` re-fly ${Math.round(C.confidence.region.before * 100)} % to ${Math.round(C.confidence.region.after * 100)} % on its targets, ${C.confidence.unreachableN} weak spots left for a human;` : ''} registration within ${s.regCm.toFixed(1)} cm and ${s.regDeg.toFixed(2)}°; wall tilt within ${s.wallTiltErr.toFixed(2)}° on ${s.wallsMeasured} walls; ${s.overCautious} room${s.overCautious === 1 ? '' : 's'} more cautious than needed.</p></div>
      <div class="row">${hasNext ? '<button class="a7pri" type="button" data-a="next">Next: Act 8, decide</button>' : ''}<button class="${hasNext ? 'a7sec' : 'a7pri'}" type="button" data-a="replay">Watch again</button><button class="a7sec" type="button" data-a="picker">Collapse it differently</button><button class="a7sec" type="button" data-a="back">Back to the story</button></div></div>`;
    const b = (a, f) => { const x = el.querySelector(`[data-a="${a}"]`); if (x) x.addEventListener('click', () => f && f()); };
    b('next', onNext); b('replay', onReplay); b('picker', onPicker); b('back', onBack);
    el.querySelectorAll('[data-tab]').forEach((t) => t.addEventListener('click', () => {
      const id = t.dataset.tab; el.querySelectorAll('[data-tab]').forEach((q) => { const on = q === t; q.classList.toggle('on', on); q.setAttribute('aria-selected', String(on)); });
      el.querySelectorAll('[data-pane]').forEach((p) => { p.hidden = p.dataset.pane !== id; });
      el.querySelector('.k').textContent = head[id][0]; el.querySelector('h2').textContent = head[id][1]; el.querySelector('.pl').textContent = head[id][2];
    }));
    el.classList.remove('hide'); shown = true;
  }
  return { show, hide() { el.classList.add('hide'); shown = false; }, get shown() { return shown; } };
}
