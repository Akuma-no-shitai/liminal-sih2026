// The room card: click a room (or its label) for its name, draft status and the reason in plain words, and what was
// measured there; with the Truth lens on, the room's true status too.
import { roomFailure } from '../film/failure.js';
const WORD = { safe: 'Safe', caution: 'Caution', noentry: 'No entry', unseen: 'Never seen' };
const pct = (v) => `${Math.round(v * 100)} %`;
// the failure quantities that apply to this room (its walls, a pod on one of them, the part that moved)
function fqHtml(C, id, k) {
  const Q = roomFailure(C, id, Math.max(1, k)); if (!Q) return '';
  const it = [];
  if (Q.phi) it.push([Q.phi.value.toFixed(2), 'order φ_wall, its walls']);
  if (Q.xi) it.push([`${Q.xi.value.toFixed(1)} m`, 'correlation length ξ, damage touching it']);
  if (Q.sus) it.push([k ? `${pct(Q.sus.before)}, then ${pct(Q.sus.after)}` : pct(Q.sus.before), `susceptibility: stiffness lost, pod ${Q.sus.pod}`]);
  if (Q.tau) it.push([`${Q.tau.value.toFixed(1)} min`, Q.tau.growing ? 'relaxation time τ, growing' : 'relaxation time τ of the moved part']);
  return `<div class="fq"><h5>How close is it to failure?</h5><dl>${it.map(([v, l]) => `<div><dt>${v}</dt><dd>${l}</dd></div>`).join('')}</dl></div>`;
}
export function createRoomCard(el, { onClose } = {}) {
  el.className = 'a7room'; el.setAttribute('role', 'dialog'); el.setAttribute('aria-label', 'Room');
  let cur = -1;
  function show(C, id, { after = false, truth = false, k = 0 } = {}) {
    const room = C.model.rooms[id], d = (after ? C.roomsAfter : C.rooms)[id], t = C.truth.rooms[id]; cur = id;
    const f = (v, u, k = 1) => (v == null || !Number.isFinite(v) ? '<span style="opacity:.5">not seen</span>' : `${(v * k).toFixed(1)}${u}`);
    const why = d.why && d.why.length ? d.why[0] : d.status === 'safe' ? 'Nothing measured here crosses a caution threshold.' : '';
    el.innerHTML = `<button class="x" type="button" aria-label="Close">×</button><p class="k">Draft status${after ? ', after the aftershock' : ''}</p><h3>${room.name.replace(/^./, (m) => m.toUpperCase())}</h3>
      <span class="st ${d.status}">${WORD[d.status]}</span><p class="why">${why}</p>
      <dl><div><dt>${f(d.tilt, '°')}</dt><dd>tilt</dd></div><div><dt>${d.sagKnown ? f(d.sag, ' cm', 100) : '<span style="opacity:.5">not seen</span>'}</dt><dd>slab sag</dd></div><div><dt>${d.phiMin != null && Number.isFinite(d.phiMin) ? d.phiMin.toFixed(2) : '<span style="opacity:.5">none</span>'}</dt><dd>lowest φ_wall</dd></div>
      <div><dt>${pct(d.debrisShare || 0)}</dt><dd>floor under debris</dd></div><div><dt>${pct(C.roomConf[id] || 0)}</dt><dd>confidence</dd></div><div><dt>${pct(d.seen || 0)}</dt><dd>of it seen</dd></div></dl>
      ${fqHtml(C, id, k)}
      ${truth ? `<p class="truth">True status: <b>${WORD[t.status]}</b>${t.status === d.status ? ', the draft agrees.' : d.status === 'safe' ? '. The draft called it safe: a false-safe room.' : (t.status === 'safe' ? '. The draft was more cautious than needed.' : '.')}</p>` : ''}`;
    el.querySelector('.x').addEventListener('click', () => { hide(); onClose && onClose(); });
    el.classList.add('on');
  }
  function hide() { el.classList.remove('on'); cur = -1; }
  return { show, hide, get room() { return cur; }, get shown() { return el.classList.contains('on'); } };
}
