// The start screen: three failure modes with small procedural posters and "Surprise me"; the mode menu in the top bar;
// the computing overlay (real progress, a readable message and Try again if anything fails).
import { ICON } from './dock.js';
import { getTheme } from '../theme.js';
let PP = getTheme('dusk').poster;   // the posters' colours (from the theme)
const esc = (s) => String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;');
export const MODE_META = {
  softstorey: { id: 'softstorey', title: 'Soft storey', line: 'Ground-floor columns on one side fail; the upper floors drop and tilt toward that side.', shows: ['Debris at the base', 'Tilted upper floors', 'Ground floor mostly gone'] },
  pancake: { id: 'pancake', title: 'Corner pancake', line: 'One corner bay’s slabs come down through every floor.', shows: ['A deep debris pile', 'Lean-to voids between slabs', 'Where someone could be'] },
  lean: { id: 'lean', title: 'Leaning block', line: 'Still standing, tilted a few degrees, with cracked infill and a few fallen panels.', shows: ['Looks fine from the street', 'A tilt of a few degrees', 'The hardest call'] },
};
export const MODE_IDS = ['softstorey', 'pancake', 'lean'];

// posters: an elevation of the block in each state, drawn on a canvas
function poster(x, w, h, id) {
  const g = x.createLinearGradient(0, 0, 0, h); g.addColorStop(0, PP.sky[0]); g.addColorStop(.62, PP.sky[1]); g.addColorStop(1, PP.sky[2]); x.fillStyle = g; x.fillRect(0, 0, w, h);
  const gy = h * .82; x.fillStyle = PP.ground; x.fillRect(0, gy, w, h - gy);
  const bw = w * .56, bh = h * .52, bx = w * .22, fl = 4, sh = bh / fl;
  const facade = (ox, oy, ang, from = 0, to = fl, piv = [0, 0]) => {
    x.save(); x.translate(piv[0], piv[1]); x.rotate(ang); x.translate(-piv[0], -piv[1]);
    for (let f = from; f < to; f++) { const y = oy - (f + 1) * sh; x.fillStyle = PP.facade; x.fillRect(ox, y, bw, sh); x.fillStyle = PP.floor; x.fillRect(ox, y + sh - 4, bw, 4);
      for (let k = 0; k < 6; k++) { x.fillStyle = PP.win; x.fillRect(ox + 10 + k * (bw - 20) / 6, y + sh * .28, (bw - 20) / 6 - 10, sh * .38); } }
    x.fillStyle = PP.parapet; x.fillRect(ox - 2, oy - to * sh - 6, bw + 4, 6); x.restore();
  };
  const rub = (cx, cy, rw, rh, n, seed) => { let s = seed; const r = () => { s = (s * 16807) % 2147483647; return s / 2147483647; }; for (let i = 0; i < n; i++) { const px = cx + (r() - .5) * rw, py = cy - r() * rh * (1 - Math.abs(px - cx) / (rw / 2)); x.fillStyle = PP.rubble[i % 3]; x.save(); x.translate(px, py); x.rotate(r() * 3); x.fillRect(-4 - r() * 6, -3 - r() * 4, 8 + r() * 10, 6 + r() * 6); x.restore(); } };
  if (id === 'softstorey') {
    // the ground floor crushed (low on the failed side), the floors above resting on it and tilted toward that side
    x.fillStyle = PP.crushed; x.beginPath(); x.moveTo(bx, gy); x.lineTo(bx + bw, gy); x.lineTo(bx + bw, gy - sh * .55); x.lineTo(bx, gy - sh * .12); x.closePath(); x.fill();
    facade(bx, gy + sh * .45, -0.075, 1, 4, [bx + bw, gy - sh * .55]); rub(bx + bw * .05, gy, bw * .55, sh * .55, 70, 3); }
  else if (id === 'pancake') { facade(bx, gy, 0, 0, 4); x.fillStyle = PP.bay; x.fillRect(bx + bw * .7, gy - bh - 8, bw * .32, bh + 8); for (let k = 0; k < 4; k++) { x.save(); x.translate(bx + bw * .86, gy - 10 - k * 9); x.rotate(-.18); x.fillStyle = PP.slab; x.fillRect(-bw * .16, -3, bw * .32, 6); x.restore(); } rub(bx + bw * .9, gy, bw * .45, sh * .9, 60, 7); }
  else { facade(bx, gy, -0.06, 0, 4, [bx + bw, gy]); rub(bx + bw * .1, gy, bw * .25, sh * .2, 14, 5); x.strokeStyle = PP.mark; x.setLineDash([4, 4]); x.beginPath(); x.moveTo(bx + bw, gy); x.lineTo(bx + bw, gy - bh - 20); x.stroke(); x.setLineDash([]); }
  // a few drones above, landed swarm
  for (let i = 0; i < 6; i++) { const px = w * (.12 + i * .05), py = h * .9; x.fillStyle = PP.drone; x.beginPath(); x.arc(px, py, 2.4, 0, 7); x.fill(); }
}
// (an export for Act 8: the same poster drawn in a given theme's colours; Act 7 itself does not call it)
export function drawPoster(x, w, h, id, theme) { const keep = PP; PP = (theme || getTheme('dusk')).poster; try { poster(x, w, h, id); } finally { PP = keep; } }
export function createPicker(el, { onPick, onSurprise, theme = null }) {
  PP = (theme || getTheme('dusk')).poster;
  el.className = 'a7over a7pick hide';
  el.innerHTML = `<div class="in"><p class="kick">Act 7, what’s left standing</p><h1>The search is certified. <em>Now judge the building.</em></h1>
    <p class="lede">The drones have landed. The ground station compares the new scans with the survey made before the disaster, and measures what collapsed, how much debris there is, how each wall stands, where someone could still be, whether it is still moving, and how far to trust each number. The swarm stays at its tipping point by watching one order parameter, φ_swarm, the alignment of the drones’ headings; here the same tool is pointed at the walls as φ_wall, the alignment of their surfaces. Pick how the building failed; each run is simulated first, then played as a film, and scored against the real damage.</p>
    <div class="acts"><button class="a7pri" type="button" data-a="surprise">${ICON.play}Surprise me</button><span class="note">About three and a half minutes, and a new collapse every visit</span></div>
    <div class="a7grid3">${MODE_IDS.map((id, i) => { const m = MODE_META[id]; return `<button class="a7m" type="button" data-m="${id}"><canvas width="480" height="300" aria-hidden="true"></canvas><div class="b"><span class="n">${String(i + 1).padStart(2, '0')}</span><h3>${esc(m.title)}</h3><p class="pl">${esc(m.line)}</p><ul>${m.shows.map((s) => `<li>${esc(s)}</li>`).join('')}</ul><span class="go">Collapse it this way</span></div></button>`; }).join('')}</div>
    <p class="note" style="margin-top:18px">The building is an ordinary apartment block. The same pipeline runs on schools, hospitals and other critical sites, which is where the before-disaster surveys start.</p></div>`;
  el.querySelector('[data-a="surprise"]').addEventListener('click', () => onSurprise());
  el.querySelectorAll('[data-m]').forEach((b) => b.addEventListener('click', () => onPick(b.dataset.m)));
  const posters = [...el.querySelectorAll('.a7m canvas')];
  const draw = () => posters.forEach((cv, i) => { const r = cv.getBoundingClientRect(); const dpr = Math.min(2, devicePixelRatio || 1); const W = Math.max(200, Math.round(r.width * dpr)), H = Math.max(120, Math.round(r.height * dpr)); if (cv.width !== W || cv.height !== H) { cv.width = W; cv.height = H; } const x = cv.getContext('2d'); x.setTransform(1, 0, 0, 1, 0, 0); try { poster(x, W, H, MODE_IDS[i]); } catch (e) { /* a poster must never stop the page */ } });
  let shown = false;
  return { show() { el.classList.remove('hide'); shown = true; requestAnimationFrame(draw); setTimeout(draw, 120); }, hide() { el.classList.add('hide'); shown = false; }, get shown() { return shown; }, draw };
}
export function createModeMenu(btnWrap, { onPick, onSurprise }) {
  btnWrap.innerHTML = `<button class="a7pill" type="button" aria-haspopup="true"><span class="cur">Collapse it differently</span><svg viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round"><path d="M4 6l4 4 4-4"/></svg></button>
    <div class="a7menu" role="menu">${MODE_IDS.map((id, i) => `<button type="button" role="menuitem" data-m="${id}"><i>${String(i + 1).padStart(2, '0')}</i><b>${esc(MODE_META[id].title)}</b><span>${esc(MODE_META[id].line)}</span></button>`).join('')}<button type="button" role="menuitem" data-m="__surprise"><i class="pl">${ICON.play}</i><b>Surprise me</b><span>Any failure, a new seed</span></button></div>`;
  const btn = btnWrap.querySelector('.a7pill'), menu = btnWrap.querySelector('.a7menu'), cur = btnWrap.querySelector('.cur');
  btn.addEventListener('click', (e) => { e.stopPropagation(); menu.classList.toggle('on'); });
  menu.addEventListener('click', (e) => { const b = e.target.closest('[data-m]'); if (!b) return; menu.classList.remove('on'); if (b.dataset.m === '__surprise') onSurprise(); else onPick(b.dataset.m); });
  const close = (e) => { if (!btnWrap.contains(e.target)) menu.classList.remove('on'); };
  document.addEventListener('pointerdown', close);
  return { get open() { return menu.classList.contains('on'); }, close() { menu.classList.remove('on'); }, set(id) { cur.textContent = 'Collapse it differently'; menu.querySelectorAll('[data-m]').forEach((b) => b.classList.toggle('on', b.dataset.m === id)); }, dispose() { document.removeEventListener('pointerdown', close); } };
}
export function createSimOverlay(el) {
  el.className = 'a7over a7sim hide';
  el.innerHTML = '<div class="box"><p class="k">Simulating</p><h2></h2><p class="pl"></p><div class="bar"><s></s></div><p class="pc">0 %</p><p class="why">The collapse, both flights and every measurement run first. Then they play back as a film you can scrub.</p></div>';
  const h2 = el.querySelector('h2'), pl = el.querySelector('.pl'), bar = el.querySelector('.bar s'), pc = el.querySelector('.pc'), k = el.querySelector('.k');
  return {
    show(meta, label = 'Simulating') { el.classList.remove('failed'); k.textContent = label; h2.textContent = meta.title; pl.textContent = meta.line; bar.style.width = '0%'; pc.textContent = '0 %'; el.classList.remove('hide'); },
    progress(p, label) { el.classList.remove('failed'); bar.style.width = (Math.max(0, Math.min(1, p)) * 100).toFixed(1) + '%'; pc.textContent = `${label || 'Working'} ${Math.round(p * 100)} %`; },
    hide() { el.classList.add('hide'); el.classList.remove('failed'); },
    fail(text, onRetry, onBack) {
      el.classList.remove('hide'); el.classList.add('failed'); k.textContent = 'Something went wrong'; pc.textContent = text;
      let row = el.querySelector('.row'); if (!row) { row = document.createElement('div'); row.className = 'row'; el.querySelector('.box').appendChild(row); }
      row.innerHTML = '<button class="a7pri" type="button" data-a="retry">Try again</button><button class="a7sec" type="button" data-a="back">Back to the collapses</button>';
      row.querySelector('[data-a="retry"]').addEventListener('click', () => onRetry && onRetry());
      row.querySelector('[data-a="back"]').addEventListener('click', () => onBack && onBack());
    },
  };
}
