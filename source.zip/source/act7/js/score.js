/* LIMINAL: the After-phase scores (Acts 7 and 8), synthesised live with the Web Audio API: no samples, no files.
 * Ported from the sketches the team picked (act7/options/music_sketches.js: 5 "Countdown", 3 "Aftermath").
 *
 *   import { createScore } from './score.js';
 *   const music = createScore('countdown');   // Act 7: 96 bpm, a ticking clock, a heartbeat, short pulsing strings
 *   const music = createScore('aftermath');   // Act 8: 60 bpm, slow bowed strings in D minor, distant low thuds
 *
 * Same interface as music.js's createMusic, so the acts can swap one for the other:
 *   { start(), stop(), toggle(), setVolume(v), on, destroy() }
 *   start()    creates (or resumes) the AudioContext (first call must come from a user gesture), fades in over 2 s.
 *   stop()     fades out over 1.5 s, then suspends the context it created; start() during the fade picks up again.
 *   destroy()  stops at once and closes the context it created.
 * createScore(piece, { ctx }) with an OfflineAudioContext schedules the whole render length on start() (for level tests).
 */

// trims put both near the level of Acts 1-6's music (RMS about -22 dBFS, measured offline over 42 s; peaks about -3 dBFS)
const PIECES = {
  countdown: { trim: 1.3 },
  aftermath: { trim: 1.4 },
};
const LEVEL = 0.85, FADE_IN = 2, FADE_OUT = 1.5, AHEAD = 2.5, WAKE_MS = 250;   // 2.5 s ahead rides out long main-thread tasks

export function createScore(piece = 'countdown', { ctx: extCtx = null } = {}) {
  const P = PIECES[piece] || PIECES.countdown;
  let ac = extCtx, owns = !extCtx, G = null, state = 'off', timer = 0, stopTimer = 0, volume = 1, S = null;
  const offline = () => typeof OfflineAudioContext !== 'undefined' && ac instanceof OfflineAudioContext;

  /* ---- the graph: voices → (dry → fade) + (wet → room → fade); fade → compressor → out → speakers ---- */
  function build() {
    const all = [];
    const node = (n) => { all.push(n); return n; };
    const comp = node(ac.createDynamicsCompressor());
    comp.threshold.value = -10; comp.knee.value = 8; comp.ratio.value = 6; comp.attack.value = 0.006; comp.release.value = 0.3;
    const out = node(ac.createGain()); out.gain.value = volume * volume; comp.connect(out); out.connect(ac.destination);
    const fade = node(ac.createGain()); fade.gain.value = 0; fade.connect(comp);
    const len = Math.floor(ac.sampleRate * 3.2), ir = ac.createBuffer(2, len, ac.sampleRate); let s = 7;
    const rnd = () => { s = (s * 16807) % 2147483647; return s / 2147483647; };
    for (let ch = 0; ch < 2; ch++) { const d = ir.getChannelData(ch); for (let i = 0; i < len; i++) d[i] = (rnd() * 2 - 1) * Math.pow(1 - i / len, 2.6); }
    const verb = node(ac.createConvolver()); verb.buffer = ir; const vg = node(ac.createGain()); vg.gain.value = 0.55; verb.connect(vg); vg.connect(fade);
    // a few short noise bursts, made once (the clock ticks pick one at random)
    const noise = [0, 1, 2, 3].map(() => { const b = ac.createBuffer(1, Math.floor(ac.sampleRate * 0.03), ac.sampleRate), d = b.getChannelData(0); for (let i = 0; i < d.length; i++) d[i] = (Math.random() * 2 - 1) * Math.pow(1 - i / d.length, 6); return b; });
    return { all, comp, out, fade, verb, noise };
  }
  const hz = (m) => 440 * Math.pow(2, (m - 69) / 12);
  const pick = (a) => a[Math.floor(Math.random() * a.length)];
  function send(n, dry = 0.7, wet = 0.5) {
    const d = ac.createGain(); d.gain.value = dry; const w = ac.createGain(); w.gain.value = wet;
    n.connect(d); n.connect(w); d.connect(G.fade); w.connect(G.verb);
  }

  /* ---- voices ---- */
  function tick(t, vel, freq, q) {
    const n = ac.createBufferSource(); n.buffer = pick(G.noise);
    const f = ac.createBiquadFilter(); f.type = 'bandpass'; f.frequency.value = freq; f.Q.value = q; const g = ac.createGain(); g.gain.value = vel;
    n.connect(f); f.connect(g); send(g, 0.8, 0.15); n.start(t);
  }
  function kick(t, vel) {   // the heartbeat
    const o = ac.createOscillator(); o.type = 'sine'; o.frequency.setValueAtTime(95, t); o.frequency.exponentialRampToValueAtTime(42, t + 0.16);
    const g = ac.createGain(); g.gain.setValueAtTime(0, t); g.gain.linearRampToValueAtTime(vel, t + 0.006); g.gain.exponentialRampToValueAtTime(0.0001, t + 0.34);
    o.connect(g); send(g, 0.9, 0.15); o.start(t); o.stop(t + 0.36);
  }
  function pad(t, midis, dur, vel = 0.06, cutoff = 900, atk = 0.35) {   // bowed strings: detuned saws, slow attack, low-pass
    midis.forEach((m) => [-6, 0, 7].forEach((cents) => {
      const o = ac.createOscillator(); o.type = 'sawtooth'; o.frequency.value = hz(m); o.detune.value = cents;
      const f = ac.createBiquadFilter(); f.type = 'lowpass'; f.frequency.value = cutoff; f.Q.value = 0.7;
      const g = ac.createGain(); g.gain.setValueAtTime(0, t); g.gain.linearRampToValueAtTime(vel, t + dur * atk); g.gain.setValueAtTime(vel, t + dur * 0.7); g.gain.linearRampToValueAtTime(0, t + dur);
      o.connect(f); f.connect(g); send(g, 0.55, 0.6); o.start(t); o.stop(t + dur + 0.05);
    }));
  }
  function thud(t, vel) {   // a distant aftershock
    const o = ac.createOscillator(); o.type = 'sine'; o.frequency.setValueAtTime(70, t); o.frequency.exponentialRampToValueAtTime(32, t + 1.4);
    const g = ac.createGain(); g.gain.setValueAtTime(0, t); g.gain.linearRampToValueAtTime(vel, t + 0.03); g.gain.exponentialRampToValueAtTime(0.0001, t + 2.2);
    o.connect(g); send(g, 0.8, 0.5); o.start(t); o.stop(t + 2.3);
  }
  function bell(t, midi, vel, dur) {   // two-operator FM
    const car = ac.createOscillator(), mod = ac.createOscillator(), mg = ac.createGain(), g = ac.createGain();
    car.frequency.value = hz(midi); mod.frequency.value = hz(midi) * 3.5; mg.gain.setValueAtTime(hz(midi) * 2.2, t); mg.gain.exponentialRampToValueAtTime(1, t + dur);
    mod.connect(mg); mg.connect(car.frequency);
    g.gain.setValueAtTime(0, t); g.gain.linearRampToValueAtTime(vel, t + 0.005); g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
    car.connect(g); send(g, 0.5, 0.7); car.start(t); mod.start(t); car.stop(t + dur); mod.stop(t + dur);
  }

  /* ---- the two pieces: step(s) schedules one event at s.next and moves s.next on ---- */
  const CHORDS = [[50, 57, 62, 65], [46, 53, 58, 62], [41, 48, 53, 57], [48, 55, 60, 64]];   // Dm Bb F C
  const STEP = {
    countdown(s) {   // eighth notes at 96 bpm; A minor, F, G under a clock and a heartbeat
      const beat = 60 / 96, e = beat / 2, bar4 = Math.floor(s.k / 16);
      tick(s.next, s.k % 2 ? 0.05 : 0.085, s.k % 2 ? 2300 : 3100, 8);
      if (s.k % 8 === 0) { kick(s.next, 0.5); kick(s.next + 0.23, 0.3); }
      const root = [57, 57, 53, 55][bar4 % 4], cell = [0, 3, 7, 3, 0, 3, 8, 3];
      pad(s.next, [root + cell[s.k % 8] - 12], e * 0.85, 0.05, 1100, 0.15);
      if (s.k % 32 === 0) pad(s.next, [root, root + 7], beat * 16, 0.018, 1100);
      if (s.k % 64 === 48) pad(s.next, [root + 12, root + 19], beat * 8, 0.02, 1800, 0.9);
      s.next += e; s.k++;
    },
    aftermath(s) {   // one chord per 4-second bar at 60 bpm
      const beat = 1, bar = 4, c = CHORDS[s.k % 4];
      pad(s.next, c, bar * 1.05, 0.045);
      if (Math.random() < 0.35) thud(s.next + beat * (1 + Math.random() * 2), 0.42);
      if (Math.random() < 0.5) bell(s.next + beat * 2, c[3] + 24, 0.035, 4);
      s.next += bar; s.k++;
    },
  };
  const step = STEP[piece] || STEP.countdown;
  function scheduleUntil(t) {
    if (S.next < ac.currentTime) S.next = ac.currentTime + 0.05;   // after a throttled timer: skip ahead, never burst
    while (S.next < t) step(S);
  }
  function wake() { timer = 0; if (state === 'off' || state === 'destroyed') return; scheduleUntil(ac.currentTime + AHEAD); timer = setTimeout(wake, WAKE_MS); }
  function fadeTo(v, dur) {
    const g = G.fade.gain, now = ac.currentTime;
    g.cancelScheduledValues(now); g.setValueAtTime(g.value, now); g.linearRampToValueAtTime(v, now + dur);
    return now + dur;
  }

  function start() {
    if (state === 'destroyed') return;
    if (!ac) {
      const AC = globalThis.AudioContext || globalThis.webkitAudioContext; if (!AC) return;
      try { ac = new AC({ latencyHint: 'playback' }); } catch (e) { ac = new AC(); }
    }
    if (!G) G = build();
    if (stopTimer) { clearTimeout(stopTimer); stopTimer = 0; }
    if (!offline() && ac.state === 'suspended') { const p = ac.resume(); if (p && p.catch) p.catch(() => {}); }
    if (state === 'on') return;
    const wasOff = state === 'off';
    state = 'on';
    fadeTo(LEVEL * P.trim, FADE_IN);
    if (!S) S = { next: ac.currentTime + 0.1, k: 0 };
    if (offline()) { scheduleUntil(ac.length / ac.sampleRate); return; }
    if (wasOff || !timer) wake();
  }
  function stop() {
    if (!ac || state !== 'on') return;
    state = 'stopping';
    const end = fadeTo(0, FADE_OUT);
    if (offline()) { state = 'off'; return; }
    const finish = () => {
      stopTimer = 0; if (state !== 'stopping') return;
      if (ac.state === 'running' && ac.currentTime < end - 0.01) { stopTimer = setTimeout(finish, (end - ac.currentTime) * 1000 + 30); return; }
      state = 'off'; if (timer) { clearTimeout(timer); timer = 0; }
      if (owns && ac.state === 'running') ac.suspend().catch(() => {});
    };
    stopTimer = setTimeout(finish, FADE_OUT * 1000 + 60);
  }
  function destroy() {
    if (state === 'destroyed') return;
    state = 'destroyed';
    if (timer) { clearTimeout(timer); timer = 0; }
    if (stopTimer) { clearTimeout(stopTimer); stopTimer = 0; }
    if (!ac || !G) { if (owns && ac && ac.state !== 'closed') ac.close().catch(() => {}); return; }
    const finish = () => { for (const n of G.all) { try { n.disconnect(); } catch (e) { /* fine */ } } if (owns && ac.state !== 'closed') ac.close().catch(() => {}); };
    if (!offline() && ac.state === 'running') { fadeTo(0, 0.06); setTimeout(finish, 90); } else finish();
  }
  return {
    start, stop, destroy,
    toggle() { if (state === 'on') stop(); else start(); return state === 'on'; },
    setVolume(v) { volume = Math.min(1, Math.max(0, Number(v) || 0)); if (G) G.out.gain.setTargetAtTime(volume * volume, ac.currentTime, 0.06); },
    get on() { return state === 'on'; },
  };
}
