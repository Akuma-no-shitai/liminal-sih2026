// Act 8's styles (#a8css), on top of Act 7's (#a7css) and Act 2's (#a2css, for the table panel and the assumptions
// panel): the commander's clock, the board, the room card's evidence and override, the table's rows, card row tones.
export const CSS8 = `
.a8 .a7chipsim .s { display: none; }
.a8 .a7chip.a2sbx.on { background: var(--paper); color: var(--ink); border-color: var(--paper); }
.a8 .a7card .q4 .r.warn b { color: var(--caution-txt); }
.a8 .a7card .q4 .r.bad b { color: var(--danger-txt); }
.a8 .a7card .q4 .r.nr b, .a8 .a7card .q4 .r.nr .n { color: var(--muted); }
.a8 .a7card .q4 b { color: var(--paper); white-space: normal; text-align: right; max-width: 11em; }
.a8 .a7card .q4 .r { grid-template-columns: minmax(0, 1fr) auto; }
.a8 .a7card .lab.as { border-color: rgba(var(--heat-rgb),.45); }
.a8 .a7card h4 { flex: none; white-space: nowrap; }
.a8 .a7card .tag { flex: 1; min-width: 0; text-align: right; line-height: 1.25; }
.a8 .a7card .st { flex-wrap: wrap; row-gap: 2px; }
.a8 .a7card .st span { white-space: nowrap; }
.a8 .a7card[data-card="interval"] canvas { height: 104px; }
.a8 .a7lab.room.ov { border-style: dashed; }
/* the commander's clock */
.a8clock .t { font: 500 15px/1.15 var(--mono); color: var(--paper); margin-top: 2px; }
.a8clock .s { font: 11.5px/1.3 var(--sans); color: var(--muted); margin-top: 2px; }
/* the board (the brief): left of the cards, clear of the caption */
.a8board { position: absolute; z-index: 10; left: 22px; top: calc(var(--top) + 44px); bottom: calc(var(--dock) + 118px); width: min(560px, calc(100% - var(--cards) - 70px)); overflow-y: auto; scrollbar-width: thin; }
.a8board[hidden] { display: none; }
.a8board .box { padding: 16px 18px 14px; border-radius: 18px; background: rgba(var(--card-rgb),.93); border: 1px solid rgba(var(--line-rgb),.18); box-shadow: 0 20px 50px rgba(var(--shadow-rgb),.4); backdrop-filter: blur(12px); -webkit-backdrop-filter: blur(12px); }
.a8board .k { font: 500 12.5px/1 var(--sans); color: var(--teal-txt); margin: 0 0 6px; }
.a8board h3 { font: 400 22px/1.12 var(--serif); margin: 0 0 10px; }
.a8board .cmd, .a8 .a7rep .cmd { display: grid; gap: 8px; }
.a8board .cmd section { padding: 9px 11px; border-radius: 12px; background: rgba(var(--well-rgb),.42); border: 1px solid rgba(var(--line-rgb),.1); }
.a8board .cmd h5 { margin: 0 0 5px; font: 500 12px/1.2 var(--sans); color: var(--haze-txt); }
.a8board .cmd p { margin: 0; font: 12.5px/1.45 var(--sans); color: rgba(var(--fg-rgb),.88); }
.a8board .cmd p + p { margin-top: 3px; }
.a8board .cmd b { font-family: var(--mono); font-weight: 500; color: var(--paper); }
.a8board .cmd .draft { font: 12px/1.4 var(--sans); color: var(--faint); margin-top: 4px; }
.a8board .cmd .chips { display: flex; flex-wrap: wrap; gap: 5px; margin-top: 4px; }
.a8board .cmd .chips span { font: 11.5px/1 var(--sans); padding: 5px 8px; border-radius: 999px; background: rgba(var(--line-rgb),.08); color: rgba(var(--fg-rgb),.86); }
.a8board .cmd .chips span.noentry { background: rgba(var(--danger-rgb),.16); color: var(--danger-on); }
.a8board .cmd .chips span.caution { background: rgba(var(--caution-rgb),.14); color: var(--caution-on); }
.a8board .cmd .chips span.safe { background: rgba(var(--safe-rgb),.14); color: var(--safe-on); }
.a8board .cmd .chips span.ov { background: rgba(var(--heat-rgb),.14); color: var(--heat-on); }
.a8board .cmd .log { background: rgba(var(--heat-rgb),.08); border-color: rgba(var(--heat-rgb),.3); }
.a8board .cmd .log p.warn, .a8tb .log p.warn { color: var(--caution-on); }
.a7.boardon .a7cap { opacity: .0; }
.a7.boardon .a8clock { opacity: 0; }
.a8 .a7labels { clip-path: inset(0 0 calc(var(--dock) + 2px) 0); }
/* the room card: evidence with ranges, and the override */
.a8room { width: min(420px, calc(100% - 60px)); max-height: calc(100% - var(--top) - var(--dock) - 60px); overflow-y: auto; }
.a8room .evg { display: grid; grid-template-columns: repeat(2, minmax(0, 1fr)); gap: 6px 10px; margin: 0 0 8px; }
.a8room .q { padding: 6px 8px; border-radius: 9px; background: rgba(var(--well-rgb),.4); border-left: 3px solid rgba(var(--safe-rgb),.7); }
.a8room .q.between, .a8room .q.straddles { border-left-color: rgba(var(--caution-rgb),.85); }
.a8room .q.over { border-left-color: rgba(var(--danger-rgb),.9); }
.a8room .q span { display: block; font: 11.5px/1.2 var(--sans); color: var(--faint); }
.a8room .q b { font: 500 14px/1.2 var(--mono); color: var(--paper); }
.a8room .q small { display: block; font: 10.5px/1.3 var(--mono); color: var(--faint); margin-top: 1px; }
.a8room .draft { color: var(--faint); }
.a8room .st.safe { background: rgba(var(--safe-rgb),.16); color: var(--safe-on); }
.a8room .ovr { display: flex; flex-wrap: wrap; align-items: center; gap: 6px; margin-top: 8px; }
.a8room .ovr .k2 { font: 500 12px/1 var(--sans); color: var(--haze-txt); margin-right: 2px; }
.a8room .ovr button { height: 30px; padding: 0 12px; border-radius: 999px; border: 1px solid var(--line); background: transparent; color: var(--muted); font: 500 12px/1 var(--sans); cursor: pointer; }
.a8room .ovr button.on.safe { background: rgba(var(--safe-rgb),.2); color: var(--safe-on); border-color: rgba(var(--safe-rgb),.6); }
.a8room .ovr button.on.caution { background: rgba(var(--caution-rgb),.2); color: var(--caution-on); border-color: rgba(var(--caution-rgb),.6); }
.a8room .ovr button.on.noentry { background: rgba(var(--danger-rgb),.2); color: var(--danger-on); border-color: rgba(var(--danger-rgb),.6); }
.a8room .ovl { margin: 6px 0 0; padding: 8px 10px; border-radius: 10px; background: rgba(var(--heat-rgb),.1); font: 12.5px/1.4 var(--sans); color: rgba(var(--fg-rgb),.88); }
.a8room .ovl.warn { background: rgba(var(--caution-rgb),.14); color: var(--caution-on); }
.a8room .hint { margin: 6px 0 0; font: 12px/1.4 var(--sans); color: var(--faint); }
/* the table */
.a8tb .k2 { margin: 0 0 4px; font: 500 12px/1.2 var(--sans); color: var(--haze-txt); }
.a8tb .sites { display: grid; gap: 5px; }
.a8tb .site { display: grid; grid-template-columns: 22px minmax(0, 1fr) auto auto; gap: 4px 6px; align-items: center; padding: 6px 7px; border-radius: 10px; background: rgba(var(--well-rgb),.38); }
.a8tb .site button.tg { grid-column: 2 / -1; justify-self: start; }
.a8tb .site.off { opacity: .55; }
.a8tb .site .n { font: italic 300 16px/1 var(--serif); color: var(--heat-txt); text-align: center; }
.a8tb .site .t { font: 12px/1.3 var(--sans); color: var(--paper); min-width: 0; }
.a8tb .site .t small { display: block; font: 11px/1.3 var(--sans); color: var(--faint); }
.a8tb .site button { height: 26px; min-width: 26px; padding: 0 8px; border-radius: 999px; border: 1px solid var(--line); background: transparent; color: var(--muted); font: 11.5px/1 var(--sans); cursor: pointer; }
.a8tb .site button.ar { padding: 0; width: 26px; display: grid; place-items: center; } .a8tb .site button.ar svg { width: 13px; height: 13px; }
.a8tb .site button.tg.on { background: var(--paper); color: var(--ink); border-color: var(--paper); }
.a8tb .read { display: grid; grid-template-columns: repeat(2, minmax(0, 1fr)); gap: 6px; }
.a8tb .read > div { display: flex; flex-direction: column; gap: 2px; min-width: 0; padding: 7px 9px; border-radius: 10px; background: rgba(var(--panel-rgb), .45); border: 1px solid var(--line); }
.a8tb .read small { font: 11px/1.25 var(--sans); color: var(--faint); }
.a8tb .read b { font: 600 13px/1.25 var(--mono); color: var(--text); white-space: normal; overflow-wrap: anywhere; }
.a8tb .read b.bad { color: var(--danger, #e98a7a); }
.a8tb .log p { margin: 0 0 3px; font: 12px/1.4 var(--sans); color: rgba(var(--fg-rgb),.86); }
.a8tb .ms { margin: 0; font: 11px/1.2 var(--mono); color: var(--faint); }
.a8 .a7rep ol li span { min-width: 0; }
/* a short desktop window (1280 x 720): the room card's evidence in three compact columns, so Override stays in view */
@media (min-width: 761px) and (max-height: 820px) {
  .a8room { padding-top: 14px; padding-bottom: 12px; }
  .a8room h3 { font-size: 20px; margin-bottom: 4px; }
  .a8room .evg { grid-template-columns: repeat(3, minmax(0, 1fr)); gap: 4px 6px; margin-bottom: 4px; }
  .a8room .q { padding: 4px 6px; }
  .a8room .q span { font-size: 10.5px; }
  .a8room .q b { font-size: 12.5px; }
  .a8room .q small { font-size: 9.5px; line-height: 1.2; }
  .a8room .ovl { padding: 6px 8px; font-size: 11.5px; }
  .a8room .ovr { margin-top: 6px; }
}
/* a dig site whose lane the safe lifts cannot open */
.a8board .flag, .a8tb .site em.flag { color: var(--caution-on, #e8c27a); font-style: normal; }
.a8tb .site em.flag { display: block; }
/* the end card: the list scrolls above a fixed row of buttons on its own background (nothing overlaps) */
.a8 .a7rep .card { display: flex; flex-direction: column; overflow: hidden; padding: 0; }
.a8 .a7rep .card .body { overflow-y: auto; min-height: 0; padding: 26px 28px 14px; }
.a8 .a7rep .card .row { position: static; flex: none; margin: 0; padding: 14px 28px 18px; background: rgb(var(--card-rgb)); border-top: 1px solid rgba(var(--line-rgb), .16); }
.a7lab.lock { padding: 3px 7px; } .a7lab.lock svg { vertical-align: -2px; margin-right: 4px; } .a7lab.lock small { display: inline; }
@media (max-width: 760px) {
  .a8 .a7labels { clip-path: none; }
  .a8 .a7chipsim { right: 8px; height: auto; min-height: 24px; padding: 4px 10px; font-size: 10.5px; line-height: 1.3; border-radius: 12px; }
  .a8clock { display: none; }
  .a8board { position: relative; grid-area: cards; left: auto; top: auto; bottom: auto; width: auto; margin: 8px 10px 12px; overflow: visible; }
  .a7.boardon .a7cards { display: none; }
  .a7.boardon .a7cap { opacity: 1; }
  .a8board h3 { font-size: 18px; }
  .a8room { left: 8px; right: 8px; width: auto; max-height: 62svh; }
  .a8 .a7rep .card .body { padding: 18px 18px 10px; } .a8 .a7rep .card .row { padding: 12px 18px 14px; }
  .a8room .evg { grid-template-columns: 1fr 1fr; }
  .a8 .a7tog { top: calc(var(--top) + 52svh - 82px); }
}
`;
