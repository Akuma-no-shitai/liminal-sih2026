// The commander's table (the sandbox): sliders for the re-entry tolerance and shift, the number of teams, the truck size
// and the lift rate; dig sites on and off (already checked by hand) and up or down; the override log. Every change
// reruns plan() (everything downstream: window, dig order and times, lanes, the clearance plan, the brief, the scores)
// and the panel reads it out.
import { clockText } from '../decide/reentry.js';
import { placardWord } from '../decide/status.js';
import { RoomName } from '../film/script.js';
const pct = (v) => `${Math.round(v * 100)} %`;
const odds = (v) => (v < 0.005 ? 'under 1 %' : pct(v));
const hrs = (h) => (h == null || !Number.isFinite(h) ? '—' : h < 1 ? `${Math.round(h * 60)} min` : `${h.toFixed(1)} h`);
const esc = (s) => String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;');
const UP = '<svg viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"><path d="M4 10l4-4 4 4"/></svg>', DN = '<svg viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"><path d="M4 6l4 4 4-4"/></svg>';
export function createTable(el, { onChange, onClose, onBoard, onAssumptions, onReset }) {
  el.className = 'a2sb a8tb'; el.hidden = true;
  let D = null, S = null, P = null, truth = false;
  const ctl = [
    ['tolerance', 'Re-entry tolerance, per shift', 0.02, 0.3, 0.01, (v) => pct(v)],
    ['shiftH', 'Shift length', 4, 24, 1, (v) => `${v} h`],
    ['teams', 'Teams', 1, 4, 1, (v) => `${v}`],
    ['truck', 'Truck size (loose)', 6, 20, 1, (v) => `${v} m³`],
    ['liftRate', 'Lift rate', 1, 10, 0.5, (v) => `${v} m³/h`],
  ];
  el.innerHTML = `<header><h4>The commander’s table</h4><span class="tag">advice only</span><button class="x" type="button" aria-label="Close the table">×</button></header>
    <p class="hint">Tap a room for its evidence and to override it. Change anything below: the window, the dig order, the lanes and the clearance plan recompute.</p>
    <div class="ctl">${ctl.map(([k, n, a, b, s]) => `<label>${n}<output data-o="${k}"></output><input type="range" min="${a}" max="${b}" step="${s}" data-k="${k}" aria-label="${n}"></label>`).join('')}</div>
    <div class="sites"></div>
    <div class="read"></div>
    <div class="log"></div>
    <p class="ms"></p>
    <div class="row"><button class="a7pri" type="button" data-a="board">The board</button><button class="a7sec" type="button" data-a="asm">Assumptions</button><button class="a7sec" type="button" data-a="reset">Reset</button></div>`;
  const out = (k) => el.querySelector(`[data-o="${k}"]`), inp = (k) => el.querySelector(`[data-k="${k}"]`);
  el.querySelectorAll('input[type=range]').forEach((r) => r.addEventListener('input', () => { const k = r.dataset.k, v = +r.value; S = { ...S, [k]: v }; paintCtl(); onChange(S); }));
  el.querySelector('.x').addEventListener('click', () => onClose());
  el.querySelector('[data-a="board"]').addEventListener('click', () => onBoard());
  el.querySelector('[data-a="asm"]').addEventListener('click', () => onAssumptions());
  el.querySelector('[data-a="reset"]').addEventListener('click', () => onReset());
  el.querySelector('.sites').addEventListener('click', (e) => {
    const b = e.target.closest('[data-s]'); if (!b || !D) return; const i = +b.dataset.s, act = b.dataset.act;
    const off = new Set(S.siteOff || []); const order = siteOrder();
    if (act === 'off') { off.has(i) ? off.delete(i) : off.add(i); S = { ...S, siteOff: [...off] }; }
    else { const j = order.indexOf(i), t = act === 'up' ? j - 1 : j + 1; if (j < 0 || t < 0 || t >= order.length) return; [order[j], order[t]] = [order[t], order[j]]; S = { ...S, siteOrder: order }; }
    onChange(S);
  });
  // the dig sites as listed: the commander's order if set, else the computed order (by the time each is reached), the
  // sites checked by hand last
  function siteOrder() { if (S.siteOrder && S.siteOrder.length) return S.siteOrder.concat(D.sites.map((s2, i) => i)).filter((v, i, a) => a.indexOf(v) === i);
    return D.sites.map((s2, i) => i).sort((a, b) => { const oa = P.sched.sites[a], ob = P.sched.sites[b]; return (oa ? oa.rank : 999 + a) - (ob ? ob.rank : 999 + b); }); }
  function paintCtl() { for (const [k, , , , , f] of ctl) { const v = S[k]; const r = inp(k); if (+r.value !== v) r.value = v; out(k).textContent = f(v); } }
  function paint() {
    if (!D || !P) return; const C = D.C, ev = D.ev, RE = P.RE, sc = P.score;
    const order = siteOrder();
    el.querySelector('.sites').innerHTML = D.sites.length ? `<p class="k2">Dig sites${S.siteOrder && S.siteOrder.length ? ', your order' : ', computed order'}</p>` + order.map((i) => { const s = D.sites[i], o = P.sched.sites[i], on = !(S.siteOff || []).includes(i);
      return `<div class="site${on ? '' : ' off'}"><span class="n">${o ? o.rank + 1 : '–'}</span><span class="t">${s.kind === 'gap' ? 'Void seen through a gap' : 'Void under a slab'}, ${s.vol.toFixed(1)} m³<small>odds ${odds(s.p)}${o ? `; team ${o.team + 1}; reached in ${hrs(o.t1)}` : '; checked by hand'}${o && o.time.stuck ? '<em class="flag">lane: an engineer’s look first</em>' : ''}</small></span><button type="button" data-s="${i}" data-act="up" aria-label="Move up" class="ar">${UP}</button><button type="button" data-s="${i}" data-act="down" aria-label="Move down" class="ar">${DN}</button><button type="button" data-s="${i}" data-act="off" class="tg${on ? '' : ' on'}">${on ? 'Mark checked by hand' : 'Dig it again'}</button></div>`; }).join('') : '<p class="k2">No candidate void in this collapse.</p>';
    const cnt = { safe: 0, restricted: 0, unsafe: 0 }; P.rooms.forEach((r) => cnt[r.status]++);
    const blk = (label, value, bad = false) => `<div><small>${label}</small><b${bad ? ' class="bad"' : ''}>${value}</b></div>`;
    el.querySelector('.read').innerHTML = [blk('Safe rooms', cnt.safe), blk('Restricted rooms', cnt.restricted), blk('Unsafe rooms', cnt.unsafe),
      blk(`Window opens (${P.reList.length} ${P.reList.length === 1 ? 'room' : 'rooms'})`, RE.open != null ? clockText(ev, RE.open) : 'not within 60 days'), blk('Last dig site reached', hrs(P.sched.finish)),
      blk('Lanes open by safe lifts', P.lanes.sites ? `${P.lanes.sitesOpen} of ${P.lanes.sites}` : 'no dig site', P.lanes.sites && P.lanes.sitesOpen < P.lanes.sites), blk('On the lanes, a closer look', `${P.lanes.left.vol.toFixed(1)} m³`, P.lanes.left.vol > 0.05),
      blk(`To move, ${P.CL.trucks} truck ${P.CL.trucks === 1 ? 'load' : 'loads'}`, `${P.CL.moved.toFixed(1)} m³`), blk('Machine time', hrs(P.CL.hours)),
      truth ? blk('False-safe rooms (truth)', `${sc.fs} of ${sc.safe}`, sc.fs > 0) : blk('Scores against the truth', 'Truth lens'),
      ...(truth ? [blk('To reach the truly trapped', sc.reached ? hrs(sc.mean) : 'nobody trapped'), blk('Heavy drops (truth)', `${sc.bigDrops} of ${sc.steps}`, sc.bigDrops > 0), blk('Needless closures', sc.needless)] : [])].join('');
    const log = S.log || [];
    el.querySelector('.log').innerHTML = log.length ? `<p class="k2">Override log</p>${log.slice(-5).reverse().map((l) => `<p class="${l.less ? 'warn' : ''}">${esc(l.t)}: ${esc(RoomName(C, l.id))} ${esc(placardWord[l.from].toLowerCase())} to <b>${esc(l.to === 'clear' ? 'computed' : placardWord[l.to].toLowerCase())}</b>${l.less ? '. Less cautious than the evidence: allowed, with a warning' : ''}</p>`).join('')}` : '';
    el.querySelector('.ms').textContent = `Recomputed in ${P.ms} ms.`;
  }
  return {
    open(d, s, p, t) { D = d; S = s; P = p; truth = t; el.hidden = false; paintCtl(); paint(); },
    update(s, p, t) { S = s; P = p; truth = t; paintCtl(); paint(); },
    close() { el.hidden = true; }, get shown() { return !el.hidden; },
  };
}
