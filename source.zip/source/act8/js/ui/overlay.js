// Act 8's panels: the start screen (Act 7's three posters), the commander's board (the brief on one page), the end card,
// the assumptions panel and the room card (evidence with ranges, and the override).
import { MODE_META, MODE_IDS, drawPoster } from '../../../act7/js/ui/picker.js';
import { ICON } from '../../../act7/js/ui/dock.js';
import { getTheme } from '../../../act7/js/theme.js';
import { clockText, RJ, MD } from '../decide/reentry.js';
import { fmtQ, QNAME, placardWord, ORDER } from '../decide/status.js';
import { LIMITS, RULE } from '../decide/calib.js';
import { SURV } from '../decide/survivors.js';
import { DIG } from '../decide/digorder.js';
import { CLEAR } from '../decide/clearance.js';
import { RESCAN } from '../decide/rescan.js';
import { FRAGILITY_PRIOR } from '../decide/fragility.js';
import { RoomName } from '../film/script.js';
const esc = (s) => String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;');
const pct = (v) => `${Math.round(v * 100)} %`;
const m3 = (v) => (v >= 100 ? `${Math.round(v)} m³` : `${v.toFixed(1)} m³`);
const hrs = (h) => (h == null || !Number.isFinite(h) ? '—' : h < 1 ? `${Math.round(h * 60)} min` : `${h.toFixed(1)} h`);
const odds = (v) => (v < 0.005 ? 'under 1 %' : pct(v));
const loads = (n) => `${n} truck ${n === 1 ? 'load' : 'loads'}`;
const FL = ['Ground floor', 'First floor', 'Second floor', 'Third floor'];
const CLS = { safe: 'safe', restricted: 'caution', unsafe: 'noentry' };

// ------------------------------------------------------------------ the start screen
export function createPicker(el, { onPick, onSurprise, theme }) {
  el.className = 'a7over a7pick hide';
  el.innerHTML = `<div class="in"><p class="kick">Act 8, the commander’s table</p><h1>The building is measured. <em>Now decide.</em></h1>
    <p class="lede">Act 7 measured a collapsed apartment block: draft room statuses, candidate voids, debris, how close it is to failure. Here those numbers become the plan an incident commander acts on: which rooms are safe, restricted or unsafe, when people may go back in, where to dig first, what to lift and in which order, what to haul away. Every decision is computed from the measurements, with a stated range; because the collapse is simulated, every decision is also scored against the truth, and the misses are shown. Pick how the building failed: the same collapse Act 7 measured, from the same seed.</p>
    <div class="acts"><button class="a7pri" type="button" data-a="surprise">${ICON.play}Surprise me</button><span class="note">About three minutes, then the commander’s table is yours</span></div>
    <div class="a7grid3">${MODE_IDS.map((id, i) => { const m = MODE_META[id]; return `<button class="a7m" type="button" data-m="${id}"><canvas width="480" height="300" aria-hidden="true"></canvas><div class="b"><span class="n">${String(i + 1).padStart(2, '0')}</span><h3>${esc(m.title)}</h3><p class="pl">${esc(m.line)}</p><ul>${m.shows.map((s) => `<li>${esc(s)}</li>`).join('')}</ul><span class="go">Decide this one</span></div></button>`; }).join('')}</div>
    <p class="note" style="margin-top:18px">Simulated collapse and simulated occupants; advice only, the commander decides.</p></div>`;
  el.querySelector('[data-a="surprise"]').addEventListener('click', () => onSurprise());
  el.querySelectorAll('[data-m]').forEach((b) => b.addEventListener('click', () => onPick(b.dataset.m)));
  const posters = [...el.querySelectorAll('.a7m canvas')];
  const draw = () => posters.forEach((cv, i) => { const r = cv.getBoundingClientRect(); const dpr = Math.min(2, devicePixelRatio || 1); const W = Math.max(200, Math.round(r.width * dpr)), H = Math.max(120, Math.round(r.height * dpr)); if (cv.width !== W || cv.height !== H) { cv.width = W; cv.height = H; } const x = cv.getContext('2d'); x.setTransform(1, 0, 0, 1, 0, 0); try { drawPoster(x, W, H, MODE_IDS[i], theme); } catch (e) { /* a poster never stops the page */ } });
  let shown = false;
  return { show() { el.classList.remove('hide'); shown = true; requestAnimationFrame(draw); setTimeout(draw, 120); }, hide() { el.classList.add('hide'); shown = false; }, get shown() { return shown; } };
}

// ------------------------------------------------------------------ the commander's board (the brief)
export function boardHtml(D, P, { log = [], compact = false } = {}) {
  const C = D.C, ev = D.ev, RE = P.RE, rooms = P.rooms;
  const floors = FL.map((f, s) => { const mine = rooms.filter((r) => C.model.rooms[r.id].storey === s); const cnt = { safe: 0, restricted: 0, unsafe: 0 }; mine.forEach((r) => cnt[r.status]++);
    return `<div class="chips"><span>${f}</span>${Object.entries(cnt).filter(([, v]) => v).map(([k, v]) => `<span class="${CLS[k]}">${placardWord[k]} ${v}</span>`).join('')}${mine.filter((r) => r.override).map((r) => `<span class="ov">${esc(C.model.rooms[r.id].short)} overridden</span>`).join('')}</div>`; }).join('');
  const sites = P.sched.sites.map((o, i) => o && { o, s: P.sites[i] }).filter(Boolean).sort((a, b) => a.o.rank - b.o.rank);
  const dig = sites.length ? sites.slice(0, 5).map(({ o, s }) => `<p>${o.rank + 1}. ${s.kind === 'gap' ? 'Void seen through a gap' : 'Void under a slab'}, ${s.vol.toFixed(1)} m³, odds <b>${odds(s.p)}</b>: team ${o.team + 1}, reached in <b>${hrs(o.t1)}</b> (${clockText(ev, o.eta)})${o.time.stuck ? `; <span class="flag">its lane needs an engineer’s look first (${Math.round(DIG.engineerMin / 60)} h, our assumption)</span>` : ''}</p>`).join('') : '<p>No candidate void: search by hand.</p>';
  const vf = (v) => (v < 0.1 ? v.toFixed(2) : v.toFixed(1)), WL = D.WL, lifts = WL.steps.slice(0, 6).map((s2, k) => `${k + 1}. ${s2.hand ? 'by hand' : 'lift'} ${vf(s2.vol)} m³`).join(', ');
  const alerts = P.AL.list.slice(0, 5).map((a) => `<p>${a.rank}. ${esc(a.title)}: ${esc(a.confText)} <span class="draft">${esc(a.sources.join(' and '))}; ${a.pos.map((v) => v.toFixed(1)).join(', ')} m</span></p>`).join('');
  const logHtml = log.length ? `<section class="log"><h5>Overrides</h5>${log.map((l) => `<p class="${l.less ? 'warn' : ''}">${esc(l.t)}: ${esc(RoomName(C, l.id))} ${esc(placardWord[l.from].toLowerCase())} to <b>${esc(placardWord[l.to].toLowerCase())}</b>. ${esc(l.why)}.${l.less ? ' Less cautious than the evidence: allowed, logged with a warning.' : ''}${l.diff ? ` Recomputed: ${esc(l.diff)}.` : ''}</p>`).join('')}</section>` : '';
  return `<div class="cmd">
    ${logHtml}
    <section><h5>Rooms</h5>${floors}<p class="draft">${P.reList.length} restricted ${P.reList.length === 1 ? 'room opens' : 'rooms open'} in the window; ${P.inspectFirst.length} ${P.inspectFirst.length === 1 ? 'needs' : 'need'} an inspector first; unsafe rooms stay closed until shored.</p></section>
    <section><h5>Re-entry window</h5><p>Aftershock of magnitude ${ev.Md.toFixed(1)} or more in a ${RE.shiftH}-hour shift: <b>${pct(RE.nowChance)}</b> now. Under ${pct(RE.tolerance)} from <b>${RE.open != null ? clockText(ev, RE.open) : 'not within 60 days'}</b>${RE.slowing ? ', after a fresh pod reading' : ''}. Stiffness warnings: ${P.stiffWarn.length} rooms.</p></section>
    <section><h5>Dig order</h5>${dig}</section>
    <section><h5>Lifts for the rescue (rescanned after every lift)</h5><p>${lanesLine(P.lanes, vf)} ${lifts ? `${lifts}${WL.steps.length > 6 ? `, then ${WL.steps.length - 6} more steps` : ''}${WL.shorings ? `; ${WL.shorings} ${WL.shorings === 1 ? 'pause' : 'pauses'} to shore` : ''}.` : 'Nothing to lift.'}</p></section>
    <section><h5>Clearance</h5><p>Move <b>${m3(P.CL.moved)}</b> of ${m3(P.CL.total)} (loose) to open every lane: <b>${loads(P.CL.trucks)}</b>, <b>${hrs(P.CL.hours)}</b> of machine time. Debris about ${m3(P.debris.est)} in place (range ${P.debris.lo.toFixed(1)} to ${P.debris.hi.toFixed(1)}).</p></section>
    ${compact ? '' : `<section><h5>Ranked alerts</h5>${alerts}</section>`}
  </div>`;
}
export function createBoard(el) {
  el.className = 'a8board'; el.hidden = true; let key = '';
  return {
    show(D, P, opts = {}) { const html = `<div class="box" role="region" aria-label="The commander’s board"><p class="k">The commander’s board</p><h3>Building no. ${D.C.seed}, ${esc(MODE_META[D.C.mode].title.toLowerCase())}</h3>${boardHtml(D, P, { ...opts, compact: true })}</div>`; if (html !== key) { key = html; el.innerHTML = html; } el.hidden = false; },
    hide() { el.hidden = true; }, get shown() { return !el.hidden; },
  };
}

// ------------------------------------------------------------------ the end card
// the lanes in one line: how many the safe lifts open, what is left on them, and that the rest of the pile waits
export function lanesLine(LA, vf, bold = false, tail = '') {
  const B = (x) => (bold ? `<b>${x}</b>` : x), left = LA.left.vol;
  const open = LA.sites ? `${B(`${LA.sitesOpen} of ${LA.sites}`)} ${LA.sites === 1 ? 'lane' : 'lanes'} to the dig sites and ${LA.entsOpen} of ${LA.ents} entrances open by safe lifts` : `No dig site; ${LA.entsOpen} of ${LA.ents} entrances open by safe lifts`;
  const note = LA.changed ? ` (The lifts were planned for the swarm's ${LA.planned} ${LA.planned === 1 ? 'site' : 'sites'} and are not replanned here; a site checked by hand no longer counts.)` : '';
  return `${open}${left > 0.05 ? `; ${B(`${vf(left)} m³`)} on the lanes needs a closer look` : ''}; the rest of the pile (${vf(LA.must.notNeeded)} m³) is not needed for the rescue${tail}.${note}`;
}
export function createReport(el, { onTable, onReplay, onNext, onBack, hasNext = false } = {}) {
  el.className = 'a7over a7rep hide'; let shown = false;
  function show(D, P) {
    const C = D.C, ev = D.ev, sc = P.score, RE = P.RE, cnt = { safe: 0, restricted: 0, unsafe: 0 }; P.rooms.forEach((r) => cnt[r.status]++); const nOv = P.rooms.filter((r) => r.override).length;
    const fsOv = P.rooms.filter((r) => r.override && r.status === 'safe' && C.truth.rooms[r.id].status !== 'safe').length;
    const first = P.sched.sites.filter(Boolean).sort((a, b) => a.rank - b.rank)[0];
    const five = [
      `Rooms: <b>${cnt.safe}</b> safe, <b>${cnt.restricted}</b> restricted, <b>${cnt.unsafe}</b> unsafe${nOv ? ` (${nOv} set by the commander's override)` : ''}.`,
      P.reList.length ? `Re-entry for ${P.reList.length} restricted ${P.reList.length === 1 ? 'room' : 'rooms'} from <b>${RE.open != null ? clockText(ev, RE.open) : 'not within 60 days'}</b> (under ${pct(RE.tolerance)} per ${RE.shiftH}-hour shift)${P.inspectFirst.length ? `; ${P.inspectFirst.length} need an inspector first` : ''}.` : `${cnt.restricted ? `No restricted room reopens on the aftershock chance alone (${cnt.restricted} ${cnt.restricted === 1 ? 'needs' : 'need'} an inspector first)` : 'No restricted room to reopen'}; the aftershock chance falls under ${pct(RE.tolerance)} per ${RE.shiftH}-hour shift from <b>${RE.open != null ? clockText(ev, RE.open) : 'not within 60 days'}</b>.`,
      first ? `Dig first: the ${P.sites[first.site].kind === 'gap' ? 'void seen through a gap' : 'void under a slab'} (odds ${odds(P.sites[first.site].p)}), reached in <b>${hrs(first.t1)}</b>${first.time && first.time.stuck ? ', its lane needing an engineer’s look first' : ''}; ${P.sched.sites.filter(Boolean).length} sites, ${P.sec.n} ${P.sec.n === 1 ? 'team' : 'teams'}.` : 'No candidate void: search by hand.',
      lanesLine(P.lanes, (v) => (v < 0.1 ? v.toFixed(2) : v.toFixed(1)), true, ` (${D.WL.lifts} lifts, ${D.WL.handSteps} patches by hand, rescanning after each)`),
      `Move <b>${m3(P.CL.moved)}</b> of ${m3(P.CL.total)} (loose, from the measured debris): ${loads(P.CL.trucks)}, ${hrs(P.CL.hours)} of machine time.`,
    ];
    const row = (n, small, v, tg, cls) => `<div class="row2 ${cls || ''}"><span class="n">${n}<small>${small}</small></span><span class="v ${cls === 'miss' ? 'bad' : cls === 'hl' ? 'ok' : ''}">${v}</span><span class="tg">${tg}</span></div>`;
    const hitTxt = `${pct(sc.hit)}`;
    el.innerHTML = `<div class="card" role="dialog" aria-label="End of Act 8"><div class="body"><p class="k">Handed to the field</p><h2>What goes to the field</h2>
      <p class="pl">Building no. ${C.seed}, ${esc(MODE_META[C.mode].title.toLowerCase())}. Simulated collapse and simulated occupants; advice only, the commander decides.</p>
      <ol>${five.map((t, i) => `<li><i>${i + 1}</i><span>${t}</span><small></small></li>`).join('')}</ol>
      <h4>Scored against the truth</h4>
      <div class="a7score">
        ${row('False-safe rooms', `rooms marked safe that are truly not; our headline metric${fsOv ? `; ${fsOv} of them by the commander’s override` : ''}`, `${sc.fs} of ${sc.safe}`, 'target 0', sc.fs ? 'miss' : 'hl')}
        ${row('Needless closures', 'truly safe rooms not marked safe', `${sc.needless} of ${sc.trulySafe}`, 'the price of caution')}
        ${row('Interval hit rate', 'this collapse’s quantities inside their ranges', hitTxt, 'nominal 90 %', sc.hit < .8 ? 'miss' : '')}
        ${row('Dig order', sc.reached ? `mean time to reach the truly trapped: ${hrs(sc.mean)}, nearest first ${hrs(sc.meanNearest)}, biggest first ${hrs(sc.meanBiggest)}` : sc.trapped ? `${sc.trapped} truly trapped, in voids no candidate void found` : 'nobody truly trapped in a void here', sc.reached ? `${sc.vsNearest}, ${sc.vsBiggest}` : 'n/a', 'vs the naive orders', sc.reached && (sc.vsNearest === 'loss' || sc.vsBiggest === 'loss') ? 'miss' : sc.trapped && !sc.reached ? 'miss' : '')}
        ${row('Lanes open by safe lifts', P.lanes.sites ? `dig-site lanes; entrances ${P.lanes.entsOpen} of ${P.lanes.ents}; ${P.lanes.left.vol < 0.1 ? P.lanes.left.vol.toFixed(2) : P.lanes.left.vol.toFixed(1)} m³ on the lanes needs a closer look` : `no dig site; entrances ${P.lanes.entsOpen} of ${P.lanes.ents}`, P.lanes.sites ? `${P.lanes.sitesOpen} of ${P.lanes.sites}` : 'n/a', 'safe lifts alone', P.lanes.sites && P.lanes.sitesOpen < P.lanes.sites ? 'miss' : '')}
        ${row('Heavy drops', sc.unsafeLifts ? `steps that drop a chunk of 0.05 m³ or more; ${sc.unsafeLifts} let some chunk settle` : 'no step drops a load', `${sc.bigDrops} of ${sc.steps}`, 'target 0', sc.bigDrops ? 'miss' : 'hl')}
      </div>
      <p class="note2">The safe limit and the ranges come from ${D.K.nCases} other simulated collapses; on ${D.K.nHoldCases} more held out, ${D.K.held.fs} of ${D.K.held.safe} rooms marked safe were not (95 % bound ${(D.K.held.fsUpper * 100).toFixed(1)} %${D.K.met ? '' : ': too few to prove under 1 %'}).</p></div>
      <div class="row"><button class="a7pri" type="button" data-a="table">Open the commander’s table</button><button class="a7sec" type="button" data-a="replay">Watch again</button>${hasNext ? '<button class="a7sec" type="button" data-a="next">Next</button>' : ''}<button class="a7sec" type="button" data-a="back">Back to the story</button></div></div>`;
    const b = (a, f) => { const x = el.querySelector(`[data-a="${a}"]`); if (x) x.addEventListener('click', () => f && f()); };
    b('table', onTable); b('replay', onReplay); b('next', onNext); b('back', onBack);
    el.classList.remove('hide'); shown = true;
  }
  return { show, hide() { el.classList.add('hide'); shown = false; }, get shown() { return shown; } };
}

// ------------------------------------------------------------------ assumptions
export function createAssumptions(el, { onClose }) {
  el.className = 'a2asm a8asm'; el.hidden = true;
  function show(D) {
    const P = D.plan, S = P.settings, K = D.K, ev = D.ev;
    const lim = Object.entries(LIMITS).map(([k, L]) => `${QNAME[k]} under ${fmtQ(k, Math.min(L.safe * K.lambda, L.unsafe))}${Number.isFinite(L.unsafe) ? `, over ${fmtQ(k, L.unsafe)}` : ''}`).join('; ');
    el.innerHTML = `<div class="box" role="dialog" aria-label="Assumptions"><button class="x" type="button" aria-label="Close">×</button><p class="k">Act 8</p><h3>Assumptions</h3>
      <dl>
        <dt>Occupancy</dt><dd>Act 2’s night-time rule, the same seed: 2 to 4 people per flat, asleep in the bedroom first, then the living room. ${D.people.length} people this night. Carried with their storey’s measured motion; a person counts toward a void within about ${SURV.sigma} m.</dd>
        <dt>Survivability</dt><dd>Lean-to space under a slab ${SURV.kind.slab}, enclosed space seen through a gap ${SURV.kind.gap}, times a size factor from 0 at ${SURV.vol0} m³ to 1 at ${SURV.vol1} m³. Our illustrative numbers: FEMA and INSARAG name lean-to, V and pancake voids as the survivable kinds; under 0.3 m³ no.</dd>
        <dt>Negative information</dt><dd>A pass spots a person in plain view at 0 m with chance ${SURV.qDet}, falling as exp(−range / ${SURV.range} m), times the share of the void it saw (its edge counts ${SURV.edgeW}). Passes beyond ${SURV.maxRange} m do not count.</dd>
        <dt>Survival curve</dt><dd>The dig order weights each site by a curve that halves every ${DIG.halfLifeH} hours: an assumption for the shape only. Macintyre et al. (2006) show survival falls with time to rescue; we use none of their numbers.</dd>
        <dt>Rescue times</dt><dd>Walking ${DIG.walk} m/s, ${DIG.stairMin} min per storey, ${DIG.ladderMin} min for a ladder; lifting ${S.liftRate} m³ an hour; ${DIG.shoreMin} min to shore and open a void; ${DIG.pathUnsafeMin} min to shore a path through an unsafe room, ${DIG.pathRestrictedMin} min to check a restricted one.</dd>
        <dt>Aftershocks</dt><dd>Reasenberg &amp; Jones (1989), generic California: a = ${RJ.a}, b = ${RJ.b}, p = ${RJ.p}, c = ${RJ.c} day. Damaging size M<sub>d</sub> = ${MD.normal.toFixed(1)}, or ${MD.weakened.toFixed(1)} when the pods show a weakened structure (mean stiffness loss after the aftershock of ${Math.round(MD.lossAt * 100)} % or more, or slowing), because a weakened building can be damaged by a smaller shake: our assumption, not a published value. Here ${ev.Md.toFixed(1)} (mean pod loss ${Math.round(ev.meanLoss * 100)} %${ev.slowing ? ', slowing' : ''}). Mainshock magnitude and time simulated: M ${ev.Mm.toFixed(1)} at ${clockText(ev, 0)}; the commander has the board ${ev.handoverH.toFixed(1)} h later.</dd>
        <dt>Re-entry</dt><dd>Tolerance ${pct(S.tolerance)} per ${S.shiftH}-hour shift (editable on the table), and the pods not slowing. A stiffness-loss warning when a pod’s range reaches 15 %; its alert level is Act 7’s 30 %.</dd>
        <dt>Room limits</dt><dd>Act 7’s truth rules: safe limits are their caution limits times ${K.lambda} (the tuned threshold), never above the no-entry limit; no-entry limits as they are. ${esc(lim)}. Seen at least ${pct(RULE.seenSafe)}.</dd>
        <dt>Conformal ranges</dt><dd>Split conformal, 90 % per quantity, calibrated separately per failure mode (plain on site) and, within it, for rooms on a storey that moved and otherwise by Act 7’s draft; each half-width adds one rounding step of the stored calibration values. Calibration fold: ${K.calFold === 'A' ? 'seeds 1 to 20, the pancake also 41 to 70, the other modes 41 to 50' : 'seeds 21 to 40, the pancake also 71 to 100, the other modes 71 to 80'} (${K.nCases} collapses); held out: the other fold. False-safe bound: one-sided 95 % Clopper-Pearson.</dd>
        <dt>Removal order</dt><dd>Only what blocks the rescue moves: the debris in the passage of each dig site’s lane (the clearance plan’s must-clear cells: 1 m cells within 1.1 m of the lane, plus 0.8 m around the void’s opening; from 0.3 m below the lane’s floor to 1.8 m above it, a stooping height, our assumption), and around the entrances (1.6 m), with whatever holds that debris down. The rest of the pile waits for heavy machinery after the rescue. A rescan after every step (the same simulated LiDAR as Act 7, ${RESCAN.rays} rays from a drone over the piece and ${RESCAN.rays} from the side). A piece goes only when the top of half its footprint or more was seen, nothing measured and no unseen space under a roof lies above it or within ${RESCAN.margin} m of it, and nothing the map takes for structure lies within ${(RESCAN.hardReach * 0.12).toFixed(1)} m over it (specks of under 4 columns of 12 cm are ignored). Where lumps only hold each other down, the one on top of the others goes first. Each piece the crew can see on top is one piece: an ideal split of the exposed surface. Rubble under ${RESCAN.hand} m³ in the same ${RESCAN.patch} m patch is cleared by hand in one step. Shoring props the void and what lies over a lump that has to go. A lane the safe lifts cannot open waits for an engineer’s look and shoring (${DIG.engineerMin} min, our assumption), then the rest of its debris is lifted under supervision; each shoring pause adds ${DIG.shorePauseMin} min.</dd>
        <dt>Debris and haulage</dt><dd>Bulking ${CLEAR.bulk} (loose to in place), truck ${S.truck} m³ loose, a skip of ${CLEAR.skip} m³, loading at ${CLEAR.productivity} m³ an hour. Haul cost: ground distance plus ${CLEAR.liftCost} m per metre of height. Must-clear cells held with a penalty of ${CLEAR.tauMust}, others ${CLEAR.tauStay}; entropic ε ${CLEAR.eps}.</dd>
        <dt>Fragility</dt><dd>Lognormal, illustrative prior: median ${FRAGILITY_PRIOR.theta} g, dispersion ${FRAGILITY_PRIOR.beta}, prior spread of the log median ${FRAGILITY_PRIOR.sdLnTheta}. Not from a published curve. This event’s shaking (simulated) ${ev.pga.toFixed(2)} g.</dd>
        <dt>What it is not</dt><dd>A structural analysis or a prediction for a real building. The collapse, the occupants and every sensor are simulated; the decisions are advice, and the commander decides.</dd>
      </dl></div>`;
    el.querySelector('.x').addEventListener('click', () => onClose && onClose());
    el.hidden = false;
  }
  return { show, hide() { el.hidden = true; }, get shown() { return !el.hidden; } };
}

// ------------------------------------------------------------------ the room card: evidence with ranges, and the override
export function createRoomCard(el, { onClose, onOverride }) {
  el.className = 'a7room a8room'; let room = -1;
  function show(D, P, id, { truth = false, table = false } = {}) {
    room = id; const C = D.C, r = P.rooms[id], t = C.truth.rooms[id], TW = { safe: 'safe', caution: 'restricted', noentry: 'unsafe' };
    const ev = r.ev.filter((e) => e.key !== 'gone' || e.m > 0).map((e) => `<div class="q ${e.verdict}"><span>${QNAME[e.key]}</span><b>${fmtQ(e.key, e.m)}</b><small>${fmtQ(e.key, e.lo)} to ${Number.isFinite(e.hi) && e.hi < 1e2 ? fmtQ(e.key, e.hi) : 'unknown'}; safe under ${fmtQ(e.key, e.safe)}</small></div>`).join('');
    const ov = r.override ? `<p class="ovl${r.lessCautious ? ' warn' : ''}">Overridden: computed ${placardWord[r.computed].toLowerCase()}, now ${placardWord[r.status].toLowerCase()}. ${esc((r.override.why || '').replace(/([^.])$/, '$1.'))}${r.lessCautious ? ' Less cautious than the evidence: allowed, logged with a warning.' : ''}</p>` : '';
    el.innerHTML = `<button class="x" type="button" aria-label="Close">×</button><p class="k">${esc(C.model.rooms[id].name)}</p><h3>${esc(RoomName(C, id))}</h3>
      <span class="st ${CLS[r.status]}">${placardWord[r.status]}${r.borderline ? ', an inspector first' : ''}</span>
      <p class="why">${esc(r.reasons[0])}${r.differs ? ` <span class="draft">Act 7’s draft: ${esc(r.draft === 'noentry' ? 'no entry' : r.draft)}. ${esc(r.why)}.</span>` : ''}</p>
      <div class="evg">${ev}<div class="q"><span>Seen</span><b>${pct(r.seen)}</b><small>never-seen space is never safe</small></div></div>${ov}
      ${table ? `<div class="ovr"><span class="k2">Override</span>${['safe', 'restricted', 'unsafe'].map((s) => `<button type="button" data-o="${s}" class="${r.status === s ? 'on' : ''} ${CLS[s]}">${placardWord[s]}</button>`).join('')}${r.override ? '<button type="button" data-o="clear" class="clr">Back to computed</button>' : ''}</div>` : '<p class="hint">Open the commander’s table to override.</p>'}
      ${truth ? `<p class="truth">Truth: <b>${TW[t.status] || 'unsafe'}</b>${r.status === 'safe' && TW[t.status] !== 'safe' ? ': a false-safe room, shown as a miss' : r.override && ORDER[r.status] < ORDER[TW[t.status] || 'unsafe'] ? ': the override is less cautious than the truth' : ''}. True lean ${t.tilt.toFixed(1)}°, sag ${(t.sag * 100).toFixed(1)} cm, wall damage ${Math.round(t.dmg * 100)} %, cracks ${t.crackLen.toFixed(1)} m.</p>` : ''}`;
    el.querySelector('.x').addEventListener('click', () => onClose && onClose());
    el.querySelectorAll('[data-o]').forEach((b) => b.addEventListener('click', () => onOverride && onOverride(id, b.dataset.o)));
    el.classList.add('on');
  }
  return { show, hide() { el.classList.remove('on'); room = -1; }, get shown() { return el.classList.contains('on'); }, get room() { return room; } };
}
