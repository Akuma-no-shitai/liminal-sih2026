// Act 8's concept cards (the right column, newest on top; Act 7's card styles, Act 2's machinery): a small live chart
// or a few rows drawn from the plan at the current moment of the film, a stat line, one plain sentence and the links.
import { getTheme, rgba } from '../../../act7/js/theme.js';
import { failureOf } from '../../../act7/js/film/failure.js';
import { CLASS } from '../decide/alerts.js';
import { fmtQ, QNAME } from '../decide/status.js';
import { clockText, shiftChance } from '../decide/reentry.js';
import { RoomName } from '../film/script.js';
const FONTS = { mono: '"Geist Mono", ui-monospace, monospace', sans: 'Geist, ui-sans-serif, system-ui, sans-serif' };
let TH = getTheme('dusk'), K;
function chartPal(T) { const d = T.data, ch = T.chart; return { teal: d.swarm, safe: d.safe, heat: d.caution, danger: d.noentry, haze: d.unseen, apr: d.mid, lav: d.empty, rose: d.added, paper: ch.paper, faint: ch.faint, grid: ch.grid, well: ch.well, bar: ch.bar, band: ch.band, dash: ch.dash, ...FONTS }; }
K = chartPal(TH);
const pct = (v) => `${Math.round(v * 100)} %`;
const pct1 = (v) => `${(v * 100).toFixed(1)} %`;
const m3 = (v) => (v >= 100 ? `${Math.round(v)} m³` : `${v.toFixed(1)} m³`);
const hrs = (h) => (h == null || !Number.isFinite(h) ? '—' : h < 1 ? `${Math.round(h * 60)} min` : `${h.toFixed(1)} h`);
const esc = (s) => String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;');
const xyz = (p) => `${p[0].toFixed(1)}, ${p[1].toFixed(1)}, ${p[2].toFixed(1)}`;
export const CARD = {
  handover: { name: 'The handover', tag: 'from Act 7’s ground station', line: 'What the swarm measured, ready for the call. The swarm recommends; the commander decides.', html: true },
  alerts: { name: 'Ranked alerts', tag: 'class, place, sources, confidence', line: 'Our proposed order: a survivor seen by two sources, by one, a hazard beside a survivor, then the rest. Positions are in the baseline map, in metres.', html: true },
  interval: { name: 'Intervals', tag: 'split conformal, 90 %', line: 'Each bar is a measured value and its range. The range is the 90th percentile of past errors on simulated collapses with known truth (Angelopoulos & Bates 2021).', labs: [['assumptions', 'Assumptions']] },
  threshold: { name: 'The safe limit', tag: 'false-safe against needless closures', line: 'On collapses held out of the tuning: as the safe limit loosens, fewer truly safe rooms stay closed (across), and the false-safe rate’s one-sided 95 % Clopper-Pearson bound (up) narrows while more rooms are marked safe without a miss. The point is the limit we use.', labs: [['assumptions', 'Assumptions']] },
  room: { name: 'One room’s evidence', tag: 'each quantity against its limits', line: 'Safe needs every range under its safe limit (teal); unsafe needs one wholly over its no-entry limit (red).', html: true },
  aftershock: { name: 'Aftershock chance', tag: 'Reasenberg & Jones 1989', line: 'The chance of a damaging aftershock during one shift, against hours since the mainshock. Generic Californian parameters; real use refits them as aftershocks are recorded.', labs: [['assumptions', 'Assumptions'], ['lab-slowing', 'Slowing in the lab']] },
  stiffness: { name: 'Stiffness-loss warnings', tag: 'vibration pods', line: 'A wall’s natural frequency falls as it loses stiffness. A warning means: check that wall before anyone goes back in.', html: true },
  odds: { name: 'Survivor map', tag: 'Bayesian search', line: 'Prior from the night’s occupants and the void’s kind and size; each pass that looked in and saw nobody lowers the odds (Koopman 1956, Stone 1975).', labs: [['lab-pocket', 'Pockets in the lab'], ['assumptions', 'Assumptions']] },
  digorder: { name: 'Dig order', tag: 'Smith’s rule, survival-weighted', line: 'Most expected people reached per hour first. Time: the walk, the debris to lift first, shoring and opening the void.', html: true, labs: [['lab-pocket', 'Pockets in the lab'], ['assumptions', 'Assumptions']] },
  sectors: { name: 'Team sectors', tag: 'Fiedler vector, recursive', line: 'The map graph cut along its weakest seam (the Fiedler vector of its Laplacian), balanced by work: one sector per team.', html: true },
  lifts: { name: 'Lifts for the rescue', tag: 'rescanned after every lift', line: 'Only what blocks the lanes and the entrances moves. A piece goes only when its top was seen, with nothing on it or within 0.5 m of it. Each step is played out against the true debris.', html: true },
  clearance: { name: 'Minimum clearance', tag: 'unbalanced optimal transport', line: 'Only the lanes and entrances must be cleared; the rest may stay. It hauls the measured debris, loose, on whole 1 m cells, so its volumes differ from the lifts’ whole true pieces. Sinkhorn with relaxed margins (Chizat et al. 2018) finds the cheapest hauls.', html: true, labs: [['assumptions', 'Assumptions']] },
  fragility: { name: 'Closing the loop', tag: 'roadmap: fragility update', line: 'A lognormal fragility curve for this kind of block (an illustrative prior), updated with this event’s simulated shaking and damage.', labs: [['assumptions', 'Assumptions']] },
  score: { name: 'Against the truth', tag: 'this simulated collapse', line: 'Every decision scored against the known truth of the simulation. Misses are shown as misses.', html: true },
};
export function createCards(el, { onLab = () => {}, phone = false, theme = null, before = false } = {}) {
  TH = theme || getTheme('dusk'); K = chartPal(TH);
  const live = new Map(), order = []; let Ds = null;
  const cap = () => (phone ? 4 : (el.clientHeight || innerHeight) < 600 || innerHeight < 800 ? 2 : 3);
  function add(id) {
    const def = CARD[id]; if (!def || live.has(id)) return;
    const node = document.createElement('article'); node.className = 'a7card enter'; node.dataset.card = id; node.setAttribute('aria-label', def.name);
    const labs = [...(def.labs || []), ...(id === 'fragility' && before ? [['before', 'The next Before plan']] : [])];
    node.innerHTML = `<header><i></i><h4>${def.name}</h4><span class="tag">${def.tag}</span></header>${def.html ? '<div class="q4"></div>' : '<canvas></canvas>'}<div class="st"><span class="a"></span><span class="b"></span></div><p>${def.line}</p>${labs.length ? `<div class="labs">${labs.map(([l, t]) => `<button class="lab${l === 'assumptions' ? ' as' : ''}" type="button" data-lab="${l}">${t}</button>`).join('')}</div>` : ''}`;
    node.querySelectorAll('[data-lab]').forEach((b) => b.addEventListener('click', () => onLab(b.dataset.lab)));
    el.insertBefore(node, el.firstChild);
    const cv = node.querySelector('canvas'); live.set(id, { node, cv, ctx: cv && cv.getContext('2d'), q4: node.querySelector('.q4'), sa: node.querySelector('.st .a'), sb: node.querySelector('.st .b'), w: 0, h: 0 }); order.unshift(id);
    requestAnimationFrame(() => node.classList.remove('enter'));
    if (phone) requestAnimationFrame(() => { if (el.scrollLeft > 0) el.scrollLeft = 0; });
    while (order.length > cap()) remove(order[order.length - 1]);
  }
  function remove(id, now = false) { const o = live.get(id); if (!o) return; live.delete(id); const i = order.indexOf(id); if (i >= 0) order.splice(i, 1); if (now) { o.node.remove(); return; } o.node.classList.add('leave'); setTimeout(() => o.node.remove(), 460); }
  function show(ids) { const want = ids.slice(-cap()); for (const c of [...live.keys()]) if (!want.includes(c)) remove(c); for (const c of want) if (!live.has(c)) add(c); }
  let last = 0;
  function update(st, force = false) {
    if (!Ds) return; const now = performance.now(); if (!force && now - last < 80) return; last = now;
    for (const [id, o] of live) {
      try {
        if (o.q4) { const s = DRAW[id](null, 0, 0, Ds, st) || ['', '', '']; if (o.q4.innerHTML !== s[2]) o.q4.innerHTML = s[2]; if (o.sa.innerHTML !== s[0]) o.sa.innerHTML = s[0]; if (o.sb.innerHTML !== s[1]) o.sb.innerHTML = s[1]; continue; }
        const r = o.cv.getBoundingClientRect(); const dpr = Math.min(2, window.devicePixelRatio || 1); if (r.width < 4) continue;
        if (Math.abs(r.width - o.w) > .5 || Math.abs(r.height - o.h) > .5) { o.w = r.width; o.h = r.height; o.cv.width = Math.round(r.width * dpr); o.cv.height = Math.round(r.height * dpr); }
        const x = o.ctx; x.setTransform(dpr, 0, 0, dpr, 0, 0); x.clearRect(0, 0, o.w, o.h);
        const s = DRAW[id](x, o.w, o.h, Ds, st) || ['', '']; if (o.sa.innerHTML !== s[0]) o.sa.innerHTML = s[0]; if (o.sb.innerHTML !== s[1]) o.sb.innerHTML = s[1];
      } catch (e) { console.warn('[act8] card', id, e); }
    }
  }
  return { show, update, setCase(d) { Ds = d; for (const k of [...live.keys()]) remove(k, true); }, refresh() { last = 0; }, clear() { for (const k of [...live.keys()]) remove(k, true); }, get active() { return [...order]; } };
}
const label = (x, s, X, Y, col = K.faint, align = 'left', size = 10.5, font = K.sans) => { x.font = `${size}px ${font}`; x.fillStyle = col; x.textAlign = align; x.textBaseline = 'alphabetic'; x.fillText(s, X, Y); };
const rows = (list) => list.map(([n, v, l, cls]) => `<div class="r${cls ? ' ' + cls : ''}"><span class="n">${n}</span><b>${v}</b>${l ? `<small>${l}</small>` : ''}</div>`).join('');
const STW = { safe: 'safe', restricted: 'restricted', unsafe: 'unsafe' };
const SHORT = { tilt: 'Lean', sag: 'Sag', crush: 'Crushed', debris: 'Debris', gone: 'Wall fallen', cracks: 'Cracks', dmg: 'Wall damage', stiff: 'Stiffness' };
const odds = (v) => (v < 0.005 ? 'under 1\u00a0%' : pct(v));
const DRAW = {
  handover(x, w, h, D) {
    const C = D.C, d = {}; C.roomsAfter.forEach((r) => (d[r.status] = (d[r.status] || 0) + 1));
    const pk = C.pockets.list, gap = pk.filter((p) => p.kind === 'gap').length, Q = failureOf(C, 1), P = D.plan;
    return [`<b>${C.model.rooms.length}</b> rooms`, `<b>${P.AL.list.length}</b> alerts`, rows([
      ['Draft statuses', `${C.model.rooms.length} rooms`, `${d.safe || 0} safe, ${d.caution || 0} caution, ${d.noentry || 0} no entry${d.unseen ? `, ${d.unseen} never seen` : ''}: Act 7’s cautious rules`],
      ['Candidate voids', `${pk.length}`, pk.length ? `${gap} seen through a gap, ${pk.length - gap} possible under a slab` : 'none found'],
      ['Debris', `${m3(P.debris.est)}`, `range ${P.debris.lo.toFixed(1)} to ${P.debris.hi.toFixed(1)} m³ (90 %)`],
      ['How close to failure', `φ ${Number.isFinite(Q.phi.value) ? Q.phi.value.toFixed(2) : '—'}`, `correlation length ${Q.xi.value.toFixed(1)} m, stiffness lost ${Q.sus.n ? pct(Q.sus.after) : '—'}, relaxation ${Q.tau.list.map((t) => t.tau.toFixed(1)).join(' then ')} min`],
    ])];
  },
  alerts(x, w, h, D, st) {
    const AL = (st.plan || D.plan).AL, list = AL.list.slice(0, 4);
    const top = AL.detections ? '' : `<div class="r nr"><span class="n">Survivors seen</span><b>none</b><small>the simulated sensors model heat and structure, not people</small></div>`;
    return [`<b>${AL.list.length}</b> alerts`, `${AL.detections} detections`, top + list.map((a) => `<div class="r"><span class="n">${a.rank}. ${esc(a.title)}</span><b>${esc(a.short || a.confText)}</b><small>${esc(a.sources.join(' and '))}; at ${xyz(a.pos)} m${a.nearVoid != null ? '; beside a candidate void' : ''}</small></div>`).join('') + (AL.list.length > 4 ? `<div class="r nr"><span class="n">and ${AL.list.length - 4} more</span></div>` : '')];
  },
  interval(x, w, h, D, st) {
    const P = st.plan || D.plan, r = P.rooms[st.room ?? 0], ev = r.ev.filter((e) => e.key !== 'gone' || e.m > 0).slice(0, 7);
    const X0 = 74, W = w - X0 - 10, rowH = Math.min(13, (h - 10) / ev.length);
    ev.forEach((e, i) => { const y = 6 + i * rowH + rowH / 2, top = Math.max(e.safe * 2.4, Number.isFinite(e.unsafe) ? e.unsafe * 1.15 : 0, Number.isFinite(e.hi) && e.hi < 1e2 ? e.hi * 1.05 : 0, e.m * 1.1, 1e-6);
      const px = (v) => X0 + Math.min(1, Math.max(0, v / top)) * W;
      x.fillStyle = K.band; x.fillRect(X0, y - 3, W, 6);
      const hi = Number.isFinite(e.hi) && e.hi < 1e2 ? e.hi : top; x.fillStyle = rgba(e.verdict === 'under' ? K.safe : e.verdict === 'over' ? K.danger : K.heat, .55); x.fillRect(px(e.lo), y - 3, Math.max(2, px(hi) - px(e.lo)), 6);
      x.fillStyle = K.paper; x.beginPath(); x.arc(px(e.m), y, 2.6, 0, 7); x.fill();
      x.fillStyle = K.safe; x.fillRect(px(e.safe) - 1, y - 5, 2, 10); if (Number.isFinite(e.unsafe) && e.unsafe < top) { x.fillStyle = K.danger; x.fillRect(px(e.unsafe) - 1, y - 5, 2, 10); }
      label(x, SHORT[e.key] || e.key, X0 - 6, y + 3.5, K.faint, 'right', 9.5); });
    const hit = D.K.held.hit, hm = Object.values(hit).reduce((a, b) => a + b, 0) / Math.max(1, Object.keys(hit).length);
    return [`hit rate held out <b>${pct(hm)}</b>`, `nominal <b>90 %</b>`];
  },
  threshold(x, w, h, D) {
    const Kc = D.K, cv = Kc.curve, X0 = 30, Y0 = 8, W = w - 40, H = h - 26, ymax = Math.max(0.05, ...cv.map((p) => Math.min(0.3, p.fsUpper)));
    const px = (v) => X0 + v * W, py = (v) => Y0 + H - Math.min(1, v / ymax) * H;
    x.strokeStyle = K.grid; x.lineWidth = 1; x.beginPath(); x.moveTo(X0, Y0); x.lineTo(X0, Y0 + H); x.lineTo(X0 + W, Y0 + H); x.stroke();
    // the 1 % target
    x.strokeStyle = rgba(K.danger, .6); x.setLineDash([3, 3]); x.beginPath(); x.moveTo(X0, py(0.01)); x.lineTo(X0 + W, py(0.01)); x.stroke(); x.setLineDash([]); label(x, '1 %', X0 + W, py(0.01) - 3, K.danger, 'right', 9.5);
    // the curve: x = truly safe rooms closed, y = false-safe rate's 95 % bound (and the rate itself)
    x.beginPath(); cv.forEach((p, i) => { const X = px(p.needlessRate), Y = py(Math.min(ymax, p.fsUpper)); i ? x.lineTo(X, Y) : x.moveTo(X, Y); }); x.strokeStyle = rgba(K.paper, .55); x.lineWidth = 1.3; x.stroke();
    x.beginPath(); cv.forEach((p, i) => { const X = px(p.needlessRate), Y = py(p.fsRate); i ? x.lineTo(X, Y) : x.moveTo(X, Y); }); x.strokeStyle = K.teal; x.lineWidth = 1.6; x.stroke();
    const op = Kc.held; x.fillStyle = K.heat; x.beginPath(); x.arc(px(op.needlessRate), py(Math.min(ymax, op.fsUpper)), 4, 0, 7); x.fill();
    label(x, 'false-safe bound', X0 + 4, Y0 + 9, K.faint, 'left', 9.5); label(x, 'truly safe rooms closed', X0 + W, h - 3, K.faint, 'right', 9.5); label(x, '0', X0 - 4, Y0 + H, K.faint, 'right', 9.5, K.mono);
    return [`held out: <b>${op.fs} of ${op.safe}</b> marked safe wrong`, `bound <b style="color:var(--${Kc.met && op.fsUpper < .01 ? 'safe' : 'heat'}-txt)">${pct1(op.fsUpper)}</b>, closed <b>${pct(op.needlessRate)}</b>`];
  },
  room(x, w, h, D, st) {
    const P = st.plan || D.plan, r = P.rooms[st.room ?? 0];
    return [`<b>${esc(RoomName(D.C, r.id))}</b>`, `<b style="color:var(--${r.status === 'safe' ? 'safe' : r.status === 'unsafe' ? 'danger' : 'caution'}-txt)">${STW[r.status]}</b>`, rows(r.ev.filter((e) => e.key !== 'gone' || e.m > 0).map((e) => [QNAME[e.key], `${fmtQ(e.key, e.m)}`, `range ${fmtQ(e.key, e.lo)} to ${Number.isFinite(e.hi) && e.hi < 1e2 ? fmtQ(e.key, e.hi) : 'unknown'}; safe under ${fmtQ(e.key, e.safe)}${Number.isFinite(e.unsafe) ? `, unsafe over ${fmtQ(e.key, e.unsafe)}` : ''}`, e.verdict === 'under' ? '' : e.verdict === 'over' ? 'bad' : 'warn'])) + `<div class="r"><span class="n">Seen</span><b>${pct(r.seen)}</b><small>never-seen space is never safe</small></div>`];
  },
  aftershock(x, w, h, D, st) {
    const P = st.plan || D.plan, RE = P.RE, ev = D.ev, Hm = Math.min(24 * 14, Math.max(72, Math.ceil(((RE.open ?? 0) * 1.25) / 24) * 24)), X0 = 26, Y0 = 8, W = w - 34, H = h - 24, ymax = Math.max(.4, RE.nowChance * 1.1);
    const px = (hh) => X0 + Math.min(1, hh / Hm) * W, py = (v) => Y0 + H - Math.min(1, v / ymax) * H;
    x.strokeStyle = K.grid; x.lineWidth = 1; x.beginPath(); x.moveTo(X0, Y0); x.lineTo(X0, Y0 + H); x.lineTo(X0 + W, Y0 + H); x.stroke();
    x.fillStyle = rgba(K.teal, .1); if (RE.open != null && RE.open < Hm) x.fillRect(px(RE.open), Y0, X0 + W - px(RE.open), H);
    x.beginPath(); for (let hh = 0.25; hh <= Hm; hh += .5) { const v = shiftChance(hh, RE.shiftH, ev.Mm, ev.Md); hh < .3 ? x.moveTo(px(hh), py(v)) : x.lineTo(px(hh), py(v)); } x.strokeStyle = K.heat; x.lineWidth = 1.7; x.stroke();
    x.strokeStyle = rgba(K.danger, .7); x.setLineDash([3, 3]); x.beginPath(); x.moveTo(X0, py(RE.tolerance)); x.lineTo(X0 + W, py(RE.tolerance)); x.stroke(); x.setLineDash([]);
    x.strokeStyle = K.dash; x.beginPath(); x.moveTo(px(ev.handoverH), Y0); x.lineTo(px(ev.handoverH), Y0 + H); x.stroke(); label(x, 'now', px(ev.handoverH) + 3, Y0 + 9, K.faint, 'left', 9.5);
    if (RE.open != null && RE.open < Hm) label(x, 'window', px(RE.open) + 3, Y0 + 20, K.teal, 'left', 9.5);
    label(x, `${pct(RE.tolerance)} per shift`, X0 + W, py(RE.tolerance) - 3, K.danger, 'right', 9.5); label(x, `${Hm} h`, X0 + W, h - 3, K.faint, 'right', 9.5, K.mono); label(x, '0', X0, h - 3, K.faint, 'center', 9.5, K.mono);
    return [`now <b>${pct(RE.nowChance)}</b> per ${RE.shiftH} h shift`, RE.open != null ? `opens <b>${clockText(ev, RE.open)}</b>` : 'not within 60 days'];
  },
  stiffness(x, w, h, D, st) {
    const P = st.plan || D.plan, C = D.C, A = C.aftershocks[0], q = D.K.qPod;
    const list = C.pods.list.map((pd, i) => { const m = Math.max(0, A.reads[i].stiffLoss); return { i, m, lo: Math.max(0, m - q), hi: Math.min(1, m + q), rooms: C.model.walls[pd.wall].rooms }; }).sort((a, b) => b.m - a.m);
    return [`<b>${P.stiffWarn.length}</b> rooms warned`, `pod range ±${Math.round(q * 100)} points`, rows(list.map((p) => [`Pod ${p.i + 1}`, `${pct(p.m)} lost`, `range ${pct(p.lo)} to ${pct(p.hi)}; ${p.hi >= .3 ? 'may be over the 30 % alert level' : p.hi >= .15 ? 'a warning before re-entry' : 'no warning'}; walls of ${p.rooms.map((id) => RoomName(C, id).replace(/^The /, 'the ')).slice(0, 2).join(' and ')}`, p.hi >= .3 ? 'bad' : p.hi >= .15 ? 'warn' : '']))];
  },
  odds(x, w, h, D, st) {
    const S = D.SV.sites, k = st.passK ?? 1; if (!S.length) { label(x, 'no candidate void in this collapse', w / 2, h / 2, K.faint, 'center'); return ['no voids', '']; }
    const X0 = 8, W = w - 16, bw = Math.min(46, W / S.length - 8), H = h - 26, Y0 = 8;
    S.forEach((s, i) => { const n = Math.round(s.passes.length * k), now = n ? s.passes[n - 1].after : s.prior, cx = X0 + (i + .5) * W / S.length;
      x.fillStyle = K.band; x.fillRect(cx - bw / 2, Y0, bw, H); x.fillStyle = rgba(K.paper, .25); x.fillRect(cx - bw / 2, Y0 + H - s.prior * H, bw, 2);
      x.fillStyle = rgba(K.lav, .8); x.fillRect(cx - bw / 2 + 4, Y0 + H - now * H, bw - 8, now * H); label(x, `${i + 1}`, cx, h - 4, K.faint, 'center', 10, K.mono); label(x, now < 0.005 ? '<1%' : pct(now).replace(/\s/g, ''), cx, Math.max(Y0 + 10, Y0 + H - now * H - 3), K.paper, 'center', 9.5, K.mono); });
    const np = S.reduce((a, s) => a + Math.round(s.passes.length * k), 0);
    return [`<b>${np}</b> passes replayed`, `${D.people.length} people that night`];
  },
  digorder(x, w, h, D, st) {
    const P = st.plan || D.plan, sc = P.score; const list = P.sched.sites.map((o, i) => o && { o, s: P.sites[i], i }).filter(Boolean).sort((a, b) => a.o.rank - b.o.rank);
    if (!list.length) return ['no dig sites', '', rows([['No candidate void', '—', 'the teams search by hand; the hazards still rank']])];
    const lr = P.settings.liftRate, rng = (o) => { const v = o.time.vol, f = o.time.h - v / lr; return `${hrs(o.t0 + f + v / (lr * 1.5))} to ${hrs(o.t0 + f + v / (lr * 0.67))}`; };
    const truth = st.truth ? `<div class="r ${sc.vsNearest === 'loss' || sc.vsBiggest === 'loss' ? 'bad' : ''}"><span class="n">Against the truth</span><b>${sc.reached ? hrs(sc.mean) : '—'}</b><small>${sc.trapped ? `${sc.reached} of ${sc.trapped} truly trapped reached; nearest first ${hrs(sc.meanNearest)}, biggest first ${hrs(sc.meanBiggest)}` : 'nobody truly trapped in a void here'}</small></div>` : '';
    return [`<b>${list.length}</b> sites, <b>${P.sec.n}</b> ${P.sec.n === 1 ? 'team' : 'teams'}`, `last done in <b>${hrs(P.sched.finish)}</b>`, list.map(({ o, s, i }) => `<div class="r"><span class="n">${o.rank + 1}. ${s.kind === 'gap' ? 'Void seen through a gap' : 'Void under a slab'} (${s.vol.toFixed(1)} m³)</span><b>${hrs(o.t1)}</b><small>odds ${odds(s.p)}; team ${o.team + 1}; ${o.time.vol.toFixed(1)} m³ to lift first; reached in ${rng(o)} at 1.5x to 0.67x the lift rate</small></div>`).join('') + truth];
  },
  sectors(x, w, h, D, st) {
    const P = st.plan || D.plan, sec = P.sec; const by = Array.from({ length: sec.n }, () => []); P.sched.sites.forEach((o, i) => { if (o) by[o.team].push(o.rank + 1); });
    return [`<b>${sec.n}</b> ${sec.n === 1 ? 'sector' : 'sectors'}`, `${sec.cells.length} map cells`, rows(by.map((ranks, t) => [`Team ${t + 1}`, ranks.length ? `${ranks.length === 1 ? "dig site" : "dig sites"} ${ranks.sort((a, b) => a - b).join(", ")}` : "no dig site", `work ${sec.work[t] ? sec.work[t].toFixed(0) : 0} (debris m³ plus sites)`]))];
  },
  lifts(x, w, h, D, st) {
    const P = st.plan || D.plan, W = D.WL, sc = P.score, f2 = (v) => (v < 0.1 ? v.toFixed(2) : v.toFixed(1)), L = P.lanes || { ...W.lanes, left: W.left, must: W.must }, LL = L.left, LM = L.must;
    const why = [LL.heldVol > 0.05 ? `${f2(LL.heldVol)} m³ held down` : '', LL.unseenVol > 0.05 ? `${f2(LL.unseenVol)} m³ never seen from above` : '', LL.lockedVol > 0.05 ? `${f2(LL.lockedVol)} m³ waiting for shoring` : ''].filter(Boolean).join(', ');
    return [`<b>${W.lifts}</b> lifts, <b>${W.handSteps}</b> by hand`, `${W.rescans} rescans`, rows([
      ['Lanes open by safe lifts', L.sites ? `${L.sitesOpen} of ${L.sites}` : 'no site', `to the dig sites; entrances ${L.entsOpen} of ${L.ents}`, L.sites && L.sitesOpen < L.sites ? 'bad' : ''],
      ['On the lanes', `${f2(LM.lifted)} of ${f2(LM.vol)} m³`, `lifted, and ${f2(LM.offLifted)} m³ beside them that held it down`],
      ['A closer look', `${f2(LL.vol)} m³`, LL.vol > 0.05 ? `left on the lanes: ${why}; an engineer’s look first` : 'nothing left on the lanes', LL.vol > 0.05 ? 'bad' : ''],
      ['Not needed for the rescue', `${f2(LM.notNeeded)} m³`, 'the rest of the pile: heavy machinery afterwards'],
      ['Against the true debris', sc.bigDrops ? `${sc.bigDrops} heavy` : `${sc.unsafeLifts} small`, sc.unsafeLifts ? `steps that let a chunk settle; ${sc.bigDrops} of 0.05 m³ or more${sc.unseenDrops ? `, ${sc.unseenDrops} where no scan saw` : ''}` : 'no step drops a load', sc.bigDrops ? 'bad' : ''],
    ])];
  },
  clearance(x, w, h, D, st) {
    const P = st.plan || D.plan, CL = P.CL;
    return [`<b>${m3(CL.moved)}</b> of ${m3(CL.total)} moved`, `<b>${pct(CL.saving)}</b> less`, rows([
      ['Must be clear', `${CL.mustN} cells`, `${CL.mustLeft} left after the plan; lanes to the dig sites and the entrances`, CL.mustLeft ? 'bad' : ''],
      ['To the loading bay', m3(CL.recv[0]), `${CL.bayTrucks} truck ${CL.bayTrucks === 1 ? 'load' : 'loads'} of ${P.settings.truck} m³ (loose)`],
      ['To the skip', m3(CL.recv[1]), `holds ${CL.dumps[1].cap} m³; leaves as one load`],
      ['Machine time', hrs(CL.hours), `at ${CL.R.productivity} m³ an hour (loose)`],
    ])];
  },
  fragility(x, w, h, D) {
    const F = D.fr, X0 = 24, Y0 = 8, W = w - 32, H = h - 24, amax = 1.2;
    const px = (a) => X0 + Math.min(1, a / amax) * W, py = (v) => Y0 + H - v * H;
    x.strokeStyle = K.grid; x.lineWidth = 1; x.beginPath(); x.moveTo(X0, Y0); x.lineTo(X0, Y0 + H); x.lineTo(X0 + W, Y0 + H); x.stroke();
    const draw = (c, col, dash) => { x.beginPath(); c.forEach(([a, v], i) => (i ? x.lineTo(px(a), py(v)) : x.moveTo(px(a), py(v)))); x.strokeStyle = col; x.lineWidth = 1.7; x.setLineDash(dash ? [3, 3] : []); x.stroke(); x.setLineDash([]); };
    draw(F.before, rgba(K.paper, .55), true); draw(F.after, K.teal, false);
    x.fillStyle = F.reached ? K.danger : K.safe; x.beginPath(); x.arc(px(F.pga), py(F.reached ? 1 : 0), 4, 0, 7); x.fill();
    label(x, 'before', X0 + 4, Y0 + 9, K.faint, 'left', 9.5); label(x, 'after', X0 + 50, Y0 + 9, K.teal, 'left', 9.5); label(x, 'peak ground acceleration, g', X0 + W, h - 3, K.faint, 'right', 9.5);
    return [`median <b>${F.thetaBefore.toFixed(2)} g</b> to <b>${F.thetaAfter.toFixed(2)} g</b>`, `this event ${F.pga.toFixed(2)} g`];
  },
  score(x, w, h, D, st) {
    const P = st.plan || D.plan, sc = P.score, n = D.C.model.rooms.length;
    return [`<b>${sc.fs}</b> false-safe`, `intervals hit <b>${pct(sc.hit)}</b>`, rows([
      ['False-safe rooms', `${sc.fs} of ${sc.safe}`, 'rooms marked safe that are truly not (headline)', sc.fs ? 'bad' : ''],
      ['Needless closures', `${sc.needless} of ${sc.trulySafe}`, 'truly safe rooms not marked safe'],
      ['Restricted, truly unsafe', `${sc.resUnsafe}`, 'restricted rooms on the re-entry list that are truly unsafe', sc.resUnsafe ? 'bad' : ''],
      ['Interval hit rate', pct(sc.hit), `this case, ${n} rooms; 90 % nominal`],
      ['Dig order', sc.reached ? `${sc.vsNearest}, ${sc.vsBiggest}` : 'n/a', sc.reached ? `against nearest first and biggest first (${hrs(sc.mean)}, ${hrs(sc.meanNearest)}, ${hrs(sc.meanBiggest)})` : 'nobody truly trapped in a void the plan digs', sc.vsNearest === 'loss' || sc.vsBiggest === 'loss' ? 'bad' : ''],
      ['Heavy drops', `${sc.bigDrops} of ${sc.steps}`, `steps that drop a true chunk of 0.05 m³ or more (${sc.unsafeLifts} let any chunk settle)`, sc.bigDrops ? 'bad' : ''],
      ['Lanes open by safe lifts', sc.lanes ? `${sc.lanesOpen} of ${sc.lanes}` : 'n/a', `dig-site lanes; ${sc.liftLeft < 0.1 ? sc.liftLeft.toFixed(2) : sc.liftLeft.toFixed(1)} m³ of ${sc.mustVol.toFixed(1)} m³ on the lanes needs a closer look`, sc.lanes && sc.lanesOpen < sc.lanes ? 'bad' : ''],
    ])];
  },
};
