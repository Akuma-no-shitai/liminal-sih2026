// The safe removal order. The support graph: piece A rests on piece B when A's underside touches B's top (at least two
// voxel faces, 0.12 m voxels: about 0.03 m2), or sits over it with only space nobody saw between (up to 0.6 m: what is
// in there may carry load), or touches it side by side while sitting higher (a crew takes the higher one first); the
// ground and the standing structure support themselves. Pieces that
// roof a candidate void (directly over it, within 0.6 m) are locked until that void is shored. Kahn's topological sort
// (Kahn 1962) gives a lift order in which no piece is lifted while another rests on it; among the pieces free to go, the
// one on the way to the best-ranked dig site goes first, then the highest. Scored against the truth: a lift is unsafe
// if a true debris chunk still in place rests on a chunk inside the piece lifted (the true chunks rasterised the same way).
import { rasterBox } from '../../../act7/js/building/voxel.js';

export const SUPPORT = { minContact: 2, roofReach: 5, mode: 'touch', gap: 5 };
export function supportGraph(P, C) {
  const { pieces, pid, g } = P, SY = g.nx * g.nz, n = pieces.length, Sh = C.Shat;
  const on = pieces.map(() => new Map());       // A -> Map(B -> contacts): A rests on B
  const ground = new Float64Array(n), structure = new Float64Array(n);
  for (const p of pieces) for (const c of p.cells) { const b = c - SY; if (b < 0) { ground[p.id]++; continue; } const o = pid[b]; if (o >= 0 && o !== p.id) on[p.id].set(o, (on[p.id].get(o) || 0) + 1); else if (o < 0) { const j = Math.floor(c / SY); if (j <= Math.ceil(-g.y0 / g.vox)) ground[p.id]++; else if (Sh[b]) structure[p.id]++; }
    // 'touch': pieces that touch side by side count too, the higher one (by its centre) resting on the lower: rubble
    // chunks lean on their neighbours, and a crew takes the higher one first
    // through space nobody saw: a piece over another with only unseen voxels between (up to 0.6 m) may rest on it
    if (o < 0 && SUPPORT.gap) { let e = b; for (let s2 = 1; s2 <= SUPPORT.gap; s2++) { if (e < 0 || C.S[e] === 1 || Sh[e]) break; const o3 = pid[e]; if (o3 >= 0) { if (o3 !== p.id) on[p.id].set(o3, (on[p.id].get(o3) || 0) + 1); break; } e -= SY; } }
    if (SUPPORT.mode === 'touch') for (const d of [1, -1, g.nx, -g.nx]) { const e = c + d; const o2 = e >= 0 && e < g.N ? pid[e] : -1; if (o2 >= 0 && o2 !== p.id && p.c[1] > pieces[o2].c[1]) on[p.id].set(o2, (on[p.id].get(o2) || 0) + 1); } }
  // contacts both ways between two pieces (ragged lattice boundaries interlock): keep the direction with more contact
  // (a tie: the higher piece rests on the lower); a longer loop loses its weakest edge until none is left
  const E = new Map(); for (const p of pieces) for (const [b, k] of on[p.id]) { if (k < SUPPORT.minContact) continue; const back = on[b].get(p.id) || 0;
    if (back >= SUPPORT.minContact && (back > k || (back === k && pieces[b].c[1] > p.c[1]))) continue; E.set(p.id * n + b, k); }
  let dropped = 0;
  for (let guard = 0; guard < 4 * n; guard++) {
    const out = pieces.map(() => []), indeg = new Int32Array(n), outdeg = new Int32Array(n); for (const key of E.keys()) { const a = Math.floor(key / n), b = key % n; out[a].push(b); indeg[b]++; outdeg[a]++; }
    // peel sources and sinks; what is left lies on a loop
    const alive = new Uint8Array(n).fill(1); let changed = true;
    const inn = pieces.map(() => []); for (const key of E.keys()) inn[key % n].push(Math.floor(key / n));
    while (changed) { changed = false; for (let i = 0; i < n; i++) { if (!alive[i]) continue; const ii = inn[i].some((a) => alive[a]), oo = out[i].some((b) => alive[b]); if (!ii || !oo) { alive[i] = 0; changed = true; } } }
    let weakest = null, wk = Infinity; for (const [key, k] of E) { const a = Math.floor(key / n), b = key % n; if (alive[a] && alive[b] && k < wk) { wk = k; weakest = key; } }
    if (weakest == null) break; E.delete(weakest); dropped++;
  }
  const rests = pieces.map(() => []); for (const key of E.keys()) rests[Math.floor(key / n)].push(key % n);
  const carries = pieces.map(() => []); rests.forEach((bs, a) => bs.forEach((b) => carries[b].push(a)));
  // locked: pieces directly over a candidate void (within roofReach voxels above one of its cells)
  const lockedBy = pieces.map(() => []);
  C.pockets.list.forEach((pk, k) => { const seen = new Set(); for (let a = 0; a < pk.cells.length; a += Math.max(1, Math.floor(pk.cells.length / 6000))) { const c = pk.cells[a]; for (let s = 1; s <= SUPPORT.roofReach; s++) { const e = c + s * SY; if (e >= g.N) break; const o = pid[e]; if (o >= 0) { if (!seen.has(o)) { seen.add(o); lockedBy[o].push(k); } break; } } } });
  return { rests, carries, ground, structure, lockedBy, locked: lockedBy.map((l) => l.length > 0), dropped };
}
// Kahn's algorithm with a priority among the pieces free to go: prio(piece) -> smaller first. Phase 1 leaves the locked
// pieces (and what lies under them) in place; phase 2 carries on from there once the voids are shored.
export function liftOrder(P, G, prio) {
  const n = P.pieces.length, indeg = new Int32Array(n); for (let a = 0; a < n; a++) for (const b of G.rests[a]) indeg[b]++;
  const done = new Uint8Array(n), order = [], after = [];
  let shored = false; const ok = (i) => !G.locked[i] || shored, avail = [];
  for (let i = 0; i < n; i++) if (indeg[i] === 0 && ok(i)) avail.push(i);
  const run = (out) => { while (avail.length) {
    let bi = 0; for (let k = 1; k < avail.length; k++) if (cmp(prio(avail[k]), prio(avail[bi])) < 0) bi = k;
    const a = avail.splice(bi, 1)[0]; done[a] = 1; out.push(a);
    for (const b of G.rests[a]) { indeg[b]--; if (indeg[b] === 0 && ok(b)) avail.push(b); } } };
  run(order);
  const waiting = []; for (let i = 0; i < n; i++) if (!done[i]) waiting.push(i);
  shored = true; for (let i = 0; i < n; i++) if (!done[i] && indeg[i] === 0 && G.locked[i]) avail.push(i);
  run(after);
  // anything still not lifted sits in a loop of mutual contacts (interlocked pieces): reported, not hidden
  const cyclic = []; for (let i = 0; i < n; i++) if (!done[i]) cyclic.push(i);
  return { order, after, waiting, cyclic };
}
const cmp = (x, y) => { for (let k = 0; k < x.length; k++) if (x[k] !== y[k]) return x[k] - y[k]; return 0; };
// everything that must be lifted before a set of pieces can go: the pieces themselves and all that rests on them
export function closureOf(ids, G) {
  const out = new Set(), st = [...ids];
  while (st.length) { const a = st.pop(); if (out.has(a)) continue; out.add(a); for (const b of G.carries[a]) st.push(b); }
  return out;
}
// ------------------------------------------------------------------ the truth
// the true debris chunks rasterised on the same grid (ids), what each rests on (another chunk, or the ground and the
// standing structure, also rasterised from the truth), and the measured piece each mostly falls in
export function trueSupport(C, P) {
  const { g, pid } = P, SY = g.nx * g.nz, chunks = C.post.parts.filter((p) => p.debris);
  const tid = new Int32Array(g.N), solid = new Uint8Array(g.N);
  for (const p of C.post.parts) if (!p.debris && p.kind !== 'door') rasterBox(g, p.box, solid, 1, {});
  for (let c = 0; c < SY; c++) solid[c] = 1;   // the ground layer
  chunks.forEach((p, i) => rasterBox(g, p.box, tid, i + 1, { ymin: 0 }));
  const on = chunks.map(() => new Set()), votes = chunks.map(() => new Map()), size = new Int32Array(chunks.length), base = new Uint8Array(chunks.length);
  for (let c = 0; c < g.N; c++) { const a = tid[c]; if (!a) continue; size[a - 1]++; const m = pid[c]; if (m >= 0) votes[a - 1].set(m, (votes[a - 1].get(m) || 0) + 1);
    const b = c - SY; if (b >= 0) { const o = tid[b]; if (o && o !== a) on[a - 1].add(o - 1); else if (!o && solid[b]) base[a - 1] = 1; } }
  const map = votes.map((v) => { let best = -1, bw = 0; for (const [m, w] of v) if (w > bw) { bw = w; best = m; } return best; });
  return { n: chunks.length, on: on.map((s) => [...s]), map, parts: votes.map((v) => [...v.keys()]), size, base, mapped: map.filter((m) => m >= 0).length, V3: g.V3 };
}
// the lifts that would drop a load: a true chunk still in place that rested on a chunk inside the piece lifted and is
// left with no support at all (no other chunk under it still in place, no ground or structure); 'shifts' counts the
// lifts that take away only part of a chunk's support
export function unsafeLifts(order, T, { touch = false } = {}) {
  // touch = false: a lift takes the true chunks mostly inside the piece; true: every chunk with any part in it
  const lifted = new Set(), out = new Set(), drops = [], shifts = [];
  const takes = new Map(); T.parts.forEach((ps, ch) => { const list = touch ? ps : T.map[ch] >= 0 ? [T.map[ch]] : []; for (const m of list) { if (!takes.has(m)) takes.set(m, []); takes.get(m).push(ch); } });
  const restsOn = T.on.map(() => []); T.on.forEach((bs, a) => bs.forEach((b) => restsOn[b].push(a)));
  order.forEach((p, k) => {
    lifted.add(p); const now = (takes.get(p) || []).filter((ch) => !out.has(ch)); for (const ch of now) out.add(ch);
    let drop = null, shift = null;
    for (const y of now) for (const x of restsOn[y]) { if (out.has(x)) continue;
      const left = T.base[x] || T.on[x].some((z) => !out.has(z));
      const o = { lift: k, piece: p, load: x, loadPiece: T.map[x], vol: T.size[x] * T.V3, unseen: T.map[x] < 0 };
      if (!left) { if (!drop || o.vol > drop.vol) drop = o; } else if (!shift || o.vol > shift.vol) shift = o; }
    if (drop) drops.push(drop); else if (shift) shifts.push(shift);
  });
  return { drops, shifts };
}
