// The measured debris split into pieces, from the scans (Act 7's debris estimate and slab pieces), never the truth:
// voxels under a tight fallen-slab plane (Act 7's slab pieces) belong to that slab; the rest of the estimate's voxels
// (debris seen, closed, and the unseen fill under the observed debris surface) are cut into rubble chunks on a
// 1.25 x 0.75 x 1.25 m lattice, and chunks under 0.25 m3 join the neighbour they touch most (preferably the one below),
// so most pieces hold 0.3 to 2 m3.
import { makeGrid } from '../../../act7/js/building/voxel.js';
import { rngFor } from '../../../act7/js/building/geom.js';
import { slabPieces } from '../../../act7/js/pipe/pieces.js';

export const PIECE = { cell: [1.25, 0.75, 1.25], minVol: 0.25, slabBelow: 0.22, slabAbove: 0.08, slabPad: 0.1 };
export function debrisPieces(C) {
  const g = makeGrid(C.g), SY = g.nx * g.nz, D = C.debrisGrid, F = C.fillGrid;
  const cells = []; for (let c = 0; c < g.N; c++) if (D[c] || F[c] === 1) cells.push(c);
  const pid = new Int32Array(g.N).fill(-1), pieces = [];
  // fallen slabs: Act 7's slab pieces (the change map's call, same inputs and seed: tight planes in the debris returns);
  // voxels just under a slab piece's plane, inside its extent, belong to it
  const slabs = slabPieces(g, D, C.scans.post.pts, C.scans.post.n, rngFor(C.seed || 1, 'pieces')).filter((p) => p.n && p.ext);
  const q = [0, 0, 0];
  slabs.forEach((sp) => { pieces.push({ id: pieces.length, kind: 'slab', cells: [], n: sp.n }); });
  for (const c of cells) { g.centre(c, q);
    for (let s = 0; s < slabs.length; s++) { const sp = slabs[s], n = sp.n, d = n[0] * q[0] + n[1] * q[1] + n[2] * q[2] - sp.d; if (d < -PIECE.slabBelow || d > PIECE.slabAbove) continue;
      const a = q[0] * sp.ua[0] + q[1] * sp.ua[1] + q[2] * sp.ua[2], b = q[0] * sp.va[0] + q[1] * sp.va[1] + q[2] * sp.va[2];
      if (a < sp.ext[0] - PIECE.slabPad || a > sp.ext[1] + PIECE.slabPad || b < sp.ext[2] - PIECE.slabPad || b > sp.ext[3] + PIECE.slabPad) continue;
      pid[c] = s; pieces[s].cells.push(c); break; } }
  // rubble: lattice cells
  const [cx, cy, cz] = PIECE.cell, key = new Map();
  for (const c of cells) { if (pid[c] >= 0) continue; g.centre(c, q); const k = `${Math.floor((q[0] - g.x0) / cx)},${Math.floor(Math.max(0, q[1]) / cy)},${Math.floor((q[2] - g.z0) / cz)}`;
    let id = key.get(k); if (id == null) { id = pieces.length; key.set(k, id); pieces.push({ id, kind: 'rubble', cells: [] }); } pid[c] = id; pieces[id].cells.push(c); }
  // small rubble chunks join the neighbour they touch most (below first)
  const V3 = g.V3; let merged = true, guard = 0;
  while (merged && guard++ < 4) { merged = false;
    for (const p of pieces) { if (p.kind !== 'rubble' || !p.cells.length || p.cells.length * V3 >= PIECE.minVol) continue;
      const touch = new Map(); for (const c of p.cells) for (const [d, w] of [[-SY, 3], [SY, 1], [1, 1], [-1, 1], [g.nx, 1], [-g.nx, 1]]) { const e = c + d; if (e < 0 || e >= g.N) continue; const o = pid[e]; if (o >= 0 && o !== p.id && pieces[o].kind === 'rubble') touch.set(o, (touch.get(o) || 0) + w); }
      if (!touch.size) continue; let best = -1, bw = 0; for (const [o, w] of touch) if (w > bw) { bw = w; best = o; }
      for (const c of p.cells) { pid[c] = best; pieces[best].cells.push(c); } p.cells = []; merged = true; } }
  // compact the ids, and describe each piece
  const live = pieces.filter((p) => p.cells.length), remap = new Int32Array(pieces.length).fill(-1); live.forEach((p, i) => { remap[p.id] = i; });
  for (const c of cells) if (pid[c] >= 0) pid[c] = remap[pid[c]];
  const out = live.map((p, i) => {
    let sx = 0, sy = 0, sz = 0, x0 = 1e9, y0 = 1e9, z0 = 1e9, x1 = -1e9, y1 = -1e9, z1 = -1e9;
    for (const c of p.cells) { g.centre(c, q); sx += q[0]; sy += q[1]; sz += q[2]; if (q[0] < x0) x0 = q[0]; if (q[0] > x1) x1 = q[0]; if (q[1] < y0) y0 = q[1]; if (q[1] > y1) y1 = q[1]; if (q[2] < z0) z0 = q[2]; if (q[2] > z1) z1 = q[2]; }
    const n = p.cells.length, h = g.vox / 2;
    return { id: i, kind: p.kind, vol: n * V3, n, c: [sx / n, sy / n, sz / n], bb: [x0 - h, y0 - h, z0 - h, x1 + h, y1 + h, z1 + h], top: y1 + h, bottom: y0 - h, cells: p.cells };
  });
  return { pieces: out, pid, g, total: cells.length * V3 };
}
