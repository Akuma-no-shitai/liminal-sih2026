// The honest core: split-conformal intervals and the safe threshold, both computed at run time from the calibration
// sweep (Act 7's pipeline over 220 simulated collapses, calib_data.js), never from the case on screen.
//  - Split conformal (Angelopoulos & Bates 2021): nonconformity = |measured - true| per quantity; q = the
//    ceil((n + 1)(1 - alpha))-th smallest score of the calibration rooms; the interval is measured +- q. Group-
//    conditional (Mondrian, Vovk et al. 2005): rooms are calibrated separately per failure mode (plain on site, and in
//    Act 7's storey fits) and, within a mode, by a label made from measured data only: on a storey that moved as a
//    block, and otherwise by Act 7's draft (clean, marked, failed), because the errors differ a lot. A group with fewer
//    than 40 calibration rooms falls back to its mode's rooms.
//  - Two folds: seeds 1-20 (with pancake 41-70, soft storey and lean 41-50) and seeds 21-40 (with pancake 71-100,
//    soft storey and lean 71-80): 110 collapses each. The extra pancake seeds are there because only the pancake has
//    truly safe rooms, so only it can show a false-safe rate; the others give each mode more rooms for its own
//    ranges. The case on screen is
//    never in the calibration fold; the other fold is held out and gives the numbers shown on screen (the case itself
//    left out of those too).
//  - The safe threshold: every quantity's safe limit is lambda times the truth rules' caution limit. The operating
//    point is the loosest lambda whose false-safe rate (rooms marked safe that are truly not safe, over the rooms marked
//    safe) on the calibration fold has a one-sided 95 % Clopper-Pearson upper bound under 1 %.
import { CALIB } from './calib_data.js';

export const QUANT = ['tilt', 'sag', 'crush', 'debris', 'gone', 'cracks', 'dmg'];
// the truth rules (Act 7's truth.js RULES): caution and no-entry limits per quantity
export const LIMITS = {
  tilt: { safe: 0.5, unsafe: 2.0, unit: '°' }, sag: { safe: 0.015, unsafe: 0.05, unit: 'm' }, crush: { safe: 0.01, unsafe: 0.08, unit: '' },
  debris: { safe: 0.03, unsafe: 0.25, unit: '' }, gone: { safe: 0.12, unsafe: 0.12, unit: '' }, cracks: { safe: 0.3, unsafe: Infinity, unit: 'm' },
  dmg: { safe: 0.1, unsafe: 0.5, unit: '' },
};
export const RULE = { alpha: 0.10, seenSafe: 0.7, goneStructure: 0.5, crushStructure: 0.3, fsTarget: 0.01, cpConf: 0.95, stiffUnsafe: 0.30 };
export const LAMBDAS = [0.25, 0.35, 0.5, 0.6, 0.7, 0.8, 0.9, 1, 1.1, 1.25, 1.4, 1.6, 1.8, 2, 2.5, 3, 4];
const GROUPS = ['moved', 'clean', 'marked', 'failed'];
const ST = ['safe', 'caution', 'noentry', 'unseen'];
export const groupOf = (moved, draft) => (moved ? 'moved' : draft === 'safe' ? 'clean' : draft === 'caution' ? 'marked' : 'failed');

// ------------------------------------------------------------------ the data
const ALPHA = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-_';
function decodeStream(s) { const out = []; let v = 0, mul = 1; for (let i = 0; i < s.length; i++) { const d = ALPHA.indexOf(s[i]); v += (d & 31) * mul; if (d & 32) mul *= 32; else { out.push(v & 1 ? -(v + 1) / 2 : v / 2); v = 0; mul = 1; } } return out; }
let DATA = null;
export function calibData() {
  if (DATA) return DATA;
  const cs = decodeStream(CALIB.cases), rs = decodeStream(CALIB.rooms), ps = decodeStream(CALIB.pods), W = CALIB.roomW, NQ = CALIB.quantities.length, sc = CALIB.scale;
  const cases = []; for (let i = 0; i < cs.length; i += 4) cases.push({ mode: CALIB.modes[cs[i]], seed: cs[i + 1], debEst: cs[i + 2] / 100, debTrue: cs[i + 3] / 100 });
  const rooms = []; let o = 0;
  for (const c of cases) { const prev = new Array(NQ).fill(0);
    for (let r = 0; r < CALIB.perCase; r++, o += W) { const f = rs[o], moved = (f & 16) > 0, sagKnown = (f & 32) === 0, draft = ST[(f >> 2) & 3], truth = ST[f & 3], m = {}, t = {};
      for (let q = 0; q < NQ; q++) { const mv = prev[q] + rs[o + 2 + q * 2]; prev[q] = mv; m[CALIB.quantities[q]] = mv / sc[q]; t[CALIB.quantities[q]] = (mv + rs[o + 3 + q * 2]) / sc[q]; }
      m.seen = rs[o + 1] / 20; m.sagKnown = sagKnown;
      rooms.push({ mode: c.mode, seed: c.seed, idx: r, moved, draft, truth, group: groupOf(moved, draft), m, t }); } }
  const pods = []; for (let i = 0; i < ps.length; i += 4) pods.push({ mode: CALIB.modes[ps[i]], seed: ps[i + 1], m: ps[i + 2] / 1000, t: ps[i + 3] / 1000 });
  DATA = { cases, rooms, pods };
  return DATA;
}
// ------------------------------------------------------------------ statistics
export function conformalQ(scores, alpha = RULE.alpha) {
  const n = scores.length; if (!n) return Infinity; const k = Math.ceil((n + 1) * (1 - alpha)); if (k > n) return Infinity;
  const s = Float64Array.from(scores).sort(); return s[k - 1];
}
const LG = (() => { const c = [76.18009172947146, -86.50532032941677, 24.01409824083091, -1.231739572450155, 0.1208650973866179e-2, -0.5395239384953e-5];
  return (x) => { let y = x, t = x + 5.5; t -= (x + .5) * Math.log(t); let s = 1.000000000190015; for (const q of c) s += q / ++y; return -t + Math.log(2.5066282746310005 * s / x); }; })();
function binomCdf(k, n, p) { if (p <= 0) return 1; if (p >= 1) return k >= n ? 1 : 0; let s = 0; for (let i = 0; i <= k; i++) s += Math.exp(LG(n + 1) - LG(i + 1) - LG(n - i + 1) + i * Math.log(p) + (n - i) * Math.log(1 - p)); return Math.min(1, s); }
// one-sided upper confidence bound on a rate from k events in n trials (Clopper-Pearson, exact)
export function clopperPearsonUpper(k, n, conf = RULE.cpConf) {
  if (n <= 0) return 1; if (k >= n) return 1; const a = 1 - conf;
  if (k === 0) return 1 - Math.pow(a, 1 / n);
  let lo = k / n, hi = 1; for (let it = 0; it < 60; it++) { const mid = (lo + hi) / 2; if (binomCdf(k, n, mid) > a) lo = mid; else hi = mid; }
  return hi;
}
// ------------------------------------------------------------------ the room rule (shared by calibration and the case)
// q: the conformal half-widths of the room's group; lambda: the safe threshold's scale; extra: [{ key, m, q, safe, unsafe }]
export function decideRoom(m, q, lambda, extra = []) {
  const ev = [];
  for (const k of QUANT) { const L = LIMITS[k], v = m[k] ?? 0, hw = k === 'sag' && m.sagKnown === false ? Infinity : q[k] ?? Infinity, cap = k === 'tilt' ? 90 : k === 'sag' || k === 'cracks' ? 1e3 : 1;
    ev.push({ key: k, m: v, lo: Math.max(0, v - hw), hi: Math.min(cap, v + hw), safe: Math.min(L.safe * lambda, L.unsafe), unsafe: L.unsafe }); }
  for (const x of extra) ev.push({ key: x.key, m: x.m, lo: Math.max(0, x.m - x.q), hi: Math.min(1, x.m + x.q), safe: x.safe, unsafe: x.unsafe });
  for (const e of ev) e.verdict = e.lo >= e.unsafe ? 'over' : e.hi < e.safe ? 'under' : e.hi >= e.unsafe ? 'straddles' : 'between';
  const gone = (m.gone ?? 0) >= RULE.goneStructure || (m.crush ?? 0) >= RULE.crushStructure;
  const seen = (m.seen ?? 1) >= RULE.seenSafe;
  let status = 'restricted';
  if (gone || ev.some((e) => e.verdict === 'over')) status = 'unsafe';
  else if (seen && ev.every((e) => e.verdict === 'under')) status = 'safe';
  // borderline: restricted, but some interval reaches the no-entry limit (an inspector looks before anyone goes back in)
  const borderline = status === 'restricted' && ev.some((e) => e.verdict === 'straddles');
  return { status, ev, gone, seen, borderline };
}
// ------------------------------------------------------------------ calibration
const foldOf = (seed) => ((seed >= 1 && seed <= 20) || (seed >= 41 && seed <= 70) ? 'A' : (seed >= 21 && seed <= 40) || (seed >= 71 && seed <= 100) ? 'B' : null);
export const MIN_GROUP = 40;
const STEP = Object.fromEntries(CALIB.quantities.map((k, i) => [k, 1 / CALIB.scale[i]]));
export const keyOf = (mode, group) => `${mode}|${group}`;
// the half-widths for a room: its mode and group, else its mode's pooled rooms
export const qOf = (Q, mode, group) => Q[keyOf(mode, group)] || Q[mode] || null;
export function quantilesFor(rooms) {
  // (the calibration values are stored rounded, measured and true each to half a step of their scale, so a stored score
  // can be one step off the real one: the half-width adds one step, keeping the guarantee for unrounded values)
  const qs = (rs) => { const o = { n: rs.length }; for (const k of QUANT) o[k] = conformalQ(rs.filter((r) => k !== 'sag' || r.m.sagKnown !== false).map((r) => Math.abs(r.m[k] - r.t[k]))) + STEP[k]; return o; };
  const Q = {}; for (const mode of [...new Set(rooms.map((r) => r.mode))]) { const rm = rooms.filter((r) => r.mode === mode); Q[mode] = qs(rm);
    for (const g of GROUPS) { const rs = rm.filter((r) => r.group === g); if (rs.length >= MIN_GROUP) Q[keyOf(mode, g)] = qs(rs); } }
  return Q;
}
const truthWord = { safe: 'safe', caution: 'restricted', noentry: 'unsafe', unseen: 'unsafe' };
export function evaluate(rooms, Q, lambda) {
  let safe = 0, fs = 0, trulySafe = 0, needless = 0, restrictedUnsafe = 0, n = 0; const hit = Object.fromEntries(QUANT.map((k) => [k, 0]));
  const byMode = {};
  for (const r of rooms) { const d = decideRoom(r.m, qOf(Q, r.mode, r.group), lambda); n++; const tw = truthWord[r.truth];
    const bm = byMode[r.mode] || (byMode[r.mode] = { n: 0, ...Object.fromEntries(QUANT.map((k) => [k, 0])) }); bm.n++;
    for (const e of d.ev) if (bm[e.key] != null && r.t[e.key] >= e.lo - 1e-9 && r.t[e.key] <= e.hi + 1e-9) bm[e.key]++;
    if (d.status === 'safe') { safe++; if (tw !== 'safe') fs++; }
    if (tw === 'safe') { trulySafe++; if (d.status !== 'safe') needless++; }
    if (d.status === 'restricted' && tw === 'unsafe' && !d.borderline) restrictedUnsafe++;
    for (const e of d.ev) if (hit[e.key] != null && r.t[e.key] >= e.lo - 1e-9 && r.t[e.key] <= e.hi + 1e-9) hit[e.key]++; }
  for (const k of QUANT) hit[k] /= Math.max(1, n);
  for (const bm of Object.values(byMode)) for (const k of QUANT) bm[k] /= Math.max(1, bm.n);
  return { byMode, n, safe, fs, fsRate: safe ? fs / safe : 0, fsUpper: clopperPearsonUpper(fs, safe), trulySafe, needless, needlessRate: trulySafe ? needless / trulySafe : 0, restrictedUnsafe, hit };
}
// the whole calibration for a case on screen: which fold calibrates, the quantiles, the operating point, the curve on
// the held-out fold and the held-out result
export function calibrate({ mode = null, seed = null } = {}) {
  const D = calibData(), f = foldOf(seed), calFold = f === 'A' ? 'B' : 'A', holdFold = calFold === 'A' ? 'B' : 'A';
  const isCase = (r) => r.mode === mode && r.seed === seed;
  const cal = D.rooms.filter((r) => foldOf(r.seed) === calFold && !isCase(r)), hold = D.rooms.filter((r) => foldOf(r.seed) === holdFold && !isCase(r));
  const Q = quantilesFor(cal);
  // the operating point on the calibration fold
  const calCurve = LAMBDAS.map((l) => ({ lambda: l, ...evaluate(cal, Q, l) }));
  const ok = calCurve.filter((p) => p.fsUpper < RULE.fsTarget);
  const met = ok.length > 0;
  // if no threshold shows the bound under the target, the ones with no false-safe room at all (said so on the card);
  // where the curve is flat, the tightest threshold that already marks as many rooms safe as the loosest one
  const qual = met ? ok : calCurve.filter((p) => p.fs === 0), best = qual.length ? Math.max(...qual.map((p) => p.safe)) : 0;
  const pick = qual.find((p) => p.safe === best) || calCurve[0];
  const lambda = pick.lambda;
  const curve = LAMBDAS.map((l) => ({ lambda: l, ...evaluate(hold, Q, l) }));
  const held = curve.find((p) => p.lambda === lambda);
  // pods: stiffness loss after the aftershock, one quantile for all pods (calibration fold)
  const podsCal = D.pods.filter((p) => foldOf(p.seed) === calFold && !(p.mode === mode && p.seed === seed)), podsHold = D.pods.filter((p) => foldOf(p.seed) === holdFold && !(p.mode === mode && p.seed === seed));
  const qPod = conformalQ(podsCal.map((p) => Math.abs(p.m - p.t)));
  const podHit = podsHold.length ? podsHold.filter((p) => Math.abs(p.m - p.t) <= qPod).length / podsHold.length : null;
  // debris: relative error of the estimate (cases), for the debris interval
  const casesCal = D.cases.filter((c) => foldOf(c.seed) === calFold && !(c.mode === mode && c.seed === seed));
  const qDeb = conformalQ(casesCal.map((c) => Math.abs(c.debEst - c.debTrue) / Math.max(0.5, c.debEst)));
  const nCases = new Set(cal.map((r) => r.mode + r.seed)).size, nHold = new Set(hold.map((r) => r.mode + r.seed)).size;
  return { calFold, holdFold, Q, lambda, met, pick, calCurve, curve, held, qPod, podHit, qDeb, nCal: cal.length, nHold: hold.length, nCases, nHoldCases: nHold, alpha: RULE.alpha };
}
