// Safe, restricted, unsafe: the final room statuses (after ATC-20's three placards: inspected, restricted use, unsafe).
// Each room's evidence is Act 7's measurements after the aftershock, each with a split-conformal interval from the
// calibration sweep (calib.js), against the safe limit (the tuned threshold) and the no-entry limit. A room is safe only
// if every interval lies under its safe limit and the room was seen well; unsafe if any interval lies wholly over its
// no-entry limit or its structure is gone; otherwise restricted. Never-seen space is never safe. A pod on one of its
// walls adds its stiffness loss (Act 7's alert level, 30 %, as both limits).
import { decideRoom, groupOf, qOf, RULE, LIMITS } from './calib.js';

export const ORDER = { safe: 0, restricted: 1, unsafe: 2 };
export const FROM_DRAFT = { safe: 'safe', caution: 'restricted', noentry: 'unsafe', unseen: 'restricted' };
const NAME = { tilt: 'Lean', sag: 'Floor sag', crush: 'Crushed space', debris: 'Debris on the floor', gone: 'Wall fallen', cracks: 'Cracks', dmg: 'Wall damage (φ_wall)', stiff: 'Stiffness lost' };
export const QNAME = NAME;
export function fmtQ(k, v) {
  if (!Number.isFinite(v)) return 'unknown';
  if (k === 'tilt') return `${v.toFixed(1)}°`;
  if (k === 'sag') return `${(v * 100).toFixed(1)} cm`;
  if (k === 'cracks') return `${v.toFixed(1)} m`;
  return `${Math.round(v * 100)} %`;
}
// the pods on a room's walls (after the scripted aftershock): measured loss, its interval half-width from calibration
export function roomPods(C, roomId) {
  const A = C.aftershocks[0], out = [];
  C.pods.list.forEach((pd, i) => { if (C.model.walls[pd.wall].rooms.includes(roomId)) out.push({ pod: i, m: Math.max(0, A.reads[i].stiffLoss) }); });
  return out;
}
export function finalStatuses(C, K, overrides = {}) {
  const lambda = K.lambda, rooms = [];
  for (const room of C.model.rooms) {
    const i = room.id, mr = C.rooms[i], draft = C.roomsAfter[i].status;
    const moved = (C.storeys[room.storey].tilt || 0) > 1 || (C.storeys[Math.min(4, room.storey + 1)].tilt || 0) > 1;
    const group = groupOf(moved, draft);
    const m = { tilt: mr.tilt, sag: mr.sag, sagKnown: !!mr.sagKnown, crush: mr.crush, debris: mr.debrisShare, gone: mr.gone, cracks: mr.cracks, dmg: mr.dmgShare, seen: mr.seen };
    const pods = roomPods(C, i), worst = pods.length ? pods.reduce((a, b) => (b.m > a.m ? b : a)) : null;
    const extra = worst ? [{ key: 'stiff', m: worst.m, q: K.qPod, safe: RULE.stiffUnsafe, unsafe: RULE.stiffUnsafe }] : [];
    const d = decideRoom(m, qOf(K.Q, C.mode, group), lambda, extra);
    const reasons = reasonsOf(d, m);
    const computed = d.status, ov = overrides[i];
    const status = ov ? ov.status : computed;
    rooms.push({ id: i, status, computed, override: ov || null, lessCautious: !!ov && ORDER[ov.status] < ORDER[computed], group, ev: d.ev, m, seen: m.seen, borderline: d.borderline && status === 'restricted', gone: d.gone, pod: worst, reasons,
      draft, draftAs: FROM_DRAFT[draft], differs: FROM_DRAFT[draft] !== computed, why: differWhy(FROM_DRAFT[draft], computed, d, m) });
  }
  return rooms;
}
function reasonsOf(d, m) {
  const out = [], iv = (e) => `${fmtQ(e.key, e.m)} (${fmtQ(e.key, e.lo)} to ${e.hi >= 1e2 && e.key !== 'tilt' ? 'unknown' : fmtQ(e.key, e.hi)})`;
  if (d.gone) out.push(m.crush >= RULE.crushStructure ? `Structure gone: ${Math.round(m.crush * 100)} % of its space is taken by structure that moved in` : `Structure gone: ${Math.round(m.gone * 100)} % of a wall has fallen`);
  for (const e of d.ev) if (e.verdict === 'over') out.push(`${NAME[e.key]} ${iv(e)}, wholly over the no-entry limit of ${fmtQ(e.key, e.unsafe)}`);
  if (out.length) return out;
  if (m.seen < RULE.seenSafe) out.push(`Only ${Math.round(m.seen * 100)} % of it was seen: space never seen is never safe`);
  if (m.sagKnown === false) out.push('The floor could not be measured, so its sag is unknown');
  const ex = (e) => (Number.isFinite(e.hi) ? (e.hi - e.safe) / Math.max(1e-9, e.safe) : 1e9);
  for (const e of d.ev.slice().sort((a, b) => ex(b) - ex(a))) if (e.verdict !== 'under' && !(e.key === 'sag' && m.sagKnown === false)) out.push(`${NAME[e.key]} ${iv(e)} reaches past the safe limit of ${fmtQ(e.key, e.safe)}`);
  if (!out.length) out.push(`Every interval sits under its safe limit; ${Math.round(m.seen * 100)} % of it was seen`);
  return out;
}
function differWhy(draftAs, computed, d, m) {
  if (draftAs === computed) return '';
  if (computed === 'safe') return 'Act 7’s draft was cautious; with calibrated intervals every quantity is clearly under its safe limit';
  if (computed === 'unsafe') return 'An interval lies wholly over a no-entry limit';
  if (draftAs === 'unsafe') return 'Act 7’s draft rule closed it; no interval lies wholly over a no-entry limit, so it is restricted, not unsafe';
  return 'Some interval reaches past its safe limit, so it cannot be called safe';
}
export const placardWord = { safe: 'Safe', restricted: 'Restricted', unsafe: 'Unsafe' };
export const limitsText = (lambda) => Object.entries(LIMITS).map(([k, L]) => `${NAME[k]}: safe under ${fmtQ(k, L.safe * lambda)}, unsafe over ${Number.isFinite(L.unsafe) ? fmtQ(k, L.unsafe) : 'none'}`);
