// When to go back in. The mainshock (magnitude and time) is part of the simulation: seeded, consistent with the failure
// mode (a leaning block from a moderate shock, a soft storey or a corner pancake from a stronger one). Aftershocks follow
// Reasenberg & Jones (1989, Science 243, 1173-1176), generic California parameters: the rate of aftershocks of magnitude
// M or more, t days after a mainshock of magnitude Mm, is
//   lambda(t, M) = 10^(a + b (Mm - M)) (t + c)^-p   per day,   a = -1.67, b = 0.91, p = 1.08, c = 0.05 day.
// The chance of at least one aftershock of the damaging size Md or more during a work shift [t, t + T] is
//   1 - exp(-integral of lambda over the shift).
// Md is an absolute magnitude, an assumption stated on the assumptions panel: 5.0 by default, 4.5 when the pods show a
// weakened structure (mean stiffness loss after Act 7's aftershock of 30 % or more, or Act 7's slowing flag), because a
// weakened building can be damaged by a smaller shake. So the window depends on the mainshock and on the building.
// Restricted rooms may be re-entered once that chance is under the tolerance AND the pods' relaxation time is not
// growing (Act 7's "slowing" flag); unsafe rooms stay closed until shored. Real use would refit a, b, p, c as the
// aftershocks are recorded.
import { rngFor } from '../../../act7/js/building/geom.js';

export const RJ = { a: -1.67, b: 0.91, p: 1.08, c: 0.05 };
export const MD = { normal: 5.0, weakened: 4.5, lossAt: 0.30 };
export const REENTRY_DEFAULTS = { tolerance: 0.10, shiftH: 12 };

// the simulated event: magnitude, the clock time of the mainshock and of the handover to the commander
export function mainshock(mode, seed, C) {
  const r = rngFor(seed, 'mainshock');
  const [lo, hi] = mode === 'lean' ? [5.6, 6.0] : [6.0, 6.6];
  const Mm = Math.round((lo + r() * (hi - lo)) * 10) / 10;
  // at night (the occupancy is the night-time one): between 01:00 and 04:00
  const clock0 = 3600 * (1 + r() * 3);
  // the swarm's search before touchdown (Acts 4 to 6), then Act 7's ground station: the commander has the board
  const searchH = 1.4 + r() * 0.8;
  const stationS = C && C.clock ? C.clock.changeMap + 900 + 37 * 60 : 3000;
  const handoverH = searchH + stationS / 3600;
  // shaking at the site (for the fragility loop): simulated peak ground acceleration, larger for the stronger shocks
  const pga = Math.round((mode === 'lean' ? 0.18 + r() * 0.1 : 0.28 + r() * 0.16) * 100) / 100;
  // the damaging size: smaller for a weakened structure (the pods after Act 7's aftershock)
  const A = C && C.aftershocks && C.aftershocks[0], loss = A ? A.reads.map((x) => x.stiffLoss) : [];
  const meanLoss = loss.length ? loss.reduce((s2, v) => s2 + v, 0) / loss.length : 0, slowing = !!(A && A.slowing);
  const weakened = meanLoss >= MD.lossAt || slowing;
  return { Mm, Md: weakened ? MD.weakened : MD.normal, weakened, meanLoss, slowing, clock0, searchH, handoverH, pga };
}
// integral of (t + c)^-p from t0 to t1 (days)
function intPow(t0, t1, c, p) { const q = 1 - p; return (Math.pow(t1 + c, q) - Math.pow(t0 + c, q)) / q; }
// chance of at least one aftershock of magnitude Md or more in [tH, tH + shiftH] (hours since the mainshock)
export function shiftChance(tH, shiftH, Mm, Md, P = RJ) {
  const k = Math.pow(10, P.a + P.b * (Mm - Md));
  const n = k * intPow(tH / 24, (tH + shiftH) / 24, P.c, P.p);
  return 1 - Math.exp(-n);
}
// the curve against hours since the mainshock, and the first hour (from the handover on) when it falls under the line
export function reentry(ev, { tolerance = REENTRY_DEFAULTS.tolerance, shiftH = REENTRY_DEFAULTS.shiftH, slowing = false, podWaitH = 2 } = {}) {
  const H = 24 * 7, curve = [];
  for (let h = 0; h <= H; h += 1) curve.push([h, shiftChance(h, shiftH, ev.Mm, ev.Md)]);
  // the window: the first time (0.25 h steps, not before the handover) the shift's chance is under the tolerance
  let open = null; for (let h = ev.handoverH; h <= 24 * 60; h += 0.25) if (shiftChance(h, shiftH, ev.Mm, ev.Md) < tolerance) { open = h; break; }
  const quake = open;
  // if the pods say the structure recovers more slowly after each aftershock, the window waits for a fresh pod reading
  if (open != null && slowing) open = Math.max(open, ev.handoverH + podWaitH);
  return { curve, open, quake, slowing, tolerance, shiftH, nowChance: shiftChance(ev.handoverH, shiftH, ev.Mm, ev.Md), Md: ev.Md, Mm: ev.Mm };
}
// clock time (seconds after midnight, may run past one day) -> "Thu 06:40"-style text, day 0 = the night of the mainshock
export function clockText(ev, hoursAfter) {
  const s = ev.clock0 + hoursAfter * 3600, day = Math.floor(s / 86400), r = s - day * 86400;
  const hh = String(Math.floor(r / 3600)).padStart(2, '0'), mm = String(Math.floor((r % 3600) / 60)).padStart(2, '0');
  return `day ${day + 1}, ${hh}:${mm}`;
}
