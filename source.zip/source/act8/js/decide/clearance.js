// The minimum-clearance plan: unbalanced optimal transport (Chizat, Peyre, Schmitzer & Vialard 2018; entropic Sinkhorn
// with relaxed marginals), solved in the log domain. Sources: the measured debris (Act 7's estimate) on 1 m cells, in
// loose volume. Targets: the dump points on the site (the street loading bay, which trucks keep emptying, and a skip
// in the yard) with capacities (an upper bound on what each receives). Cost per m3: the haul distance on the ground
// around the building and the site walls (Dijkstra on a 0.5 m grid) plus a lift term for height. Each source's mass is
// held to its cell by a KL penalty: a large one on the must-clear cells (the lanes to the dig sites and the entrances),
// a modest one elsewhere, so the plan moves only what must move.
import { floorTop } from '../../../act7/js/building/building.js';

export const CLEAR = { bulk: 1.3, truck: 10, productivity: 15, liftCost: 4, eps: 0.6, tauMust: 1e4, tauStay: 0.5, iters: 5000, skip: 8, entranceR: 1.6, cell: 1.0, leftTol: 0.01 };
// the dump points, from the site model: the loading bay on the street clear of the responders' things, a skip in the yard
export function dumpPoints(C) {
  const s = C.model.site, { L, D } = C.model.dims;
  const bayX = Math.min(s.bounds.x1 - 3, Math.max(s.pad.x, s.anchor.x) + 4.5), bay = { id: 'bay', name: 'Street loading bay', p: [bayX, 0, Math.min(s.street.z1 - 2, s.street.z0 + 3.2)], cap: Infinity };
  const skip = { id: 'skip', name: 'Skip in the yard', p: [-L / 2 + 2.2, 0, Math.max(s.yard.z0 + 1.4, -D / 2 - 2.0)], cap: CLEAR.skip };
  return [bay, skip];
}
// ground distance from each dump over a 0.5 m grid: the building's footprint can be carried through (x1.6), the site's
// walls and the neighbours cannot (the gate is open)
function groundField(C, dumps) {
  const b = C.model.site.bounds, h = 0.5, nx = Math.ceil((b.x1 - b.x0) / h), nz = Math.ceil((b.z1 - b.z0) / h), cost = new Float32Array(nx * nz).fill(1);
  const { L, D } = C.model.dims;
  for (const p of C.model.parts) { if (p.kind !== 'site' || !p.aabb || p.aabb[4] < 0.9) continue; const a = p.aabb;
    for (let k = Math.max(0, Math.floor((a[2] - b.z0) / h)); k <= Math.min(nz - 1, Math.floor((a[5] - b.z0) / h)); k++) for (let i = Math.max(0, Math.floor((a[0] - b.x0) / h)); i <= Math.min(nx - 1, Math.floor((a[3] - b.x0) / h)); i++) cost[i + nx * k] = 0; }
  const gate = C.model.site.gate; for (let dz = -2; dz <= 2; dz++) for (let dx = -3; dx <= 3; dx++) { const i = Math.floor((gate.x - b.x0) / h) + dx, k = Math.floor((gate.z - b.z0) / h) + dz; if (i >= 0 && k >= 0 && i < nx && k < nz) cost[i + nx * k] = 1; }
  for (let k = 0; k < nz; k++) for (let i = 0; i < nx; i++) { const x = b.x0 + (i + .5) * h, z = b.z0 + (k + .5) * h; if (Math.abs(x) < L / 2 && Math.abs(z) < D / 2) cost[i + nx * k] = 1.6; }
  const fields = dumps.map((d) => {
    const dist = new Float64Array(nx * nz).fill(Infinity), s0 = Math.floor((d.p[0] - b.x0) / h) + nx * Math.floor((d.p[2] - b.z0) / h); dist[s0] = 0;
    const heap = [[0, s0]]; const push = (x) => { heap.push(x); let i = heap.length - 1; while (i > 0) { const p = (i - 1) >> 1; if (heap[p][0] <= heap[i][0]) break; [heap[p], heap[i]] = [heap[i], heap[p]]; i = p; } };
    const pop = () => { const top = heap[0], last = heap.pop(); if (heap.length) { heap[0] = last; let i = 0; for (;;) { const l = 2 * i + 1, r = l + 1; let m = i; if (l < heap.length && heap[l][0] < heap[m][0]) m = l; if (r < heap.length && heap[r][0] < heap[m][0]) m = r; if (m === i) break; [heap[m], heap[i]] = [heap[i], heap[m]]; i = m; } } return top; };
    while (heap.length) { const [dd, c] = pop(); if (dd > dist[c]) continue; const i = c % nx, k = (c - i) / nx;
      for (const [di, dk, w] of [[1, 0, 1], [-1, 0, 1], [0, 1, 1], [0, -1, 1], [1, 1, 1.414], [1, -1, 1.414], [-1, 1, 1.414], [-1, -1, 1.414]]) { const ii = i + di, kk = k + dk; if (ii < 0 || kk < 0 || ii >= nx || kk >= nz) continue; const e = ii + nx * kk; if (!cost[e]) continue; const nd = dd + h * w * (cost[e] + cost[c]) / 2; if (nd < dist[e]) { dist[e] = nd; push([nd, e]); } } }
    return dist;
  });
  return { at: (x, z, j) => { const i = Math.max(0, Math.min(nx - 1, Math.floor((x - b.x0) / h))), k = Math.max(0, Math.min(nz - 1, Math.floor((z - b.z0) / h))); let v = fields[j][i + nx * k]; if (!Number.isFinite(v)) { // a walled-in cell: the nearest reachable one
      let best = Infinity; for (let r = 1; r < 8 && !Number.isFinite(best); r++) for (let dk = -r; dk <= r; dk++) for (let di = -r; di <= r; di++) { const ii = i + di, kk = k + dk; if (ii < 0 || kk < 0 || ii >= nx || kk >= nz) continue; const w = fields[j][ii + nx * kk]; if (w + r * h < best) best = w + r * h; } v = best; } return v; } };
}
// the debris on 1 m cells (loose volume) with its mean height
export function debrisCells(P) {
  const g = P.g, q = [0, 0, 0], m = new Map();
  for (const pc of P.pieces) for (const c of pc.cells) { g.centre(c, q); const k = `${Math.floor(q[0] / CLEAR.cell)},${Math.floor(q[2] / CLEAR.cell)}`; let o = m.get(k); if (!o) { o = { x: (Math.floor(q[0] / CLEAR.cell) + .5) * CLEAR.cell, z: (Math.floor(q[2] / CLEAR.cell) + .5) * CLEAR.cell, vol: 0, ySum: 0, n: 0, top: 0 }; m.set(k, o); } o.vol += g.V3; o.ySum += q[1]; o.n++; if (q[1] > o.top) o.top = q[1]; }
  return [...m.values()].map((o) => ({ x: o.x, z: o.z, vol: o.vol, loose: o.vol * CLEAR.bulk, y: o.ySum / o.n, top: o.top + g.vox / 2 }));
}
// must-clear cells: under the lanes of the active dig sites, and around the entrances
export function mustClear(cells, lanes, entrances) {
  const near = (c, a, b, r) => { const dx = b[0] - a[0], dz = b[2] - a[2], L2 = dx * dx + dz * dz; let t = L2 ? ((c.x - a[0]) * dx + (c.z - a[2]) * dz) / L2 : 0; t = Math.max(0, Math.min(1, t)); return Math.hypot(c.x - (a[0] + dx * t), c.z - (a[2] + dz * t)) < r; };
  return cells.map((c) => lanes.some((l) => near(c, l.a, l.b, 0.6 + CLEAR.cell * 0.5)) || entrances.some((e) => Math.hypot(c.x - e[0], c.z - e[2]) < CLEAR.entranceR));
}
const lse = (arr) => { let m = -Infinity; for (const v of arr) if (v > m) m = v; if (m === -Infinity) return m; let s = 0; for (const v of arr) s += Math.exp(v - m); return m + Math.log(s); };
// log-domain Sinkhorn for unbalanced OT: KL-relaxed sources (tau per source), capacity upper bounds on the targets
export function sinkhornUOT(a, b, cost, tau, eps = CLEAR.eps, iters = CLEAR.iters) {
  const n = a.length, m = b.length, f = new Float64Array(n), g = new Float64Array(m), tmp = new Float64Array(Math.max(n, m));
  let resid = 0;
  for (let it = 0; it < iters; it++) {
    let ch = 0;
    for (let i = 0; i < n; i++) { if (a[i] <= 0) { f[i] = -Infinity; continue; } for (let j = 0; j < m; j++) tmp[j] = (g[j] - cost[i][j]) / eps; const k = tau[i] / (tau[i] + eps); const nf = k * eps * (Math.log(a[i]) - lse(tmp.subarray(0, m))); if (Number.isFinite(f[i])) ch = Math.max(ch, Math.abs(nf - f[i])); f[i] = nf; }
    for (let j = 0; j < m; j++) { for (let i = 0; i < n; i++) tmp[i] = (f[i] - cost[i][j]) / eps; const s = lse(tmp.subarray(0, n)); const ng = Number.isFinite(b[j]) ? Math.min(0, eps * (Math.log(b[j]) - s)) : 0; ch = Math.max(ch, Math.abs(ng - g[j])); g[j] = ng; }
    resid = ch; if (ch < 1e-7) break;
  }
  const plan = []; for (let i = 0; i < n; i++) { const row = new Float64Array(m); for (let j = 0; j < m; j++) row[j] = Number.isFinite(f[i]) ? Math.exp((f[i] + g[j] - cost[i][j]) / eps) : 0; plan.push(row); }
  return { plan, resid };
}
export function clearancePlan(C, P, lanes, entrances, opts = {}) {
  const R = { ...CLEAR, ...opts }, dumps = dumpPoints(C); dumps[1].cap = R.skip;
  const cells = debrisCells(P), must = mustClear(cells, lanes, entrances), field = groundField(C, dumps);
  const cost = cells.map((c) => dumps.map((d, j) => field.at(c.x, c.z, j) + R.liftCost * Math.max(0, c.y)));
  const a = cells.map((c) => c.loose), b = dumps.map((d) => d.cap), tau = must.map((mc) => (mc ? R.tauMust : R.tauStay));
  const { plan, resid } = sinkhornUOT(a, b, cost, tau, R.eps, R.iters);
  let moved = 0, recv = dumps.map(() => 0), mustLeft = 0, mustN = 0, total = 0, arcs = [], workM = 0;
  cells.forEach((c, i) => { const out = plan[i].reduce((s, v) => s + v, 0); total += c.loose; moved += out; plan[i].forEach((v, j) => { recv[j] += v; if (v > 0.02) arcs.push({ from: [c.x, Math.max(0.2, c.y), c.z], to: dumps[j].p, j, loose: v }); workM += v * cost[i][j];
    }); if (must[i]) { mustN++; if (c.loose - out > Math.max(R.leftTol * c.loose, 0.005)) mustLeft++; } });
  const sent = recv.reduce((s, v) => s + v, 0);
  const balance = Math.abs(sent - moved) / Math.max(1e-9, total);
  const overflow = dumps.map((d, j) => (Number.isFinite(d.cap) ? Math.max(0, recv[j] - d.cap) / d.cap : 0));
  const bayTrucks = recv[0] > 0.05 ? Math.ceil(recv[0] / R.truck - 1e-9) : 0, trucks = bayTrucks + (recv[1] > 0.05 ? 1 : 0);   // the skip leaves as one load when it is collected
  const hours = moved / R.productivity;
  return { cells: cells.map((c, i) => ({ ...c, must: must[i], left: c.loose - plan[i].reduce((s, v) => s + v, 0) })), dumps, recv, moved, total, inPlace: total / R.bulk, movedInPlace: moved / R.bulk,
    saving: total > 0 ? 1 - moved / total : 0, mustN, mustLeft, balance, overflow, resid, trucks, bayTrucks, hours, arcs: arcs.sort((x, y) => y.loose - x.loose), R };
}
export const entrancesOf = (C) => { const { D } = C.model.dims, e0 = C.routes[0].entry || [0, 0.3, D / 2]; return [[e0[0], floorTop(0), D / 2 + 0.4], [0, floorTop(0), -D / 2 - 0.4]]; };
