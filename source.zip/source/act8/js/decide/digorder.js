// Where to dig first. For each candidate void (a dig site): the cheapest way in (walk along Act 7's routes, or a ladder
// from outside for an upper floor), the lane from there to the void, the debris pieces in the lane and everything
// resting on them (they must be lifted first, at the lift rate), the rooms the lane crosses (an unsafe room needs its
// path shored, a restricted one a check) and the time to shore and open the void. Then the order: teams work their
// sectors in parallel; each picks next the site with the most expected people reached per hour (Smith's rule, p / t),
// weighted by a survival curve that falls with time to rescue. Sectors: the map graph (1 m cells of the work area,
// dig sites in it) split by the Fiedler vector (Fiedler 1973), recursively, one sector per team, balanced by work.
// Scored against the truth: the mean time to reach the people who would truly be trapped in a void, against two naive
// orders (nearest first, biggest void first) with the same teams and the same time model.
import { floorTop } from '../../../act7/js/building/building.js';
import { tApply, tInvert } from '../../../act7/js/building/geom.js';
import { closureOf } from './support.js';

export const DIG = {
  walk: 0.5,            // m/s through a damaged building
  stairMin: 1.0,        // min per storey climbed
  ladderMin: 15,        // min to set a ladder for an upper floor from outside
  liftRate: 3.0,        // m3/h of debris lifted, carefully, by hand and light tools (a team)
  shoreMin: 45,         // min to shore and open a void
  pathUnsafeMin: 30,    // min to shore a path through an unsafe room
  pathRestrictedMin: 10,// min to check a restricted room on the way
  laneR: 0.6,           // m: half-width of a lane a rescuer crawls along
  engineerMin: 120,     // min: a lane the safe lifts cannot open waits for an engineer's look and shoring (an assumption)
  shorePauseMin: 30,    // min per shoring pause the removal plan makes on a lane (an assumption)
  halfLifeH: 48,        // h: the survival weight halves every 48 h (an assumption for the shape only)
  teams: 2,
};
export const survival = (h, P = DIG) => Math.pow(0.5, h / P.halfLifeH);
const storeyOfY = (y) => Math.max(0, Math.min(3, Math.floor((y + 0.2) / 3)));
// the room (id) a point lies in, through each storey's measured motion
function roomAt(C, p, inv) {
  for (let s = 0; s < 4; s++) { const q = tApply(inv[s], p[0], p[1], p[2]); if (q[1] < floorTop(s) - 0.3 || q[1] > floorTop(s) + 3.0) continue;
    for (const r of C.model.rooms) if (r.storey === s && q[0] >= r.x0 && q[0] <= r.x1 && q[2] >= r.z0 && q[2] <= r.z1) return r.id; }
  return -1;
}
const segBoxDist = (a, b, bb) => { // distance from segment ab to an axis-aligned box (sampled)
  let best = 1e9; const n = Math.max(2, Math.ceil(Math.hypot(b[0] - a[0], b[1] - a[1], b[2] - a[2]) / 0.25));
  for (let i = 0; i <= n; i++) { const t = i / n, x = a[0] + (b[0] - a[0]) * t, y = a[1] + (b[1] - a[1]) * t, z = a[2] + (b[2] - a[2]) * t;
    const d = Math.hypot(Math.max(0, bb[0] - x, x - bb[3]), Math.max(0, bb[1] - y, y - bb[4]), Math.max(0, bb[2] - z, z - bb[5])); if (d < best) best = d; }
  return best;
};
// access candidates and lanes for every site (independent of statuses and rates: computed once)
export function siteAccess(C, P, G, sites) {
  const g = P.g, { L, D } = C.model.dims, door = C.routes[0].entry || [0, 0.3, D / 2];
  const inv = C.storeys.map((f) => tInvert(f.T));
  return sites.map((st) => {
    const pk = C.pockets.list[st.pocket], s = storeyOfY(pk.centre[1]);
    // the void's nearest cell to a point
    const q = [0, 0, 0], near = (p) => { let bd = 1e9, bp = pk.centre; for (let a = 0; a < pk.cells.length; a += Math.max(1, Math.floor(pk.cells.length / 400))) { g.centre(pk.cells[a], q); const d = (q[0] - p[0]) ** 2 + (q[1] - p[1]) ** 2 + (q[2] - p[2]) ** 2; if (d < bd) { bd = d; bp = [q[0], q[1], q[2]]; } } return bp; };
    const cands = [];
    const fl = C.routes[s], entry = fl && fl.entry;
    const toEntry = s === 0 ? 0 : Math.hypot((entry ? entry[0] : 0) - door[0], (entry ? entry[2] : 0) - door[2]) + s * 7;
    if (fl && entry) { cands.push({ p: entry, walk: toEntry, via: 'route' });
      for (const r of fl.routes) { if (!r.reachable || !r.pts) continue; let u = 0; for (let i = 0; i < r.pts.length; i++) { if (i) u += Math.hypot(r.pts[i][0] - r.pts[i - 1][0], r.pts[i][2] - r.pts[i - 1][2]); if (i % 2 === 0 || i === r.pts.length - 1) cands.push({ p: [r.pts[i][0], floorTop(s) + 0.5, r.pts[i][2]], walk: toEntry + u, via: 'route' }); } } }
    // from outside: around the footprint, at the void's floor (a ladder above the ground floor)
    const y = floorTop(s) + 0.5, ring = [];
    for (let x = -L / 2 - 0.8; x <= L / 2 + 0.8; x += 1) { ring.push([x, y, -D / 2 - 0.8]); ring.push([x, y, D / 2 + 0.8]); }
    for (let z = -D / 2 - 0.8; z <= D / 2 + 0.8; z += 1) { ring.push([-L / 2 - 0.8, y, z]); ring.push([L / 2 + 0.8, y, z]); }
    for (const p of ring) cands.push({ p, walk: Math.hypot(p[0] - door[0], p[2] - door[2]) + 4, via: s ? 'ladder' : 'outside' });
    // keep the 40 nearest candidates (in plan) to the void
    for (const c of cands) c.d = Math.hypot(c.p[0] - pk.centre[0], c.p[2] - pk.centre[2]) + Math.abs(c.p[1] - pk.centre[1]);
    cands.sort((a, b) => a.d - b.d); const keep = cands.slice(0, 40);
    for (const c of keep) {
      c.to = near(c.p);
      const lane = []; for (const pc of P.pieces) if (!G.locked[pc.id] && segBoxDist(c.p, c.to, pc.bb) < DIG.laneR) lane.push(pc.id);
      c.lane = lane; c.closure = [...closureOf(lane, G)].filter((i) => !G.locked[i]);
      c.vol = c.closure.reduce((a, i) => a + P.pieces[i].vol, 0);
      // rooms the lane crosses (every 0.5 m) and the void's own room
      const rs = new Set(); const n = Math.max(1, Math.ceil(Math.hypot(c.to[0] - c.p[0], c.to[1] - c.p[1], c.to[2] - c.p[2]) / 0.5));
      for (let i = 0; i <= n; i++) { const t = i / n, r = roomAt(C, [c.p[0] + (c.to[0] - c.p[0]) * t, c.p[1] + (c.to[1] - c.p[1]) * t, c.p[2] + (c.to[2] - c.p[2]) * t], inv); if (r >= 0) rs.add(r); }
      if (pk.room >= 0) rs.add(pk.room);
      c.rooms = [...rs]; c.laneLen = Math.hypot(c.to[0] - c.p[0], c.to[1] - c.p[1], c.to[2] - c.p[2]);
    }
    return { site: st.pocket, storey: s, cands: keep };
  });
}
// time (hours) to reach a site through one access candidate, given what is already lifted and the room statuses
function candTime(c, P, lifted, statusOf, R) {
  // the lifts: the removal plan's steps for this lane (not yet done for another site), then what is left on it after an
  // engineer's look; before the removal plan exists, the measured pieces in the lane and what rests on them
  let vol = 0; if (c.steps) { for (const s of c.steps) if (!lifted.has(s.key)) vol += s.vol; vol += c.leftVol || 0; } else for (const i of c.closure) if (!lifted.has(i)) vol += P.pieces[i].vol;
  let roomMin = 0; for (const r of c.rooms) { const s = statusOf(r); roomMin += s === 'unsafe' ? R.pathUnsafeMin : s === 'restricted' ? R.pathRestrictedMin : 0; }
  const walkMin = (c.walk + c.laneLen) / R.walk / 60 + (c.via === 'ladder' ? R.ladderMin : 0);
  const extraMin = c.extraMin || 0;
  return { h: (walkMin + roomMin + R.shoreMin + extraMin) / 60 + vol / R.liftRate, vol, roomMin, walkMin, extraMin, stuck: !!c.stuck, unverified: !!c.unverified };
}
export function bestAccess(acc, P, lifted, statusOf, R) {
  let best = null; for (const c of acc.cands) { const t = candTime(c, P, lifted, statusOf, R); if (!best || t.h < best.t.h) best = { c, t }; } return best;
}
// ------------------------------------------------------------------ sectors (Fiedler bisection of the map graph)
export function sectors(C, P, sites, access, nTeams) {
  const { L, D } = C.model.dims, x0 = -L / 2 - 3, z0 = -D / 2 - 3, nx = Math.ceil(L + 6), nz = Math.ceil(D + 6), cell = (x, z) => { const i = Math.floor(x - x0), k = Math.floor(z - z0); return i < 0 || k < 0 || i >= nx || k >= nz ? -1 : i + nx * k; };
  const w = new Float64Array(nx * nz), use = new Uint8Array(nx * nz);
  for (let k = 0; k < nz; k++) for (let i = 0; i < nx; i++) { const x = x0 + i + .5, z = z0 + k + .5; if (Math.abs(x) < L / 2 + 0.5 && Math.abs(z) < D / 2 + 0.5) use[i + nx * k] = 1; }
  for (const pc of P.pieces) { const c = cell(pc.c[0], pc.c[2]); if (c >= 0) { use[c] = 1; w[c] += pc.vol; } }
  const siteCell = sites.map((s) => { const pk = C.pockets.list[s.pocket]; const c = cell(pk.centre[0], pk.centre[2]); if (c >= 0) { use[c] = 1; w[c] += 3; } return c; });
  const ids = []; const idx = new Int32Array(nx * nz).fill(-1); for (let c = 0; c < nx * nz; c++) if (use[c]) { idx[c] = ids.length; ids.push(c); }
  const nbr = ids.map((c) => { const i = c % nx, k = (c - i) / nx, out = []; for (const [di, dk] of [[1, 0], [-1, 0], [0, 1], [0, -1]]) { const ii = i + di, kk = k + dk; if (ii < 0 || kk < 0 || ii >= nx || kk >= nz) continue; const j = idx[ii + nx * kk]; if (j >= 0) out.push(j); } return out; });
  const wt = ids.map((c) => w[c] + 0.2);
  let parts = [ids.map((c, j) => j)];
  while (parts.length < nTeams) {
    let bi = 0, bw = -1; parts.forEach((p, i) => { const s = p.reduce((a, j) => a + wt[j], 0); if (s > bw && p.length > 1) { bw = s; bi = i; } });
    const p = parts[bi]; if (p.length < 2) break;
    const f = fiedler(p, nbr); const ord = p.map((j, k) => [f[k], j]).sort((a, b) => a[0] - b[0]);
    const tot = ord.reduce((a, [, j]) => a + wt[j], 0); let acc = 0, cut = 1; for (let k = 0; k < ord.length; k++) { acc += wt[ord[k][1]]; if (acc >= tot / 2) { cut = Math.max(1, Math.min(ord.length - 1, k + 1)); break; } }
    parts.splice(bi, 1, ord.slice(0, cut).map((q) => q[1]), ord.slice(cut).map((q) => q[1]));
  }
  // largest work first
  parts.sort((a, b) => b.reduce((s, j) => s + wt[j], 0) - a.reduce((s, j) => s + wt[j], 0));
  const sectorOfNode = new Int32Array(ids.length).fill(0); parts.forEach((p, s) => p.forEach((j) => { sectorOfNode[j] = s; }));
  const cellsOut = ids.map((c, j) => ({ x: x0 + (c % nx) + .5, z: z0 + Math.floor(c / nx) + .5, s: sectorOfNode[j] }));
  const siteSector = siteCell.map((c) => (c >= 0 && idx[c] >= 0 ? sectorOfNode[idx[c]] : 0));
  return { n: parts.length, cells: cellsOut, siteSector, work: parts.map((p) => p.reduce((s, j) => s + wt[j], 0)) };
}
// the Fiedler vector of a subgraph (normalised Laplacian, power iteration with deflation)
function fiedler(nodes, nbr) {
  const n = nodes.length, loc = new Map(nodes.map((j, k) => [j, k])), adj = nodes.map((j) => nbr[j].map((x) => loc.get(x)).filter((x) => x != null)), deg = adj.map((a) => Math.max(1, a.length));
  const sq = deg.map((d) => Math.sqrt(d)); let nrm = Math.hypot(...sq); const u0 = sq.map((v) => v / nrm);
  let v = nodes.map((j, k) => Math.sin(k * 1.7 + 0.3) + (k / n - 0.5)); const tmp = new Float64Array(n);
  for (let it = 0; it < 1500; it++) {
    // M = I + D^-1/2 A D^-1/2 (eigenvalues in [0, 2]); its second largest eigenvector is the Fiedler direction
    for (let k = 0; k < n; k++) { let s = v[k]; for (const m of adj[k]) s += v[m] / (sq[k] * sq[m]); tmp[k] = s; }
    let d = 0; for (let k = 0; k < n; k++) d += tmp[k] * u0[k]; for (let k = 0; k < n; k++) tmp[k] -= d * u0[k];
    nrm = 0; for (let k = 0; k < n; k++) nrm += tmp[k] * tmp[k]; nrm = Math.sqrt(nrm) || 1; for (let k = 0; k < n; k++) v[k] = tmp[k] / nrm;
  }
  return v.map((x, k) => x / sq[k]);
}
// ------------------------------------------------------------------ the order (teams in parallel), for any picking rule
// rule: 'smith' | 'nearest' | 'biggest' | 'manual' (manual: a fixed list of site indices, in order)
export function schedule(sites, access, P, statusOf, sec, R, rule = 'smith', manual = null) {
  const nT = Math.max(1, sec.n), lifted = new Set(), out = sites.map(() => null);
  const teamOf = sites.map((s, i) => Math.min(nT - 1, sec.siteSector[i] || 0));
  const left = sites.map((s, i) => i).filter((i) => sites[i].on !== false);
  const tFree = new Float64Array(nT); let order = 0; const seq = [];
  const solo = sites.map((s, i) => bestAccess(access[i], P, new Set(), statusOf, R));
  while (left.length) {
    // the team free first (that still has work in its sector; else any free team takes the next site)
    let team = -1; for (let t = 0; t < nT; t++) if (left.some((i) => teamOf[i] === t) && (team < 0 || tFree[t] < tFree[team])) team = t;
    const mine = left.filter((i) => teamOf[i] === team);
    let pick = -1, best = null, bScore = -Infinity;
    for (const i of mine) { const b = bestAccess(access[i], P, lifted, statusOf, R); let sc;
      if (rule === 'manual') sc = -manual.indexOf(i);
      else if (rule === 'nearest') sc = -(solo[i].c.walk + solo[i].c.laneLen);
      else if (rule === 'biggest') sc = sites[i].vol;
      else sc = sites[i].p * survival(R.startH + tFree[team] + b.t.h, R) / Math.max(0.05, b.t.h);
      if (sc > bScore) { bScore = sc; pick = i; best = b; } }
    const t0 = tFree[team], t1 = t0 + best.t.h; tFree[team] = t1;
    if (best.c.steps) for (const st of best.c.steps) lifted.add(st.key); else for (const k of best.c.closure) lifted.add(k);
    out[pick] = { site: pick, team, rank: order++, t0, t1, eta: R.startH + t1, access: best.c, time: best.t };
    seq.push(pick); left.splice(left.indexOf(pick), 1);
  }
  // the dig order as the field sees it: by when each site is reached (teams work in parallel)
  out.filter(Boolean).sort((a, b) => a.t1 - b.t1 || a.rank - b.rank).forEach((o, k) => { o.pick = o.rank; o.rank = k; });
  return { sites: out, seq, teamOf, finish: Math.max(0, ...tFree) };
}
