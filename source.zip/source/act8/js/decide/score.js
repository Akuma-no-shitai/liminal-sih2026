// Every decision scored against the simulation's known truth (the pipeline never reads the truth; only this does).
import { QUANT } from './calib.js';
const TW = { safe: 'safe', caution: 'restricted', noentry: 'unsafe' };
export function scoreStatuses(C, rooms) {
  let fs = 0, safe = 0, trulySafe = 0, needless = 0, resUnsafe = 0, hit = 0, n = 0; const fsRooms = [], needRooms = [], resUnsafeRooms = [], perQ = Object.fromEntries(QUANT.map((k) => [k, [0, 0]]));
  const truthOf = (i) => TW[C.truth.rooms[i].status] || 'unsafe';
  const T = C.truth.rooms;
  rooms.forEach((r, i) => { const tw = truthOf(i);
    if (r.status === 'safe') { safe++; if (tw !== 'safe') { fs++; fsRooms.push(i); } }
    if (tw === 'safe') { trulySafe++; if (r.status !== 'safe') { needless++; needRooms.push(i); } }
    if (r.status === 'restricted' && tw === 'unsafe' && !r.borderline) { resUnsafe++; resUnsafeRooms.push(i); }
    const t = { tilt: T[i].tilt, sag: T[i].sag, crush: T[i].crush, debris: T[i].debrisShare, gone: T[i].gone, cracks: T[i].crackLen, dmg: T[i].dmg };
    for (const e of r.ev) if (perQ[e.key]) { perQ[e.key][1]++; n++; if (t[e.key] >= e.lo - 1e-9 && t[e.key] <= e.hi + 1e-9) { perQ[e.key][0]++; hit++; } } });
  return { safe, fs, fsRooms, trulySafe, needless, needRooms, resUnsafe, resUnsafeRooms, hit: n ? hit / n : 1, perQ: Object.fromEntries(Object.entries(perQ).map(([k, [a, b]]) => [k, b ? a / b : 1])), truth: rooms.map((r, i) => truthOf(i)) };
}
// mean time to reach the truly trapped under a schedule: a person is reached when the first site matching their void opens
export function reachTimes(trapped, sites, sched) {
  const per = trapped.map((tp) => { let best = Infinity; sites.forEach((s, i) => { const o = sched.sites[i]; if (!o || s.truthVoid !== tp.void) return; best = Math.min(best, o.t1); }); return best; });
  const fin = per.filter(Number.isFinite);
  return { per, reached: fin.length, mean: fin.length ? fin.reduce((a, b) => a + b, 0) / fin.length : null };
}
export const cmp3 = (a, b) => (a == null || b == null ? 'n/a' : a < b * 0.99 ? 'win' : a > b * 1.01 ? 'loss' : 'tie');
