// Ranked alerts (our proposed order): every alert has a class, a 3-D position in the baseline map, its sources and a
// confidence. Order: a survivor seen by two sources, a survivor seen by one, a hazard beside a survivor, then (our
// addition, under every detection) a candidate void with no detection, then the other hazards. Act 7's simulated
// sensors model the fire, the burst tank and the structure, not people: this case has no survivor detections, and the
// list says so.
export const CLASS = [
  { id: 'survivor2', name: 'Survivor, two sources' }, { id: 'survivor1', name: 'Survivor, one source' }, { id: 'hazardNear', name: 'Hazard beside a survivor' },
  { id: 'void', name: 'Candidate void, no detection' }, { id: 'hazard', name: 'Hazard' },
];
const RANK = Object.fromEntries(CLASS.map((c, i) => [c.id, i]));
const near = (a, b, r) => a && b && Math.hypot(a[0] - b[0], a[1] - b[1], a[2] - b[2]) < r;
export function rankedAlerts(C, survivors, statuses, K) {
  const out = [], P = C.thermal.passes, detections = [];   // no detections: the simulated sensors do not model people
  // the fire: hot in some passes, growing or not
  const hotN = P.filter((p) => p.hotArea > 0.2).length, fire = P[2].hotCentre || C.post.fire.pos;
  if (hotN) out.push({ cls: 'hazard', kind: 'fire', title: C.thermal.spreading ? 'Fire, spreading' : 'Fire', pos: fire, sources: ['thermal'], conf: hotN / 3, confText: `hot in ${hotN} of 3 passes`, short: `${hotN} of 3 passes`, detail: `${P[2].hotArea.toFixed(1)} m² hot in the last pass${C.thermal.spreading ? `, up from ${P[0].hotArea.toFixed(1)} m²` : ''}` });
  const coldN = P.filter((p) => p.coldArea > 0.3).length, tank = P[2].coldCentre || (C.post.tank && C.post.tank.pos);
  if (coldN && tank) out.push({ cls: 'hazard', kind: 'water', title: 'Water from the burst roof tank', pos: tank, sources: ['thermal'], conf: coldN / 3, confText: `cold in ${coldN} of 3 passes`, short: `${coldN} of 3 passes`, detail: `${P[2].coldArea.toFixed(1)} m² wet and cold; slippery, and weight on a damaged slab` });
  // pods: stiffness lost after the aftershock, with its interval
  const A = C.aftershocks[0];
  C.pods.list.forEach((pd, i) => { const m = Math.max(0, A.reads[i].stiffLoss), lo = Math.max(0, m - K.qPod), hi = Math.min(1, m + K.qPod);
    if (hi < 0.3) return; out.push({ cls: 'hazard', kind: 'stiffness', title: `Wall losing stiffness (pod ${i + 1})`, pos: pd.pos, sources: ['vibration pod'], conf: lo >= 0.3 ? 0.9 : m >= 0.3 ? 0.6 : 0.3, confText: lo >= 0.3 ? 'over 30 % for sure' : m >= 0.3 ? 'over 30 % likely' : 'may reach 30 %', short: `${Math.round(m * 100)} % lost`, detail: `${Math.round(m * 100)} % stiffness lost (${Math.round(lo * 100)} to ${Math.round(hi * 100)} %)` }); });
  // candidate voids, by the survivor map's odds
  survivors.sites.forEach((s) => { const pk = C.pockets.list[s.pocket];
    out.push({ cls: 'void', kind: 'void', site: s.pocket, title: pk.kind === 'gap' ? 'Candidate void, seen through a gap' : 'Candidate void, under a slab', pos: pk.centre, sources: pk.kind === 'gap' ? ['LiDAR'] : ['LiDAR (inferred)'], conf: s.post, confText: `odds someone is there ${s.post < 0.005 ? 'under 1' : Math.round(s.post * 100)} %`, short: `odds ${s.post < 0.005 ? 'under 1' : Math.round(s.post * 100)} %`, detail: `${pk.vol.toFixed(1)} m³; Act 7’s confidence in the void ${Math.round(pk.conf * 100)} %` }); });
  // a hazard within 3 m of a candidate void: noted (the deck's class is for a hazard beside a survivor)
  for (const a of out) if (a.cls === 'hazard') { const v = survivors.sites.find((s) => near(a.pos, C.pockets.list[s.pocket].centre, 3)); if (v) a.nearVoid = v.pocket; }
  out.sort((a, b) => RANK[a.cls] - RANK[b.cls] || (b.nearVoid != null) - (a.nearVoid != null) || b.conf - a.conf);
  out.forEach((a, i) => { a.rank = i + 1; });
  return { list: out, detections: detections.length, note: 'No survivor was detected: Act 7’s simulated sensors model the fire, the burst tank and the structure, not people. The candidate voids come first, then the hazards.' };
}
