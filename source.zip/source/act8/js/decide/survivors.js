// Where someone could be: a Bayesian survivor map over the candidate voids (Act 7's pockets, both tiers).
//  prior: the night-time occupancy (Act 2's occupancy(), the same seed: the same people) carried to where their rooms
//    went (the measured storey fits), near a void, times a survivability factor for the void's kind and size;
//  negative information (Koopman 1956; Stone 1975): every drone pass that looked into space next to a void and saw
//    nobody lowers that void's odds, p' = p (1 - q) / (1 - p q), with q the pass's detection chance from its range;
//  evidence: Act 7's simulated sensors model the fire, the burst tank and the structure, not body heat, so there are no
//    survivor detections to add here (a real thermal camera finds heat, not people, and could add some).
// The truth (scoring only): the occupants whose room collapsed into a true void (the true storey motion carries them).
import { tApply } from '../../../act7/js/building/geom.js';
import { floorTop } from '../../../act7/js/building/building.js';
import { makeGrid } from '../../../act7/js/building/voxel.js';

export const SURV = {
  base: 0.02,                  // someone the night's occupancy does not list (a visitor, a passer-by), per void
  sigma: 1.0,                  // m: how far a person's position may sit from a void and still be "in" it (prior kernel)
  kind: { slab: 0.6, gap: 0.5 },// survivability by void kind: lean-to wedge under a slab, enclosed space seen through a gap
  vol0: 0.3, vol1: 1.5,        // m3: no survivable space under 0.3 m3; full factor from 1.5 m3
  qDet: 0.8,                   // chance to spot a person in plain view at 0 m (RGB and thermal together)
  edgeW: 0.25,                 // a void's edge (the seen space just outside it) counts a quarter: someone must lie right there
  range: 5,                    // m: the detection chance falls as exp(-range / 5 m)
  maxRange: 8,                 // m: passes further than this did not look
  bedY: 0.3,                   // m above the floor: a person asleep
  trapTol: 0.8,                // m: truth: a person this close to a true void would be trapped in it
};
const O_FREE = 1;
// the occupants carried with their storey (motion: measured fits for the prior, true motions for the truth)
export function placePeople(people, motions) {
  return people.map((p, i) => { const T = motions[p.storey]; const q = tApply(T, p.x, floorTop(p.storey) + SURV.bedY, p.z); return { i, room: p.room, storey: p.storey, pos: q }; });
}
function nearestCell(g, cells, p, stride = 1) {
  let best = 1e9, bc = -1; const q = [0, 0, 0];
  for (let a = 0; a < cells.length; a += stride) { g.centre(cells[a], q); const d = (q[0] - p[0]) ** 2 + (q[1] - p[1]) ** 2 + (q[2] - p[2]) ** 2; if (d < best) { best = d; bc = cells[a]; } }
  return { d: Math.sqrt(best), c: bc };
}
// the survivor map: prior, the passes that looked, and the posterior after each of them
export function survivorMap(C, people, opts = {}) {
  const g = makeGrid(C.g), S = C.S, PK = C.pockets.list, P = { ...SURV, ...opts };
  const placed = placePeople(people, C.storeys.map((f) => f.T));
  const regPoses = C.scans.post.poses.map((q) => tApply(C.reg.T, ...(q.raw || q.p)));
  const out = PK.map((pk, k) => {
    const stride = Math.max(1, Math.floor(pk.cells.length / 1500));
    // prior: the people near this void
    const near = []; let pNone = 1;
    for (const pp of placed) { const { d } = nearestCell(g, pk.cells, pp.pos, stride); const w = Math.exp(-0.5 * (Math.max(0, d - 0.3) / P.sigma) ** 2); if (w > 0.02) near.push({ person: pp.i, room: pp.room, d, w }); }
    const kindF = P.kind[pk.kind] ?? 0.5, volF = Math.max(0, Math.min(1, (pk.vol - P.vol0) / (P.vol1 - P.vol0)));
    const surv = kindF * volF;
    pNone *= 1 - P.base * surv; for (const n of near) pNone *= 1 - n.w * surv;
    const prior = 1 - pNone;
    // the window: observed free voxels in the void (a gap pocket has some) and in a one-voxel shell around it (its edge)
    const inSet = new Set(pk.cells); const winIn = [], winEdge = []; const SY = g.nx * g.nz;
    for (let a = 0; a < pk.cells.length; a++) { const c = pk.cells[a]; if (S[c] === O_FREE) winIn.push(c); if (a % 2) continue; for (const d of [1, -1, g.nx, -g.nx, SY, -SY]) { const e = c + d; if (e >= 0 && e < g.N && !inSet.has(e) && S[e] === O_FREE) winEdge.push(e); } }
    const sIn = Math.max(1, Math.floor(winIn.length / 300)), sEd = Math.max(1, Math.floor(winEdge.length / 300));
    const wIn = winIn.filter((c, i) => i % sIn === 0), wEd = [...new Set(winEdge)].filter((c, i) => i % sEd === 0);
    // passes: each post-event scan stop within range; the share of the void it saw (clear lines of sight)
    const passes = []; let p = prior; const ctr = pk.centre, q = [0, 0, 0], nCells = pk.cells.length;
    for (let i = 0; i < regPoses.length; i++) {
      const o = regPoses[i], dc = Math.hypot(o[0] - ctr[0], o[1] - ctr[1], o[2] - ctr[2]); if (dc > P.maxRange + 2) continue;
      let vin = 0, ved = 0, dsum = 0, dn = 0;
      for (const c of wIn) { g.centre(c, q); const d = Math.hypot(q[0] - o[0], q[1] - o[1], q[2] - o[2]); if (d > P.maxRange) continue; if (clearRay(g, S, o, c, inSet)) { vin++; dsum += d; dn++; } }
      for (const c of wEd) { g.centre(c, q); const d = Math.hypot(q[0] - o[0], q[1] - o[1], q[2] - o[2]); if (d > P.maxRange) continue; if (clearRay(g, S, o, c, inSet)) { ved++; dsum += d; dn++; } }
      if (!dn) continue;
      const share = Math.min(1, (vin * sIn + P.edgeW * ved * sEd) / nCells), d = dsum / dn;
      const qd = P.qDet * share * Math.exp(-d / P.range); if (qd < 1e-4) continue;
      const before = p; p = p * (1 - qd) / (1 - p * qd);
      passes.push({ pose: i, at: o, d, share, q: qd, before, after: p });
    }
    return { pocket: k, kind: pk.kind, vol: pk.vol, conf: pk.conf, centre: pk.centre, room: pk.room, near, surv, prior, passes, post: p };
  });
  return { sites: out, placed };
}
// a clear line of sight: every voxel between the pass and the target is observed free (or inside the void)
function clearRay(g, S, o, target, inSet) {
  const q = g.centre(target, [0, 0, 0]); const dx = q[0] - o[0], dy = q[1] - o[1], dz = q[2] - o[2], L = Math.hypot(dx, dy, dz); if (L < 1e-6) return true;
  const st = g.vox * 0.7, n = Math.floor(L / st);
  for (let k = 1; k < n; k++) { const t = k * st / L; const c = g.cell(o[0] + dx * t, o[1] + dy * t, o[2] + dz * t); if (c < 0 || c === target) continue; if (S[c] !== O_FREE && !inSet.has(c)) return false; }
  return true;
}
// the truth: occupants whose position, carried by the true storey motion, lies in or next to a true void
export function trappedTruth(C, people) {
  const g = makeGrid(C.g), V = C.truth.voids;
  const placed = placePeople(people, C.post.motions);
  const out = [];
  for (const pp of placed) {
    let best = { d: 1e9, v: -1 };
    for (let v = 0; v < V.length; v++) { const bb = V[v].bb, lo = [g.x0 + bb[0] * g.vox, g.y0 + bb[1] * g.vox, g.z0 + bb[2] * g.vox], hi = [g.x0 + (bb[3] + 1) * g.vox, g.y0 + (bb[4] + 1) * g.vox, g.z0 + (bb[5] + 1) * g.vox];
      const dd = Math.hypot(Math.max(0, lo[0] - pp.pos[0], pp.pos[0] - hi[0]), Math.max(0, lo[1] - pp.pos[1], pp.pos[1] - hi[1]), Math.max(0, lo[2] - pp.pos[2], pp.pos[2] - hi[2]));
      if (dd > SURV.trapTol || dd > best.d) continue;
      const { d } = nearestCell(g, V[v].cells, pp.pos, Math.max(1, Math.floor(V[v].cells.length / 3000))); if (d < best.d) best = { d, v }; }
    if (best.v >= 0 && best.d <= SURV.trapTol) out.push({ person: pp.i, room: pp.room, storey: pp.storey, pos: pp.pos, void: best.v, d: best.d });
  }
  return out;
}
