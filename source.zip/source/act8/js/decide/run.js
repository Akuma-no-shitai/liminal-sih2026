// The decision engine as one generator (progress in slices, like Act 7's pipeline): from Act 7's case to the plan.
//   occupants (Act 2's occupancy, same seed) -> calibration (folds, conformal quantiles, the safe threshold) -> the event
//   -> debris pieces -> support graph -> survivor map -> dig-site access -> the true support (for scoring) -> the
//   lifts, planned with rescans (rescan.js) -> plan()
// plan(D, settings) is everything downstream of the viewer's choices (overrides, tolerance, shift, teams, truck size,
// lift rate, dig sites on/off and their order): statuses, re-entry window, sectors, dig order (and the naive orders),
// lift order, clearance plan, alerts and every score against the truth. It is cheap, so the commander's table reruns it.
// Pure JS: no DOM, no three.js.
import { accessGraph, crowdWorld, occupancy, lobbyClutter } from '../../../act2/js/pipe/plan.js';
import { NIGHT } from '../../../act2/js/pipe/run.js';
import { tiltOf, DEG } from '../../../act7/js/building/geom.js';
import { calibrate } from './calib.js';
import { finalStatuses } from './status.js';
import { mainshock, reentry, REENTRY_DEFAULTS } from './reentry.js';
import { debrisPieces } from './pieces.js';
import { supportGraph, trueSupport } from './support.js';
import { rescanSteps } from './rescan.js';
import { survivorMap, trappedTruth } from './survivors.js';
import { siteAccess, sectors, schedule, DIG } from './digorder.js';
import { clearancePlan, entrancesOf, CLEAR } from './clearance.js';
import { rankedAlerts } from './alerts.js';
import { fragility } from './fragility.js';
import { scoreStatuses, reachTimes, cmp3 } from './score.js';

const PERF = () => (typeof performance !== 'undefined' ? performance.now() : Date.now());
export const DEFAULTS = { tolerance: REENTRY_DEFAULTS.tolerance, shiftH: REENTRY_DEFAULTS.shiftH, teams: DIG.teams, truck: CLEAR.truck, liftRate: DIG.liftRate, overrides: {}, siteOff: [], siteOrder: null };

export function* decideCase(C, opts = {}) {
  const tm = {}, t = (k, t0) => { tm[k] = Math.round(PERF() - t0); };
  let t0 = PERF();
  yield { p: 0.02, label: 'Placing the night’s occupants' };
  // the same people Act 2's crowd model evacuated: its occupancy rule needs its crowd world (the walkable plan)
  const clutter = lobbyClutter(C.model, C.seed), AG = accessGraph(C.model, { clutter }), W = crowdWorld(C.model, AG, { clutter });
  const people = occupancy(C.model, W, C.seed, NIGHT); t('people', t0);
  yield { p: 0.15, label: 'Calibrating the intervals' }; t0 = PERF();
  const K = calibrate({ mode: C.mode, seed: C.seed }); t('calibrate', t0);
  const ev = mainshock(C.mode, C.seed, C);
  yield { p: 0.3, label: 'Splitting the debris into pieces' }; t0 = PERF();
  const P = debrisPieces(C); t('pieces', t0); t0 = PERF();
  const SG = supportGraph(P, C); t('support', t0);
  yield { p: 0.45, label: 'Mapping where someone could be' }; t0 = PERF();
  const SV = survivorMap(C, people), trapped = trappedTruth(C, people); t('survivors', t0);
  yield { p: 0.6, label: 'Finding the way to each void' }; t0 = PERF();
  const sites = SV.sites.map((s) => ({ pocket: s.pocket, p: s.post, prior: s.prior, vol: s.vol, kind: s.kind, centre: s.centre, truthVoid: C.pockets.list[s.pocket].truth ?? -1, on: true }));
  const access = siteAccess(C, P, SG, sites); t('access', t0);
  yield { p: 0.75, label: 'Checking against the true debris' }; t0 = PERF();
  const TS = trueSupport(C, P); t('truthSupport', t0);
  // the closed loop's data point: did the block reach the damage state at this shaking?
  const fallen = C.post.parts.some((p) => p.state === 'fallen'), maxTilt = Math.max(...C.post.motions.map((T) => tiltOf(T.R) / DEG)), unsafeShare = C.truth.rooms.filter((r) => r.status === 'noentry').length / C.truth.rooms.length;
  const fr = fragility(ev, fallen || maxTilt >= 2 || unsafeShare >= 0.25);
  const D = { C, people, K, ev, P, SG, SV, trapped, sites, access, TS, fr, timings: tm, reached: { fallen, maxTilt, unsafeShare } };
  // the removal order for the rescue: only what blocks the lanes to the dig sites, the voids' openings and the entrances
  // (the clearance plan's must-clear cells), opened lane by lane in the dig order, with a rescan after every step. Each
  // site's way in is chosen once, from the first plan (the measured debris); its lifts then come from this plan.
  yield { p: 0.8, label: 'Planning the lifts on the lanes, rescanning after each' }; t0 = PERF();
  const S0 = plan(D, DEFAULTS), order = S0.sched.sites.filter(Boolean).sort((x, y) => x.rank - y.rank);
  const targets = order.map((o) => ({ kind: 'site', site: o.site, a: o.access.p, b: o.access.to, to: o.access.to, y0: Math.min(o.access.p[1], o.access.to[1]) - 0.5 }))
    .concat(entrancesOf(C).map((e, k) => ({ kind: 'entrance', entrance: k, a: e, b: e, to: e, y0: e[1] })));
  const gen = rescanSteps(C, { targets }); let r; while (!(r = gen.next()).done) yield { p: 0.8 + 0.15 * (r.value.p || 0), label: 'Planning the lifts on the lanes, rescanning after each' };
  D.WL = r.value; D.targets = targets; t('lifts', t0);
  // each site's way in, fixed, with the steps its lane needs; a lane the safe lifts cannot open gets an engineer's look
  // (and shoring) before the rest of it is lifted under supervision
  D.siteLane = D.sites.map((s, i) => { const o = S0.sched.sites[i]; if (!o) return null; const st = D.WL.targets.find((x) => x.kind === 'site' && x.site === i);
    return { ...o.access, steps: st ? st.stepList : [], leftVol: st ? st.leftVol : 0, stuck: !!(st && !st.open), open: !!(st && st.open), unverified: !!(st && st.trulyOpen && !st.plannerOpen),
      extraMin: (st && !st.open ? DIG.engineerMin : 0) + (st ? st.shorings * DIG.shorePauseMin : 0), shorings: st ? st.shorings : 0 }; });
  yield { p: 0.96, label: 'Drawing up the plan' }; t0 = PERF();
  D.plan = plan(D, DEFAULTS); t('plan', t0);
  tm.total = Object.values(tm).reduce((s, v) => s + v, 0);
  yield { p: 1, label: 'Ready' };
  return D;
}
export function decideSync(C, opts) { const g = decideCase(C, opts); for (;;) { const r = g.next(); if (r.done) return r.value; } }

// the removal plan seen through the dig sites still dug. The plan itself is not rerun when the commander checks a site
// by hand (it takes seconds): that site's lane stops counting, and what was lifted on it counts as lifted beside the lanes
export function activeLanes(WL, active) {
  const L = WL.lanes || { sites: 0, sitesOpen: 0, ents: 0, entsOpen: 0 }, base = { sites: L.sites, sitesOpen: L.sitesOpen, ents: L.ents, entsOpen: L.entsOpen, left: WL.left, must: WL.must, changed: false, planned: L.sites };
  const tg = (WL.targets || []).filter((t) => t.kind !== 'site' || active.has(t.site));
  if (!WL.onChunks || tg.length === (WL.targets || []).length) return base;
  const on = new Set(); for (const t of tg) for (const i of t.on) on.add(i);
  const left = { chunks: 0, vol: 0, unseen: 0, held: 0, locked: 0, unseenVol: 0, heldVol: 0, lockedVol: 0, list: [] }; let vol = 0, lifted = 0, other = 0;
  for (const c of WL.onChunks) { if (!on.has(c.i)) { if (c.scored && c.lifted) other += c.vol; continue; } if (c.scored) { vol += c.vol; if (c.lifted) lifted += c.vol; } if (!c.lifted) { left.chunks++; left.vol += c.vol; left[c.why]++; left[c.why + 'Vol'] += c.vol; } }
  const sites = tg.filter((t) => t.kind === 'site'), ents = tg.filter((t) => t.kind === 'entrance'), offLifted = WL.must.offLifted + other;
  return { sites: sites.length, sitesOpen: sites.filter((t) => t.open).length, ents: ents.length, entsOpen: ents.filter((t) => t.open).length, left,
    must: { vol, lifted, left: left.vol, offLifted, notNeeded: Math.max(0, WL.scoredVol - vol - offLifted) }, changed: true, planned: L.sites };
}
export function plan(D, settings = {}) {
  const S = { ...DEFAULTS, ...settings }, { C, K, ev, P, SG, sites, access, TS } = D, t0 = PERF();
  // statuses (with the commander's overrides) and the re-entry window
  const rooms = finalStatuses(C, K, S.overrides || {});
  const statusOf = (id) => rooms[id].status;
  const slowing = !!C.aftershocks[0].slowing;
  const RE = reentry(ev, { tolerance: S.tolerance, shiftH: S.shiftH, slowing });
  // a restricted room reopens in the window unless its ranges straddle a no-entry limit, too little of it was seen, or the
  // commander overrode an unsafe verdict (less cautious than the evidence): those need an inspector first
  const needsInspector = (r) => r.borderline || r.seen < 0.7 || (r.override && r.computed === 'unsafe');
  const reList = rooms.filter((r) => r.status === 'restricted' && !needsInspector(r)).map((r) => r.id);
  const inspectFirst = rooms.filter((r) => r.status === 'restricted' && needsInspector(r)).map((r) => r.id);
  const stiffWarn = rooms.filter((r) => r.pod && r.pod.m + K.qPod >= 0.15).map((r) => r.id);
  // dig order: sectors, then the teams' schedule (and the naive orders, for the score)
  const act = sites.map((s, i) => ({ ...s, on: !(S.siteOff || []).includes(i) }));
  const R = { ...DIG, liftRate: S.liftRate, teams: S.teams, startH: ev.handoverH };
  // the lanes' lifts come from the removal plan (decideCase); before it exists (the first plan), the measured estimate
  const accessUsed = D.siteLane ? access.map((ac, i) => (D.siteLane[i] ? { ...ac, cands: [D.siteLane[i]] } : ac)) : access;
  const sec = sectors(C, P, act, access, Math.max(1, S.teams));
  const rule = S.siteOrder && S.siteOrder.length ? 'manual' : 'smith';
  const sched = schedule(act, accessUsed, P, statusOf, sec, R, rule, S.siteOrder);
  const nearest = schedule(act, accessUsed, P, statusOf, sec, R, 'nearest'), biggest = schedule(act, accessUsed, P, statusOf, sec, R, 'biggest');
  const smithRef = rule === 'smith' ? sched : schedule(act, accessUsed, P, statusOf, sec, R, 'smith');
  // the removal order, planned with rescans (decideCase; it does not depend on the table's settings)
  const WL = D.WL || { steps: [], drops: [], shifts: 0, left: { vol: 0, chunks: 0, unseen: 0, held: 0, locked: 0, list: [] }, lifts: 0, handSteps: 0, relaxedSteps: 0, shorings: 0, scoredVol: 0, must: { vol: 0, lifted: 0, left: 0, offLifted: 0, notNeeded: 0 }, lanes: { sites: 0, sitesOpen: 0, ents: 0, entsOpen: 0 }, targets: [] };
  const LO = { steps: WL.steps }, LA = activeLanes(WL, new Set(sched.sites.filter(Boolean).map((o) => o.site)));
  const full = WL.steps, bad = WL.drops;
  // the clearance plan: lanes of the active dig sites and the entrances must be clear
  const lanes = sched.sites.filter(Boolean).map((o) => ({ a: o.access.p, b: o.access.to, site: o.site }));
  const CL = clearancePlan(C, P, lanes, entrancesOf(C), { truck: S.truck });
  const AL = rankedAlerts(C, D.SV, rooms, K);
  // scores against the truth
  const st = scoreStatuses(C, rooms);
  const rt = { ranked: reachTimes(D.trapped, act, sched), smith: reachTimes(D.trapped, act, smithRef), nearest: reachTimes(D.trapped, act, nearest), biggest: reachTimes(D.trapped, act, biggest) };
  const score = { ...st, trapped: D.trapped.length, reached: rt.ranked.reached, mean: rt.ranked.mean, meanNearest: rt.nearest.mean, meanBiggest: rt.biggest.mean, vsNearest: cmp3(rt.ranked.mean, rt.nearest.mean), vsBiggest: cmp3(rt.ranked.mean, rt.biggest.mean),
    unsafeLifts: bad.length, badLifts: bad, shiftLifts: WL.shifts, bigDrops: bad.filter((b) => b.vol >= 0.05).length, unseenDrops: bad.filter((b) => b.unseen).length, steps: WL.steps.length, liftLeft: LA.left.vol, liftTotal: WL.scoredVol, mustVol: LA.must.vol, mustLifted: LA.must.lifted, lanesOpen: LA.sitesOpen, lanes: LA.sites, entsOpen: LA.entsOpen, ents: LA.ents, mustLeft: CL.mustLeft, balance: CL.balance };
  const deb = C.debris, qd = K.qDeb;
  return { settings: S, rooms, statusOf, RE, reList, inspectFirst, stiffWarn, sites: act, sec, sched, nearest, biggest, rt, LO, lanes: LA, full, CL, AL, score,
    debris: { est: deb.estimate, lo: Math.max(deb.low, deb.estimate * (1 - qd)), hi: deb.estimate * (1 + qd), low7: deb.low, high7: deb.high, q: qd },
    ms: Math.round(PERF() - t0) };
}
