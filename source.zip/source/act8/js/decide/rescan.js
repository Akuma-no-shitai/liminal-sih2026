// The lifts for the rescue, planned as the work goes. During the rescue only what blocks the lanes to the dig sites, the
// voids' openings and the entrances has to move (the clearance plan's must-clear cells); the rest of the pile waits for
// heavy machinery afterwards. The lanes are opened one by one in the dig order, then the entrances. A plan made once from
// Act 7's scans cannot see inside the pile, so after every step the pile is rescanned (the anchor's tethered drone, or a
// drone hovering over the pile, simulated with Act 7's scan module, the same LiDAR, cast against the true debris still
// in place) and the next lift is planned on what is now exposed:
//   1. the rescan is carved into an occupancy grid of the pile (Act 7's ray carving, 0.12 m voxels): seen surfaces, seen
//      free space, unseen space; unseen space under a seen surface, inside the debris Act 7 measured, could hold debris
//      (the candidate voids themselves are known empty space);
//   2. the exposed surface is split into the pieces lying on top: each piece the crew can see on top is one piece (an
//      ideal split of the exposed surface: on site the crew sees where one lump ends);
//   3. what has to go for a lane: the pieces in its passage, and, transitively, the lumps holding them down;
//   4. a piece may be lifted only when the top of half its footprint was seen in the latest scan, nothing measured and no
//      unseen space that could hold debris lies above it (over its footprint, or higher than it within a 0.5 m margin),
//      and nothing the map takes for standing structure lies just over it (0.6 m); pieces over a candidate void are locked
//      until it is shored. Lumps that only hold each other down go top first (the one lying over the others more than they
//      lie over it), when nothing unnamed or unseen lies over it. If nothing qualifies: a closer look (the drone flies in
//      where it fits), then shoring, then the lane is left to an engineer's look. (A variant, off by default and measured
//      in the sweep, lets a margin wait give way.)
// Each step is played out against the truth: the pieces come out whole. A step is unsafe when a true chunk still in
// place is left with no support (nothing under it any more: no chunk, no ground, no standing structure); the chunk is
// then assumed to settle where it lands. Scoring uses the truth; the plan uses only the scans (and the split of the
// exposed surface into lumps, the one idealisation, stated).
import { makeGrid, rasterBox } from '../../../act7/js/building/voxel.js';
import { boxAABB, qToMat } from '../../../act7/js/building/geom.js';
import { makeScene, scan } from '../../../act7/js/pipe/scan.js';
import { makeObs, carve } from '../../../act7/js/pipe/occupancy.js';

export const RESCAN = { margin: 0.5, hover: 1.8, cone: 0.85, sideCone: 0.7, rays: 1000, firstRays: 1200, maxSteps: 500, relax: false, loops: true, looks: 2, shoringsPerLane: 3, roofReach: 5, hardReach: 5, pad: 4, seenTop: 0.5, hand: 0.05, patch: 1.25, big: 0.05 };
const I3 = { R: [1, 0, 0, 0, 1, 0, 0, 0, 1], t: [0, 0, 0] };
const PERF = () => (typeof performance !== 'undefined' ? performance.now() : Date.now());
const run = (gen) => { for (;;) { const r = gen.next(); if (r.done) return r.value; } };

export function rescanPlan(C, opts = {}) { return run(rescanSteps(C, opts)); }
export function* rescanSteps(C, opts = {}) {
  const T0 = PERF(), tm = { scan: 0, carve: 0, eval: 0 };
  const G = makeGrid(C.g), v = G.vox;
  // ---------------------------------------------------------------- the pile's own grid (aligned with Act 7's)
  let i0 = 1e9, j1 = 0, k0 = 1e9, i1 = -1, k1 = -1; const q = [0, 0, 0];
  for (let c = 0; c < G.N; c++) if (C.debrisGrid[c] || C.fillGrid[c] === 1) { G.ijk(c, q); if (q[0] < i0) i0 = q[0]; if (q[0] > i1) i1 = q[0]; if (q[1] > j1) j1 = q[1]; if (q[2] < k0) k0 = q[2]; if (q[2] > k1) k1 = q[2]; }
  const chunks = []; C.post.parts.forEach((p, idx) => { if (p.debris) chunks.push({ p, idx }); });
  for (const ch of chunks) { const bb = boxAABB(ch.p.box); i0 = Math.min(i0, Math.floor((bb[0] - G.x0) / v)); i1 = Math.max(i1, Math.floor((bb[3] - G.x0) / v)); k0 = Math.min(k0, Math.floor((bb[2] - G.z0) / v)); k1 = Math.max(k1, Math.floor((bb[5] - G.z0) / v)); j1 = Math.max(j1, Math.floor((bb[4] - G.y0) / v)); }
  if (i1 < 0) return empty(T0);
  const P = RESCAN.pad; i0 = Math.max(0, i0 - P); k0 = Math.max(0, k0 - P); i1 = Math.min(G.nx - 1, i1 + P); k1 = Math.min(G.nz - 1, k1 + P); j1 = Math.min(G.ny - 1, j1 + 10);
  const nx = i1 - i0 + 1, ny = j1 + 1, nz = k1 - k0 + 1;
  const g = makeGrid({ x0: G.x0 + i0 * v, y0: G.y0, z0: G.z0 + k0 * v, nx, ny, nz, vox: v }), SY = nx * nz, N = g.N;
  const full = (c) => { const i = c % nx, r = (c - i) / nx, k = r % nz, j = (r - k) / nz; return (i + i0) + G.nx * ((k + k0) + G.nz * j); };
  const jG = Math.ceil(-g.y0 / v);
  // measured, from Act 7: its debris (and fill) grown by two voxels (registration), the predicted standing structure,
  // and the candidate voids with the space just above them (locks)
  const D0 = new Uint8Array(N), SH = new Uint8Array(N), VU = new Uint8Array(N);
  for (let c = 0; c < N; c++) { const f = full(c); if (C.debrisGrid[f] || C.fillGrid[f] === 1) D0[c] = 1; if (C.Shat[f]) SH[c] = 1; }
  const SHd = SH.slice(); for (let c = 0; c < N; c++) { if (!SH[c]) continue; for (const d of [1, -1, nx, -nx, SY, -SY]) { const e = c + d; if (e >= 0 && e < N) SHd[e] = 1; } }
  const D0d = D0.slice(); for (let c = 0; c < N; c++) { if (!D0[c]) continue; const i = c % nx, k = ((c - i) / nx) % nz, j = Math.floor(c / SY);
    for (let dj = -2; dj <= 2; dj++) for (let dk = -2; dk <= 2; dk++) for (let di = -2; di <= 2; di++) { const a = i + di, b = k + dk, e = j + dj; if (a < 0 || b < 0 || e < 0 || a >= nx || b >= nz || e >= ny) continue; D0d[a + nx * (b + nz * e)] = 1; } }
  // the candidate voids themselves: unseen, but known empty space (what the lanes lead to), never 'could hold debris'
  const VOID = new Uint8Array(N);
  for (const pk of C.pockets.list) for (const f of pk.cells) { const i = f % G.nx - i0, r = Math.floor(f / G.nx), k = r % G.nz - k0, j = Math.floor(r / G.nz); if (i < 0 || k < 0 || i >= nx || k >= nz || j >= ny) continue; VOID[i + nx * (k + nz * j)] = 1; for (let s = 0; s <= RESCAN.roofReach && j + s < ny; s++) VU[i + nx * (k + nz * (j + s))] = 1; }
  yield { p: 0.05 };
  // ---------------------------------------------------------------- the truth: chunks and what holds them
  const tid = new Int32Array(N), solid = new Uint8Array(N);
  for (const p of C.post.parts) if (!p.debris && p.kind !== 'door') rasterBox(g, p.box, solid, 1, {});
  for (let c = 0; c < jG * SY; c++) solid[c] = 1;
  chunks.forEach((ch, i) => rasterBox(g, ch.p.box, tid, i + 1, { ymin: 0 }));
  const nC = chunks.length, size = new Int32Array(nC), cellsOf = chunks.map(() => []);
  for (let c = 0; c < N; c++) { const a = tid[c]; if (a) { size[a - 1]++; cellsOf[a - 1].push(c); } }
  const on = chunks.map(() => new Set()), base = new Uint8Array(nC);
  for (let c = SY; c < N; c++) { const a = tid[c]; if (!a) continue; const o = tid[c - SY]; if (o && o !== a) on[a - 1].add(o - 1); else if (!o && solid[c - SY]) base[a - 1] = 1; }
  const restsOn = chunks.map(() => []); on.forEach((s, a) => s.forEach((b) => restsOn[b].push(a)));
  const alive = new Uint8Array(nC), seenEver = new Uint8Array(nC);
  for (let i = 0; i < nC; i++) if (size[i]) alive[i] = 1;          // with no voxel of its own (inside others): not scored
  // a chunk with no voxel of its own lies inside or against another: it comes out with the one at its centre
  const extras = chunks.map(() => []);
  for (let i = 0; i < nC; i++) { if (size[i]) continue; const cc = chunks[i].p.box.c, c = g.cell(cc[0], Math.max(0.01, cc[1]), cc[2]); let o = c >= 0 ? tid[c] : 0;
    if (!o && c >= 0) for (const d of [SY, -SY, 1, -1, nx, -nx]) { const e = c + d; if (e >= 0 && e < N && tid[e]) { o = tid[e]; break; } }
    if (o) extras[o - 1].push(chunks[i].idx); }
  // each chunk's footprint (column -> its top there), highest voxel, lock, centre
  // (the footprint from a conservative raster: every voxel the box reaches into, so a thin tilted slab's surface voxels
  // belong to it; its own returns are then never read as something lying on it)
  const consCols = (box) => { const m = qToMat(box.q), bb = boxAABB(box), cols = new Map(), hv = v / 2;
    const ia = Math.max(0, Math.floor((bb[0] - g.x0) / v)), ib = Math.min(nx - 1, Math.floor((bb[3] - g.x0) / v)), ja = Math.max(jG, Math.floor((bb[1] - g.y0) / v)), jb2 = Math.min(ny - 1, Math.floor((bb[4] - g.y0) / v)), ka = Math.max(0, Math.floor((bb[2] - g.z0) / v)), kb = Math.min(nz - 1, Math.floor((bb[5] - g.z0) / v));
    const ex = [0, 1, 2].map((a) => box.h[a] + hv * (Math.abs(m[a]) + Math.abs(m[3 + a]) + Math.abs(m[6 + a])));
    for (let j = ja; j <= jb2; j++) for (let k = ka; k <= kb; k++) for (let i = ia; i <= ib; i++) { const d0 = g.x0 + (i + .5) * v - box.c[0], d1 = g.y0 + (j + .5) * v - box.c[1], d2 = g.z0 + (k + .5) * v - box.c[2]; let ins = true;
      for (let a = 0; a < 3 && ins; a++) { const e = m[a] * d0 + m[3 + a] * d1 + m[6 + a] * d2; if (Math.abs(e) > ex[a]) ins = false; }
      if (ins) { const col = i + nx * k; if (!cols.has(col) || cols.get(col) < j) cols.set(col, j); } }
    return cols; };
  const info = chunks.map((ch, i) => { const cols = size[i] ? consCols(ch.p.box) : new Map(); let jTop = -1, jBot = 1e9; for (const j of cols.values()) if (j > jTop) jTop = j; for (const c of cellsOf[i]) { const j = Math.floor(c / SY); if (j < jBot) jBot = j; }
    let locked = false; for (const c of cellsOf[i]) if (VU[c]) { locked = true; break; }
    let ia = 1e9, ib = -1, ka = 1e9, kb = -1; for (const col of cols.keys()) { const x = col % nx, z = (col - x) / nx; if (x < ia) ia = x; if (x > ib) ib = x; if (z < ka) ka = z; if (z > kb) kb = z; }
    const b = ch.p.box; return { cols, jTop, jBot, locked, vol: size[i] * g.V3, c: b.c, top: g.y0 + (jTop + 1) * v, bb: [ia, ib, ka, kb] }; });
  // ---------------------------------------------------------------- the simulated rescans
  const scene = makeScene(C.model, C.post.parts, { post: true }), SB = scene.B;
  const removeBox = (idx) => { SB[idx * 15] = 1e7; SB[idx * 15 + 1] = 1e7; SB[idx * 15 + 2] = 1e7; };
  const inside = (p, pad = 0.25) => { const ci = Math.floor((p[0] - scene.x0) / scene.cell), cj = Math.floor((p[1] - scene.y0) / scene.cell), ck = Math.floor((p[2] - scene.z0) / scene.cell);
    if (ci < 0 || cj < 0 || ck < 0 || ci >= scene.nx || cj >= scene.ny || ck >= scene.nz) return false; const cc = ci + scene.nx * (cj + scene.ny * ck);
    for (let s = scene.start[cc]; s < scene.start[cc + 1]; s++) { const o = scene.items[s] * 15; let ins = true;
      for (let a = 0; a < 3 && ins; a++) { const e = SB[o + 6 + a] * (p[0] - SB[o]) + SB[o + 9 + a] * (p[1] - SB[o + 1]) + SB[o + 12 + a] * (p[2] - SB[o + 2]); if (Math.abs(e) > SB[o + 3 + a] + pad) ins = false; }
      if (ins) return true; } return false; };
  const O = makeObs(g), S = new Uint8Array(N); let nScan = 0, nRays = 0;
  const classify = (b) => { for (let j = b[1]; j <= b[4]; j++) for (let k = b[2]; k <= b[5]; k++) for (let i = b[0]; i <= b[3]; i++) { const c = i + nx * (k + nz * j), h = O.hits[c], p = O.pass[c]; S[c] = h && h * 4 >= p ? 2 : p ? 1 : 0; if (S[c] === 2 && tid[c]) seenEver[tid[c] - 1] = 1; } };
  const doScan = (poses, rays, salt) => { if (!poses.length) return null; let t = PERF(); const out = run(scan(scene, poses, { rays: () => rays, seed: C.seed || 1, salt })); tm.scan += PERF() - t; t = PERF(); run(carve(g, O, out, I3)); tm.carve += PERF() - t; nScan++; nRays += out.n; return out; };
  // the first rescan: a drone over the pile (3 x 3), a ring around it at two heights, and into the gaps around the pile
  // where a drone fits (Act 7's own post-event poses nearby)
  let bx0 = 1e9, bx1 = -1e9, bz0 = 1e9, bz1 = -1e9, top = 0;
  for (let c = 0; c < N; c++) if (D0[c]) { g.centre(c, q); bx0 = Math.min(bx0, q[0]); bx1 = Math.max(bx1, q[0]); bz0 = Math.min(bz0, q[2]); bz1 = Math.max(bz1, q[2]); top = Math.max(top, q[1]); }
  if (bx1 < bx0) return empty(T0);
  const cxp = (bx0 + bx1) / 2, czp = (bz0 + bz1) / 2, rad = Math.hypot(bx1 - bx0, bz1 - bz0) / 2 + 1.5, first = [];
  for (const fx of [.2, .5, .8]) for (const fz of [.2, .5, .8]) first.push({ p: [bx0 + (bx1 - bx0) * fx, top + 2.0, bz0 + (bz1 - bz0) * fz], aim: [0, -1, 0], cone: 0.95 });
  for (let a = 0; a < 8; a++) for (const hy of [1.0, 2.4]) { const p = [cxp + Math.cos(a * Math.PI / 4) * rad, hy, czp + Math.sin(a * Math.PI / 4) * rad], d = [cxp - p[0], Math.min(top, 1.5) - p[1], czp - p[2]], L = Math.hypot(...d); first.push({ p, aim: d.map((x) => x / L), cone: RESCAN.sideCone }); }
  const flyIn = (pts, r, max) => { const out = []; for (const q0 of C.scans.post.poses) { const p = q0.p; if (p[1] < 0.4 || inside(p, 0.15)) continue; if (!pts.some((c) => Math.hypot(p[0] - c[0], p[2] - c[2]) < r && p[1] < c[1] + 3)) continue; out.push({ p }); } return out.slice(0, max); };
  doScan(first.filter((x) => x.p[1] > 0.4 && !inside(x.p)).concat(flyIn([[cxp, top, czp]], rad, 30)), RESCAN.firstRays, 'rescan0'); classify([0, 0, 0, nx - 1, ny - 1, nz - 1]);
  yield { p: 0.15 };
  // ---------------------------------------------------------------- the measured field each round
  const R = Math.ceil(RESCAN.margin / v), SHORED = new Uint8Array(N);
  const colTop = new Int16Array(SY), hiM = new Int16Array(SY), Wt = new Int16Array(SY), W = new Int16Array(SY), hardLo = new Uint32Array(SY), hardHi = new Uint32Array(SY);
  // (recomputed only where the last rescan changed something: the columns of its region, and the margin window around)
  const heldAt = (c) => { for (const d of [0, -SY, 1, -1]) { const e = c + d; if (e >= 0 && e < N && tid[e]) return !!base[tid[e] - 1]; } return true; };
  function colField(col) {
    let ct = -1; for (let j = ny - 1; j >= 0; j--) { const c = col + SY * j; if (S[c] === 2 || SH[c]) { ct = j; break; } } colTop[col] = ct;
    let hm = -1, lo = 0, hi = 0;
    for (let j = jG; j < ny; j++) { const c = col + SY * j;
      // (a shore holds what it props: a return in shored space counts only if it belongs to a lump the shore does not hold)
      if (S[c] === 2) { const held = SHORED[c] && heldAt(c); if (D0d[c] && !SHd[c]) { if (!held && j > hm) hm = j; } else if (!held) { if (j < 32) lo |= (1 << j); else if (j < 64) hi |= (1 << (j - 32)); } }
      else if (S[c] === 0 && D0d[c] && !SHd[c] && !VOID[c] && j < ct && j > hm) hm = j; }
    hiM[col] = hm; hardLo[col] = lo; hardHi[col] = hi; }
  function field(b = null) {
    const [a0, a1, c0, c1] = b || [0, nx - 1, 0, nz - 1];
    for (let k = c0; k <= c1; k++) for (let i = a0; i <= a1; i++) colField(i + nx * k);
    const wa0 = Math.max(0, a0 - R), wa1 = Math.min(nx - 1, a1 + R), wc0 = Math.max(0, c0 - R), wc1 = Math.min(nz - 1, c1 + R);
    for (let k = c0; k <= c1; k++) for (let i = wa0; i <= wa1; i++) { let m = -1; for (let d = -R; d <= R; d++) { const a = i + d; if (a >= 0 && a < nx) { const t2 = hiM[a + nx * k]; if (t2 > m) m = t2; } } Wt[i + nx * k] = m; }
    for (let k = wc0; k <= wc1; k++) for (let i = wa0; i <= wa1; i++) { let m = -1; for (let d = -R; d <= R; d++) { const bb = k + d; if (bb >= 0 && bb < nz) { const t2 = Wt[i + nx * bb]; if (t2 > m) m = t2; } } W[i + nx * k] = m; }
  }
  const hardOver = (col, jt) => { for (let j = jt + 1; j <= jt + RESCAN.hardReach; j++) { if (j < 32 ? (hardLo[col] >>> j) & 1 : j < 64 ? (hardHi[col] >>> (j - 32)) & 1 : 0) return true; } return false; };
  const stampJA = new Int32Array(SY); let stampJ = 0; let propped = null;
  function judge(i) {
    const f = info[i]; let seen = 0, own = false, margin = false, hard = false, unk = 0, ret = 0;
    for (const [col, jt] of f.cols) {
      const a = col + SY * jt, up = jt + 1 < ny ? S[a + SY] : 1, up2 = jt + 2 < ny ? S[a + 2 * SY] : 1;
      if (S[a] === 2 || up === 1 || (up === 2 && up2 === 1)) seen++;
      // something above its top here (the footprint is conservative: its own returns lie at or under jt): a return, or
      // unseen space under a roof
      // (a few columns of unseen space between beams are ignored: under 4 columns, 0.06 m2, holds no chunk)
      if (hiM[col] > jt) { if (S[col + SY * hiM[col]] === 2) ret++; else unk++; }
      if (W[col] > f.jTop + 1) margin = true;        // something higher than its highest point within the margin (checked below)
      if (!hard && hardOver(col, jt)) hard = true; }
    // (returns from under 3 columns, an object under 0.2 m across, are loose bits brushed off by hand before the lift)
    // (specks scale down for a small piece: a return over a quarter of its footprint is no speck)
    const nF = f.cols.size; if (unk >= Math.max(1, Math.min(4, Math.ceil(nF / 4))) || ret >= Math.max(1, Math.min(3, Math.ceil(nF / 4)))) own = true;
    // the margin: columns around the footprint (not in it) where something lies higher than its highest point; fewer than
    // 3 such columns of 12 cm are specks, ignored (as over its own footprint)
    if (margin) { stampJ++; let mc = 0; for (const col of f.cols.keys()) { const ci = col % nx, ck = (col - ci) / nx;
      for (let dk = -R; dk <= R && mc < 3; dk++) for (let di = -R; di <= R; di++) { const a2 = ci + di, b2 = ck + dk; if (a2 < 0 || b2 < 0 || a2 >= nx || b2 >= nz) continue; const cc = a2 + nx * b2; if (stampJA[cc] === stampJ || f.cols.has(cc)) continue; stampJA[cc] = stampJ; if (hiM[cc] > f.jTop + 1 && ++mc >= 3) break; }
      if (mc >= 3) break; } margin = mc >= 3; }
    return { seen: seen / Math.max(1, f.cols.size), own, margin, hard, specks: ret + unk, unk };
  }
  // ---------------------------------------------------------------- the targets: what must move during the rescue
  // opts.targets: [{ kind: 'site' | 'entrance', site, a, b, to, y0 }] in the order the plan opens them (the dig sites by
  // rank, then the entrances). The must-clear cells are the clearance plan's: 1 m plan cells whose centre lies within
  // 0.6 m + half a cell of a lane (or within 1.6 m of an entrance), plus the void's opening (0.8 m around the lane's end);
  // only debris in the passage (from 0.3 m below the lane's floor to 1.8 m above it, a stooping height: an assumption)
  // blocks the lane, and whatever holds that debris down has to go first. A chunk is on a lane when 0.01 m3 of it (or a
  // quarter of a smaller one) lies in the passage.
  const CELL = 1.0, ENT_R = 1.6, OPEN_R = 0.8, LANE_R = 0.6, PASSAGE = 1.8;
  const nearSeg = (x, z, a, b, r) => { const dx = b[0] - a[0], dz = b[2] - a[2], L2 = dx * dx + dz * dz; let t = L2 ? ((x - a[0]) * dx + (z - a[2]) * dz) / L2 : 0; t = Math.max(0, Math.min(1, t)); return Math.hypot(x - (a[0] + dx * t), z - (a[2] + dz * t)) < r; };
  const targets = (opts.targets || []).map((t) => {
    const col = new Uint8Array(SY);
    for (let k = 0; k < nz; k++) for (let i = 0; i < nx; i++) { const x = g.x0 + (i + .5) * v, z = g.z0 + (k + .5) * v, cx = (Math.floor(x / CELL) + .5) * CELL, cz = (Math.floor(z / CELL) + .5) * CELL;
      const inC = t.kind === 'site' ? nearSeg(cx, cz, t.a, t.b, LANE_R + CELL / 2) || Math.hypot(x - t.to[0], z - t.to[2]) < OPEN_R : Math.hypot(cx - t.a[0], cz - t.a[2]) < ENT_R;
      if (inC) col[i + nx * k] = 1; }
    const j0 = Math.max(jG, Math.floor((t.y0 - 0.3 - g.y0) / v)), j1 = Math.floor((t.y0 + PASSAGE - g.y0) / v), on = [];
    for (let i = 0; i < nC; i++) { if (!alive[i]) continue; let n = 0; for (const c of cellsOf[i]) { const j = Math.floor(c / SY); if (col[c % SY] && j >= j0 && j <= j1) n++; } if (n >= Math.max(1, Math.min(6, Math.ceil(size[i] / 4)))) on.push(i); }
    return { ...t, col, j0, j1, chunks: on, mustVol: on.reduce((s2, i) => s2 + info[i].vol, 0) };
  });
  const onAny = new Uint8Array(nC); for (const T of targets) for (const i of T.chunks) onAny[i] = 1;
  // ---------------------------------------------------------------- the loop: open each lane in turn
  const steps = [], Jc = new Map(), unlocked = new Uint8Array(nC); propped = new Uint8Array(nC); let shorings = 0, looks = 0, shoredChunks = 0, dirty = null, guard = 0;
  const refresh = () => { field(dirty); if (!dirty) Jc.clear(); else { const [a0, a1, c0, c1] = dirty, m2 = 2 * R + 1; for (const [i2] of Jc) { const bb = info[i2].bb; if (bb[1] >= a0 - m2 && bb[0] <= a1 + m2 && bb[3] >= c0 - m2 && bb[2] <= c1 + m2) Jc.delete(i2); } } dirty = null; };
  const J = (i) => { let jd = Jc.get(i); if (!jd) { jd = judge(i); Jc.set(i, jd); } return jd; };
  // the lumps holding a chunk down: the chunks the seen returns above it belong to (in its footprint, above its top
  // there; within the margin, above its highest point). Unseen space above it is no lump anyone can lift.
  const stampB = new Int32Array(SY); let stampBN = 0;
  const ownerAt = (c) => { for (const d of [0, -SY, 1, -1, nx, -nx]) { const e = c + d; if (e >= 0 && e < N && tid[e]) return tid[e] - 1; } return -1; };
  function blockersOf(i, jd) {
    // returns the lumps (with the number of 12 cm columns each covers) and how many columns hold something no one can
    // name: unseen space under a roof, or a return no lump owns
    const f = info[i], out = new Map(); let anon = 0;
    const scan = (col, jFrom, w) => { let named = false, unnamed = false; const seenHere = new Set();
      for (let j = jFrom; j < ny; j++) { const c = col + SY * j; if (!D0d[c] || SHd[c]) continue; if (S[c] === 2) { if (SHORED[c] && heldAt(c)) continue; const o = ownerAt(c); if (o >= 0 && o !== i && alive[o]) { if (!seenHere.has(o)) { seenHere.add(o); out.set(o, (out.get(o) || 0) + w); } named = true; } else if (o !== i) unnamed = true; } else if (S[c] === 0 && !VOID[c] && j < colTop[col]) unnamed = true; }
      if (unnamed && !named) anon++; };
    if (jd.own) for (const [col, jt] of f.cols) scan(col, jt + 1, 1);
    if (jd.margin) { stampBN++; for (const col of f.cols.keys()) { const ci = col % nx, ck = (col - ci) / nx;
      for (let dk = -R; dk <= R; dk++) for (let di = -R; di <= R; di++) { const a = ci + di, b = ck + dk; if (a < 0 || b < 0 || a >= nx || b >= nz) continue; const cc = a + nx * b; if (stampB[cc] === stampBN || f.cols.has(cc)) continue; stampB[cc] = stampBN;
        if (W[cc] <= f.jTop + 1 && hiM[cc] <= f.jTop + 1) continue; scan(cc, f.jTop + 2, 0.5); } } }
    out.anon = anon; return out;
  }
  // a lane as the rescans see it: the columns of its cells where measured debris, or unseen space under a roof inside
  // Act 7's debris region, lies above its floor (fewer than 4 such columns of 12 cm: specks, ignored)
  const blockedCols = (T) => { let n = 0; for (let c = 0; c < SY; c++) { if (!T.col[c] || hiM[c] < T.j0) continue; let hit = false;
    for (let j = T.j0; j <= Math.min(ny - 1, T.j1) && !hit; j++) { const e = c + SY * j; if (!D0d[e] || SHd[e] || SHORED[e] || VOID[e]) continue; if (S[e] === 2 || (S[e] === 0 && j < colTop[c])) hit = true; } if (hit) n++; } return n; };
  const status = targets.map((T) => ({ kind: T.kind, site: T.site, on: T.chunks, mustVol: T.mustVol, nOn: T.chunks.length, steps: [], shorings: 0, looks: 0, stuck: false, plannerOpen: false, trulyOpen: false, open: false, leftVol: 0, leftWhy: { unseen: 0, held: 0, locked: 0 } }));
  const rescanAround = (took, first, hand) => {
    let a0 = 1e9, a1 = -1, b0 = 1e9, b1 = -1, jb = 1e9; for (const ch of took) { for (const col of info[ch].cols.keys()) { const i = col % nx, k = (col - i) / nx; a0 = Math.min(a0, i); a1 = Math.max(a1, i); b0 = Math.min(b0, k); b1 = Math.max(b1, k); } jb = Math.min(jb, info[ch].jBot); }
    const bi0 = Math.max(0, a0 - R - 4), bi1 = Math.min(nx - 1, a1 + R + 4), bk0 = Math.max(0, b0 - R - 4), bk1 = Math.min(nz - 1, b1 + R + 4), bj0 = Math.max(0, jb - 2);
    for (let j = bj0; j < ny; j++) for (let k = bk0; k <= bk1; k++) for (let i = bi0; i <= bi1; i++) { const c = i + nx * (k + nz * j); O.pass[c] = 0; O.hits[c] = 0; O.rmin[c] = 255; }
    const tc = [info[first].c[0], info[first].top, info[first].c[2]], poses = [];
    for (const h of [RESCAN.hover, 1.2, 2.6]) { const p = [tc[0], tc[1] + h, tc[2]]; if (!inside(p)) { poses.push({ p, aim: [0, -1, 0], cone: RESCAN.cone }); break; } }
    const away = [tc[0] - cxp, tc[2] - czp]; const al = Math.hypot(...away) || 1;
    if (!hand || !poses.length) for (const [ax, az] of [[away[0] / al, away[1] / al], [1, 0], [-1, 0], [0, 1], [0, -1]]) { const p = [tc[0] + ax * 1.6, tc[1] + 0.9, tc[2] + az * 1.6]; if (p[1] > 0.4 && !inside(p)) { const d = [tc[0] - p[0], tc[1] - p[1], tc[2] - p[2]], L = Math.hypot(...d); poses.push({ p, aim: d.map((x) => x / L), cone: RESCAN.sideCone }); break; } }
    doScan(poses, RESCAN.rays, 'rescan' + steps.length); classify([bi0, bj0, bk0, bi1, ny - 1, bk1]); dirty = [bi0, bi1, bk0, bk1];
  };
  for (let ti = 0; ti < targets.length; ti++) {
    const T = targets[ti], st = status[ti], onSet = new Set(T.chunks); let tLooks = 0, tShor = 0;
    for (;;) {
      if (guard++ > RESCAN.maxSteps * 3 || steps.length >= RESCAN.maxSteps) { st.stuck = true; break; }
      let t = PERF(); refresh();
      const onLane = T.chunks.filter((i) => alive[i]); if (!onLane.length || onLane.reduce((s2, i) => s2 + info[i].vol, 0) < 0.01 && onLane.every((i) => J(i).seen < RESCAN.seenTop)) break;
      // what has to go: the chunks on the lane and, transitively, the lumps holding them down
      const need = new Set(onLane), queue = [...onLane];
      const BL = new Map();
      while (queue.length && need.size < 600) { const i = queue.pop(), jd = J(i); if (!jd.own && !jd.margin) continue; const bl = blockersOf(i, jd); BL.set(i, bl); for (const b of bl.keys()) if (!need.has(b)) { need.add(b); queue.push(b); } }
      const strict = [], relaxed = [];
      for (const i of need) { const jd = J(i), ok = jd.seen >= RESCAN.seenTop && !jd.hard && (!info[i].locked || unlocked[i]) && !jd.own;
        // (a margin wait gives way only to a piece with nothing at all over it, not even a speck: the variant, off)
        if (ok && !jd.margin) strict.push(i); else if (ok && !jd.specks) relaxed.push(i); }
      tm.eval += PERF() - t;
      let pool = strict, relax = false, loop = false;
      if (!pool.length && relaxed.length && (opts.relax ?? RESCAN.relax)) { pool = relaxed; relax = true; }
      // lumps that only hold each other down (pancaked slabs and the rubble wedged between them): when every lump holding a
      // group down belongs to the group, and nothing unnamed lies over a member, the member that lies over the others more
      // than they lie over it goes first (the crew sees which slab is on top)
      if (!pool.length && RESCAN.loops) {
        const ids = [...need], idx = new Map(ids.map((x, k) => [x, k])), nxt = ids.map((x) => [...(BL.get(x) || new Map()).keys()].map((b) => idx.get(b)).filter((b) => b != null));
        const comp = tarjan(ids.length, (k) => nxt[k]), extIn = new Set();
        ids.forEach((x, k) => { for (const b of nxt[k]) if (comp[b] !== comp[k]) extIn.add(comp[k]); });
        let best = -1, bs = -Infinity;
        ids.forEach((x, k) => { const jd = J(x), bl = BL.get(x); if (extIn.has(comp[k]) || !bl || jd.seen < RESCAN.seenTop || jd.hard || (info[x].locked && !unlocked[x]) || bl.anon >= 3 || (jd.own && jd.unk >= 4)) return;
          let over = 0, under = 0; for (const [b, w] of bl) under += w; ids.forEach((y, m) => { const bly = BL.get(y); if (bly && bly.has(x)) over += bly.get(x); });
          const sc = over - under; if (over > under && sc > bs) { bs = sc; best = x; } });
        if (best >= 0) { pool = [best]; loop = true; }
      }
      if (!pool.length) {
        const nl = [...need];
        // stuck: a closer look (the drone flies in where it fits, around what has to go), then shoring (the void, and
        // what the map takes for structure lying just over the lane), then the lane needs an engineer's look
        if (tLooks < RESCAN.looks) { tLooks++; looks++; st.looks++; const ps = flyIn(nl.map((i) => [info[i].c[0], info[i].top, info[i].c[2]]), 3, 24); if (ps.length) { doScan(ps, RESCAN.firstRays, 'look' + looks); classify([0, 0, 0, nx - 1, ny - 1, nz - 1]); dirty = null; continue; } }
        // shoring props the void, the structure lying just over the lane, and whatever no one can name lying on a lump
        // that has to go (structure, thin parts): returns only; unseen space stays unseen
        const anonHeld = (i) => { const bl = BL.get(i); return !!(bl && bl.anon >= 3); };
        if (tShor < RESCAN.shoringsPerLane && nl.some((i) => (info[i].locked && !unlocked[i]) || J(i).hard || anonHeld(i))) { tShor++; shorings++; st.shorings++; tLooks = Math.min(tLooks, RESCAN.looks - 1);
          const prop = (c) => { const ci = c % nx, ck = Math.floor(c / nx) % nz, cj = Math.floor(c / SY); for (let dj = -2; dj <= 2; dj++) for (let dk = -2; dk <= 2; dk++) for (let di = -2; di <= 2; di++) { const a2 = ci + di, b2 = ck + dk, e2 = cj + dj; if (a2 < 0 || b2 < 0 || e2 < 0 || a2 >= nx || b2 >= nz || e2 >= ny) continue; SHORED[a2 + nx * (b2 + nz * e2)] = 1; } const o = ownerAt(c); if (o >= 0 && alive[o] && !base[o]) { base[o] = 1; shoredChunks++; } };
          for (const i of nl) { if (info[i].locked) unlocked[i] = 1; const hardI = J(i).hard, anonI = anonHeld(i); if (!hardI && !anonI) continue; if (hardI) propped[i] = 1;
            for (const [col, jt] of info[i].cols) for (let j = jt + 1; j < ny; j++) { const c = col + SY * j; if (S[c] !== 2) continue;
              if (!(D0d[c] && !SHd[c])) { if (j <= jt + RESCAN.hardReach) prop(c); } else if (anonI) { const o = ownerAt(c); if (o < 0) prop(c); } }
            if (anonI) { const f = info[i]; stampBN++; for (const col of f.cols.keys()) { const ci = col % nx, ck = (col - ci) / nx; for (let dk = -R; dk <= R; dk++) for (let di = -R; di <= R; di++) { const a2 = ci + di, b2 = ck + dk; if (a2 < 0 || b2 < 0 || a2 >= nx || b2 >= nz) continue; const cc = a2 + nx * b2; if (stampB[cc] === stampBN || f.cols.has(cc)) continue; stampB[cc] = stampBN;
              for (let j = f.jTop + 2; j < ny; j++) { const c = cc + SY * j; if (S[c] === 2 && D0d[c] && !SHd[c] && ownerAt(c) < 0) prop(c); } } } } }
          dirty = null; continue; }
        st.stuck = true; break;
      }
      pool.sort((a, b) => info[b].jTop - info[a].jTop || info[b].vol - info[a].vol);
      const first = pool[0], took = [first];
      // hand-sized rubble free to go in the same patch is cleared in the same step
      const hand = info[first].vol < RESCAN.hand;
      if (hand && !relax && !loop) { const px = Math.floor((info[first].c[0] - G.x0) / RESCAN.patch), pz = Math.floor((info[first].c[2] - G.z0) / RESCAN.patch);
        for (const i of pool) { if (i === first || info[i].vol >= RESCAN.hand) continue; if (Math.floor((info[i].c[0] - G.x0) / RESCAN.patch) === px && Math.floor((info[i].c[2] - G.z0) / RESCAN.patch) === pz) took.push(i); } }
      // play it out against the truth
      for (const ch of took) { alive[ch] = 0; for (const c of cellsOf[ch]) tid[c] = 0; removeBox(chunks[ch].idx); for (const x of extras[ch]) removeBox(x); }
      let drop = null, shift = null;
      for (const y of took) for (const x of restsOn[y]) { if (!alive[x]) continue; const left = base[x] || [...on[x]].some((z) => alive[z]);
        const o = { load: x, vol: info[x].vol, unseen: !seenEver[x], c: info[x].c, by: y };
      if (opts.debug && !left) { const f = info[y], fx = info[x]; let ov = 0, ret = 0, inSH = 0, seenR = 0; for (const [col, jt] of f.cols) { if (!fx.cols.has(col)) continue; ov++; for (let j = jt + 1; j < ny; j++) { const c = col + SY * j; if (S[c] === 2) { seenR++; if (!(D0d[c] && !SHd[c])) inSH++; else if (j > jt + 1) ret++; break; } } }
        o.dbg = { nF: f.cols.size, overlap: ov, firstRetAbove: ret, inSH, seenR, jd: Jc.get(y) || null, hiMs: [...f.cols].slice(0, 6).map(([col, jt]) => [jt, hiM[col], colTop[col]]) }; }
        if (!left) { base[x] = 1; if (!drop || o.vol > drop.vol) drop = o; } else if (!shift || o.vol > shift.vol) shift = o; }
      const vol = took.reduce((s2, ch) => s2 + info[ch].vol, 0), onVol = took.reduce((s2, ch) => s2 + (onAny[ch] ? info[ch].vol : 0), 0);
      steps.push({ k: steps.length, target: ti, site: T.site ?? -1, chunks: took.map((ch) => chunks[ch].idx), took: took.slice(), hand, relaxed: relax, loop, vol, onVol, top: Math.max(...took.map((ch) => info[ch].top)), c: info[first].c, locked: took.some((ch) => info[ch].locked), shoring: shorings, drop, shift });
      st.steps.push(steps.length - 1);
      rescanAround(took, first, hand);
      if (steps.length % 6 === 0) yield { p: 0.15 + 0.85 * Math.min(1, (ti + steps.length / 60) / Math.max(1, targets.length + 1)) };
    }
    // the lane as the field sees it now; if debris is gone but the rescans cannot confirm it, one closer look at the lane
    // (truly open: under 0.01 m3 of true debris left in the passage, a brick)
    refresh(); st.trulyOpen = T.chunks.reduce((s2, i) => s2 + (alive[i] ? info[i].vol : 0), 0) < 0.01;
    if (st.trulyOpen && blockedCols(T) >= 4) { const pts = []; for (let c = 0; c < SY; c += 7) if (T.col[c] && hiM[c] >= T.j0) { const i = c % nx, k = (c - i) / nx; pts.push([g.x0 + (i + .5) * v, g.y0 + (hiM[c] + 1) * v, g.z0 + (k + .5) * v]); } const ps = flyIn(pts, 2.5, 16); if (ps.length) { doScan(ps, RESCAN.firstRays, 'verify' + ti); classify([0, 0, 0, nx - 1, ny - 1, nz - 1]); looks++; st.looks++; } dirty = null; refresh(); }
    st.plannerOpen = blockedCols(T) < 4; st.open = st.trulyOpen && st.plannerOpen;
    if (opts.debug) { st.dbg = []; const need = new Set(T.chunks.filter((i) => alive[i])), q = [...need]; while (q.length) { const i = q.pop(), jd = J(i); if (!jd.own && !jd.margin) continue; for (const b2 of blockersOf(i, jd).keys()) if (!need.has(b2)) { need.add(b2); q.push(b2); } }
      for (const i of need) { const jd = J(i); st.dbg.push({ i, on: onSet.has(i), vol: +info[i].vol.toFixed(3), top: +info[i].top.toFixed(2), seen: +jd.seen.toFixed(2), own: jd.own, margin: jd.margin, hard: jd.hard, locked: info[i].locked && !unlocked[i], nb: (jd.own || jd.margin) ? blockersOf(i, jd).size : 0, anon: (jd.own || jd.margin) ? Math.min(3, blockersOf(i, jd).anon) : 0, unk: jd.unk }); } }
    for (const i of T.chunks) { if (!alive[i]) continue; const jd = J(i), why = jd.seen < RESCAN.seenTop ? 'unseen' : jd.hard || (info[i].locked && !unlocked[i]) ? 'locked' : 'held'; st.leftVol += info[i].vol; st.leftWhy[why] += info[i].vol; }
  }
  // per target, the steps a team must do to open it: its own, and the earlier ones that took a chunk on it
  for (let ti = 0; ti < targets.length; ti++) { const st = status[ti], onSet = new Set(targets[ti].chunks), keys = new Set(st.steps);
    for (const s2 of steps) if (s2.target < ti && s2.took.some((ch) => onSet.has(ch))) keys.add(s2.k);
    st.stepList = [...keys].sort((a, b) => a - b).map((k) => ({ key: 's' + k, vol: steps[k].vol })); st.liftVol = st.stepList.reduce((s2, x) => s2 + x.vol, 0); }
  // what is left on the lanes and why; the rest of the pile is not needed for the rescue
  // (onChunks keeps each lane chunk's end state, so the table can count only the lanes of the sites still dug)
  const left = { chunks: 0, vol: 0, unseen: 0, held: 0, locked: 0, unseenVol: 0, heldVol: 0, lockedVol: 0, list: [] }, onChunks = [];
  for (let i = 0; i < nC; i++) { if (onAny[i]) onChunks.push({ i, vol: info[i].vol, scored: size[i] > 0, lifted: !alive[i], why: '' }); if (!alive[i] || !onAny[i]) continue; const jd = J(i); const why = jd.seen < RESCAN.seenTop ? 'unseen' : jd.hard || (info[i].locked && !unlocked[i]) ? 'locked' : 'held'; onChunks[onChunks.length - 1].why = why; left.chunks++; left.vol += info[i].vol; left[why]++; left[why + 'Vol'] += info[i].vol; if (info[i].vol >= RESCAN.big) left.list.push({ idx: chunks[i].idx, vol: info[i].vol, why }); }
  const scoredVol = info.reduce((s2, f, i) => s2 + (size[i] ? f.vol : 0), 0);
  let mustVol = 0, mustLifted = 0, offLifted = 0; for (let i = 0; i < nC; i++) { if (!size[i]) continue; if (onAny[i]) { mustVol += info[i].vol; if (!alive[i]) mustLifted += info[i].vol; } else if (!alive[i]) offLifted += info[i].vol; }
  const drops = steps.filter((s2) => s2.drop).map((s2) => ({ step: s2.k, ...s2.drop }));
  const sites = status.filter((x) => x.kind === 'site'), ents = status.filter((x) => x.kind === 'entrance');
  for (const s2 of steps) delete s2.took;
  const onLaneIdx = []; for (let i = 0; i < nC; i++) if (onAny[i]) onLaneIdx.push(chunks[i].idx);
  return { onLaneIdx, onChunks, steps, drops, shifts: steps.filter((s2) => s2.shift && !s2.drop).length, targets: status, left, shorings, shoredChunks, looks, rescans: nScan, rays: nRays, chunks: nC, scored: [...size].filter((x) => x > 0).length, scoredVol,
    must: { vol: mustVol, lifted: mustLifted, left: left.vol, offLifted, notNeeded: Math.max(0, scoredVol - mustVol - offLifted) },
    lanes: { sites: sites.length, sitesOpen: sites.filter((x) => x.open).length, ents: ents.length, entsOpen: ents.filter((x) => x.open).length, clearUnverified: status.filter((x) => x.trulyOpen && !x.plannerOpen).length, missed: status.filter((x) => x.plannerOpen && !x.trulyOpen).length, stuck: status.filter((x) => x.stuck).length },
    lifts: steps.filter((s2) => !s2.hand).length, handSteps: steps.filter((s2) => s2.hand).length, relaxedSteps: steps.filter((s2) => s2.relaxed).length, loopSteps: steps.filter((s2) => s2.loop).length,
    ms: Math.round(PERF() - T0), tm: Object.fromEntries(Object.entries(tm).map(([k, x]) => [k, Math.round(x)])) };
}
// strongly connected components (Tarjan 1972), iterative: comp[k] for each node; next(k) lists the nodes k waits for
function tarjan(n, next) {
  const index = new Int32Array(n).fill(-1), low = new Int32Array(n), onS = new Uint8Array(n), comp = new Int32Array(n).fill(-1), st = []; let idx = 0, nc = 0;
  for (let s0 = 0; s0 < n; s0++) { if (index[s0] >= 0) continue; const work = [[s0, next(s0), 0]]; index[s0] = low[s0] = idx++; st.push(s0); onS[s0] = 1;
    while (work.length) { const top = work[work.length - 1], v = top[0], nb = top[1];
      if (top[2] < nb.length) { const w = nb[top[2]++]; if (index[w] < 0) { index[w] = low[w] = idx++; st.push(w); onS[w] = 1; work.push([w, next(w), 0]); } else if (onS[w]) low[v] = Math.min(low[v], index[w]); continue; }
      work.pop(); if (work.length) { const u = work[work.length - 1][0]; low[u] = Math.min(low[u], low[v]); }
      if (low[v] === index[v]) { for (;;) { const w = st.pop(); onS[w] = 0; comp[w] = nc; if (w === v) break; } nc++; } } }
  return comp;
}
function empty(T0) { return { onLaneIdx: [], steps: [], drops: [], shifts: 0, targets: [], left: { chunks: 0, vol: 0, unseen: 0, held: 0, locked: 0, unseenVol: 0, heldVol: 0, lockedVol: 0, list: [] }, shorings: 0, shoredChunks: 0, looks: 0, rescans: 0, rays: 0, chunks: 0, scored: 0, scoredVol: 0,
  must: { vol: 0, lifted: 0, left: 0, offLifted: 0, notNeeded: 0 }, lanes: { sites: 0, sitesOpen: 0, ents: 0, entsOpen: 0, clearUnverified: 0, missed: 0, stuck: 0 }, lifts: 0, handSteps: 0, relaxedSteps: 0, ms: Math.round(PERF() - T0), tm: {} }; }
