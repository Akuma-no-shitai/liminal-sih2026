// The closed loop (roadmap): a lognormal fragility curve for this building type, P(damage state reached | shaking) =
// Phi(ln(PGA / theta) / beta), with an illustrative prior on the median theta (not from a published curve), updated by
// this event's simulated data point (the site's shaking and whether the block reached the damage state, from the
// truth). A grid posterior over theta; beta stays fixed. One building moves the curve a little; many events move it a lot.
export const FRAGILITY_PRIOR = { theta: 0.45, sdLnTheta: 0.45, beta: 0.6, state: 'extensive damage (rooms unsafe)' };
const erf = (x) => { const t = 1 / (1 + 0.3275911 * Math.abs(x)), y = 1 - (((((1.061405429 * t - 1.453152027) * t) + 1.421413741) * t - 0.284496736) * t + 0.254829592) * t * Math.exp(-x * x); return x >= 0 ? y : -y; };
export const Phi = (z) => 0.5 * (1 + erf(z / Math.SQRT2));
export function fragility(ev, reached, P = FRAGILITY_PRIOR) {
  // grid over ln(theta)
  const n = 241, lo = Math.log(P.theta) - 4 * P.sdLnTheta, hi = Math.log(P.theta) + 4 * P.sdLnTheta, lt = [], prior = [], post = [];
  let zp = 0, zq = 0;
  for (let i = 0; i < n; i++) { const l = lo + (hi - lo) * i / (n - 1); lt.push(l); const pr = Math.exp(-0.5 * ((l - Math.log(P.theta)) / P.sdLnTheta) ** 2); prior.push(pr); zp += pr;
    const p = Phi((Math.log(ev.pga) - l) / P.beta); const lik = reached ? p : 1 - p; post.push(pr * lik); zq += pr * lik; }
  for (let i = 0; i < n; i++) { prior[i] /= zp; post[i] /= zq; }
  // the posterior median of theta
  let acc = 0, med = P.theta; for (let i = 0; i < n; i++) { acc += post[i]; if (acc >= 0.5) { med = Math.exp(lt[i]); break; } }
  const curveOf = (dist) => { const out = []; for (let k = 0; k <= 40; k++) { const a = 0.02 + k * 0.03; let s = 0; for (let i = 0; i < n; i++) s += dist[i] * Phi((Math.log(a) - lt[i]) / P.beta); out.push([a, s]); } return out; };
  return { prior: P, reached, pga: ev.pga, thetaBefore: P.theta, thetaAfter: med, before: curveOf(prior), after: curveOf(post), pBefore: curveOf(prior).find((q) => q[0] >= ev.pga - 1e-9)?.[1] ?? null, pAfter: curveOf(post).find((q) => q[0] >= ev.pga - 1e-9)?.[1] ?? null };
}
