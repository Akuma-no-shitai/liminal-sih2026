// Act 8's lenses (Act 7's lens machinery): in the World lens the film decides which overlays show; any other lens pins
// its own until the viewer goes back to World. Layer names from Act 7's overlays (draft, pockets, heat, pods, truthRooms,
// voids) and Act 8's (the commander's marks). Every weight eases toward its goal, so switching never pops.
export const LENSES = [
  { id: 'world', name: 'World', key: '1', tip: 'The damaged building with whatever the film is deciding now' },
  { id: 'statuses', name: 'Statuses', key: '2', tip: 'The placards: safe, restricted, unsafe', layers: { placards: 1 }, dim: .4 },
  { id: 'evidence', name: 'Evidence', key: '3', tip: 'How far each room’s worst range sits from its limits', layers: { evidence: 1 }, dim: .45 },
  { id: 'reentry', name: 'Re-entry', key: '4', tip: 'Which rooms open in the re-entry window, which need an inspector first, which stay closed', layers: { reentry: 1, pods: 1 }, dim: .45 },
  { id: 'dig', name: 'Dig order', key: '5', tip: 'Dig flags, lanes, team sectors and the odds someone is in each void', layers: { flags: 1, lanes: 1, sectors: 1, odds: 1, pockets: .6 }, dim: .5 },
  { id: 'lifts', name: 'Lifts', key: '6', tip: 'The lifts for the rescue, planned with a rescan after every lift: first lifts light, last ones deep, pieces over a void darker; left on a lane amber; not needed for the rescue grey', layers: { pieces: 1 }, dim: .55 },
  { id: 'haul', name: 'Haul', key: '7', tip: 'The clearance plan: haul arcs to the loading bay and the skip, the cells that must be cleared', layers: { haul: 1, must: 1, dumps: 1 }, dim: .45 },
  { id: 'truth', name: 'Truth', key: 't', tip: 'The real statuses, the people who would truly be trapped, the loads a lift would drop', layers: { truthRooms: 1, voids: 1, trapped: 1, trueLoads: 1, flags: .5 }, dim: .55 },
];
export const LAYERS7 = ['draft', 'pockets', 'heat', 'pods', 'truthRooms', 'voids', 'packets'];
export const LAYERS = [...LAYERS7, 'placards', 'evidence', 'reentry', 'flags', 'lanes', 'sectors', 'odds', 'pieces', 'support', 'haul', 'must', 'dumps', 'trapped', 'trueLoads', 'alerts'];
export function createLenses() {
  let cur = 'world';
  const W = {}; for (const l of LAYERS) W[l] = 0;
  const S = { dim: 0 };
  return {
    W, S,
    get current() { return cur; },
    set(id) { if (LENSES.some((l) => l.id === id)) cur = id; },
    update(dt, film = {}) {
      const L = LENSES.find((l) => l.id === cur); const k = 1 - Math.exp(-dt * 5);
      for (const name of LAYERS) { const goal = cur === 'world' ? (film[name] || 0) : (L.layers[name] || 0); W[name] += (goal - W[name]) * k; if (Math.abs(W[name] - goal) < .003) W[name] = goal; }
      const dg = cur === 'world' ? (film.dim || 0) : L.dim; S.dim += (dg - S.dim) * k; if (Math.abs(S.dim - dg) < .003) S.dim = dg;
    },
  };
}
