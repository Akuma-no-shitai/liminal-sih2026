// Act 8's overlays: the commander's marks on the clay diorama. Placards on the rooms (safe, restricted, unsafe), the
// evidence margin, the re-entry state, dig flags with their lanes and the team sectors, the debris pieces with the
// support graph and the lift order, the haul arcs to the dumps and the must-clear cells, and (Truth lens) the people who
// would truly be trapped and the loads a lift would drop. Built lazily from the case and the plan; weights eased by the
// lenses; the floor cutaway is Act 7's clipping plane (shared).
import * as THREE from 'three';
import { createLines as createLines0, createGlows as createGlows0 } from '../../../act7/js/engine/lines.js';
import { roomQuads } from '../../../act7/js/engine/layers.js';
import { floorTop } from '../../../act7/js/building/building.js';

const C3 = (h) => new THREE.Color(h), lin = (c) => [c.r, c.g, c.b];
const tA = (T, x, y, z) => { const R = T.R; return [R[0] * x + R[1] * y + R[2] * z + T.t[0], R[3] * x + R[4] * y + R[5] * z + T.t[1], R[6] * x + R[7] * y + R[8] * z + T.t[2]]; };
export const STATUS7 = { safe: 'safe', restricted: 'caution', unsafe: 'noentry' };
export const LAYERS8 = ['placards', 'evidence', 'reentry', 'flags', 'lanes', 'sectors', 'odds', 'pieces', 'support', 'haul', 'must', 'dumps', 'trapped', 'trueLoads', 'alerts'];

function quadMesh(quads, clip, { depthTest = true } = {}) {
  const n = quads.length, pos = new Float32Array(Math.max(1, n) * 12), col = new Float32Array(Math.max(1, n) * 16), idx = new Uint32Array(Math.max(1, n) * 6);
  quads.forEach((q, i) => { for (let k = 0; k < 4; k++) { pos.set(q.p[k], i * 12 + k * 3); col.set([q.c.r, q.c.g, q.c.b, (q.a ?? 1) * (q.hatch ? -1 : 1)], i * 16 + k * 4); } idx.set([i * 4, i * 4 + 1, i * 4 + 2, i * 4, i * 4 + 2, i * 4 + 3], i * 6); });
  const g = new THREE.BufferGeometry(); g.setAttribute('position', new THREE.BufferAttribute(pos, 3)); g.setAttribute('qc', new THREE.BufferAttribute(col, 4)); g.setIndex(new THREE.BufferAttribute(idx, 1)); g.setDrawRange(0, n * 6);
  const m = new THREE.ShaderMaterial({ transparent: true, depthWrite: false, depthTest, side: THREE.DoubleSide, clipping: true, clippingPlanes: [clip], uniforms: { alpha: { value: 0 } },
    vertexShader: `attribute vec4 qc; varying vec4 vC; varying vec3 vW;
      #include <clipping_planes_pars_vertex>
      void main(){ vC = qc; vec4 w = modelMatrix * vec4(position, 1.); vW = w.xyz; vec4 mvPosition = viewMatrix * w; gl_Position = projectionMatrix * mvPosition;
      #include <clipping_planes_vertex>
      }`,
    fragmentShader: `uniform float alpha; varying vec4 vC; varying vec3 vW;
      #include <clipping_planes_pars_fragment>
      void main(){
        #include <clipping_planes_fragment>
        float a = abs(vC.a) * alpha; if (vC.a < 0.) { float s = step(.5, fract((vW.x + vW.z) * 2.2)); a *= .3 + .7 * s; }
        gl_FragColor = vec4(vC.rgb, a); }` });
  const mesh = new THREE.Mesh(g, m); mesh.renderOrder = 7; mesh.frustumCulled = false; return mesh;
}
// a room's tile, through its storey's measured motion
function roomTile(C, id, lift = 0.08, inset = 0.14) { const room = C.model.rooms[id], T = C.storeys[room.storey].T, y = room.y0 + lift; return [[room.x0 + inset, y, room.z0 + inset], [room.x1 - inset, y, room.z0 + inset], [room.x1 - inset, y, room.z1 - inset], [room.x0 + inset, y, room.z1 - inset]].map((q) => tA(T, ...q)); }
export function createLayers8(scene, C, D, world, { theme, clip, getPlan, sectorColors }) {
  const TH = theme, dd = TH.data, PAL = { safe: C3(dd.safe), caution: C3(dd.caution), danger: C3(dd.noentry), haze: C3(dd.unseen), teal: C3(dd.swarm), lav: C3(dd.empty), rose: C3(dd.added), apr: C3(dd.mid), paper: C3(dd.paper), hot: C3(dd.hot) };
  const SECT = (sectorColors || [dd.swarm, dd.mid, dd.empty, dd.added]).map(C3);
  const createGlows = (cap, o = {}) => createGlows0(cap, dd.additive || o.additive === false ? o : { ...o, additive: false, premul: true });
  const createLines = (cap, o = {}) => createLines0(cap, { ...(dd.additive || !o.additive ? o : { ...o, additive: false, premul: true }), packetColor: dd.linePacket });
  const root = new THREE.Group(); root.name = 'layers8'; scene.add(root);
  const L = {}, disposers = [], lineObjs = [];
  const add = (o, dispose) => { root.add(o); disposers.push(dispose); return o; };
  const P = () => getPlan();
  const pieceBox = new THREE.BoxGeometry(1, 1, 1); disposers.push(() => pieceBox.dispose());
  const get = {
    placards() { const plan = P(); const m = quadMesh(roomQuads(C, (id) => STATUS7[plan.rooms[id].status]), clip); return add(m, () => { m.geometry.dispose(); m.material.dispose(); }); },
    // evidence: how far the worst range sits from its limits (clear of the safe limit, near or past it, over no-entry)
    evidence() { const plan = P(); const q = plan.rooms.map((r) => { let k = 1; for (const e of r.ev) { const v = e.verdict === 'over' ? -1 : e.verdict === 'straddles' ? -.6 : e.verdict === 'between' ? -.2 : Math.min(1, (e.safe - e.hi) / Math.max(1e-6, e.safe)); k = Math.min(k, v); } if (r.gone) k = -1;
      const c = k <= -.9 ? PAL.danger : k < 0 ? PAL.caution.clone().lerp(PAL.danger, Math.min(1, -k)) : PAL.caution.clone().lerp(PAL.safe, Math.min(1, k * 2.5)); return { p: roomTile(C, r.id), c, a: .7, hatch: r.seen < .7 }; });
      const m = quadMesh(q, clip); return add(m, () => { m.geometry.dispose(); m.material.dispose(); }); },
    reentry() { const plan = P(); const re = new Set(plan.reList), ins = new Set(plan.inspectFirst);
      const q = plan.rooms.map((r) => ({ p: roomTile(C, r.id), c: r.status === 'unsafe' ? PAL.danger : re.has(r.id) ? PAL.teal : ins.has(r.id) ? PAL.caution : PAL.safe, a: r.status === 'safe' ? .35 : .7, hatch: ins.has(r.id) || r.status === 'unsafe' }));
      const m = quadMesh(q, clip); return add(m, () => { m.geometry.dispose(); m.material.dispose(); }); },
    flags() { const plan = P(); const grp = new THREE.Group(); const pole = new THREE.CylinderGeometry(.025, .025, 1.6, 6), flag = new THREE.BufferGeometry(); flag.setAttribute('position', new THREE.BufferAttribute(new Float32Array([0, 0, 0, .55, -.18, 0, 0, -.36, 0]), 3)); flag.computeVertexNormals();
      const mp = new THREE.MeshBasicMaterial({ color: PAL.paper, transparent: true, clippingPlanes: [clip] }); const mats = [];
      plan.sched.sites.forEach((o, i) => { if (!o) return; const pk = C.pockets.list[plan.sites[i].pocket], top = pk.centre[1] + 0.9; const pm = new THREE.Mesh(pole, mp); pm.position.set(pk.centre[0], top + .8, pk.centre[2]);
        const fm = new THREE.MeshBasicMaterial({ color: SECT[o.team % SECT.length], side: THREE.DoubleSide, transparent: true, clippingPlanes: [clip] }); mats.push(fm); const f = new THREE.Mesh(flag, fm); f.position.set(pk.centre[0], top + 1.6, pk.centre[2]); grp.add(pm, f); });
      grp.userData.tops = plan.sched.sites.map((o, i) => (o ? [C.pockets.list[plan.sites[i].pocket].centre[0], C.pockets.list[plan.sites[i].pocket].centre[1] + 2.75, C.pockets.list[plan.sites[i].pocket].centre[2]] : null));
      return add(grp, () => { pole.dispose(); flag.dispose(); mp.dispose(); mats.forEach((m) => m.dispose()); }); },
    lanes() { const plan = P(); const ln = createLines(256, { width: 3, additive: false, dash: .45 }); ln.begin();
      plan.sched.sites.forEach((o) => { if (!o) return; const a = o.access.p, b = o.access.to, c = lin(SECT[o.team % SECT.length]), Lh = Math.hypot(b[0] - a[0], b[1] - a[1], b[2] - a[2]); ln.seg(a[0], a[1] + .1, a[2], b[0], b[1] + .1, b[2], ...c, .95, .95, 0, Lh); });
      ln.end(); lineObjs.push(ln); return add(ln.mesh, () => ln.dispose()); },
    sectors() { const plan = P(); const y0 = floorTop(plan.siteLevel ?? 0) + 0.06, top = new Map(plan.CL.cells.map((c) => [`${Math.floor(c.x)},${Math.floor(c.z)}`, c.top]));
      const q = plan.sec.cells.map((c) => { const t = top.get(`${Math.floor(c.x)},${Math.floor(c.z)}`), y = Math.max(y0, t != null && t < y0 + 2.6 ? t + .1 : y0); return { p: [[c.x - .48, y, c.z - .48], [c.x + .48, y, c.z - .48], [c.x + .48, y, c.z + .48], [c.x - .48, y, c.z + .48]], c: SECT[c.s % SECT.length], a: .38 }; });
      const m = quadMesh(q, clip); return add(m, () => { m.geometry.dispose(); m.material.dispose(); }); },
    odds() { const g = createGlows(32, { minPx: 10 }); g.begin(); g.end(); g.mesh.userData.api = g; return add(g.mesh, () => g.dispose()); },
    // the lifts for the rescue: the true debris chunks, solid clay tinted on a sequential ramp by the step that takes them
    // (first steps light, last ones deep), the ones over a void darker; left on a lane (a closer look) amber; not needed
    // for the rescue grey; thin edges.
    // While this layer is up, Act 7's own debris is hidden (these boxes are the same chunks).
    pieces() { const W = D.WL, parts = C.post.parts, idx = [], stepOf = new Map(); W.steps.forEach((s2, k) => s2.chunks.forEach((ci) => stepOf.set(ci, k)));
      parts.forEach((p, i) => { if (p.debris) idx.push(i); }); const n = idx.length, nS = Math.max(1, W.steps.length);
      const mat = new THREE.MeshStandardMaterial({ color: 0xffffff, roughness: .92, metalness: 0, clippingPlanes: [clip] });
      const im = new THREE.InstancedMesh(pieceBox, mat, Math.max(1, n)); im.count = n; im.frustumCulled = false; im.castShadow = true; im.receiveShadow = true;
      const M = new THREE.Matrix4(), Qn = new THREE.Quaternion(), Pv = new THREE.Vector3(), Sv = new THREE.Vector3(), col = new THREE.Color();
      const white = new THREE.Color(1, 1, 1), light = PAL.apr.clone().lerp(white, .45), deep = PAL.teal.clone().lerp(PAL.lav, .25).multiplyScalar(.42), left = PAL.haze.clone().lerp(white, .4).multiplyScalar(.72);
      const place = (i, up, sc) => { const b = parts[idx[i]].box; Pv.set(b.c[0], b.c[1] + up, b.c[2]); Qn.set(b.q[0], b.q[1], b.q[2], b.q[3]); Sv.set((b.h[0] * 2 + .02) * sc, (b.h[1] * 2 + .02) * sc, (b.h[2] * 2 + .02) * sc); M.compose(Pv, Qn, Sv); im.setMatrixAt(i, M); };
      const onLane = new Set(W.onLaneIdx || []), closer = PAL.caution.clone().lerp(white, .1).multiplyScalar(.8);
      idx.forEach((pi, i) => { place(i, 0, 1); const k = stepOf.get(pi); if (k == null) col.copy(onLane.has(pi) ? closer : left); else { { const u = k / Math.max(1, nS - 1); if (u < .5) col.copy(light).lerp(PAL.teal, u * 2); else col.copy(PAL.teal).lerp(deep, (u - .5) * 2); } if (W.steps[k].locked) col.multiplyScalar(.62); } im.setColorAt(i, col); });
      im.instanceMatrix.needsUpdate = true; if (im.instanceColor) im.instanceColor.needsUpdate = true;
      // thin edges, rebuilt when the number of steps done changes
      const E = [[0, 1], [1, 3], [3, 2], [2, 0], [4, 5], [5, 7], [7, 6], [6, 4], [0, 4], [1, 5], [2, 6], [3, 7]], corner = new THREE.Vector3();
      const eg = new THREE.BufferGeometry(), epos = new Float32Array(n * 24 * 3); eg.setAttribute('position', new THREE.BufferAttribute(epos, 3));
      const em = new THREE.LineBasicMaterial({ color: PAL.paper.clone().multiplyScalar(.35), transparent: true, opacity: .55, clippingPlanes: [clip] }), edges = new THREE.LineSegments(eg, em); edges.frustumCulled = false;
      let lastK = -2; const edgesFor = (k, cur, up) => { let o = 0; idx.forEach((pi, i) => { const st = stepOf.get(pi); if (st != null && st < k) return; const b = parts[pi].box; Qn.set(b.q[0], b.q[1], b.q[2], b.q[3]); const lift = st === k ? up : 0;
          const cs = []; for (let a = 0; a < 8; a++) { corner.set((a & 1 ? 1 : -1) * (b.h[0] + .011), (a & 2 ? 1 : -1) * (b.h[1] + .011), (a & 4 ? 1 : -1) * (b.h[2] + .011)).applyQuaternion(Qn); cs.push([corner.x + b.c[0], corner.y + b.c[1] + lift, corner.z + b.c[2]]); }
          for (const [a2, b2] of E) { epos.set(cs[a2], o); epos.set(cs[b2], o + 3); o += 6; } });
        eg.setDrawRange(0, o / 3); eg.attributes.position.needsUpdate = true; eg.computeBoundingSphere(); };
      edgesFor(0, 0, 0);
      const grp = new THREE.Group(); grp.add(im, edges);
      // the lift animation: the chunks of the first k steps are off, step k rises and shrinks
      grp.userData.lift = (plan, k, frac) => { idx.forEach((pi, i) => { const st = stepOf.get(pi); if (st != null && st < k) place(i, 0, 0); else if (st === k) place(i, frac * 1.2, 1 - frac * .6); else place(i, 0, 1); }); im.instanceMatrix.needsUpdate = true;
        if (k !== lastK || frac > 0) { edgesFor(k, k, frac * 1.2); lastK = k; } };
      grp.userData.recolor = () => {};
      const deb = (world.inst || []).filter((it) => it.mat === 'debris' || it.mat === 'debrisSlab');
      grp.setOpacity = (w) => { grp.visible = w > .01; mat.transparent = w < .98; mat.opacity = w; mat.depthWrite = w > .5; em.opacity = .55 * w; for (const it of deb) it.mesh.visible = w < .5; };
      return add(grp, () => { mat.dispose(); im.dispose(); eg.dispose(); em.dispose(); for (const it of deb) it.mesh.visible = true; }); },
    support() { const ln = createLines(Math.max(16, D.SG.rests.reduce((a, r) => a + r.length, 0) + 8), { width: 1.6, additive: false }); ln.begin(); const hz = lin(PAL.paper), dg = lin(PAL.danger);
      D.SG.rests.forEach((bs, a) => { const A = D.P.pieces[a].c; for (const b of bs) { const B = D.P.pieces[b].c; ln.seg(A[0], A[1], A[2], B[0], B[1], B[2], ...(D.SG.locked[b] ? dg : hz), D.SG.locked[b] ? .7 : .4); } });
      ln.end(); lineObjs.push(ln); return add(ln.mesh, () => ln.dispose()); },
    haul() { const plan = P(), arcs = plan.CL.arcs.slice(0, 160), grp = new THREE.Group(), objs = [];
      const bins = [[0, .35, 1.6], [.35, 1.2, 3.2], [1.2, 1e9, 5.5]];
      for (const [lo, hi, w] of bins) { const sel = arcs.filter((a) => a.loose >= lo && a.loose < hi); if (!sel.length) continue; const ln = createLines(sel.length * 14 + 4, { width: w, additive: true, packets: true }); ln.begin();
        for (const a of sel) { const c = lin(a.j === 0 ? PAL.apr : PAL.lav); let u = 0, prev = a.from; const top = Math.max(a.from[1], 0) + 2.2 + Math.hypot(a.to[0] - a.from[0], a.to[2] - a.from[2]) * .12;
          for (let k = 1; k <= 12; k++) { const t = k / 12, x = a.from[0] + (a.to[0] - a.from[0]) * t, z = a.from[2] + (a.to[2] - a.from[2]) * t, y = a.from[1] * (1 - t) + .3 * t + Math.sin(t * Math.PI) * top; const Lh = Math.hypot(x - prev[0], y - prev[1], z - prev[2]); ln.seg(prev[0], prev[1], prev[2], x, y, z, ...c, .85, .85, u, u + Lh, 1); u += Lh; prev = [x, y, z]; } }
        ln.end(); lineObjs.push(ln); objs.push(ln); grp.add(ln.mesh); }
      return add(grp, () => objs.forEach((o) => o.dispose())); },
    must() { const plan = P(); const q = plan.CL.cells.map((c) => { const y = (c.top ?? 0) + .1; return { p: [[c.x - .46, y, c.z - .46], [c.x + .46, y, c.z - .46], [c.x + .46, y, c.z + .46], [c.x - .46, y, c.z + .46]], c: c.must ? PAL.danger : PAL.haze, a: c.must ? .6 : .2, hatch: c.must }; });
      const m = quadMesh(q, clip); return add(m, () => { m.geometry.dispose(); m.material.dispose(); }); },
    dumps() { const g = createGlows(8, { minPx: 14 }); g.begin(); for (const d of P().CL.dumps) { g.add(d.p[0], .4, d.p[2], ...lin(d.id === 'bay' ? PAL.apr : PAL.lav), 1, 1.6); g.add(d.p[0], .4, d.p[2], 1, 1, 1, .8, .4); } g.end(); return add(g.mesh, () => g.dispose()); },
    trapped() { const g = createGlows(Math.max(4, D.trapped.length * 2 + 2), { minPx: 9 }); g.begin(); for (const t of D.trapped) { g.add(t.pos[0], t.pos[1], t.pos[2], ...lin(PAL.rose), 1, .7); g.add(t.pos[0], t.pos[1], t.pos[2], 1, 1, 1, .8, .22); } g.end(); return add(g.mesh, () => g.dispose()); },
    // the loads a step would drop (truth): a line from the chunk taken to the chunk left with nothing under it
    trueLoads() { const W = D.WL, parts = C.post.parts, chunks = parts.filter((p) => p.debris); const ln = createLines(Math.max(8, W.drops.length + 4), { width: 3, additive: false }); ln.begin(); const dg = lin(PAL.danger);
      for (const d of W.drops) { const st = W.steps[d.step]; const A = st.c, B = d.c; ln.seg(A[0], A[1], A[2], B[0], B[1], B[2], ...dg, .95); } ln.end(); lineObjs.push(ln); return add(ln.mesh, () => ln.dispose()); },
    alerts() { const plan = P(); const g = createGlows(Math.max(8, plan.AL.list.length * 2 + 2), { minPx: 10 }); g.begin(); for (const a of plan.AL.list) { const c = a.cls === 'void' ? PAL.lav : a.kind === 'fire' ? PAL.hot : a.kind === 'water' ? PAL.teal : PAL.caution; g.add(a.pos[0], a.pos[1], a.pos[2], ...lin(c), 1, .9); } g.end(); return add(g.mesh, () => g.dispose()); },
  };
  const ensure = (name) => { if (!(name in L)) { try { L[name] = get[name](); } catch (e) { console.warn('[act8] layer', name, e); L[name] = null; } } return L[name]; };
  const setW = (name, w) => {
    if (w <= .005 && !L[name]) return; const o = ensure(name); if (!o) return;
    try {
      if (o.setOpacity) { o.setOpacity(w); return; }
      if (o.isPoints) { o.visible = w > .005; return; }
      if (o.isMesh && o.material && o.material.uniforms) { o.visible = w > .005; if (o.material.uniforms.alpha) o.material.uniforms.alpha.value = w; if (o.material.uniforms.op) o.material.uniforms.op.value = w; return; }
      o.visible = w > .005; o.traverse((x) => { if (x.material && x.material.uniforms) { if (x.material.uniforms.op) x.material.uniforms.op.value = w; } else if (x.material && 'opacity' in x.material && x !== o) { x.material.opacity = w; } });
    } catch (e) { if (!setW.warned) { setW.warned = true; console.warn('[act8] layer weight', name, e); } }
  };
  return {
    root, L, ensure, setW, get: (n) => L[n], lineObjs,
    // an outline round one room (the room in focus), or none
    focus(id) { if (id === this._fid) return; this._fid = id; if (this._fl) { root.remove(this._fl.mesh); this._fl.dispose(); this._fl = null; } if (id == null || id < 0) return;
      const ln = createLines(8, { width: 3.2, additive: false }); ln.begin(); const t = roomTile(C, id, 0.12, 0.06), c = lin(PAL.paper); for (let k = 0; k < 4; k++) { const a = t[k], b = t[(k + 1) % 4]; ln.seg(a[0], a[1], a[2], b[0], b[1], b[2], ...c, .95); } ln.end(); ln.mesh.renderOrder = 9; root.add(ln.mesh); this._fl = ln; lineObjs.push(ln); },
    // the odds glows: [{ p: [x, y, z], v: odds }] at each void, sized by its odds now (the passes replaying)
    setOdds(list) { const m = ensure('odds'); if (!m) return; const g = m.userData.api; g.begin(); for (const q of list) { g.add(q.p[0], q.p[1], q.p[2], ...lin(PAL.lav), .35 + .65 * q.v, .4 + 1.6 * q.v); g.add(q.p[0], q.p[1], q.p[2], 1, 1, 1, .7 * q.v, .25); } g.end(); },
    reset(name) { const o = L[name]; if (!o) { delete L[name]; return; } root.remove(o);
      for (let i = lineObjs.length - 1; i >= 0; i--) { let inside = false; o.traverse((x) => { if (x === lineObjs[i].mesh) inside = true; }); if (inside) lineObjs.splice(i, 1); } o.traverse((x) => { if (x.geometry && x.geometry !== pieceBox) x.geometry.dispose(); if (x.material) x.material.dispose(); }); delete L[name]; },
    resetPlan() { for (const n of ['placards', 'evidence', 'reentry', 'flags', 'lanes', 'sectors', 'haul', 'must', 'dumps', 'trueLoads', 'alerts']) this.reset(n); },
    syncClip() { const n = clip.normal; for (const l of lineObjs) if (l.U && l.U.clip) l.U.clip.value.set(n.x, n.y, n.z, clip.constant); },
    dispose() { for (const d of disposers) { try { d(); } catch (e) { /* ignore */ } } scene.remove(root); },
  };
}
