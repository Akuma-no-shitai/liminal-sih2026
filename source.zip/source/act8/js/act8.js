// LIMINAL Act 8: the commander's table (After: decide). Act 7 measured a collapsed block; here the same collapse (same
// failure mode and seed: the same building, damage and numbers) becomes the plan an incident commander acts on: final
// room statuses with conformal intervals, a re-entry window from an aftershock model, a ranked dig order split into team
// sectors, a safe removal order, a minimum-clearance plan and the brief, every decision scored against the simulation's
// truth; then the lessons go back to the next Before plan. Played as a directed film, then an open commander's table.
//   createAct8(host, opts) -> { play, pause, resume, destroy, mode(id, {seed}), seek, chapter, speed, lens, director(),
//     takeCamera(), table(on), showPicker(), openRoom(id), override(id, status), state, renderNow(settle), frameStats() }
//   opts: { base: 'assets/', onExit(), onLab(id), onNext(), onBefore(), music, mode, seed, case, theme, quality, onReady(), test }
import * as THREE from 'three';
import { GLTFLoader } from 'three/addons/loaders/GLTFLoader.js';
import { MeshoptDecoder } from 'three/addons/libs/meshopt_decoder.module.js';
import { CSS as CSS7 } from '../../act7/js/style.js';
import { CSS2 } from '../../act2/js/style.js';
import { CSS8 } from './style.js';
import { createScore } from '../../act7/js/score.js';
import { createRenderer } from '../../act7/js/engine/renderer.js';
import { createDirector } from '../../act7/js/engine/director.js';
import { buildWorld } from '../../act7/js/engine/world.js';
import { createLayers } from '../../act7/js/engine/layers.js';
import { createLabels } from '../../act7/js/ui/labels.js';
import { createCaptions } from '../../act7/js/ui/captions.js';
import { createModeMenu, createSimOverlay, MODE_META, MODE_IDS } from '../../act7/js/ui/picker.js';
import { getTheme, applyTheme } from '../../act7/js/theme.js';
import { runCase } from '../../act7/js/pipe/run.js';
import { createLenses, LENSES, LAYERS, LAYERS7 } from './engine/lenses.js';
import { createLayers8, LAYERS8, STATUS7 } from './engine/layers.js';
import { createDock } from './ui/dock.js';
import { createCards } from './ui/cards.js';
import { createPicker, createBoard, createReport, createAssumptions, createRoomCard, boardHtml } from './ui/overlay.js';
import { createTable } from './ui/table.js';
import { buildScript, overrideDiff, RoomName } from './film/script.js';
import { decideCase, plan as replan, DEFAULTS } from './decide/run.js';
import { clockText } from './decide/reentry.js';
import { ORDER, placardWord } from './decide/status.js';

const ICON = {
  note: '<svg viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.4" stroke-linecap="round" stroke-linejoin="round"><path d="M6 12V3.5l7-1.5v8.5"/><circle cx="4.3" cy="12" r="1.7"/><circle cx="11.3" cy="10.5" r="1.7"/></svg>',
  back: '<svg viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"><path d="M10 3 5 8l5 5"/></svg>',
};
const LENS_CARDS = { statuses: ['interval', 'threshold'], evidence: ['room', 'interval'], reentry: ['aftershock', 'stiffness'], dig: ['odds', 'digorder', 'sectors'], lifts: ['lifts'], haul: ['clearance'], truth: ['score'] };
const pct = (v) => `${Math.round(v * 100)} %`;
const odds = (v) => (v < 0.005 ? 'under 1 %' : pct(v));
const LOCK_SVG = '<svg viewBox="0 0 16 16" width="12" height="12" aria-hidden="true"><rect x="3" y="7" width="10" height="7" rx="1.5" fill="currentColor"/><path d="M5.2 7V5.2a2.8 2.8 0 0 1 5.6 0V7" fill="none" stroke="currentColor" stroke-width="1.6"/></svg>';
const hrs = (h) => (h < 1 ? `${Math.round(h * 60)} min` : `${h.toFixed(1)} h`);
const ease = (x) => { x = Math.max(0, Math.min(1, x)); return x * x * (3 - 2 * x); };
const tA = (T, x, y, z) => { const R = T.R; return [R[0] * x + R[1] * y + R[2] * z + T.t[0], R[3] * x + R[4] * y + R[5] * z + T.t[1], R[6] * x + R[7] * y + R[8] * z + T.t[2]]; };
const DRAFT7 = { safe: 'safe', caution: 'caution', noentry: 'noentry', unseen: 'unseen' };
const EVW = { tilt: 'lean', sag: 'sag', crush: 'crushed', debris: 'debris', gone: 'wall fallen', cracks: 'cracks', dmg: 'wall damage', stiff: 'stiffness' };

export async function createAct8(host, opts = {}) {
  const base = opts.base || 'assets/';
  for (const [id, css] of [['a7css', CSS7], ['a2css', CSS2], ['a8css', CSS8]]) if (!document.getElementById(id)) { const st = document.createElement('style'); st.id = id; st.textContent = css; document.head.appendChild(st); }
  const PH = matchMedia('(max-width: 760px)').matches, TEST = !!opts.test, THEME = getTheme(opts.theme || 'worklight');
  const h = (tag, cls, html) => { const e = document.createElement(tag); if (cls) e.className = cls; if (html != null) e.innerHTML = html; return e; };
  const exitAct = () => { if (opts.onExit) opts.onExit(); else if (history.length > 1) history.back(); };
  const onLab = (id) => { if (id === 'assumptions') { if (D) asm.show(D); return; } if (id === 'before') { if (opts.onBefore) opts.onBefore(); return; } if (opts.onLab) opts.onLab(id); else toast(`Opens the swarm lab: ${id}`); };

  // ------------------------------------------------------------------ DOM
  const root = h('div', 'a7 a8 nomis' + (TEST ? ' test' : '')); root.tabIndex = -1; root.setAttribute('role', 'region'); root.setAttribute('aria-label', 'Act 8: the commander’s table');
  const view = h('div', 'a7view'), canvas = h('canvas'), labelsEl = h('div', 'a7labels');
  view.append(canvas, labelsEl);
  const top = h('header', 'a7top', `<div class="a7brand">LIMINAL <i>Act 8, the commander’s table</i></div><div class="a7mis"></div><span class="sp"></span>
    <button class="a7pill a7mus" type="button" data-a="music" aria-pressed="false" title="Music">${ICON.note}<span class="hideS">Music</span></button>
    <button class="a7pill" type="button" data-a="exit">${ICON.back}<span class="hideS">Back to the story</span><span class="showS">Back</span></button>`);
  const chip = h('div', 'a7chipsim', '<i></i><span class="l">Simulated collapse and simulated occupants; advice only, the commander decides</span><span class="s">Simulated; advice only, the commander decides</span>');
  const clockEl = h('div', 'a7clock a8clock', '<div class="k">Simulated mainshock</div><div class="t"></div><div class="s"></div>');
  const floorsEl = h('div', 'a7floors'), togEl = h('div', 'a7tog'), capEl = h('div', 'a7cap'); capEl.setAttribute('aria-live', 'polite');
  const cardsEl = h('div', 'a7cards'), dockEl = h('div', 'a7dock'), boardEl = h('div'), roomEl = h('div'), tableEl = h('div'), repEl = h('div'), asmEl = h('div'), simEl = h('div'), pickEl = h('div'), toastEl = h('div', 'a7toast');
  root.append(view, top, chip, clockEl, floorsEl, togEl, capEl, cardsEl, boardEl, tableEl, dockEl, roomEl, repEl, asmEl, simEl, pickEl, toastEl);
  applyTheme(root, THEME); host.appendChild(root);
  let toastT = 0; function toast(s) { toastEl.textContent = s; toastEl.classList.add('on'); clearTimeout(toastT); toastT = setTimeout(() => toastEl.classList.remove('on'), 2600); }

  // ------------------------------------------------------------------ engine
  const R = createRenderer(canvas, { phone: PH || opts.quality === 'low', preserve: TEST }); R.renderer.setClearColor(THEME.sky.fog, 1);
  const onLost = (e) => { e.preventDefault(); toast('The graphics were reset. One moment…'); }; canvas.addEventListener('webglcontextlost', onLost);
  const { scene, camera, renderer } = R;
  let props = null;
  try { const gl = new GLTFLoader(); gl.setMeshoptDecoder(MeshoptDecoder); props = (await gl.loadAsync(base + 'props.glb')).scene; } catch (e) { props = null; console.warn('[act8] props.glb did not load; using simple shapes', e && e.message); }
  const lenses = createLenses(), labels = createLabels(labelsEl);
  const director = createDirector(camera, canvas, { phone: PH, onTake: (u) => dock.setUser(u), onCut: (lv) => { dirLevel = lv; if (userLevel === undefined) applyCut(lv); } });

  // ------------------------------------------------------------------ UI
  const captions = createCaptions(capEl);
  const cards = createCards(cardsEl, { onLab, phone: PH, theme: THEME, before: !!opts.onBefore });
  const idleEl = h('div', 'idle', '<h4>The commander’s table</h4><p>The cards for each step appear here as the film reaches it.</p>'); cardsEl.appendChild(idleEl);
  const simOv = createSimOverlay(simEl);
  const dock = createDock(dockEl, {
    onPlay: () => (playing ? pause() : play()), onSpeed: (s) => setSpeed(s), onSeek: (p) => { if (sbOn) setTable(false); seek(p); }, onLens: (l) => setLens(l),
    onDirector: () => { if (director.user) director.giveBack(); else toast('The director has the camera. Drag the view to take over.'); },
    onShock: () => setTable(!sbOn), onStep: (d) => seek(P + d), onScrub: (on) => { scrubbing = on; },
  });
  const picker = createPicker(pickEl, { onPick: (id) => start(id), onSurprise: () => surprise(), theme: THEME });
  const menu = createModeMenu(top.querySelector('.a7mis'), { onPick: (id) => start(id), onSurprise: () => surprise() });
  const board = createBoard(boardEl);
  const report = createReport(repEl, { hasNext: !!opts.onNext, onNext: () => opts.onNext && opts.onNext(), onReplay: () => { report.hide(); seek(0); play(); }, onTable: () => { report.hide(); setTable(true); }, onBack: exitAct });
  const asm = createAssumptions(asmEl, { onClose: () => asm.hide() });
  const roomCard = createRoomCard(roomEl, { onClose: () => closeRoom(), onOverride: (id, s) => doOverride(id, s) });
  const table = createTable(tableEl, { onChange: (s) => tableChange(s), onClose: () => setTable(false), onBoard: () => { boardPinned = !boardPinned; if (boardPinned) closeRoom(); wantRender = true; }, onAssumptions: () => { if (D) asm.show(D); }, onReset: () => tableReset() });
  top.querySelector('[data-a="exit"]').addEventListener('click', exitAct);
  const music = createScore('aftermath'), musB = top.querySelector('[data-a="music"]');
  const paintMus = () => { musB.classList.toggle('on', music.on); musB.setAttribute('aria-pressed', String(music.on)); const t = musB.querySelector('span'); if (t) t.textContent = music.on ? 'Music on' : 'Music off'; };
  musB.addEventListener('click', () => { music.on ? music.stop() : music.start(); paintMus(); });
  if (opts.music) { try { music.start(); } catch (e) { /* needs a gesture */ } } paintMus();
  floorsEl.innerHTML = '<div class="k">Floors</div>' + [['auto', 'Auto'], ['all', 'All'], ['3', '3rd'], ['2', '2nd'], ['1', '1st'], ['0', 'Gnd']].map(([v, t]) => `<button type="button" data-f="${v}" class="${v === 'auto' ? 'auto' : ''}" title="${v === 'auto' ? 'The director chooses' : v === 'all' ? 'The whole building' : 'Hide every floor above this one'}">${t}</button>`).join('');
  floorsEl.addEventListener('click', (e) => { const b = e.target.closest('[data-f]'); if (!b) return; const v = b.dataset.f; userLevel = v === 'auto' ? undefined : v === 'all' ? null : +v; applyCut(userLevel === undefined ? dirLevel : userLevel); paintFloors(); wantRender = true; });
  const paintFloors = () => floorsEl.querySelectorAll('[data-f]').forEach((b) => { const v = b.dataset.f; const on = v === 'auto' ? userLevel === undefined : userLevel !== undefined && (v === 'all' ? userLevel === null : +v === userLevel); b.classList.toggle('on', on); });
  // lens extras: the Statuses lens can show Act 7's drafts next to the final placards
  const tog = { draft: false };
  function paintTog() { const L = lenses.current; let html = ''; if (L === 'statuses') html = `<span class="k">Show</span><button type="button" data-t="final" class="${!tog.draft ? 'on' : ''}">Final placards</button><button type="button" data-t="draft" class="${tog.draft ? 'on' : ''}">Act 7’s drafts</button>`; togEl.innerHTML = html; togEl.classList.toggle('on', !!html); }
  togEl.addEventListener('click', (e) => { const b = e.target.closest('[data-t]'); if (!b) return; tog.draft = b.dataset.t === 'draft'; paintTog(); wantRender = true; });

  // ------------------------------------------------------------------ state
  let C = null, D = null, script = null, world = null, layers = null, layers8 = null, modeId = null, seedUsed = 0;
  let P = 0, playing = false, speed = 1, dur = 1, chapters = [], scrubbing = false, readyFired = false, loading = false, loadId = 0, destroyed = false;
  let userLevel, dirLevel = null, cutLevel = null, segIdx = -1, curShot = null, sbOn = false, boardPinned = false, planShown = null, roomFocus = 0;
  let tableSet = null, tablePlan = null, lastCapText = null;
  let lastRender = -1e9, wantRender = false;
  function setSpeed(s) { speed = s; dock.setSpeed(s); }
  function setLens(id) { const was = lenses.current; lenses.set(id); dock.setLens(lenses.current); paintTog(); wantRender = true; if (roomCard.shown && D) openRoom(roomCard.room);
    if (sbOn && script && was !== lenses.current) { const s2 = SB_SHOT(); if (!curShot || s2.level !== curShot.level) { curShot = s2; director.setShot(curShot, { cut: true }); } } }
  setSpeed(1); setLens('world'); paintFloors();
  function applyCut(lv) { cutLevel = lv; if (world) world.cutaway(lv); if (layers) layers.setCut(lv); }
  const chapterAt = (p) => { const i = chapters.findIndex((c) => p >= c.p0 && p < c.p1); return i < 0 ? chapters.length - 1 : i; };
  const segAt = (p) => { if (!script) return -1; for (let i = 0; i < script.segs.length; i++) if (p < script.segs[i].t1) return i; return script.segs.length - 1; };
  // the plan in force at this moment: the table's, the film's override (in the brief), or the computed one
  const planNow = () => { if (!D) return null; if (sbOn && tablePlan) return tablePlan; if (script && lenses.current === 'world') { const sg = script.segs[segAt(P)]; if (sg && sg.override && P >= sg.t0) return script.plan2; } return D.plan; };

  // ------------------------------------------------------------------ the pipeline (Act 7's, then the decision engine), in slices
  const cache = new Map();
  const newSeed = () => (TEST ? 7 : ((Math.random() * 1e6) | 0) + 1);
  const nextTask = (ms = 0) => new Promise((r) => setTimeout(r, ms));
  let loadInfo = null;
  async function pump(gen, my, onP, budget) {
    let lastP = -1, lastT = performance.now(); const t0 = performance.now(); let work = 0;
    for (;;) { const s0 = performance.now(); let r;
      do { r = gen.next(); if (r.done) break; if (r.value.p > lastP + 1e-4) { lastP = r.value.p; lastT = performance.now(); onP(r.value); } } while (performance.now() - s0 < budget);
      work += performance.now() - s0;
      if (r.done) return { v: r.value, work };
      if (performance.now() - lastT > 20000) throw new Error('the pipeline stopped making progress');
      if (performance.now() - t0 > 180000) throw new Error('the pipeline took too long');
      await nextTask(0); if (my !== loadId || destroyed) return null;
    }
  }
  function surprise() { const id = MODE_IDS[Math.floor(Math.random() * MODE_IDS.length)]; start(id, { seed: newSeed() }); }
  function showPicker() { pause(); report.hide(); closeRoom(); if (sbOn) setTable(false); if (loading) { loadId++; loading = false; simOv.hide(); } picker.show(); root.classList.add('nomis'); }
  async function start(id, { seed, caseObj } = {}) {
    if (!MODE_META[id]) id = MODE_IDS[0];
    const my = ++loadId; picker.hide(); report.hide(); closeRoom(); if (sbOn) setTable(false); pause(); menu.set(id); modeId = id;
    root.classList.add('nomis'); loading = true; cards.clear(); captions.set(null, '', ''); board.hide();
    const want = seed ?? opts.seed ?? newSeed();
    simOv.show(MODE_META[id], 'Deciding'); simOv.progress(.01, 'Starting');
    await nextTask(TEST ? 0 : 40); if (my !== loadId) return;
    const T0 = performance.now();
    for (let attempt = 0; attempt < 2; attempt++) {
      const s = attempt ? newSeed() + 1 : want;
      try {
        const key = `${id}:${s}`; let c = caseObj && attempt === 0 ? caseObj : null, w7 = 0, d = cache.get(key);
        if (!d) {
          if (!c) { const o = await pump(runCase(id, s), my, (v) => simOv.progress(.02 + v.p * .8, v.label), TEST ? 400 : 45); if (!o || my !== loadId) return; c = o.v; w7 = o.work; }
          const o2 = await pump(decideCase(c), my, (v) => simOv.progress(.83 + v.p * .15, v.label), TEST ? 400 : 45); if (!o2 || my !== loadId) return;
          d = o2.v; d.work = { act7: Math.round(w7), act8: Math.round(o2.work) }; cache.set(key, d); while (cache.size > 2) cache.delete(cache.keys().next().value);
        }
        simOv.progress(.99, 'Building the scene'); await nextTask(0); if (my !== loadId) return;
        const tb = performance.now(); begin(d);
        loadInfo = { mode: id, seed: s, act7: d.work.act7, act8: d.work.act8, scene: Math.round(performance.now() - tb), total: Math.round(performance.now() - T0), timings: d.timings, given: !!caseObj };
        await nextTask(TEST ? 0 : 200); if (my !== loadId) return;
        simOv.hide(); root.classList.remove('nomis'); loading = false; P = 0; segIdx = -1; director.giveBack(); play();
        if (!readyFired) { readyFired = true; if (opts.onReady) opts.onReady(); }
        return;
      } catch (e) { console.warn(`[act8] ${id} (seed ${s}) failed:`, e); cache.delete(`${id}:${s}`); dropScene(); if (my !== loadId) return; caseObj = null; }
    }
    loading = false;
    simOv.fail('This collapse could not be decided here. Another seed usually works.', () => start(id, { seed: newSeed() + 2 }), () => { simOv.hide(); showPicker(); });
  }
  function dropScene() {
    if (layers8) { try { layers8.dispose(); } catch (e) { /* ignore */ } layers8 = null; }
    if (layers) { try { layers.dispose(); } catch (e) { /* ignore */ } layers = null; }
    if (world) { scene.remove(world.group); try { world.dispose(); } catch (e) { /* ignore */ } world = null; }
    C = null; D = null; script = null; chapters = []; tablePlan = null; tableSet = null; planShown = null;
  }
  function begin(d) {
    dropScene(); D = d; C = d.C; P = 0; playing = false; seedUsed = C.seed; segIdx = -1; curShot = null; userLevel = undefined; paintFloors(); boardPinned = false;
    for (const n of LAYERS) lenses.W[n] = 0; lenses.S.dim = 0;
    idleEl.querySelector('h4').textContent = MODE_META[C.mode].title; idleEl.querySelector('p').textContent = 'The cards for each step appear here as the film reaches it.';
    world = buildWorld(C, props, { phone: PH, theme: THEME }); scene.add(world.group);
    R.setSky(world.sky, world.bounds, THEME.look);
    layers = createLayers(scene, C, world, { statusOf: (id) => DRAFT7[C.roomsAfter[id].status], theme: THEME });
    script = buildScript(C, D); chapters = script.chapters; dur = script.dur;
    D.plan.siteLevel = script.siteLevel; script.plan2.siteLevel = script.siteLevel; roomFocus = script.exampleRoom;
    layers8 = createLayers8(scene, C, D, world, { theme: THEME, clip: layers.clip, getPlan: () => planShown || D.plan });
    dock.setTimeline(chapters, dur, script.events); cards.setCase(D); dock.setSandbox && dock.setSandbox(false);
    director.setScene(new THREE.Vector3(0, 5, 0), 15); director.setShot(script.segs[0].shot, { cut: true });
    applyCut(null); wantRender = true; paintTog();
    const sl = world.padSlots; for (let i = 0; i < 8; i++) world.setDrone(i, sl[i][0], sl[i][1], sl[i][2], i * .8, true); world.drones.instanceMatrix.needsUpdate = true;
    clockEl.querySelector('.t').textContent = `M ${D.ev.Mm.toFixed(1)} at ${clockText(D.ev, 0).replace(/^day \d+, /, '')}`; clockEl.querySelector('.s').textContent = `the board at ${clockText(D.ev, D.ev.handoverH).replace(/^day \d+, /, '')}, ${D.ev.handoverH.toFixed(1)} h later`;
    if (!TEST) { const order = ['placards', 'evidence', 'reentry', 'flags', 'lanes', 'sectors', 'pieces', 'haul', 'must']; const my = loadId, L8 = layers8;
      const step = () => { if (destroyed || my !== loadId || L8 !== layers8 || !order.length) return; const n = order.shift(); try { L8.ensure(n); L8.setW(n, lenses.W[n] || 0); } catch (e) { /* on demand */ } setTimeout(step, 80); }; setTimeout(step, 500); }
  }
  function play() { if (!D) return; if (sbOn) setTable(false); if (P >= dur - .05) { P = 0; segIdx = -1; } report.hide(); playing = true; if (held) { held = false; running = true; last = performance.now(); } }
  function pause() { playing = false; }
  function seek(p) { if (!D) return; P = Math.max(0, Math.min(dur, p)); segIdx = -1; if (P < dur - .1) report.hide(); wantRender = true; }
  let held = false, heldPlaying = false, heldMusic = false;
  function hold() { if (held) { playing = false; return; } held = true; heldPlaying = playing; playing = false; running = false; heldMusic = music.on; if (music.on) { music.stop(); paintMus(); } }
  function unhold() { running = true; last = performance.now(); if (!held) return; held = false; if (heldPlaying) play(); if (heldMusic) { music.start(); paintMus(); } }

  // ------------------------------------------------------------------ the commander's table
  // the table's still camera: cut at the statuses' floor, or at the dig sites' floor for the lenses about digging and debris
  const SB_SHOT = (lens = lenses.current) => { const lv = !script ? 1 : ['dig', 'lifts', 'haul'].includes(lens) ? script.siteLevel : script.statusLevel; return { kind: 'cutaway', level: lv, target: [0, lv * 3 + 1, 0], az: script ? script.anchors.damageAz * .4 : .3, el: 1.0, dist: PH ? 33 : 31, drift: 0 }; };
  function setTable(on) {
    if (!D) return; if (on === sbOn) return; sbOn = on; root.classList.toggle('sbx', on); dock.setSandbox && dock.setSandbox(on);
    if (on) { pause(); report.hide(); if (!tableSet) { tableSet = { ...DEFAULTS, overrides: {}, log: [] }; tablePlan = D.plan; } table.open(D, tableSet, tablePlan, lenses.current === 'truth'); if (lenses.current === 'world') setLens('statuses'); director.giveBack(); curShot = SB_SHOT(); director.setShot(curShot, { cut: true }); }
    else { table.close(); boardPinned = false; segIdx = -1; if (roomCard.shown) openRoom(roomCard.room); }
    wantRender = true;
  }
  function tableChange(s) { if (!D) return; const prev = tablePlan || D.plan; tableSet = s; tablePlan = replan(D, s); tablePlan.siteLevel = script.siteLevel; table.update(tableSet, tablePlan, lenses.current === 'truth'); if (roomCard.shown) openRoom(roomCard.room); wantRender = true; return prev; }
  function tableReset() { tableSet = { ...DEFAULTS, overrides: {}, log: [] }; tablePlan = D.plan; table.update(tableSet, tablePlan, lenses.current === 'truth'); if (roomCard.shown) openRoom(roomCard.room); toast('Back to the computed plan.'); wantRender = true; }
  function doOverride(id, s) {
    if (!D) return; if (!sbOn) setTable(true);
    const cur = tablePlan.rooms[id], ov = { ...(tableSet.overrides || {}) }, from = cur.status;
    if (s === 'clear') delete ov[id]; else ov[id] = { status: s, why: 'The commander’s call' };
    const less = s !== 'clear' && ORDER[s] < ORDER[cur.computed];
    const prev = tablePlan; const next = replan(D, { ...tableSet, overrides: ov });
    const diff = overrideDiff(prev, next, { id });
    const log = [...(tableSet.log || []), { t: clockText(D.ev, D.ev.handoverH).replace(/^day \d+, /, ''), id, from, to: s, why: s === 'clear' ? 'Back to the computed status' : 'The commander’s call', less, diff }];
    tableSet = { ...tableSet, overrides: ov, log }; tablePlan = next; tablePlan.siteLevel = script.siteLevel;
    table.update(tableSet, tablePlan, lenses.current === 'truth'); openRoom(id);
    if (less) toast('Less cautious than the evidence: allowed, and logged with a warning.');
    wantRender = true;
  }

  // ------------------------------------------------------------------ per-frame playback
  const filmW = {}; for (const n of LAYERS) filmW[n] = 0;
  const st = { P: 0, passK: 1, room: 0, plan: null, truth: false };
  let liftK = -1, liftF = -1, shownKey = '';
  function playback(dt) {
    if (!D) return;
    if (playing && !scrubbing && !sbOn) { P += dt * speed; if (P >= dur) { P = dur; playing = false; onEnded(); } }
    const ci = chapterAt(P), ch = chapters[ci], si = segAt(P), sg = script.segs[si], Ln = lenses.current;
    for (const n of LAYERS) filmW[n] = sg.layers[n] || 0; filmW.dim = sg.dim || 0;
    if (sbOn && Ln === 'world') { for (const n of LAYERS) filmW[n] = 0; filmW.placards = 1; filmW.dim = .4; }
    lenses.update(dt, filmW);
    const W = lenses.W;
    // the plan shown: a change rebuilds the plan's overlays
    const pn = planNow(); if (pn !== planShown) { planShown = pn; if (layers8) layers8.resetPlan(); }
    // weights: Act 7's overlays (the draft tiles are its 'rooms') and Act 8's
    for (const n of LAYERS7) layers.setW(n === 'draft' ? 'rooms' : n, n === 'draft' && Ln === 'statuses' && tog.draft ? 1 : W[n]);
    for (const n of LAYERS8) layers8.setW(n, n === 'placards' && Ln === 'statuses' && tog.draft ? 0 : W[n]);
    world.setDim(lenses.S.dim);
    // the lift animation (World lens, the lift segment): pieces come off in order
    const pc = layers8.get('pieces');
    if (pc) { let k = 0, f = 0; if (Ln === 'world' && sg.lift) { const raw = script.liftAt(P), per = script.liftPer; k = raw; f = raw < D.WL.steps.length ? Math.max(0, Math.min(1, ((P - script.beats.lift0) / per) - raw)) : 0; }
      if (k !== liftK || Math.abs(f - liftF) > .02) { liftK = k; liftF = f; pc.userData.lift(planShown, k, f); } }
    // the room in focus (the evidence beat, or the room card): an outline
    const fr = roomCard.shown ? roomCard.room : Ln === 'world' && !sbOn && sg.focusRoom != null ? sg.focusRoom : -1; layers8.focus(fr);
    // the odds glows: the passes replay at the start of the dig chapter
    st.passK = Ln === 'world' && ch.id === 'dig' ? script.passAt(P) : 1;
    if (W.odds > .01) layers8.setOdds(D.SV.sites.map((s) => { const n = Math.round(s.passes.length * st.passK); return { p: s.centre, v: n ? s.passes[n - 1].after : s.prior }; }));
    // captions, shots, cards, the board
    let cap = null; for (const c of script.captions) { if (c.t <= P + .05) cap = c; else break; }
    if (sbOn) captions.set(null, 'The commander’s table', ''); else captions.set(ci, ch.title, cap ? cap.text : '');
    // the caption crossfades in 0.26 s: once the new sentence is in place, labels it now covers are hidden too
    { const ct = sbOn ? '' : cap ? cap.text : ''; if (ct !== lastCapText) { lastCapText = ct; setTimeout(() => { try { hideCovered(canvas.getBoundingClientRect()); } catch (e) { /* ignore */ } }, 275); } }
    if (!sbOn && si !== segIdx) { segIdx = si; curShot = sg.shot; director.setShot(curShot, { cut: !!(sg.shot && sg.shot.cut) }); }
    st.room = roomCard.shown ? roomCard.room : sg.focusRoom ?? roomFocus; st.plan = planShown; st.truth = Ln === 'truth'; st.P = P;
    const ids = sbOn ? (Ln === 'world' || Ln === 'statuses' ? ['room', 'interval'] : LENS_CARDS[Ln] || []) : Ln === 'world' ? sg.cards : LENS_CARDS[Ln] || [];
    cards.show(ids);
    const bShow = !roomCard.shown && ((sbOn && boardPinned) || (!sbOn && Ln === 'world' && !!sg.board));
    if (bShow) { const log = sbOn ? (tableSet.log || []) : sg.board === 'override' ? [{ t: clockText(D.ev, D.ev.handoverH).replace(/^day \d+, /, ''), id: script.override.id, from: script.override.from, to: script.override.status, why: script.override.why, less: script.override.less, diff: overrideDiff(D.plan, script.plan2, script.override) }] : [];
      board.show(D, planShown, { log }); } else if (board.shown) board.hide();
    root.classList.toggle('boardon', bShow);
    world.tick(clockT, camera, false);
  }
  // what goes to the field: the commander's table if it was opened, else the film's plan with the director's override
  const fieldPlan = () => (tableSet && tablePlan) || (script && script.plan2) || D.plan;
  function onEnded() { closeRoom(); report.show(D, fieldPlan()); }

  // ------------------------------------------------------------------ labels in the scene
  const RE_WORD = (P2, r) => (r.status === 'unsafe' ? 'closed until shored' : r.status === 'safe' ? 'open' : P2.reList.includes(r.id) ? (P2.RE.open != null ? `from ${clockText(D.ev, P2.RE.open).replace('day ', 'day ')}` : 'window not open') : 'inspector first');
  function sceneLabels() {
    const r = canvas.getBoundingClientRect(); labels.begin(camera, r.width, r.height);
    if (!D || !world) { labels.end(); return; }
    const W = lenses.W, Pn = planShown || D.plan, Ln = lenses.current, sg = script.segs[segAt(P)];
    // rooms of the level in view: placards (or Act 7's drafts), the evidence, or the re-entry state
    const wR = Math.max(W.placards, W.evidence, W.reentry, Ln === 'statuses' && tog.draft ? 1 : 0, W.truthRooms * (Ln === 'truth' ? 1 : 0));
    if (wR > .3) {
      // (only with the floors above cut away: labels of a floor seen from outside would float over the walls)
      const lv = cutLevel != null ? Math.min(3, cutLevel) : null;
      if (lv != null) for (const room of C.model.rooms) { if (room.storey !== lv) continue; const rr = Pn.rooms[room.id]; const T = C.storeys[room.storey].T, p = tA(T, (room.x0 + room.x1) / 2, room.y0 + .25, (room.z0 + room.z1) / 2);
        let cls = STATUS7[rr.status], word = placardWord[rr.status];
        if (Ln === 'statuses' && tog.draft) { const ds = C.roomsAfter[room.id].status; cls = DRAFT7[ds]; word = `draft: ${ds === 'noentry' ? 'no entry' : ds === 'unseen' ? 'never seen' : ds}`; }
        else if (Ln === 'truth') { const ts = C.truth.rooms[room.id].status; cls = DRAFT7[ts]; word = `truth: ${ts === 'noentry' ? 'unsafe' : ts === 'caution' ? 'restricted' : 'safe'}`; }
        else if (W.reentry > .3 && W.reentry >= W.placards) word = RE_WORD(Pn, rr);
        else if (W.evidence > .3 && W.evidence >= W.placards) { const ex = (x) => (Number.isFinite(x.hi) ? (x.hi - x.safe) / Math.max(1e-9, x.safe) : 1e9); const e = rr.ev.find((x) => x.verdict === 'over') || rr.ev.filter((x) => x.verdict !== 'under').sort((a, b) => ex(b) - ex(a))[0]; word = e ? `${EVW[e.key] || e.key}: ${e.verdict === 'over' ? 'over the limit' : 'near the limit'}` : 'clear margins'; }
        if (rr.override) word += ', overridden';
        labels.add(p[0], p[1], p[2], `<b>${room.short}</b><small>${word}</small>`, `room ${cls}${rr.override ? ' ov' : ''}`, Math.min(1, wR * 1.2), 4, 0, room.id); }
    }
    // dig flags (rank numbers), their odds, and the voids' odds while the passes replay
    if (W.flags > .3) { const fl = layers8.get('flags'); const tops = fl && fl.userData.tops; Pn.sched.sites.forEach((o, i) => { if (!o || !tops || !tops[i]) return; const t = tops[i]; if (cutLevel != null && t[1] - 2.75 > (cutLevel + 1) * 3) return; labels.num(t[0], t[1], t[2], String(o.rank + 1), Math.min(1, W.flags));
      const sv = D.SV.sites[i], n = Math.round(sv.passes.length * st.passK), v = st.passK < 1 ? (n ? sv.passes[n - 1].after : sv.prior) : Pn.sites[i].p;
      if (o.rank < 3) labels.add(t[0], t[1] + .45, t[2], `<b>Dig ${o.rank + 1}</b><small>odds ${odds(v)}, ${hrs(o.t1)}, team ${o.team + 1}</small>`, 'lav', Math.min(1, W.flags), 14); }); }
    else if (W.odds > .3) D.SV.sites.forEach((s, i) => { const n = Math.round(s.passes.length * st.passK), v = n ? s.passes[n - 1].after : s.prior; labels.add(s.centre[0], s.centre[1] + .6, s.centre[2], `<b>Void ${i + 1}</b><small>odds ${odds(v)}${n ? `, ${n} passes` : ''}</small>`, 'lav', Math.min(1, W.odds), 8); });
    // the next lift numbers (about 8, never two on top of each other) and a small lock on pieces over a void
    if (W.pieces > .3) { const steps = D.WL.steps, tags = []; let shown = 0, locks = 0;
      for (let k = Math.max(0, liftK); k < steps.length && shown < 8; k++) { const s2 = steps[k]; if (cutLevel != null && s2.top - 0.5 > (cutLevel + 1) * 3) continue;
        const p = labels.project(s2.c[0], s2.top + .12, s2.c[2]); if (!p) continue; if (tags.some((t) => Math.abs(t[0] - p[0]) < 26 && Math.abs(t[1] - p[1]) < 22)) continue; tags.push(p);
        labels.num(s2.c[0], s2.top + .12, s2.c[2], String(k + 1), Math.min(1, W.pieces)); shown++;
        if (s2.locked && locks < 2) { locks++; labels.add(s2.c[0], s2.top + .12, s2.c[2], `${LOCK_SVG}<small>over a void: after shoring</small>`, 'noentry lock', Math.min(1, W.pieces), 18); } } }
    // the dumps
    if (W.dumps > .3) for (const [j, d] of Pn.CL.dumps.entries()) labels.add(d.p[0], 1.2, d.p[2], `<b>${d.name}</b><small>${Pn.CL.recv[j].toFixed(1)} m³${Number.isFinite(d.cap) ? ` of ${d.cap} m³` : ', trucks keep it empty'}</small>`, j ? 'lav' : 'apr', Math.min(1, W.dumps), 8);
    // the alerts (handover)
    if (W.alerts > .3) Pn.AL.list.slice(0, 6).forEach((a) => { labels.num(a.pos[0], a.pos[1] + .3, a.pos[2], String(a.rank), Math.min(1, W.alerts)); if (a.rank <= 3) labels.add(a.pos[0], a.pos[1] + .8, a.pos[2], `<b>${a.title}</b><small>${a.confText}</small>`, a.cls === 'void' ? 'lav' : a.kind === 'fire' ? 'heat' : 'teal', Math.min(1, W.alerts), 12); });
    // the truth: people who would be trapped, loads a lift would drop
    if (W.trapped > .3) D.trapped.slice(0, 4).forEach((t, i) => { if (cutLevel != null && t.pos[1] > (cutLevel + 1) * 3) return; labels.add(t.pos[0], t.pos[1] + .5, t.pos[2], i ? '<b>Would be trapped</b>' : `<b>Would be trapped</b><small>${D.trapped.length} in all, truth only</small>`, 'rose', Math.min(1, W.trapped), 6); });
    labels.end(); hideCovered(r);
  }
  // a scene label is hidden (not dimmed) where it would touch the caption, the cards, the dock, the board, the table or
  // the room card; a label over another dig site's number gives way to the number
  function hideCovered(r) {
    const keep = []; for (const e of [capEl, cardsEl, dockEl, boardEl, tableEl, roomEl]) { if (!e || e.hidden || !e.offsetParent) continue; if (e === capEl && (PH || !capEl.textContent.trim() || +getComputedStyle(capEl).opacity < .5)) continue; if (e === boardEl && !board.shown) continue; if (e === roomEl && !roomCard.shown) continue;
      for (const b of e === cardsEl ? [...cardsEl.children] : [e]) { const q2 = b.getBoundingClientRect(); if (q2.width > 2 && q2.height > 2 && +getComputedStyle(b).opacity > .05) keep.push([q2.left - 4, q2.top - 4, q2.right + 4, q2.bottom + 4]); } }
    const hit = (a, b) => a[0] < b[2] && a[2] > b[0] && a[1] < b[3] && a[3] > b[1];
    const nums = []; for (const n of labelsEl.querySelectorAll('.a7num')) { if (n.style.opacity === '0') continue; const q2 = n.getBoundingClientRect(); const box = [q2.left, q2.top, q2.right, q2.bottom]; if (keep.some((k) => hit(box, k))) { n.style.opacity = '0'; continue; } nums.push(box); }
    for (const l of labelsEl.querySelectorAll('.a7lab')) { if (l.style.opacity === '0') continue; const q2 = l.getBoundingClientRect(); const box = [q2.left, q2.top, q2.right, q2.bottom];
      const over = nums.some((nb) => { const w = Math.max(0, Math.min(box[2], nb[2]) - Math.max(box[0], nb[0])), hh = Math.max(0, Math.min(box[3], nb[3]) - Math.max(box[1], nb[1])); return w * hh > 0.4 * (nb[2] - nb[0]) * (nb[3] - nb[1]); });
      if (over || keep.some((k) => hit(box, k))) { l.style.opacity = '0'; l.style.pointerEvents = 'none'; } else l.style.pointerEvents = ''; }
  }

  // ------------------------------------------------------------------ rooms: click or tap
  const ray = new THREE.Raycaster(), ndc = new THREE.Vector2();
  function pickRoom(cx, cy) {
    if (!C) return -1; const r = canvas.getBoundingClientRect(); ndc.set((cx - r.left) / r.width * 2 - 1, -(cy - r.top) / r.height * 2 + 1); ray.setFromCamera(ndc, camera);
    const o = ray.ray.origin, d = ray.ray.direction, topLv = cutLevel == null ? 3 : Math.min(3, cutLevel); let best = -1, bt = 1e9;
    for (let s = 0; s <= topLv; s++) {
      const T = C.storeys[s].T, Rm = T.R; const ox = o.x - T.t[0], oy = o.y - T.t[1], oz = o.z - T.t[2];
      const lo = [Rm[0] * ox + Rm[3] * oy + Rm[6] * oz, Rm[1] * ox + Rm[4] * oy + Rm[7] * oz, Rm[2] * ox + Rm[5] * oy + Rm[8] * oz], ld = [Rm[0] * d.x + Rm[3] * d.y + Rm[6] * d.z, Rm[1] * d.x + Rm[4] * d.y + Rm[7] * d.z, Rm[2] * d.x + Rm[5] * d.y + Rm[8] * d.z];
      for (const room of C.model.rooms) { if (room.storey !== s || Math.abs(ld[1]) < 1e-6) continue; const t = (room.y0 + .05 - lo[1]) / ld[1]; if (t <= 0 || t >= bt) continue; const x = lo[0] + ld[0] * t, z = lo[2] + ld[2] * t; if (x >= room.x0 && x <= room.x1 && z >= room.z0 && z <= room.z1) { bt = t; best = room.id; } }
    }
    return best;
  }
  function openRoom(id) { if (id < 0 || !D) return; roomCard.show(D, planNow() || D.plan, id, { truth: lenses.current === 'truth', table: sbOn }); root.classList.add('roomopen'); wantRender = true; }
  function closeRoom() { roomCard.hide(); root.classList.remove('roomopen'); }
  let downAt = null;
  canvas.addEventListener('pointerdown', (e) => { downAt = { x: e.clientX, y: e.clientY }; });
  canvas.addEventListener('pointerup', (e) => { if (!downAt || Math.hypot(e.clientX - downAt.x, e.clientY - downAt.y) > 6) return; downAt = null; const id = pickRoom(e.clientX, e.clientY); if (id >= 0) openRoom(id); else closeRoom(); });
  labelsEl.addEventListener('click', (e) => { const l = e.target.closest('[data-room]'); if (l) openRoom(+l.dataset.room); });

  // ------------------------------------------------------------------ frame loop
  let raf = 0, last = performance.now(), clockT = 0, running = true, frames = 0, fpsT = 0, fps = 0, frameErr = 0;
  const prof = {};
  function frame(now) { raf = requestAnimationFrame(frame); if (!running || document.hidden) { last = now; return; } try { frameBody(now); } catch (e) { resetGL(); if (frameErr++ < 3) console.warn('[act8] frame failed', e); } }
  let offNow = 0, cardsHalf = 0, viewW = 1, viewH = 1;
  function frameBody(now) {
    const dt = Math.min(TEST ? 1 : .4, (now - last) / 1000); last = now; clockT += dt; frames++;
    if (now - fpsT > 1000) { fps = frames; frames = 0; fpsT = now; }
    const idle = picker.shown || loading || !D;
    if (!TEST && !idle) R.adapt(dt); else if (!TEST) R.resetAdapt();
    const q0 = performance.now();
    if (D && !loading) { try { playback(dt); } catch (e) { if (frameErr++ < 3) console.warn('[act8] playback failed', e); } }
    { const goal = (cards.active.length || sbOn) && !PH ? cardsHalf : 0; const n = offNow + (goal - offNow) * (1 - Math.exp(-dt * 1.6)); if (Math.abs(n - offNow) > .05) { offNow = n; director.setFrame(viewW, viewH, offNow, PH ? 0 : 22); } }
    director.update(dt, 0); if (world) world.fadeNeighbours(camera.position, director.tgt, TEST ? 1 : dt);
    prof.play = performance.now() - q0;
    if (!idle && (!TEST || wantRender || (playing && now - lastRender > (opts.testRenderMs ?? 2500)))) { safeDraw(); lastRender = now; wantRender = false; }
    if (D) { dock.update(P, playing, sbOn ? 'the commander’s table' : ''); cards.update(st, TEST); }
    prof.frame = performance.now() - q0;
  }
  function syncUniforms() {
    const dpr = R.dpr, H = R.h; const f = (o) => { const m = o.material; if (!m || !m.uniforms) return; const u = m.uniforms; if (u.res) u.res.value.set(R.w, R.h); if (u.time) u.time.value = clockT; if (u.hh) u.hh.value = H * dpr; if (u.px) u.px.value = dpr; };
    if (layers) layers.root.traverse(f); if (layers8) { layers8.root.traverse(f); layers8.syncClip(); } if (world) { f(world.cracks.mesh); f(world.cable.mesh); }
  }
  function draw() { syncUniforms(); if (world) { camera.updateMatrixWorld(); world.setSwipe(camera, null); } R.render(clockT); sceneLabels(); }
  function resetGL() { renderer.setRenderTarget(null); renderer.setScissorTest(false); renderer.setViewport(0, 0, R.w, R.h); renderer.autoClear = true; }
  function safeDraw() { try { draw(); } catch (e) { resetGL(); if (frameErr++ < 3) console.warn('[act8] frame failed', e); } }
  function resize() {
    const r = view.getBoundingClientRect(); const w = Math.max(16, r.width), hh = Math.max(16, r.height);
    R.setSize(w, hh); viewW = w; viewH = hh; cardsHalf = PH ? 0 : Math.min(190, (parseFloat(getComputedStyle(root).getPropertyValue('--cards')) || 336) * .5);
    director.setFrame(w, hh, offNow, PH ? 0 : 22); dock.layout(); wantRender = true;
  }
  const ro = new ResizeObserver(resize); ro.observe(view); resize();
  raf = requestAnimationFrame(frame);
  const typing = (t) => t && t.closest && t.closest('input, textarea, select');
  const onKey = (e) => {
    if (typing(e.target) || e.ctrlKey || e.metaKey || e.altKey) return;
    if (e.key === ' ' && D && !picker.shown) { e.preventDefault(); if (!sbOn) (playing ? pause() : play()); }
    else if (e.key === 'ArrowRight' && D && !sbOn) seek(P + 5); else if (e.key === 'ArrowLeft' && D && !sbOn) seek(P - 5);
    else if (/^[1-8]$/.test(e.key) && D) { const L = LENSES.find((l) => l.key === e.key); if (L) setLens(L.id); }
    else if ((e.key === 't' || e.key === 'T') && D) setLens('truth');
    else if (e.key === 'd' || e.key === 'D') director.giveBack();
    else if ((e.key === 'c' || e.key === 'C') && D) setTable(!sbOn);
    else if (e.key === 'Escape') { if (asm.shown) asm.hide(); else if (menu.open) menu.close(); else if (roomCard.shown) closeRoom(); else if (sbOn) setTable(false); else exitAct(); }
  };
  addEventListener('keydown', onKey);
  // start: a case handed over by the host, a mode (and seed), or the picker
  const startMode = opts.mode || opts.start || (opts.case && opts.case.mode) || (TEST ? 'softstorey' : null);
  if (opts.case) start(opts.case.mode, { seed: opts.case.seed, caseObj: opts.case }); else if (startMode && MODE_META[startMode]) start(startMode, { seed: opts.seed ?? (TEST ? 7 : undefined) }); else showPicker();
  root.focus({ preventScroll: true });

  const api = {
    root,
    play: () => { held = false; running = true; play(); }, pause: () => hold(), resume: () => unhold(),
    mode: (id, o = {}) => start(id, o), seek: (p) => { if (sbOn) setTable(false); seek(p); }, lens: setLens, speed: setSpeed,
    chapter: (i) => { const c = chapters[i]; if (c) { if (sbOn) setTable(false); seek(c.p0 + .01); } },
    director: () => director.giveBack(), takeCamera: () => director.take(), showPicker,
    floors: (lv) => { userLevel = lv === 'auto' ? undefined : lv; applyCut(userLevel === undefined ? dirLevel : userLevel); paintFloors(); wantRender = true; },
    table: (on = true) => { setTable(!!on); return { change: (s) => tableChange({ ...tableSet, ...s }), override: (id, s) => doOverride(id, s), reset: () => tableReset(), board: (b = true) => { boardPinned = b; if (b) closeRoom(); wantRender = true; }, get plan() { return tablePlan; }, get settings() { return tableSet; } }; },
    openRoom: (id) => openRoom(id), override: (id, s) => doOverride(id, s), assumptions: () => { if (D) asm.show(D); }, showReport: () => { if (D) { closeRoom(); report.show(D, fieldPlan()); } }, pickRoom,
    get state() { const pn = planShown || (D && D.plan); return { mode: modeId, seed: seedUsed, P, dur, playing, chapter: chapters[chapterAt(P)]?.id, lens: lenses.current, cards: cards.active, caption: captions.text, shot: curShot && curShot.kind, cut: cutLevel, user: director.user, table: sbOn, board: board.shown, fps, dpr: R.dpr, calls: renderer.info.render.calls, tris: renderer.info.render.triangles, load: loadInfo, planMs: pn && pn.ms, score: pn && { fs: pn.score.fs, safe: pn.score.safe, needless: pn.score.needless, unsafeLifts: pn.score.unsafeLifts, vsNearest: pn.score.vsNearest, vsBiggest: pn.score.vsBiggest } }; },
    renderNow(settle = 0) {
      if (!D) { R.render(clockT); return api.state; }
      playback(0); offNow = (cards.active.length || sbOn) && !PH ? cardsHalf : 0; director.setFrame(viewW, viewH, offNow, PH ? 0 : 22);
      for (let i = 0; i < settle; i++) { lenses.update(.1, filmW); playback(0); director.update(.1, 0); }
      playback(0); director.update(.016, 0); if (world) world.fadeNeighbours(camera.position, director.tgt, 5); draw(); dock.update(P, playing, sbOn ? 'the commander’s table' : ''); cards.update(st, true); return api.state;
    },
    frameStats() {
      if (D && world) { try { draw(); } catch (e) { /* stats of whatever is on screen */ } }
      const stat = (sx, sy, sw, sh, W, H) => { const c = document.createElement('canvas'); c.width = W; c.height = H; const x = c.getContext('2d', { willReadFrequently: true }); x.drawImage(canvas, sx, sy, sw, sh, 0, 0, W, H); const d = x.getImageData(0, 0, W, H).data, L = new Float32Array(W * H);
        let m = 0; for (let i = 0; i < W * H; i++) { L[i] = (.2126 * d[i * 4] + .7152 * d[i * 4 + 1] + .0722 * d[i * 4 + 2]) / 255; m += L[i]; } m /= W * H; let v = 0, e = 0, n = 0;
        for (let k = 1; k < H - 1; k++) for (let i = 1; i < W - 1; i++) { const q = k * W + i; v += (L[q] - m) ** 2; const g = Math.abs(L[q + 1] - L[q - 1]) + Math.abs(L[q + W] - L[q - W]); if (g > .06) e++; n++; }
        return { mean: +m.toFixed(3), std: +Math.sqrt(v / n).toFixed(3), edge: +(e / n).toFixed(3) }; };
      const cw = canvas.width, ch = canvas.height; return { main: stat(0, 0, cw * (PH ? 1 : .72), ch * .82, 192, 120), chapter: chapters[chapterAt(P)]?.id };
    },
    get caseData() { return C; }, get decision() { return D; }, get script() { return script; }, get prof() { return prof; },
    _dbg: { scene, camera, renderer, R, director, lenses, get layers() { return layers; }, get layers8() { return layers8; }, get world() { return world; } },
    destroy() {
      if (destroyed) return; destroyed = true; loadId++;
      canvas.removeEventListener('webglcontextlost', onLost); cancelAnimationFrame(raf); running = false; playing = false; ro.disconnect(); removeEventListener('keydown', onKey); clearTimeout(toastT);
      try { music.destroy(); } catch (e) { /* ignore */ } menu.dispose(); dock.dispose(); director.dispose();
      dropScene(); cache.clear();
      scene.traverse((o) => { if (o.geometry) o.geometry.dispose(); if (o.material) (Array.isArray(o.material) ? o.material : [o.material]).forEach((m) => { for (const k in m) if (m[k] && m[k].isTexture) m[k].dispose(); m.dispose(); }); });
      if (props) props.traverse((o) => { if (o.geometry) o.geometry.dispose(); if (o.material) (Array.isArray(o.material) ? o.material : [o.material]).forEach((m) => m.dispose()); });
      R.dispose(); root.remove();
    },
  };
  return api;
}
