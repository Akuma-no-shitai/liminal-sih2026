// The film, written from the case and its plan: six chapters (about two and three quarter minutes at 1x), each made of
// segments that say which overlays the World lens shows, how dim the clay gets, which cards are up and where the camera
// goes; captions are one plain sentence each, with this run's numbers. A pure function of (case, decision), so
// scrubbing is exact. The override the director plays in the brief is computed here too (plan() with that override).
import { anchorsOf } from '../../../act7/js/film/script.js';
import { plan } from '../decide/run.js';
import { clockText } from '../decide/reentry.js';
import { fmtQ, QNAME } from '../decide/status.js';

const FLOOR = ['ground', 'first', 'second', 'third'];
const pct = (v) => `${Math.round(v * 100)} %`;
const odds = (v) => (v < 0.005 ? 'under 1 %' : pct(v));
const m3 = (v) => (v >= 100 ? `${Math.round(v)} m³` : `${v.toFixed(1)} m³`);
const hrs = (h) => (h < 1 ? `${Math.round(h * 60)} minutes` : h >= 48 ? `${(h / 24).toFixed(1)} days` : `${h.toFixed(1)} hours`);
const num = (n, one, many) => `${n} ${n === 1 ? one : many}`;
export const roomName = (C, id) => { const r = C.model.rooms[id]; return r.flat === 'core' ? `the ${FLOOR[r.storey]}-floor stair` : `the ${FLOOR[r.storey]}-floor ${r.short.toLowerCase()} of flat ${r.flat}`; };
export const RoomName = (C, id) => { const s = roomName(C, id); return s[0].toUpperCase() + s.slice(1); };
// the storey whose rooms show the most varied statuses (a mix reads best), never one that is gone
function statusLevel(C, rooms) {
  let best = 1, bs = -1; for (let s = 0; s < 4; s++) { const st = new Set(rooms.filter((r) => C.model.rooms[r.id].storey === s).map((r) => r.status)); const sc = st.size + (rooms.some((r) => C.model.rooms[r.id].storey === s && r.status !== 'unsafe') ? .5 : 0) + (s === 1 ? .2 : 0); if (sc > bs) { bs = sc; best = s; } }
  return best;
}
// the room the evidence beat looks at: a restricted one with a clear reason, else a room that differs from the draft, else any
function exampleRoom(rooms) {
  const r = rooms.find((x) => x.status === 'restricted' && !x.borderline && x.ev.some((e) => e.verdict !== 'under' && e.key !== 'stiff')) || rooms.find((x) => x.status === 'restricted') || rooms.find((x) => x.differs) || rooms.find((x) => x.status === 'safe') || rooms.find((x) => !x.gone) || rooms[0];
  return r.id;
}
// the override the director plays: a restricted room marked unsafe (a crew reports a new crack); if no room is
// restricted, an unsafe one marked restricted to let a shoring crew through (less cautious: allowed, with a warning)
function overrideOf(C, D) {
  const rs = D.plan.rooms, sites = D.plan.sched.sites.filter(Boolean);
  const onLane = new Set(sites.flatMap((o) => o.access.rooms));
  const res = rs.filter((r) => r.status === 'restricted');
  if (res.length) { const r = res.find((x) => onLane.has(x.id)) || res.find((x) => D.plan.reList.includes(x.id)) || res[0]; return { id: r.id, status: 'unsafe', from: 'restricted', why: 'A crew reports a new crack', less: false }; }
  const un = rs.filter((r) => r.status === 'unsafe' && !r.gone);
  const r = un.find((x) => onLane.has(x.id)) || un.find((x) => C.model.rooms[x.id].kind === 'core') || un[0] || rs[0];
  return { id: r.id, status: 'restricted', from: r.status, why: 'To let a shoring crew through', less: true };
}
const outAz = (p) => { let a = Math.atan2(p[0], p[2] + 0.001); const f = Math.cos(a) >= 0 ? 0 : Math.PI; let d = Math.atan2(Math.sin(a - f), Math.cos(a - f)); d = Math.max(-0.87, Math.min(0.87, d)); return f + d; };
export function buildScript(C, D) {
  const P = D.plan, A = anchorsOf(C), ev = D.ev, K = D.K, sc = P.score, rooms = P.rooms, site = C.model.site;
  const cnt = { safe: 0, restricted: 0, unsafe: 0 }; rooms.forEach((r) => cnt[r.status]++);
  const lvl = statusLevel(C, rooms), ex = exampleRoom(rooms), exR = rooms[ex];
  const ctr = [0, 5.2, 0];
  let dAz = A.damageAz; { const f = Math.cos(dAz) >= 0 ? 0 : Math.PI; let d = Math.atan2(Math.sin(dAz - f), Math.cos(dAz - f)); d = Math.max(-0.87, Math.min(0.87, d)); if (Math.abs(d) < 0.25) d = d < 0 ? -0.35 : 0.35; dAz = f + d; }
  const sites = P.sched.sites, act = sites.filter(Boolean), nSites = act.length;
  const siteC = nSites ? [0, 1, 2].map((i) => act.reduce((a, o) => a + C.pockets.list[P.sites[o.site].pocket].centre[i], 0) / nSites) : A.debris;
  const siteLv = nSites ? Math.min(3, Math.max(...act.map((o) => Math.floor((C.pockets.list[P.sites[o.site].pocket].centre[1] + 0.3) / 3)))) : 0;
  const first = act.slice().sort((a, b) => a.rank - b.rank)[0];
  const sAz = outAz(siteC), pAz = outAz(A.debris);
  const arcs = P.CL.arcs.slice(0, 60), hw = arcs.reduce((a, q) => a + q.loose, 0);
  const haulC = hw > 0.05 ? [0, 2].map((i) => arcs.reduce((a, q) => a + (q.from[i] + q.to[i]) / 2 * q.loose, 0) / hw) : [A.debris[0], A.debris[2]];
  const ov = overrideOf(C, D);
  const P2 = plan(D, { ...P.settings, overrides: { [ov.id]: { status: ov.status, why: ov.why, film: true } } });
  // ------------------------------------------------------------------ chapters: segments and captions in seconds from each chapter's start
  const S = (t0, t1, o) => ({ t0, t1, layers: {}, dim: 0, cards: [], ...o });
  const CH = [];
  const chapter = (id, title, label, len, segs, caps, beats = {}) => CH.push({ id, title, label, len, segs, caps, beats });
  const AL = P.AL, nVoid = AL.list.filter((a) => a.cls === 'void').length, nHaz = AL.list.length - nVoid;
  chapter('handover', 'The handover', 'Handover', 15, [
    S(0, 6, { layers: { draft: 1, pockets: .8, heat: .8 }, dim: .25, cards: ['handover'], shot: { kind: 'wide', az: dAz, el: .5, dist: 44, drift: .016, target: ctr } }),
    S(6, 15, { layers: { draft: .6, pockets: 1, heat: 1, alerts: 1 }, dim: .35, cards: ['handover', 'alerts'], shot: { kind: 'wide', az: dAz + .25, el: .62, dist: 40, drift: .012, target: [A.debris[0] * .4, 3, A.debris[2] * .4] } }),
  ], [
    [0, 'Act 7 measured the building. Now the incident commander has to decide what to do with it.'],
    [4, `The ground station hands over draft room statuses, ${num(C.pockets.list.length, 'candidate void', 'candidate voids')}, about ${m3(C.debris.estimate)} of debris and ${num(AL.list.length, 'alert', 'alerts')}.`],
    [8.5, AL.detections ? 'Alerts are ranked: a survivor seen by two sources first, then by one, then a hazard beside a survivor, then the rest.' : `No survivor was detected: the simulated sensors see heat and structure, not people. So the ${num(nVoid, 'candidate void comes', 'candidate voids come')} first, then ${num(nHaz, 'hazard', 'hazards')}.`],
    [12, 'The swarm recommends; the commander decides. An override always wins.'],
  ], { packets0: 1, alerts0: 8 });
  const differ = rooms.filter((r) => r.differs);
  const heldTxt = K.held.fs === 0 ? `On ${K.nHoldCases} more, held out, it marked ${K.held.safe} rooms safe and none was wrong` : `On ${K.nHoldCases} more, held out, ${K.held.fs} of ${K.held.safe} rooms it marked safe were not: shown as a miss`;
  const exEv = exR.ev.filter((e) => e.verdict !== 'under' && e.key !== 'stiff' && Number.isFinite(e.hi) && e.hi < 1e2).sort((a, b) => (b.hi - b.safe) / b.safe - (a.hi - a.safe) / a.safe)[0] || exR.ev.find((e) => e.key === 'tilt');
  chapter('statuses', 'Safe, restricted, unsafe', 'Statuses', 35, [
    S(0, 11, { layers: { placards: 1 }, dim: .4, cards: ['interval'], roomLabels: lvl, shot: { kind: 'cutaway', level: lvl, target: [0, lvl * 3 + 1, 0], az: dAz * .5, el: .95, dist: 31, drift: .006 } }),
    S(11, 23, { layers: { placards: 1 }, dim: .4, cards: ['interval', 'threshold'], roomLabels: lvl, shot: { kind: 'cutaway', level: lvl, target: [0, lvl * 3 + 1, 0], az: dAz * .5 + .2, el: 1.05, dist: 30, drift: .006 } }),
    S(23, 35, { layers: { placards: 1, evidence: .0 }, dim: .45, cards: ['threshold', 'room'], roomLabels: C.model.rooms[ex].storey, focusRoom: ex, shot: { kind: 'cutaway', level: C.model.rooms[ex].storey, target: roomCentre(C, ex), az: dAz * .5 + .4, el: .9, dist: 17, drift: .006 } }),
  ], [
    [0, 'Every measurement now carries a range with a stated hit rate, checked on simulated collapses this one is not part of: a conformal interval.'],
    [6, 'A room is safe only if every range sits under its safe limit and it was seen; unsafe if any range sits wholly over its no-entry limit; otherwise restricted.'],
    [12, 'Safe, restricted, unsafe: the three placards inspectors use after earthquakes.'],
    [17, K.met ? `The safe limit was tuned on ${K.nCases} other simulated collapses, keeping false-safe rooms provably under 1 %. ${heldTxt} (95 % bound ${(K.held.fsUpper * 100).toFixed(1)} %).` : `The safe limit was tuned on ${K.nCases} other simulated collapses. ${heldTxt}; too few to prove a rate under 1 %: the 95 % bound is ${(K.held.fsUpper * 100).toFixed(1)} %.`],
    [23, `Here: ${cnt.safe} safe, ${cnt.restricted} restricted, ${cnt.unsafe} unsafe. ${differ.length ? `${num(differ.length, 'room differs', 'rooms differ')} from Act 7’s draft.` : 'Every room keeps Act 7’s draft status.'}`],
    [29, `${RoomName(C, ex)}: ${QNAME[exEv.key].toLowerCase()} ${fmtQ(exEv.key, exEv.m)}, range ${fmtQ(exEv.key, exEv.lo)} to ${Number.isFinite(exEv.hi) && exEv.hi < 1e2 ? fmtQ(exEv.key, exEv.hi) : 'unknown'}: ${exR.status === 'safe' ? 'under its safe limit' : exEv.verdict === 'over' ? 'wholly over the no-entry limit' : 'past the safe limit'}, so ${exR.status}.`],
  ], {});
  const RE = P.RE, nowPct = pct(RE.nowChance), openTxt = RE.open != null ? clockText(ev, RE.open) : 'not within two months', openNow = RE.open != null && RE.open <= ev.handoverH + 0.01;
  const nRe = P.reList.length, nIns = P.inspectFirst.length;
  chapter('reentry', 'When to go back in', 'Re-entry', 25, [
    S(0, 12, { layers: { reentry: 1 }, dim: .4, cards: ['aftershock'], roomLabels: lvl, reLabels: true, shot: { kind: 'cutaway', level: lvl, target: [0, lvl * 3 + 1, 0], az: dAz * .5 - .3, el: 1.0, dist: 34, drift: .01 } }),
    S(12, 25, { layers: { reentry: 1, pods: 1 }, dim: .45, cards: ['aftershock', 'stiffness'], roomLabels: lvl, reLabels: true, shot: { kind: 'cutaway', level: lvl, target: [0, lvl * 3 + 1, 0], az: dAz * .5 + .55, el: .92, dist: 32, drift: .008 } }),
  ], [
    [0, `The mainshock was simulated: magnitude ${ev.Mm.toFixed(1)} at ${clockText(ev, 0).replace('day 1, ', '')}. Aftershocks fade as a power law in time (Omori decay).`],
    [5, ev.weakened ? `The pods show a weakened building, which a smaller shake can damage: an aftershock of magnitude ${ev.Md.toFixed(1)} or more counts. The chance of one in a ${RE.shiftH}-hour shift starting now is ${nowPct}.` : `An aftershock of magnitude ${ev.Md.toFixed(1)} or more could do damage. The chance of one in a ${RE.shiftH}-hour shift starting now is ${nowPct} (Reasenberg and Jones’s generic model).`],
    [10.5, cnt.restricted ? `Restricted rooms may be re-entered once that chance is under ${pct(RE.tolerance)} and the pods show no slowing: ${openNow ? 'from now: the chance is already under it' : `from ${openTxt}, ${hrs(RE.open ?? 0)} after the mainshock`}.` : `It falls under ${pct(RE.tolerance)} per shift from ${openTxt}. No room is restricted here, so that window opens no rooms: every one is unsafe until shored.`],
    [16, RE.slowing ? 'The pods say the building recovers more slowly after each aftershock, so the window waits for a fresh pod reading.' : P.stiffWarn.length ? `${num(P.stiffWarn.length, 'room has', 'rooms have')} a pod on a wall that lost stiffness: a warning to check before anyone goes back in.` : 'No pod reads a stiffness loss worth a warning.'],
    [20.5, `${nIns ? `${num(nIns, 'restricted room needs', 'restricted rooms need')} an inspector first (a range reaches the no-entry limit). ` : ''}Unsafe rooms stay closed until shored. Real use would refit the model as aftershocks are recorded.`],
  ], {});
  const trapped = sc.trapped, reached = sc.reached;
  const truthLine = !nSites ? 'No candidate void here, so there is no dig order to score.' : !trapped ? 'In the truth nobody would be trapped in a void here, so the order cannot be scored on this collapse.' : !reached ? `In the truth ${num(trapped, 'person would', 'people would')} be trapped in a void none of the candidate voids found: a miss, shown here as it is.` :
    `In the truth ${num(trapped, 'person would', 'people would')} be trapped in a void; the plan reaches ${reached === trapped ? (trapped === 1 ? 'them' : 'all of them') : `${reached} of them`} in ${hrs(sc.mean)} on average, against ${hrs(sc.meanNearest)} nearest first and ${hrs(sc.meanBiggest)} biggest first.`;
  const fs0 = first ? P.sites[first.site] : null, firstPk = fs0 ? C.pockets.list[fs0.pocket] : null;
  chapter('dig', 'Where to dig first', 'Dig order', 35, [
    S(0, 12, { layers: { flags: 1, pockets: .7, odds: 1 }, dim: .5, cards: ['odds'], roomLabels: null, shot: { kind: 'cutaway', level: siteLv, target: siteC, az: sAz - .15, el: .95, dist: 23, drift: .008 } }),
    S(12, 24, { layers: { flags: 1, lanes: 1 }, dim: .5, cards: ['odds', 'digorder'], shot: { kind: 'cutaway', level: siteLv, target: siteC, az: sAz + .15, el: 1.0, dist: 25, drift: .008 } }),
    S(24, 35, { layers: { flags: 1, sectors: 1, lanes: .6 }, dim: .5, cards: ['digorder', 'sectors'], shot: { kind: 'top', level: siteLv, target: [siteC[0] * .5, siteLv * 3, siteC[2] * .5], az: sAz * .3, el: 1.25, dist: 36, drift: .004 } }),
  ], [
    [0, nSites ? `${num(nSites, 'candidate void', 'candidate voids')} to dig. Who could be in each starts from the night’s occupants, the same people Act 2 evacuated, carried to where their rooms went.` : 'No candidate void was found in this collapse: nothing to dig for. The teams would search by hand.'],
    [6, nSites ? 'Every drone pass that looked in and saw nobody lowers the odds: not found here counts as evidence (negative information).' : 'A leaning block can stand with no void inside; the hazards still rank.'],
    [12, nSites ? `Time to reach each void: the walk, the debris to lift first at ${D.plan.settings.liftRate} m³ an hour, then shoring and opening it.` : 'With no void there is no lane to open and no lift order is forced by a rescue.'],
    [18, nSites ? `The order puts first the most people reached per hour (Smith’s rule), weighted by a survival curve that falls with time.${firstPk ? ` First: the ${firstPk.kind === 'gap' ? 'void seen through a gap' : 'void under a slab'}, odds ${odds(fs0.p)}, reached in ${hrs(first.t1)}.` : ''}` : ''],
    [24, `${P.sec.n === 1 ? 'One team takes the whole map.' : `${num(P.sec.n, 'team', 'teams')}, one sector each: the map split along its Fiedler vector, the graph’s weakest seam.`}`],
    [29.5, truthLine],
  ], {});
  const WL = D.WL, CL = P.CL, nSt = WL.steps.length, leftV = WL.left.vol, totV = WL.scoredVol, LN = WL.lanes, MU = WL.must;
  const whyLeft = [WL.left.heldVol > 0.05 ? `${m3(WL.left.heldVol)} held down` : '', WL.left.unseenVol > 0.05 ? `${m3(WL.left.unseenVol)} never seen from above` : '', WL.left.lockedVol > 0.05 ? `${m3(WL.left.lockedVol)} waiting for shoring` : ''].filter(Boolean).join(', ');
  const lanesTxt = LN.sites ? `${LN.sitesOpen} of ${num(LN.sites, 'dig-site lane', 'dig-site lanes')} and ${LN.entsOpen} of ${LN.ents} entrances open by safe lifts alone` : `No dig site here; ${LN.entsOpen} of ${LN.ents} entrances open by safe lifts alone`;
  const liftTruth = sc.unsafeLifts === 0 ? 'Against the true debris: no step drops a load.' : sc.bigDrops === 0 ? `Against the true debris, ${num(sc.unsafeLifts, 'step', 'steps')} of ${nSt} let a small chunk settle (each under 0.05 m³); none drops a heavier load.` : `Against the true debris, ${num(sc.unsafeLifts, 'step', 'steps')} of ${nSt} would drop a chunk, ${sc.bigDrops} of 0.05 m³ or more: ${sc.unseenDrops ? 'some sit where no scan saw them, ' : ''}resting on more than the scans could show.`;
  chapter('lifts', 'What to lift, and what to haul', 'Lift and haul', 30, [
    S(0, 15, { layers: { pieces: 1 }, dim: .55, cards: ['lifts'], lift: true, shot: { kind: 'focus', target: [A.debris[0], Math.max(1, A.debris[1]), A.debris[2]], az: pAz, el: .78, dist: 21, drift: .008 } }),
    S(15, 30, { layers: { haul: 1, must: 1, dumps: 1, pieces: .3 }, dim: .45, cards: ['lifts', 'clearance'], shot: { kind: 'top', target: [haulC[0], 0, haulC[1]], az: outAz([haulC[0], 0, haulC[1]]), el: 1.08, dist: 40, drift: .003 } }),
  ], [
    [0, MU.vol > 0.05 ? `During the rescue only what blocks the lanes to the dig sites and the entrances has to move: ${m3(MU.vol)} of the pile’s ${m3(totV)}.` : `Nothing blocks the lanes or the entrances: during the rescue none of the pile’s ${m3(totV)} has to move.`],
    [4, 'The pile is rescanned after every lift, so the next lift is planned on what is now exposed.'],
    [7, 'A piece goes only when its top was seen and nothing lies on it or within half a metre of it.'],
    [10, `${lanesTxt}${leftV > 0.05 ? `; ${m3(leftV)} on the lanes needs a closer look (${whyLeft || 'held'})` : ''}.`],
    [13, `The rest of the pile, ${m3(MU.notNeeded)}, is not needed for the rescue: it waits for heavy machinery afterwards.`],
    [16, liftTruth],
    [21, CL.mustN ? `Only the lanes to the dig sites and the entrances must be clear. The cheapest way to move it to the loading bay and the skip: optimal transport.` : 'No lane to open: the entrances are clear, so nothing has to be moved yet.'],
    [25.5, CL.moved > 0.05 ? `${m3(CL.moved)} moved of ${m3(CL.total)} (loose): ${pct(CL.saving)} less to open every lane. ${num(CL.trucks, 'truck load', 'truck loads')}, ${hrs(CL.hours)} of machine time.` : `Nothing has to be moved to open the way; all ${m3(CL.total)} (loose) can wait for the clean-up.`],
  ], { lift0: 4.5, lift1: 15 });
  const ovName = RoomName(C, ov.id), chg = overrideDiff(P, P2, ov);
  chapter('brief', 'The brief', 'Brief', 20, [
    S(0, 5, { layers: { placards: .7 }, dim: .55, cards: [], board: 'base', shot: { kind: 'wide', az: dAz, el: .62, dist: 46, drift: .01, target: ctr } }),
    S(5, 11, { layers: { placards: .7 }, dim: .55, cards: [], board: 'override', override: ov, shot: { kind: 'wide', az: dAz, el: .62, dist: 46, drift: .01, target: ctr } }),
    S(11, 20, { layers: { placards: .5 }, dim: .55, cards: ['fragility'], board: null, override: ov, shot: { kind: 'wide', az: dAz + .4, el: .45, dist: 48, drift: .012, target: ctr } }),
  ], [
    [0, 'The commander’s board on one page: statuses, the re-entry window, the dig order, the lift order, the clearance plan and the alerts, each number with its range.'],
    [5, ov.less ? `The commander marks ${roomName(C, ov.id)} restricted to let a shoring crew through. Less cautious than the evidence: allowed, logged with a warning.` : `A crew reports a new crack in ${roomName(C, ov.id)}: the commander marks it unsafe. The board recomputes${chg ? `: ${chg}` : ''}.`],
    [11, 'Closing the loop (roadmap): this collapse’s damage updates the fragility curve for this kind of block, and the next Before plan starts from it.'],
    [16, 'That is Sendai priority 4, build back better: each event makes the next plan sharper.'],
  ], {});
  // flatten to film seconds
  const chapters = [], segs = [], cap = [], B = {}; let t = 0;
  for (const ch of CH) {
    chapters.push({ id: ch.id, title: ch.title, label: ch.label, p0: t, p1: t + ch.len });
    for (const sg of ch.segs) segs.push({ ...sg, t0: t + sg.t0, t1: t + sg.t1, ch: ch.id });
    for (const [tt, text] of ch.caps) if (text) cap.push({ t: t + tt, text });
    B[ch.id] = [t, t + ch.len]; for (const [k, v] of Object.entries(ch.beats)) B[k] = t + v;
    t += ch.len;
  }
  const dur = t;
  // the lift animation: film seconds -> how many steps of the removal order are done
  const nL = D.WL.steps.length, liftPer = Math.max(.02, (B.lift1 - B.lift0) * .8 / Math.max(1, nL));
  const liftAt = (p) => (p < B.lift0 ? 0 : Math.min(nL, Math.floor((p - B.lift0) / liftPer)));
  // the odds dropping as the passes replay (first 12 s of the dig chapter)
  const passAt = (p) => Math.max(0, Math.min(1, (p - B.dig[0] - 1.5) / 9));
  return { chapters, dur, segs, captions: cap, beats: B, anchors: A, liftAt, liftPer, passAt, override: ov, plan2: P2, exampleRoom: ex, statusLevel: lvl, siteLevel: siteLv, events: [{ p: B.statuses[0] + 12, color: 'var(--teal)' }, { p: B.brief[0] + 5, color: 'var(--heat)' }] };
}
function roomCentre(C, id) { const r = C.model.rooms[id], T = C.storeys[r.storey].T, R = T.R, x = (r.x0 + r.x1) / 2, y = r.y0 + 1, z = (r.z0 + r.z1) / 2; return [R[0] * x + R[1] * y + R[2] * z + T.t[0], R[3] * x + R[4] * y + R[5] * z + T.t[1], R[6] * x + R[7] * y + R[8] * z + T.t[2]]; }
// what an override changed downstream, in a few words
export function overrideDiff(P, P2, ov) {
  const out = [];
  if (P.reList.length !== P2.reList.length) out.push(`rooms to re-enter ${P.reList.length} to ${P2.reList.length}`);
  if (P.inspectFirst.length !== P2.inspectFirst.length) out.push(`rooms needing an inspector first ${P.inspectFirst.length} to ${P2.inspectFirst.length}`);
  P.sched.sites.forEach((o, i) => { const o2 = P2.sched.sites[i]; if (o && o2 && Math.abs(o.t1 - o2.t1) > 0.05) out.push(`dig site ${o.rank + 1} reached in ${o2.t1.toFixed(1)} h, not ${o.t1.toFixed(1)}`); });
  if (Math.abs(P.CL.moved - P2.CL.moved) > 0.1) out.push(`${P2.CL.moved.toFixed(1)} m³ to move, not ${P.CL.moved.toFixed(1)}`);
  return out.slice(0, 2).join('; ');
}
