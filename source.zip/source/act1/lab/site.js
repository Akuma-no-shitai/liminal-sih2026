// LIMINAL for SIH26223, Act 1: the facts that change between builds, one line each.
export const PS = '26223';
// The code link, used by every "Read the code" button (lab.js) and by the noscript note (build_site223.py reads it from here).
// It is the deck's link and not yet confirmed by the team: change this one line.
export const REPO_URL = 'https://github.com/Akuma-no-shitai/liminal-sih2026';
// Acts 2, 7 and 8 are wired into this page during assembly (an opener in main.js `EXTRA`). Until an act is live here its
// buttons show a short note ("Opens in the full 223 site") instead of a broken host. Set an act to true once it is wired.
export const ACT_LIVE = { 2: true, 7: true, 8: true };
