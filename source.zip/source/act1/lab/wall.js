// LIMINAL (SIH26223), Act 1, "A collapse is a phase transition": one wall, before and after.
// The deck's figure (slide 2: "one wall, before and after"), drawn from a small model so the picture and the curves agree:
//  - the wall is a grid of patches; each has a strength (a smooth random field with two weak spots, ranked so the
//    strengths are spread evenly over 0..1);
//  - the stress rises as you scroll; a patch whose strength is passed is damaged, and the way it faces (its normal, drawn
//    as a tick) turns away from the rest by an angle that grows with how far the stress is past its strength and with the
//    size of the damage cluster it belongs to (damage that joins up moves the wall more); the wall leans a little too;
//  - φ_wall is the order of the normals: the largest eigenvalue of Q = <(3nnᵀ − I)/2>, the same nematic order Act 7
//    measures per patch (1 = every patch faces one way, near 0 = random);
//  - ξ is the mean size of the damage clusters that do not yet run across the wall (percolation's mean cluster size). It
//    peaks where the clusters join up: the threshold. It is averaged over 120 walls (and lightly smoothed) so the curve reads.
// A sketch of the idea, not a structural simulation: none of its values are measurements, and the page says so.
const C = 12, R = 7, N = C * R, K = 121, SEED = 11, AVG = 120;
const N4 = [[1, 0], [-1, 0], [0, 1], [0, -1]];
const clamp = (x, a = 0, b = 1) => Math.min(b, Math.max(a, x));
function rng(seed) { let a = seed >>> 0; return () => { a = (a + 0x6D2B79F5) | 0; let t = Math.imul(a ^ (a >>> 15), 1 | a); t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t; return ((t ^ (t >>> 14)) >>> 0) / 4294967296; }; }

function makeWall(seed) {
  const r = rng(seed), f = new Float32Array(N);
  for (let i = 0; i < N; i++) f[i] = r();
  const spots = [[r() * C * .4, R - 1 - r() * 1.5], [C * .5 + r() * C * .45, r() * R]];   // weak spots: one low on the wall, one anywhere
  for (let y = 0; y < R; y++) for (let x = 0; x < C; x++) { let d = 0; for (const [sx, sy] of spots) d += Math.exp(-((x - sx) ** 2 + (y - sy) ** 2) / 6); f[y * C + x] -= .9 * d; }
  for (let k = 0; k < 2; k++) { const g = f.slice(); for (let y = 0; y < R; y++) for (let x = 0; x < C; x++) { let s = g[y * C + x] * 2, n = 2; for (const [dx, dy] of N4) { const xx = x + dx, yy = y + dy; if (xx < 0 || yy < 0 || xx >= C || yy >= R) continue; s += g[yy * C + xx]; n++; } f[y * C + x] = s / n; } }
  const idx = [...Array(N).keys()].sort((a, b) => f[a] - f[b]), str = new Float32Array(N); idx.forEach((k, i) => { str[k] = (i + .5) / N; });
  const ax = new Float32Array(N), mag = new Float32Array(N);
  for (let i = 0; i < N; i++) { ax[i] = r() * Math.PI * 2; mag[i] = .55 + r() * .75; }   // turn axis in the wall plane; full turn 31-74 degrees
  return { str, ax, mag };
}
const sev = (stress, s) => clamp((stress - s) / .22);
function clusters(W, stress) {   // the damaged patches joined into clusters (4-neighbours): root per patch, size per root, which edges it touches
  const par = new Int32Array(N).fill(-1);
  const find = (i) => { while (par[i] !== i) { par[i] = par[par[i]]; i = par[i]; } return i; };
  for (let i = 0; i < N; i++) if (stress > W.str[i]) par[i] = i;
  for (let y = 0; y < R; y++) for (let x = 0; x < C; x++) { const i = y * C + x; if (par[i] < 0) continue;
    if (x + 1 < C && par[i + 1] >= 0) { const a = find(i), b = find(i + 1); if (a !== b) par[a] = b; }
    if (y + 1 < R && par[i + C] >= 0) { const a = find(i), b = find(i + C); if (a !== b) par[a] = b; } }
  const root = new Int32Array(N).fill(-1), size = new Map(), ext = new Map();
  for (let i = 0; i < N; i++) { if (par[i] < 0) continue; const r = find(i), x = i % C, y = (i / C) | 0; root[i] = r; size.set(r, (size.get(r) || 0) + 1);
    ext.set(r, (ext.get(r) || 0) | (x === 0 ? 1 : 0) | (x === C - 1 ? 2 : 0) | (y === 0 ? 4 : 0) | (y === R - 1 ? 8 : 0)); }
  return { root, size, ext };
}
function normals(W, stress, out) {   // rotate (0, 0, 1) about the axis (cos ax, sin ax, 0)
  const { root, size } = clusters(W, stress);
  for (let i = 0; i < N; i++) { const join = root[i] < 0 ? 0 : clamp(size.get(root[i]) / (N * .3)), a = W.mag[i] * sev(stress, W.str[i]) * (.3 + .7 * join), s = Math.sin(a);
    out[i * 3] = Math.sin(W.ax[i]) * s; out[i * 3 + 1] = -Math.cos(W.ax[i]) * s; out[i * 3 + 2] = Math.cos(a); }
  return out;
}
function eigMax(a, b, c, d, e, f) {   // largest eigenvalue of the symmetric [[a d e] [d b f] [e f c]]
  const p1 = d * d + e * e + f * f, q = (a + b + c) / 3;
  if (p1 < 1e-12) return Math.max(a, b, c);
  const p = Math.sqrt(((a - q) ** 2 + (b - q) ** 2 + (c - q) ** 2 + 2 * p1) / 6);
  const A = (a - q) / p, B = (b - q) / p, Cc = (c - q) / p, D = d / p, E = e / p, F = f / p;
  const det = A * (B * Cc - F * F) - D * (D * Cc - F * E) + E * (D * F - B * E);
  return q + 2 * p * Math.cos(Math.acos(clamp(det / 2, -1, 1)) / 3);
}
function orderPhi(n) {
  let a = 0, b = 0, c = 0, d = 0, e = 0, f = 0;
  for (let i = 0; i < N; i++) { const x = n[i * 3], y = n[i * 3 + 1], z = n[i * 3 + 2]; a += x * x; b += y * y; c += z * z; d += x * y; e += x * z; f += y * z; }
  return 1.5 * eigMax(a / N, b / N, c / N, d / N, e / N, f / N) - .5;
}
function clusterXi(W, stress) {   // mean size of the damage clusters that do not run across the wall
  const { size, ext } = clusters(W, stress); let s1 = 0, s2 = 0;
  for (const [r, n] of size) { const m = ext.get(r); if ((m & 3) === 3 || (m & 12) === 12) continue; s1 += n; s2 += n * n; }
  return s1 ? s2 / s1 : 0;
}
// the curves, computed once: φ for the wall on screen, ξ averaged over AVG walls; the threshold is where ξ peaks
const WALL = makeWall(SEED), NB = new Float32Array(N * 3);
const PHI = new Float32Array(K), XI = new Float32Array(K);
{ const walls = Array.from({ length: AVG }, (_, k) => makeWall(1000 + k));
  for (let k = 0; k < K; k++) { const s = k / (K - 1); PHI[k] = orderPhi(normals(WALL, s, NB)); let x = 0; for (const w of walls) x += clusterXi(w, s); XI[k] = x / AVG; }
  const raw = XI.slice(); for (let k = 0; k < K; k++) { let a = 0, n = 0; for (let j = -3; j <= 3; j++) { const i = k + j; if (i < 0 || i >= K) continue; const w = 4 - Math.abs(j); a += raw[i] * w; n += w; } XI[k] = k === 0 ? 0 : a / n; }
  let m = 0; for (let k = 0; k < K; k++) m = Math.max(m, XI[k]); for (let k = 0; k < K; k++) XI[k] /= m || 1; }
const THR = (() => { let b = 0; for (let k = 1; k < K; k++) if (XI[k] > XI[b]) b = k; return b / (K - 1); })();
const at = (arr, s) => { const t = clamp(s) * (K - 1), i = Math.min(K - 2, Math.floor(t)), f = t - i; return arr[i] * (1 - f) + arr[i + 1] * f; };
const PHI_SAFE = at(PHI, THR * .6), PHI_UNSAFE = at(PHI, THR);   // the room's status follows the order left: safe above, unsafe past the threshold
const S_MAX = .86;

export function mountWall(section) {
  const cv = section.querySelector('.wall-cv'); if (!cv) return null;
  const x = cv.getContext('2d'), RM = matchMedia('(prefers-reduced-motion: reduce)').matches;
  const css = getComputedStyle(document.documentElement), V = (k, d) => (css.getPropertyValue(k) || d).trim() || d;
  const COL = { ink: V('--ink', '#1E2140'), paper: V('--paper', '#F3EEF2'), haze: V('--haze', '#8F8CC4'), mist: V('--mist', '#DCE4EE'), rose: V('--rose', '#EFB1B4'),
    apricot: V('--apricot', '#F6D2B1'), signal: V('--signal', '#7FD4CF'), heat: V('--heat', '#FFC36B'), danger: V('--danger', '#F08A7E') };
  const rgba = (hex, a) => { const h = hex.replace('#', ''), n = parseInt(h.length === 3 ? h.split('').map((c) => c + c).join('') : h, 16); return `rgba(${(n >> 16) & 255},${(n >> 8) & 255},${n & 255},${a})`; };
  let Wd = 0, Ht = 0, dpr = 1, p = RM ? 1 : 0, shown = -1, raf = 0, on = false, last = 0;
  const st = { p: 0, stress: 0, phi: 1, xi: 0, status: 'safe' };
  // the layout: wall and curves side by side; on a narrow figure (a phone) the wall on top and the curves under it
  const lay = (w) => { const statusH = 30;
    if (w >= 470) { const h = Math.round(clamp(w * .56, 214, 330)), top = 20, bottom = h - statusH - 8, ww = w * .56;
      return { stack: false, h, top, bottom, ps: Math.min((ww - 22) / C, (bottom - top - 44) / R), gx: w * .62, gT: top + 18, gB: bottom - 14, statusH }; }
    const top = 16, ps = Math.min((w - 16) / C, 18), gy = top + 10 + ps * R, gT = gy + 44, gB = gT + 80;
    return { stack: true, h: Math.round(gB + 24 + statusH + 4), top, bottom: gB, ps, gx: 8, gT, gB, statusH }; };
  function size() {
    const par = cv.parentElement, pc = getComputedStyle(par), w = Math.max(240, Math.floor(par.clientWidth - parseFloat(pc.paddingLeft) - parseFloat(pc.paddingRight))), h = lay(w).h;
    dpr = Math.min(2, devicePixelRatio || 1);
    if (w !== Wd || h !== Ht) { Wd = w; Ht = h; cv.width = w * dpr; cv.height = h * dpr; cv.style.width = w + 'px'; cv.style.height = h + 'px'; shown = -1; }
  }
  const target = () => { if (RM) return 1; const r = section.getBoundingClientRect();
    if (r.height > innerHeight * 1.3) return clamp(-r.top / (r.height - innerHeight));                   // the sticky panel: progress through the section
    const f = cv.getBoundingClientRect(); return clamp((innerHeight * .9 - f.top) / (innerHeight * .75)); };  // a short screen: the figure's own way up the screen
  const stressOf = (q) => S_MAX * clamp((q - .12) / .72);
  function draw() {
    const stress = stressOf(p), small = Wd < 470, fs = small ? 11 : 12;
    normals(WALL, stress, NB); const phi = orderPhi(NB), xi = at(XI, stress);
    const status = phi >= PHI_SAFE ? 'safe' : phi > PHI_UNSAFE ? 'restricted' : 'unsafe';
    Object.assign(st, { p, stress, phi, xi, status });
    x.setTransform(dpr, 0, 0, dpr, 0, 0); x.clearRect(0, 0, Wd, Ht);
    x.textBaseline = 'alphabetic'; x.lineCap = 'round'; x.lineJoin = 'round';
    const font = (w, s, f = 'Geist') => `${w} ${s}px ${f}, ui-sans-serif, system-ui, sans-serif`;
    const Lo = lay(Wd), { statusH, top, ps } = Lo;
    // ---- the wall (left, or on top)
    const wW = ps * C, wH = ps * R, wx = 6, wy = top + 10, gy = wy + wH;
    x.font = font(500, fs); x.fillStyle = rgba(COL.mist, .75); x.fillText('One wall', wx, top);
    let ms = 0; for (let i = 0; i < N; i++) ms += sev(stress, WALL.str[i]); ms /= N;
    x.strokeStyle = rgba(COL.haze, .5); x.lineWidth = 1; x.beginPath(); x.moveTo(wx - 4, gy + .5); x.lineTo(wx + wW + 8, gy + .5); x.stroke();   // ground
    x.save(); x.translate(wx, gy); x.rotate(-.06 * ms); x.translate(-wx, -gy);   // the wall leans a little as damage grows
    for (let r = 0; r < R; r++) for (let c = 0; c < C; c++) { const i = r * C + c, s = sev(stress, WALL.str[i]);
      x.fillStyle = s > 0 ? rgba(COL.rose, .14 + .42 * s) : rgba(COL.mist, .055); x.fillRect(wx + c * ps + .5, wy + r * ps + .5, ps - 1, ps - 1); }
    x.strokeStyle = rgba(COL.mist, .32); x.lineWidth = 1; x.strokeRect(wx + .5, wy + .5, wW - 1, wH - 1);
    const L = ps * .6;
    for (let r = 0; r < R; r++) for (let c = 0; c < C; c++) { const i = r * C + c, s = sev(stress, WALL.str[i]);
      const cx = wx + (c + .5) * ps - L * .25, cy = wy + (r + .5) * ps + L * .18, nx = NB[i * 3], ny = NB[i * 3 + 1], nz = NB[i * 3 + 2];
      const tx = cx + L * (nx + nz * .62), ty = cy - L * (ny + nz * .42);   // the normal, drawn in a light oblique view: straight out of the wall = up and right
      x.strokeStyle = s > .02 ? COL.rose : COL.signal; x.lineWidth = small ? 1.4 : 1.6; x.beginPath(); x.moveTo(cx, cy); x.lineTo(tx, ty); x.stroke();
      x.fillStyle = s > .02 ? COL.rose : COL.signal; x.beginPath(); x.arc(tx, ty, small ? 1.4 : 1.7, 0, 7); x.fill(); }
    x.restore();
    const word = stress < .02 ? 'baseline: all one way' : status === 'unsafe' ? 'past the threshold' : 'damage spreading';
    x.font = font(500, fs, 'Geist Mono'); x.fillStyle = COL.signal; const ro = `φ wall ${phi.toFixed(2)}`; x.fillText(ro, wx, gy + (small ? 17 : 20));
    const rw = x.measureText(ro).width; x.font = font(400, fs); x.fillStyle = rgba(COL.mist, .72); x.fillText(word, wx + rw + 8, gy + (small ? 17 : 20));
    // ---- the curves (right): φ falls, ξ peaks at the threshold
    const { gx, gT, gB } = Lo, gw = Wd - gx - 6, gh = gB - gT;
    const X = (s) => gx + s * gw, Y = (v) => gB - v * gh * .92;
    x.strokeStyle = rgba(COL.haze, .55); x.lineWidth = 1; x.beginPath(); x.moveTo(gx + .5, gT - 6); x.lineTo(gx + .5, gB + .5); x.lineTo(gx + gw, gB + .5); x.stroke();
    x.setLineDash([3, 4]); x.strokeStyle = rgba(COL.mist, .4); x.beginPath(); x.moveTo(X(THR), gT - 4); x.lineTo(X(THR), gB); x.stroke(); x.setLineDash([]);
    x.font = font(400, fs - 1); x.fillStyle = rgba(COL.mist, .7); x.textAlign = 'center'; x.fillText('threshold', clamp(X(THR), gx + 26, gx + gw - 26), gT - 8); x.textAlign = 'left';
    const curve = (arr, col, upto) => { x.strokeStyle = col; x.lineWidth = 2; x.beginPath(); for (let k = 0; k < K; k++) { const s = k / (K - 1); if (s > upto) break; const X1 = X(s), Y1 = Y(arr[k]); k ? x.lineTo(X1, Y1) : x.moveTo(X1, Y1); } x.stroke(); };
    curve(PHI, rgba(COL.signal, .28), 1); curve(XI, rgba(COL.apricot, .28), 1);   // the whole run, faint
    curve(PHI, COL.signal, stress); curve(XI, COL.apricot, stress);               // up to now, bright
    x.strokeStyle = rgba(COL.paper, .45); x.lineWidth = 1; x.beginPath(); x.moveTo(X(stress) + .5, gT); x.lineTo(X(stress) + .5, gB); x.stroke();
    for (const [v, col] of [[at(PHI, stress), COL.signal], [xi, COL.apricot]]) { x.fillStyle = col; x.beginPath(); x.arc(X(stress), Y(v), 3.5, 0, 7); x.fill(); }
    x.font = font(500, fs); x.fillStyle = COL.signal; x.fillText('φ order', gx + 6, Y(1) - 7);
    x.fillStyle = COL.apricot; const xl = 'ξ range', xlw = x.measureText(xl).width; x.fillText(xl, clamp(X(THR + .2), gx + 6, gx + gw - xlw), Y(.2));
    x.font = font(400, fs - 1); x.fillStyle = rgba(COL.mist, .7); x.textAlign = 'right'; x.fillText('stress →', gx + gw, gB + (small ? 13 : 15)); x.textAlign = 'left';
    // ---- the room's status
    const chips = [['safe', 'Safe', COL.signal], ['restricted', 'Restricted', COL.heat], ['unsafe', 'Unsafe', COL.danger]];
    let cx = wx; const cy = Ht - statusH + 2, chH = small ? 22 : 24;
    x.font = font(400, fs); x.fillStyle = rgba(COL.mist, .72); x.fillText('Room', cx, cy + chH * .68); cx += x.measureText('Room').width + 10;
    x.font = font(600, fs);
    for (const [k, label, col] of chips) { const w = x.measureText(label).width + 20, act = k === status;
      x.beginPath(); x.roundRect(cx, cy, w, chH, chH / 2);
      if (act) { x.fillStyle = col; x.fill(); } else { x.strokeStyle = rgba(col, .45); x.lineWidth = 1; x.stroke(); }
      x.fillStyle = act ? COL.ink : rgba(col, .6); x.fillText(label, cx + 10, cy + chH * .68); cx += w + 8; }
    if (status !== 'safe') { x.font = font(400, fs); x.fillStyle = rgba(COL.mist, .72); x.fillText('← was safe', cx + 2, cy + chH * .68); }
  }
  function frame(t) {
    raf = on ? requestAnimationFrame(frame) : 0;
    const dt = Math.min(.1, (t - (last || t)) / 1000); last = t;
    const tg = target(); p = RM ? 1 : p + (tg - p) * (1 - Math.exp(-dt * 7)); if (Math.abs(tg - p) < .0008) p = tg;
    if (Math.abs(p - shown) > .0004) { shown = p; draw(); }
  }
  const go = (v) => { on = v; if (on && !raf) { last = 0; raf = requestAnimationFrame(frame); } };
  new IntersectionObserver((es) => { for (const e of es) go(e.isIntersecting); }, { rootMargin: '20% 0px 20% 0px' }).observe(section);
  new ResizeObserver(() => { size(); shown = -1; if (!on) draw(); }).observe(cv.parentElement);
  size();
  if (document.fonts && document.fonts.ready) document.fonts.ready.then(() => { shown = -1; if (!on) draw(); });
  const api = { get state() { return { ...st, threshold: THR }; }, redraw() { shown = -1; draw(); } };
  section.__wall = api; draw();
  return api;
}
